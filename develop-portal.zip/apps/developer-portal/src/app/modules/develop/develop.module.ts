import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { CaSidebarModule, CaTooltipModule } from '@global-front-components/ui';
import { DevelopRoutingModule } from './develop-routing.module';
import { DevelopView } from './develop.view';
@NgModule({
  imports: [
    CaTooltipModule,
    CommonModule,
    HttpClientModule,
    DevelopRoutingModule,
    CaSidebarModule
  ],
  declarations: [
    DevelopView
  ],
  providers: []
})
export class DevelopModule {}
