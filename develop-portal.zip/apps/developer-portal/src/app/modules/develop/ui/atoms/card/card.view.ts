import { Component } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
  templateUrl: 'card.view.html',
  styleUrls: ['card.view.scss']
})
export class CardView {
  constructor() {}

  importModule = `import { CaCardModule } from '@global-front-components/ui';`;

  caseOneContent: ComponentDoc = {
    title: `Uso básico`,
    description: `Uso de los diferentes tipos de componente <code class="tag">ca-card</code>`,
    codeExample: {
      html: `<div class="my-2 mb-4">
  <div class="container">
    <div class="row mb-4">
      <div class="col-sm">
        <ca-card>
          <div ca-card-title>Tarjeta por defecto</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia? De
            apocalypsi gorger omero undead
          </div>
        </ca-card>
      </div>
      <div class="col-sm">
        <ca-card primary>
          <div ca-card-title>Tarjeta Primary</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia? De
            apocalypsi gorger omero undead
          </div>
        </ca-card>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row mb-4">
      <div class="col-sm">
        <ca-card secondary>
          <div ca-card-title>Tarjeta por Secondary</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia? De
            apocalypsi gorger omero undead
          </div>
        </ca-card>
      </div>
      <div class="col-sm">
        <ca-card ui-1>
          <div ca-card-title>Tarjeta UI-1</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia? De
            apocalypsi gorger omero undead
          </div>
        </ca-card>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row mb-4">
      <div class="col-sm">
        <ca-card ui-2>
          <div ca-card-title>Tarjeta UI-2</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia? De
            apocalypsi gorger omero undead
          </div>
        </ca-card>
      </div>
      <div class="col-sm">
        <ca-card ui-3>
          <div ca-card-title>Tarjeta UI-3</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia? De
            apocalypsi gorger omero undead
          </div>
        </ca-card>
      </div>
    </div>
  </div>
</div>`
    }
  }

  caseTwoContent: ComponentDoc = {
    title: `Card con header y footer`,
    description: `Ejemplo de <code class="tag">ca-card</code> con un header <code class="attribute">ca-card-header</code> y un footer <code class="attribute">ca-card-footer</code>.`,
    codeExample: {
      html: `<div class="my-2 mb-4">
  <div class="container">
    <div class="row mb-4">
      <div class="col-sm">
        <ca-card primary>
          <h4 ca-card-header class="ca-card-header">
            Header
          </h4>
          <div ca-card-title>Tarjeta con primary</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains
            sit​​, morbo vel maleficia? De apocalypsi gorger omero undead
          </div>
          <div ca-card-footer class="ca-card-footer">
            <a class="link" href="url">LEER MÁS</a>
          </div>
        </ca-card>
      </div>
      <div class="col-sm">
        <ca-card secondary>
          <h4 ca-card-header class="ca-card-header">
            Header
          </h4>
          <div ca-card-title>Tarjeta con secondary</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains
            sit​​, morbo vel maleficia? De apocalypsi gorger omero undead
          </div>
          <div ca-card-footer class="ca-card-footer">
            <a class="link" href="url">LEER MÁS</a>
          </div>
        </ca-card>
      </div>
    </div>
  </div>
</div>`
    }
  }

  caseThreeContent: ComponentDoc = {
    title: `Cards con contenido multimedía`,
    description: `Ejmplo de <code class="tag">ca-card</code> con contenido multimedía. Para ellos usaremos los atributos <code class="attribute">card-media-up</code>,
    <code class="attribute">card-media-down</code>, <code class="attribute">card-media-left</code> y <code class="attribute">card-media-right</code>`,
    codeExample: {
      html: `<div class="my-2 mb-4">
  <div class="container">
    <div class="row mb-4">
      <div class="col-sm">
        <ca-card primary class="card-media-up">
          <div ca-card-title>Tarjeta con imagen arriba</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia? De
            apocalypsi gorger omero undead
          </div>
          <div ca-card-media>
            <img src="../../../../../../../assets/images/examples/image-card.png" alt="corporative image" />
          </div>
        </ca-card>
      </div>
      <div class="col-sm">
        <ca-card secondary class="card-media-down">
          <div ca-card-title>Tarjeta con imagen abajo</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia? De
            apocalypsi gorger omero undead
          </div>
          <div ca-card-media>
            <img src="../../../../../../../assets/images/examples/image-card.png" alt="corporative image" />
          </div>
        </ca-card>
      </div>
    </div>
  </div>
</div>
<div class="my-2 mb-4">
  <div class="container">
    <div class="row mb-4">
      <div class="col-sm">
        <ca-card ui-1 class="card-media-up">
          <div ca-card-title>Tarjeta con vídeo arriba</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia? De
            apocalypsi gorger omero undead
          </div>
          <div ca-card-media>
            <iframe
              width="100%"
              height="100%"
              src="https://www.youtube.com/embed/kWNAq3i_SQ8"
              frameborder="0"
              allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen
            ></iframe>
          </div>
        </ca-card>
      </div>
      <div class="col-sm">
        <ca-card ui-2 class="card-media-down">
          <div ca-card-title>Tarjeta con vídeo abajo</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia? De
            apocalypsi gorger omero undead
          </div>
          <div ca-card-media>
            <iframe
              width="100%"
              height="100%"
              src="https://www.youtube.com/embed/dQw4w9WgXcQ"
              frameborder="0"
              allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen
            ></iframe>
          </div>
        </ca-card>
      </div>
    </div>
  </div>
</div>
<div class="my-2 mb-4">
  <div class="container">
    <div class="row mb-4">
      <div class="w100 mb-4">
        <ca-card primary class="card-media-left">
          <div ca-card-title>Tarjeta con imagen izquierda</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia? De
            apocalypsi gorger omero undead
          </div>
          <div ca-card-media>
            <img src="../../../../../../../assets/images/examples/image-card.png" alt="corporative image" />
          </div>
        </ca-card>
      </div>
      <div class="w100">
        <ca-card secondary class="card-media-right">
          <div ca-card-title>Tarjeta con imagen derecha</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia? De
            apocalypsi gorger omero undead
          </div>
          <div ca-card-media>
            <img src="../../../../../../../assets/images/examples/image-card.png" alt="corporative image" />
          </div>
        </ca-card>
      </div>
    </div>
  </div>
</div>
<div class="my-2 mb-4">
  <div class="container">
    <div class="row mb-4">
      <div class="w100 mb-4">
        <ca-card ui-1 class="card-media-left">
          <div ca-card-title>Tarjeta con vídeo izquierda</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia.De apocalypsi
            gorger omero undead survivor dictum mauris. Hi mindless mortuis soulless creaturas. De carne
            lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia.De apocalypsi gorger
            omero undead survivor dictum mauris.
          </div>
          <div ca-card-media>
            <iframe
              width="100%"
              height="100%"
              src="https://www.youtube.com/embed/dQw4w9WgXcQ"
              frameborder="0"
              allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen
            ></iframe>
          </div>
        </ca-card>
      </div>
      <div class="w100">
        <ca-card ui-2 class="card-media-right">
          <div ca-card-title>Tarjeta con vídeo derecha</div>
          <div ca-card-content>
            De carne lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia.De apocalypsi
            gorger omero undead survivor dictum mauris. Hi mindless mortuis soulless creaturas. De carne
            lumbering animata corpora quaeritis. Summus brains sit​​, morbo vel maleficia.De apocalypsi gorger
            omero undead survivor dictum mauris.
          </div>
          <div ca-card-media>
            <iframe
              width="100%"
              height="100%"
              src="https://www.youtube.com/embed/dQw4w9WgXcQ"
              frameborder="0"
              allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen
            ></iframe>
          </div>
        </ca-card>
      </div>
    </div>
  </div>
</div>`
    }
  }
}
