import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './extensions.view.html',
  styleUrls: ['./extensions.view.scss']
})
export class ExtensionsView implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
