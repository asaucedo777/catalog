import { Component } from '@angular/core';

@Component({
  templateUrl: 'provinces-service.view.html',
  styleUrls: ['provinces-service.view.scss']
})
export class ProvincesServiceView {
  moduleContent = `
  import { CaProvincesService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaProvincesService ],
    ...
  })`;
}
