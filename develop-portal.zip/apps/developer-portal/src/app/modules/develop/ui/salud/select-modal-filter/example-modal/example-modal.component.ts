import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CaFilterPipe } from '@global-front-components/common';
import { CaModalOverlayRef } from '@global-front-components/ui';
import { BehaviorSubject, Subject } from 'rxjs';
import { debounceTime, takeUntil } from 'rxjs/operators';
interface TableColumn {
	id: number;
	field: string;
	value: string;
}

@Component({
	templateUrl: './example-modal.component.html',
	styleUrls: ['./example-modal.component.scss'],
	providers: [ CaFilterPipe ]
})
export class ExampleModalComponent implements OnInit {
	constructor(
		private _formBuilder: FormBuilder,
		private _caModalOverlayRef: CaModalOverlayRef<ExampleModalComponent>,
		private _caFilterPipe: CaFilterPipe,
    	private _changeDetectorRef: ChangeDetectorRef
	) {}
	private _destroy$: Subject<void> = new Subject();
	private _filterChange$: BehaviorSubject<string> = new BehaviorSubject(undefined);
	public form: FormGroup;
	displayedColumns: string[] = [];
	displayedTableData: any[] = [];
	queryFilter = '';
	selectedRow: any;
	queryFilterNIF = '';
	queryFilterSalePoint = '';
	columns: TableColumn[] = [
		{
			id: 0,
			field: 'selectable',
			value: ''
		},
		{
			id: 0,
			field: 'code',
			value: 'Código'
		},
		{
			id: 1,
			field: 'salePoint',
			value: 'Descripción'
		}
	];

	tableData = [
		{
			code: 1,
			salePoint: '33300100 - Punto de venta 1'
		},
		{
			code: 2,
			salePoint: '33300101 - Punto de venta 2'
		},
		{
			code: 3,
			salePoint: 'Punto de venta 3'
		}
	];

	private _setDisplayedColumns(): void {
		this.displayedColumns = this.columns.map((column) => column.field);
	}

	isSelectedRow(row): boolean {
		return this.selectedRow && Object.keys(this.selectedRow).every((key) => this.selectedRow[key] === row[key]);
	  }

	onSelectedRow(row: any): void {
		if (!this.isSelectedRow(row)) {
			this.selectedRow = row;
		}
	}

	onFilter(query: string): void {
		this._filterChange$.next(query);
	}

	closeDialog(): void {
		if(this.selectedRow){
			const arrayData = this.mapTableData([this.selectedRow]) ;
			this._caModalOverlayRef.close(arrayData);
		} else {
			const arrayData = this.mapTableData(this.tableData);
			this._caModalOverlayRef.close(arrayData);
		}

	}

	mapTableData(tableData){
		const arrayData = tableData.map(function(row) {
			return { value : row.code, textValue : row.salePoint }
		 });
		return arrayData;
	}

	ngOnInit() {
		this._setDisplayedColumns();
    	this.displayedTableData= this.tableData;
    	this._filterChange$.pipe(takeUntil(this._destroy$),debounceTime(200)).subscribe((value) => {
      	this.displayedTableData = this._caFilterPipe.transform(this.tableData, value);
      	this._changeDetectorRef.markForCheck();
    })
	}
	ngOnDestroy() {
		this._destroy$.next();
		this._destroy$.complete();
	}
}
