import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CaSnackbarService } from '@global-front-components/ui';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: 'snackbar.view.html',
	styleUrls: ['snackbar.view.scss']
})
export class SnackbarView implements OnInit {
	constructor(private _snackbarService: CaSnackbarService, private formBuilder: FormBuilder) {}
	form: FormGroup;
  moduleContent = `import { CaSnackbarModule } from '@global-front-components/ui';`;
  actionSelected: string

	caseBasic: ComponentDoc = {
		title: 'Uso del Sanckbar',
		description: `<p>El lanzamiento de Snackbar lo haremos de manera programática. Para poder lanzarlo, no solo desde un componente, sino tambien desde cualquier servicio o incluso desde un interceptor </p>
                  <P>para ello injectaremos el servicio <code class="directive">SnackbarService</code> en el constructor de la clase desde donde queramos lanzarlo y llamaremos al metodo <code class="directive">.open()</code> pasandole  como parametro un objecto de tipo <code class="directive">SnackbarConfig</code> el cual debe contener como mínimo el mensaje que mostrará el snackbar</P>
                  <p>Para conocer mas detalle sobre los attributos de dicho objeto vaya a la pestaña API</p>
                  <p>El servicio dispone de un  Observable público <code class="directive">close$</code>, al cual podemos subscribirnos, para escuchar cuando el el snackbar es cerrado por una acción del usuario, este observable emitirá un string con el valor de la acción que haya seleccionado el usuario, o undefined si se cerro mediante el aspa de cierre</p>`,
		codeExample: {
			ts: `
      import { CaSnackbarService, CaSnackbarConfig } from '@global-front-components/ui';
      export Class MyComponent implements OnInit {
        constructor(private _snackbarService: CaSnackbarService) { }

        private _sanckbarConfig: SnackbarConfig {
          message: 'texto que mostrará el snackbar //requerido
          actions: ['deshacer', 'visualizar'],
          sticky: false,
          timer: 700
        }

        openSnackbar(): void {
          this._snackbarService.open(this._sanckbarConfig);
        }

        ngOnInit(){
          this._snackbarService.closed$.subscribe(value => {
            // funcionalidad que se lanzará al cerrar la pestaña mediante acción del usuario
          });

        }

      }
      `
		}
	};

	ngOnInit(): void {
		this.form = this.formBuilder.group({
			message: ['', Validators.required],
      actions: this.formBuilder.array(['', '']),
      timer: [undefined],
      sticky: [false]
    });
    this.form.get('sticky').valueChanges.subscribe((value) => {
      if(value){
        this.form.get('timer').disable();
      }else{
        this.form.get('timer').enable();
      }
    })
		this._snackbarService.closed$.subscribe((value) => {
      this.actionSelected = value
    });
  }

  get actions(): FormArray {
    return this.form.get("actions") as FormArray
  }

  disbledTimer(): boolean {
    return this.form.get('sticky').value
  }

	launchSnackbar() {
		if (this.form.valid) {
			this._snackbarService.open(this.form.value);
		}
	}
}
