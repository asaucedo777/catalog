import { Component, OnInit } from '@angular/core';
import { CaRoadTypeService } from '@global-front-components/common';
import {
  RoadType,
  RoadTypeRequest,
  RoadTypeResponse,
} from '@global-front-components/common/lib/models/road-type.interfaces';
import { combineLatest, Observable, of } from 'rxjs';
import {
  catchError,
  debounceTime,
  distinctUntilChanged,
  map,
  switchMap,
} from 'rxjs/operators';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { ROAD_TYPES_RESPONSE_MOCK } from './_mock_/road-types-list.response';

@Component({
  templateUrl: 'road-type.view.html',
  styleUrls: ['road-type.view.scss'],
})
export class RoadTypeView implements OnInit {
  constructor(private _CaRoadTypeService: CaRoadTypeService) {}
  roadTypes: RoadType[];
  roadType: RoadType;
  roadTypeFound: RoadType;
  selectedReadType: RoadType;

  caseRoadTypeSelect: ComponentDoc = {
    title: 'Componente Seleccionable de Tipo de Vias',
    description: `
    `,
    codeExample: {
      html: `
      <ca-form-field>
        <ca-select
          placeholder="Seleccione su tipo de via"
          keyValue="valor"
          [options]="roadTypes"
          [(ngModel)]="selectedRoadType"
        ></ca-select>
        <pre class="mt-2" *ngIf="selectedRoadType">
          {{ selectedRoadType | json }}
        </pre>
      </ca-form-field>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { RoadType, RoadTypeRequest, RoadTypeResponse, CaRoadTypeService } from '@global-front-components/common';

      @Component({
        selector: 'road-type-select-example',
        templateUrl: 'road-type-select-example.component.html',
        styleUrls: ['road-type-select-example.component.scss']
      })

      export class RoadTypeSelectExampleComponent implements OnInit {
        constructor( private _caRoadTypeService: CaRoadTypeService ) { }

        ListRoadTypes: RoadType[];
        selectedRoadTypes: RoadType;

        ngOnInit() {
          const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
          const request: RoadTypeRequest = {
            serviceId: 'CtaTiposViaBDI',
          }
          this._caRoadTypeService.getRoadType(endpoint, request).subscribe((response: RoadTypeResponse) => {
            this.ListRoadTypes = response.outputMap.lista;
          })
        }
      }`,
    },
  };

  codeRoadTypeahead: ComponentDoc = {
    title: 'Componente Predictivo de Tipo de Vias',
    description: `Hay dos formas de emplear este componente predictivo. Por un lado se puede hacer una única llamada al servicio de tipos de vías que nos devuelva toda la lista y filtrar a través del componente,
      o bien, llamar al servicio cada vez que el usuario introduce un valor en el <code class="tag">input</code>.
      <br />
      Primeramente se describe como implementarlo con una única llamada incial.`,
    codeExample: {
      html: `
        <ca-form-field>
          <ca-label>Tipos de vias</ca-label>
          <input
            type="text"
            placeholder="Busque un tipo de via"
            [caTypeahead]="search"
            [inputFormatter]="roadTypeFormatter"
            [(ngModel)]="roadType"
          />
        </ca-form-field>
        <pre class="mt-2" *ngIf="roadType">
          {{ roadType | json }}
        </pre>`,
      ts: `
        import { Component, OnInit } from '@angular/core';
        import { Observable } from 'rxjs';
        import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
        import { RoadType, RoadTypeRequest, RoadTypeResponse, CaRoadTypeService } from '@global-front-components/common';

        @Component({
          selector: 'road-type-typeahead-example',
          templateUrl: 'road-type-typeahead-example.component.html',
          styleUrls: ['road-type-typeahead-example.component.scss']
        })

        export class RoadTypeTypeaheadExampleComponent implements OnInit {
          constructor( private _caRoadTypeService: CaRoadTypeService ) { }

          roadTypes: RoadType[];
          roadType: RoadType;

          roadTypeFormatter = (x:{valor: string}) => x.valor;

          search = (text$: Observable<string>) =>
            text$.pipe(
              debounceTime(300),
              distinctUntilChanged(),
              map(term => term === '' ? []
                : this.roadTypes.filter(v => v.valor.toLowerCase().indexOf(term.toLowerCase()) > -1))
            )

          ngOnInit() {
            const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
            const request: RoadTypeRequest = {
              serviceId: 'CtaTiposViaBDI',
            }
            this._caRoadTypeService.getRoadType(endpoint, request).subscribe((response: RoadTypeResponse) => {
              this.roadTypes = response.outputMap.lista;
            })
          }
        }`,
    },
  };

  codeRoadTypeTypeaheadService: ComponentDoc = {
    description: `A continuación se describe como implementarlo con llamadas al servicio cuando el usuario interactúe.`,
    codeExample: {
      html: `
        <ca-form-field>
          <ca-label>Tipo de Vias</ca-label>
          <input
            type="text"
            placeholder="Busque un tipo de via"
            [caTypeahead]="searchRoadType"
            [inputFormatter]="roadTypeFormatter"
            [(ngModel)]="roadTypeFound"
          />
        </ca-form-field>
        <pre class="mt-2" *ngIf="roadTypeFound">
          {{ roadTypeFound | json }}
        </pre>`,
      ts: `
        import { Component } from '@angular/core';
        import { Observable } from 'rxjs';
        import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
        import { RoadType, RoadTypeRequest, RoadTypeResponse, CaRoadTypeService } from '@global-front-components/common';

        @Component({
          selector: 'road-type-typeahead-example',
          templateUrl: 'road-type-typeahead-example.component.html',
          styleUrls: ['road-type-typeahead-example.component.scss']
        })

        export class RoadTypeTypeaheadExampleComponent {
          constructor( private _caRoadTypeService: CaRoadTypeService ) { }

          roadTypeFound: RoadType;

          roadTypeFormatter = (x:{denCia: string}) => x.denCia;

          searchRoadType = (text$: Observable<string>) =>
            text$.pipe(
              debounceTime(300),
              distinctUntilChanged(),
              switchMap(term => {
                const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
                const request: RoadTypeRequest = {
                  serviceId: 'CtaTiposViaBDI',
                }
                return this._caRoadTypeService.getRoadType(endpoint, request)
              })
              ).pipe(map((response: RoadTypeResponse) => response.outputMap.lista)
            );
        }`,
    },
  };

  roadTypeFormatter = (x: { valor: string }) => x.valor;

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      map((term) =>
        term === ''
          ? []
          : this.roadTypes.filter(
              (v) => v.valor.toLowerCase().indexOf(term.toLowerCase()) > -1
            )
      )
    );

  searchRoadType = (text$: Observable<string>) =>
    text$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((term) => {
          const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
          const request: RoadTypeRequest = {
            serviceId: 'CtaTiposViaBDI',
          };
          return combineLatest([
            this._getRoadTypeMock(endpoint, request),
            of(term),
          ]);
        })
      )
      .pipe(
        map(([response, term]) =>
          term === ''
            ? []
            : this.roadTypes.filter(
                (v) => v.valor.toLowerCase().indexOf(term.toLowerCase()) > -1
              )
        )
      );

  private _getRoadTypeMock(
    endpoint: string,
    request: RoadTypeRequest
  ): Observable<RoadTypeResponse> {
    return this._CaRoadTypeService.getRoadType(endpoint, request).pipe(
      catchError(() => {
        return of(<RoadTypeResponse>ROAD_TYPES_RESPONSE_MOCK);
      })
    );
  }

  ngOnInit() {
    const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
    const request: RoadTypeRequest = {
      serviceId: 'CtaTiposViaBDI',
    };
    this._getRoadTypeMock(endpoint, request).subscribe(
      (response: RoadTypeResponse) => {
        this.roadTypes = response.outputMap.lista;
      }
    );
  }
}
