import { Component } from '@angular/core';

@Component({
  templateUrl: 'flex.view.html'
})
export class FlexView {

  columnClassList = [
    {type: 'flex', title: 'Flex', listItem: [
      {className: 'ca-flex', description: 'Contenedor con un ancho predefinido de 1250px'},
      {className: 'ca-container-fluid', description: 'Contenedor con un ancho del 100%'},
      {className: 'ca-row', description: 'Clase predefinida para ser utilizadas con columnas'},
      {className: 'ca-no-gutters', description: 'Clase predefinida para eliminar los margenes y paddings'}
    ]}
  ];

}