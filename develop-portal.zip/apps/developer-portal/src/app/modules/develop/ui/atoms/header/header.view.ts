import { Component, OnInit } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: './header.view.html',
	styleUrls: ['./header.view.scss']
})
export class HeaderView implements OnInit {
  moduleContent = `import { CaHeaderModule } from '@global-front-components/ui';`;
	srcLogo = './assets/images/logo.png';
	version = 'Test';
	menu = [
		{
      title: 'Item 1',

    },
		{
      title: 'item 2',

		},
		{
			title: 'Item 3',

		}
	];

  caseBasic: ComponentDoc = {
    title: 'Uso de Header',
    description: `
    <p>para incluir esta cabecera en nuestra aplicación tan sólo hemos de añadir la etiqueta  <code class="tag">ca-header</code> y  pasarle la ruta del logo a traves del input  <code class="attribute">srcLogo</code></p>
    <p>adiccionalmente podemos incicarle la versión de nuestra aplicación mediante el input <code class="tag">versionTag</code>, la cual se mostrará al lado del logo, tal y cómo vemos en el ejemplo </p>`,
    codeExample: {
      ts: ``,
      html: `<ca-header srcLogo="/path/to/image-logo" versionTag="yourVersion"></ca-header>`
    }
  };

  caseContent: ComponentDoc = {
    title: 'Transclusión de contenido',
    description: `
    <p>Para insertar un menu de navegación o botones de acciones a la cabecera, utilizaremos la transclusión de contenidos de Angular. para ello añadiremos los elementos dentro de la etiqueta <code class="tag">ca-header</code> y le añadiremos las clases <code >ca-header__nav</code> para el menu y <code >ca-header__action</code> a acada uno de los botones de accion.</p>
    `,
    codeExample: {
      ts: `	srcLogo = './assets/images/logo.png';
      version = 'Test';
      menu = [
        {
          title: 'Item 1',

        },
        {
          title: 'item 2',

        },
        {
          title: 'Item 3',

        }
      ];`,
      html: `	<ca-header [srcLogo]="srcLogo" versionTag="Test">
      <ul class="ca-header__nav">
        <ng-container *ngFor="let app of menu">
          <li >{{ app.title }}</li>
        </ng-container>
      </ul>

      <div class="ca-header__action">
        <button class="button__icon" ca-button-icon>
          <span caTooltipDialogPosition="center" caTooltipPosition="below" class="material-icons">star</span>
        </button>
      </div>
      <div class="ca-header__action">
        <button class="button__user">
          <span class="material-icons">account_circle</span>
          <span class="name">UserName</span>
        </button>
      </div>
    </ca-header>`,
    css: `
    .ca-header__nav {
      list-style: none;
      li {
        display: inline-block;

        margin-right: 44px;
        cursor: pointer;
        &:first-child {
          margin-left: 51px;
        }
      }
    }

    .ca-header__action {
      display: flex;
      align-items: center;
      height: 32px;
      &:first-child {
        margin-right: 18px;
      }
      .button__icon {
        min-width: 32px;
        height: 32px;
        &:hover,
        &:focus {
          background-color: rgba(0, 0, 0, 0.15);
        }
        .material-icons {
          color: #ffffff;
          cursor: pointer;
          font-size: 24px;
        }
      }
      .button__user {
        display: flex;
        height: 32px;
        background: inherit;
        border: none;
        color: #FFFFFF;
        align-items: center;
        span {
          margin-right: 8px;
          &:last-child {
            margin-right: 0px;
          }
          &.name {
            text-transform: uppercase;
            font-family: Lato;
            font-size: 18px;
          }
        }
        &:hover, &:focus {
          border-radius: 16px;
          background-color: #0c8c85;
        }
      }
    }
    `
    }
  };

	constructor() {}

	ngOnInit(): void {}
}
