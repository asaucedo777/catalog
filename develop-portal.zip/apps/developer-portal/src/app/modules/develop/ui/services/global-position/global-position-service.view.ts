import { Component } from '@angular/core';

@Component({
  templateUrl: 'global-position-service.view.html',
  styleUrls: ['global-position-service.view.scss']
})

export class GlobalPositionServiceView  {
  moduleContent = `
  import { CaGlobalPositionService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaGlobalPositionService ],
    ...
  })`;
}
