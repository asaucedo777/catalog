import { Component } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
  templateUrl: 'client-value.view.html',
  styleUrls: ['client-value.view.scss']
})
export class ClientValueView {
  importModule = `import { CaClientValueModule } from '@global-front-components/ui';`;

  caseSmall: ComponentDoc = {
    title: 'ClientValue con Tipo de cliente',
    description: `Si se desea visualizar sólo el tipo de cliente, sólo informaremos al componente de su <em>Input</em> <code>type</code>.
    Los tipos pueden ser <code>'Bronce'</code>, <code>'Plata'</code>, <code>'Oro'</code> y <code>'Platino</code>.`,
    codeExample: {
      html: `
    <div class="d-flex justify-content-between">
      <ca-client-value type="Bronce"></ca-client-value>
      <ca-client-value type="Plata"></ca-client-value>
      <ca-client-value type="Oro"></ca-client-value>
      <ca-client-value type="Platino"></ca-client-value>
    </div>`
    }
  }

  caseMedium: ComponentDoc = {
    title: 'ClientValue con Vinculación',
    description: `Si se desea visualizar el tipo de cliente y su vinculación, informaremos al componente a través de su <em>Input</em> <code>link</code>.`,
    codeExample: {
      html: `
    <div class="d-flex justify-content-between">
      <ca-client-value type="Bronce" link="BAJA"></ca-client-value>
      <ca-client-value type="Plata" link="MEDIA"></ca-client-value>
      <ca-client-value type="Oro" link="ALTA"></ca-client-value>
      <ca-client-value type="Platino" link="ALTA"></ca-client-value>
    </div>`
    }
  }

  caseLarge: ComponentDoc = {
    title: 'ClientValue con Número de pólizas',
    description: `Si se desea visualizar el tipo de cliente, su vinculación y el número de polizas contratadas, informaremos al componente a través de su <em>Input</em> <code>policiesNumber</code>.`,
    codeExample: {
      html: `
    <div class="d-flex justify-content-between">
      <ca-client-value type="Bronce" link="BAJA" policiesNumber="1"></ca-client-value>
      <ca-client-value type="Plata" link="MEDIA" policiesNumber="2"></ca-client-value>
      <ca-client-value type="Oro" link="ALTA" policiesNumber="3"></ca-client-value>
      <ca-client-value type="Platino" link="ALTA" policiesNumber="4"></ca-client-value>
    </div>`
    }
  }
}
