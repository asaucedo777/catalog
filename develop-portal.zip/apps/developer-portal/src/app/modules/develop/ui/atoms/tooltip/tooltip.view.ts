import { Component } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
@Component({
  templateUrl: 'tooltip.view.html',
  styleUrls: ['tooltip.view.scss']
})
export class TooltipView {

  isDisabled = true;

  text = 'Texto variable';

  importModule = `import { CaTooltipModule } from '@global-front-components/ui';`;

  caseSimple: ComponentDoc = {
    title: `Uso simple`,
    codeExample: {
      html: `<span caTooltip="Texto de prueba"> Haz hover aquí para ver el tooltip </span>`
    }
  }

  casePosition: ComponentDoc = {
    title: `Uso con diversas posiciones`,
    description: `Se puede posicionar el tooltip por encima (por defecto) o por debajo del elemento sobre el que se situa,
    mediante el atributo <code class="attribute">caTooltipPosition</code>.`,
    codeExample: {
      html: `<span caTooltip="Tooltip Inferior" caTooltipPosition="below">Hover para ver tooltip inferior</span>
<span caTooltip="Tooltip Superior" caTooltipPosition="above">Hover para ver tooltip superior</span>`
    }
  }

  caseDialogPosition: ComponentDoc = {
    title: `Uso con diversas posiciones de diálogo`,
    description: `Se puede cambiar la posición relativa del diálogo, que por defecto esta a la izquierda.
    Esto se realiza a través del atributo <code class="attribute">dialogPosition</code>.`,
    codeExample: {
      html: `<span caTooltip="Texto de prueba" caTooltipDialogPosition="left"> Tooltip superior izquierda </span>
<span caTooltip="Texto de prueba" caTooltipDialogPosition="center"> Tooltip superior centro </span>
<span caTooltip="Texto de prueba" caTooltipDialogPosition="right"> Tooltip superior derecha </span>
<span caTooltip="Texto de prueba" caTooltipPosition="below" caTooltipDialogPosition="left"> Tooltip inferior izquierda </span>
<span caTooltip="Texto de prueba" caTooltipPosition="below" caTooltipDialogPosition="center"> Tooltip inferior centro </span>
<span caTooltip="Texto de prueba" caTooltipPosition="below" caTooltipDialogPosition="right"> Tooltip inferior derecha </span>`
    }
  }

  caseDisabledPosition: ComponentDoc = {
    title: `Deshabilitar o habilitar del tooltip`,
    description: `Se puede deshabilitar el tooltip a traves del atributo <code class="attribute">disabled</code>. Por defecto es <em>false</em>.`,
    codeExample: {
      html:`<ca-checkbox [(ngModel)]="isDisabled">Deshabilitado</ca-checkbox>
<span caTooltip="Texto de prueba" [caTooltipDisabled]="isDisabled"> Haz hover aquí para ver el tooltip </span>`,
      ts: `import { Component } from '@angular/core';
@Component({
  selector: 'ca-example-view',
  templateUrl: './example-view.component.html',
  styleUrls: ['./example-view.component.scss']
})
export class ExampleViewComponent {
  isDisabled = true;
}`
    }
  }

  caseChangeText: ComponentDoc = {
    title: `Cambio dinámico del texto del tooltip`,
    description: `Podemos cambiar el contenido del texto del tooltip de manera dinámica, del siguiente modo:`,
    codeExample: {
      html: `<span [caTooltip]="text">
  Haz hover aquí para ver el tooltip
</span>
<ca-form-field>
  <ca-label>Contenido del tooltip variable</ca-label>
  <input caInput type="text"
    placeholder="Escribe el contenido del tooltip"
    (input)="changeTooltipText($event.target.value)"
  >
</ca-form-field>`,
      ts: `import { Component } from '@angular/core';
@Component({
  selector: 'ca-example-text',
  templateUrl: './example-text.component.html',
  styleUrls: ['./example-text.component.scss']
})
export class ExampleTextComponent {
  text = 'Texto variable';
  changeTooltipText(text: string): void {
    this.text = text;
  }
}`
    }
  }

  changeTooltipText(text: string): void {
    this.text = text;
  }
}
