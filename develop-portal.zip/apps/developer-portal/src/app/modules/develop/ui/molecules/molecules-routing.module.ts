import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MoleculesView } from './molecules.view';
import { AccordionView } from './accordion/accordion.view';
import { TransferView } from './transfer/transfer.view';
import { SidebarView } from './sidebar/sidebar.view';
import { MenuHeaderView } from './menu-header/menu-header.view';

const routes: Routes = [
	{
		path: '',
		component: MoleculesView,
		children: [
			{
				path: 'accordion',
				component: AccordionView
			},
      {
        path: 'menu-header',
        component: MenuHeaderView
      },
			{
				path: 'transfer',
				component: TransferView
			},
			{
				path: 'sidebar',
				component: SidebarView
			}
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class MoleculesRoutingModule {}
