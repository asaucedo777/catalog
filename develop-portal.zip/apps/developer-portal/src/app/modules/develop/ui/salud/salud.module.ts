import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormsModule,
  ReactiveFormsModule
} from '@angular/forms';
import { CdkTableModule } from '@angular/cdk/table';
import {
  CaButtonModule,
  CaFormFieldModule,
  CaInputModule,
  CaRadioButtonModule
} from '@global-front-components/ui';
import { CaInputModalFilterModule, CaProtocoloModule, CaSelectModalFilterModule } from '@global-front-components/salud';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SaludRoutingModule } from './salud-routing.module';
import { SaludView } from './salud.view';
import { COMPONENTS } from './components';
import { ComponentDocModule } from '../../../../components/component-doc/component-doc.module';


@NgModule({
  declarations: [
    ...COMPONENTS,
    SaludView,
    SaludView
  ],
  imports: [
    CaButtonModule,
    CaFormFieldModule,
    CaInputModalFilterModule,
    CaInputModule,
    CaProtocoloModule,
    CaRadioButtonModule,
    CaSelectModalFilterModule,
    CdkTableModule,
    CommonModule,
    ComponentDocModule,
    FormsModule,
    NgbModule,
    ReactiveFormsModule,
    SaludRoutingModule
  ]
})
export class SaludModule { }
