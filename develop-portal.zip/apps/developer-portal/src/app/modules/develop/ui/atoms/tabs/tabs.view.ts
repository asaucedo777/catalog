import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { DragTabEvent } from '@global-front-components/ui';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: 'tabs.view.html',
	styleUrls: ['tabs.view.scss']
})
export class TabsView implements OnInit {
 constructor(private _cd: ChangeDetectorRef) {

 }
  dragTabData: DragTabEvent;
  dropedTabs = [];
	importModule = `import { CaTabsModule } from '@global-front-components/ui';`;
  tabList = ['First', 'Second', 'third'];
  loremContent = `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.`

	caseSimple: ComponentDoc = {
		title: `Uso simple`,
    description: `
    <p>Para generar pestañas tan sólo debemos incluir dentro de la etiqueta  <code class="tag">ca-tabs-grop</code>, tantas etiquetas <code class="tag">ca-tab</code> como pestañas necesitemos</p>
    <p>A cada <code class="tag">ca-tab</code> le añadiremos el atributo <code class="attribute">label</code> con el texto que incluirá la pestaña y dentro de la etiqueta el contenido a mostar. Este puede ser tanto texto plano como html u otros componentes</p>
    <p>Opcionalmente podemos añadir a cada etiqueta <code class="tag">ca-tab</code> el atributo <code class="attribute">icon</code> conel nombre de unos de los iconos aceptados por <a href="https://fonts.google.com/icons" target="_blank">Material Icon</a> </p>
    <p>Cada vez que cambiemos de pestaña, el componente emitirá un evento con el indice de la nueva activa a través del output <code class="attribute">changeTab</code> </p>   `
    ,
		codeExample: {
      html: `
      <ca-tabs-group  (changeTab)="onChangeTab($event)">
        <ca-tab label="First" icon="perm_identity">Content 1</ca-tab>
        <ca-tab label="Second"><custom-component></custom-component></ca-tab>
        <ca-tab label="Third">Content 3</ca-tab>
      </ca-tabs-group>
        `
		}
  };

	caseDisabled: ComponentDoc = {
		title: `Pestañas deshabilitadas`,
    description: `
    <p>Para deshabilitar el uso de pestañas tan dolo debemos añadir el atributo <ode class="atrribute">disabled</code> a la pestaña que queremos deshabilitar</p>
    <p>También podemos hacerlo de forma programática asociando el atributo a una variable y dándole a esta el valor true o false<p>`,
		codeExample: {
      html: `
      <ca-tabs-group>
        <ca-tab label="First">Content 1</ca-tab>
        <ca-tab label="Second"disable><custom-component></custom-component></ca-tab>
        <ca-tab label="Third" [disabled]="isDisabled">Content 3</ca-tab>
      </ca-tabs-group>
        `
		}
  };

	caseClosable: ComponentDoc = {
		title: `Habilitar cierre de pestañas`,
    description: `
    <p>Para habilitar el cierre  de pestañas tan dolo debemos añadir el atributo <ode class="atrribute">closable</code> a la pestaña que queremos habilitar esta función</p>
    <p>También podemos hacerlo de forma genérica añadiendo el atributo <code class="atrribute">closableTabs</code> al elemento <code class="tag">ca-tabs-grop</code><p>
    <p><code class="tag">ca-tabs-grop</code> emitirá un evento a través del output <code class="atrribute">closableTabs</code> por el cual emitirá el índice del elemento que se quiere eliminar</p>
    <p>es reponsabilidad del componente que implementa las tabs eliminarla </p>
    `,
		codeExample: {
      html: `
      <ca-tabs-group (closeTab)="oncloseTab($event)">
      <ca-tab [label]="tab" *ngFor="let tab of tabList" [closable]="true">Content for {{tab}} tab</ca-tab>
      </ca-tabs-group>

      <ca-tabs-group closableTabs (closeTab)="oncloseTabGeneric($event)">
      <ca-tab [label]="tab" *ngFor="let tab of tabList" >Content for {{tab}} tab</ca-tab>
    </ca-tabs-group>
        `,
        ts:
          `
          class MyClass {
            tabList = ['First', 'Second', 'third'];

            oncloseTabGeneric(index: number) {
              this.tabList.splice(index, 1);

            }

          }
          `

		}
  };

	caseLabelPosition: ComponentDoc = {
		title: `Posicionando las pestañas a la izquierda`,
    description: `
    <p>Podemos cambiar la posición de las pestañas al lado izquierdo del contenido añadiendo el attributo <ode class="atrribute">labelPosition</code> y dándole como valor <b>left</b></p>
    `,

		codeExample: {
      html: `
      <ca-tabs-group labelsPosition="left">
        <ca-tab label="First" icon="perm_identity">Content 1</ca-tab>
        <ca-tab label="Second"  icon="perm_identity"><custom-component></custom-component></ca-tab>
        <ca-tab label="Third" disabled  icon="perm_identity">Content 3</ca-tab>
      </ca-tabs-group>
        `
		}
  };

	caseLazyLoad: ComponentDoc = {
		title: `Carga perezosa del contenido`,
    description: `
    <p>Por defecto el contenido de todas las pestañas se carga al inicializar el componente de pestañas</p>
    <p>Si queremos que el contenido interno se cargue de al activar la pestaña y se destruya al estar esta inactiva, deberemos añadir el atributo <ode class="atrribute">lazyload</code> a la etiqueta <code class="tag">ca-tabs-grop</code><p> e incluir el contenido dentro de un <code class="tag">ng-template</code> usando la directiva <code class="directive">ca-tab-content</code> tal y como se indica en el ejemplo`,
		codeExample: {
      html: `
      <ca-tabs-group lazyLoad>
        <ca-tab label="First">
          <ng-template ca-tab-content>
            Content 1
          </ng-template>
        </ca-tab>
        <ca-tab label="Second">
          <ng-template ca-tab-content>
            <ca-test-tab></ca-test-tab>
          </ng-template>
        </ca-tab>
      <ca-tab label="Third">
        <ng-template ca-tab-content>
          Content 1
        </ng-template>
      </ca-tab>
    </ca-tabs-group>
        `
		}
  };

  caseStyleFlat: ComponentDoc = {
		title: `Estilo secundario de las pestañas`,
    description: `
    <p>Podemos darle otro estilo a las label de las pestañas. Para ello debemos añadir el atributo <code class="attribute">headerStyle</code> con valor secondary </p>
    <p>este estilo no tendrá efecto si posicionoamos las pestañas a la izquierda</p>`,
		codeExample: {
      html: `
      <ca-tabs-group headerStyle="secondary">
        <ca-tab label="First">Content 1</ca-tab>
        <ca-tab label="Second"><custom-component></custom-component></ca-tab>
        <ca-tab label="Third" disbled>Content 3</ca-tab>
      </ca-tabs-group>
        `
		}
  };

  caseStyleTertiary: ComponentDoc = {
		title: `Estilo terciario de las pestañas`,
    description: `
    <p>Podemos darle un tercer estilo a las label de las pestañas. Para ello debemos añadir el atributo <code class="attribute">headerStyle</code> con valor tertiary </p>
    <p>este estilo no tendrá efecto si posicionoamos las pestañas a la izquierda</p>`,
		codeExample: {
      html: `
      <ca-tabs-group headerStyle="tertiary">
        <ca-tab label="First"  icon="perm_identity">Content 1</ca-tab>
        <ca-tab label="Second"><custom-component></custom-component></ca-tab>
        <ca-tab label="Third" disbled>Content 3</ca-tab>
      </ca-tabs-group>
        `
		}
  };

  caseMin: ComponentDoc = {
		title: `Uso de pestañas con tamaño mínimo`,
    description: `
    <p>Para generar pestañas con estilos pequeños tan sólo debemos incluir dentro de la etiqueta <code class="tag">ca-tabs-group</code> añadiéndole la directiva <code class="attribute">ca-min-component</code>, tantas etiquetas <code class="tag">ca-tab</code> como pestañas necesitemos</p>
    <p>A cada <code class="tag">ca-tab</code> le añadiremos el attributo<code class="attribute">label</code> con el texto que incluira la pestaña y dentro de la etiqueta el contenido a mostar. Este pued ser tanto texto plano como html u otros componentes</p>`,
		codeExample: {
      html: `
      <ca-tabs-group ca-min-component>
        <ca-tab label="First">Content 1</ca-tab>
        <ca-tab label="Second"><ca-test-tab></ca-test-tab></ca-tab>
        <ca-tab label="Third">Content 3</ca-tab>
      </ca-tabs-group>
      <ca-tabs-group labelsPosition="left" ca-min-component>
        <ca-tab label="First">Content 1</ca-tab>
        <ca-tab label="Second">Content 2</ca-tab>
        <ca-tab label="Third" disabled>Content 3</ca-tab>
      </ca-tabs-group>
      <ca-tabs-group headerStyle="secondary" ca-min-component>
        <ca-tab label="First">Content 1</ca-tab>
        <ca-tab label="Second"><ca-test-tab></ca-test-tab></ca-tab>
        <ca-tab label="Third">Content 3</ca-tab>
      </ca-tabs-group>
        `
		}
  };

  caseDragAndDrop: ComponentDoc = {
    title: 'Pestañas con evento Drag',
    description: `
    <p> Podemos hacer que las pestañas emitan un evento al realizarle la acción de drag sobre ellas.</p>
    <p> Para ello  añadiremos sobre el elemento <code class="tag">ca-tabs-group</code> el atributo <code class="attribute">draggable</code> </p>
    <p> Esto emitira un evento con que nos devolvera un objeto de tipo <code class="property">DragTabEvent</code>el cual contienen los datois correspondes al titulo y posición de la pestaña
    <p> Para captura este evento lo haremos por medio del output <code class="attribute">dragTab</code></p>
    `,
    codeExample: {
      html: `
      <ca-tabs-group (closeTab)="oncloseTab($event)" [draggable]="true" (dragTab)="ondragTab($event)">
      <ca-tab [label]="tab" *ngFor="let tab of tabList">
        <div>
          <h1>Tab {{tab}}</h1>
          <p>{{ loremContent }}</p>
        </div>
      </ca-tab>
    </ca-tabs-group>`,
    ts: `
    import { DragTabEvent } from '@global-front-components/ui';

    class MyClass {
      tabList = ['First', 'Second', 'third'];

      ondragTab(event: DragTabEvent) {
       // some code here.
      }
    }
    `
    }
  }

  caseAnidados: ComponentDoc = {
    title: `Tabs anidados`,
    codeExample: {
      html: `
      <ca-tabs-group>
				<ca-tab label="Tab 1">
          <ca-tabs-group>
            <ca-tab label="Subtab 1">Subtab 1</ca-tab>
            <ca-tab label="Subtab 2">Subtab 2</ca-tab>
            <ca-tab label="Subtab 3">Subtab 3</ca-tab>
          </ca-tabs-group>
        </ca-tab>
        <ca-tab label="Tab 2">Contenido A</ca-tab>
        <ca-tab label="Tab 3">Contenido B</ca-tab>
        <ca-tab label="Tab 4">Contenido C</ca-tab>
			</ca-tabs-group>`
    }
  }

  allowDrop(event: Event) {
    event.preventDefault();
  }

  drop(event: DragEvent) {
   console.log('dropping event:', event);
   this.dropedTabs.push(this.dragTabData.label)
   console.log(this.dropedTabs);



  }

  addNewTab() {
    this.tabList.push('New');
    this._cd.markForCheck();
  }

	oncloseTab(index: number) {
    this.tabList.splice(index, 1);
  }
  onChangeTab(index: number) {
    console.log('indice de la nueva pestaña activa: ', index)

  }

	ngOnInit(): void {}
}
