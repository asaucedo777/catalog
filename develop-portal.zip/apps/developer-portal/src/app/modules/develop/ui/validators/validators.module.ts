import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CaFormFieldModule, CaInputModule } from '@global-front-components/ui';
import { ComponentDocModule } from '../../../../components/component-doc/component-doc.module';
import { ValidatorsView } from './validators.view';
import { ValidatorsRoutingModule } from './validators-routing.module';
import { NifValidatorView } from './nif/nif-validator.view';
import { EmailValidatorView } from './email/email-validator.view';
import { IbanValidatorView } from './iban/iban-validator.view';

@NgModule({
  declarations: [
    EmailValidatorView,
    IbanValidatorView,
    NifValidatorView,
    ValidatorsView
  ],
	imports: [
    CaFormFieldModule,
    CaInputModule,
		CommonModule,
    ComponentDocModule,
    FormsModule,
		NgbModule,
    ReactiveFormsModule,
    RouterModule,
    ValidatorsRoutingModule
	]
})
export class ValidatorsModule {}
