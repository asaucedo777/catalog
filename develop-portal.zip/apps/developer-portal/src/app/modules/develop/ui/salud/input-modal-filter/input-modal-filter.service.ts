import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({providedIn: 'root'})
export class InputModalFilterExampleService {
  constructor() { }

  getPolicy(): Observable<any> {
    return of({
      policyNumber: 33300100,
      name: 'M.P.C.G.A. DE VALENCIA'
    })
  }
}
