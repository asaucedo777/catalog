import { of } from 'rxjs';

export const MenuApplicationsMock = {
  getAppsSSE() {
    return of(APPLICATION_MOCK);
  }
}

const APPLICATION_MOCK =
  {
    "id": "recobros",
    "title": "Recobros",
    "route": "http://localhost:4206",
    "options": [
      {
        "title": "Acerca de",
        "route": "/acerca-de"
      },
      {
        "title": "Administración",
        "options": [
          {
            "title": "Usuarios",
            "options": [
              {
                "title": "Prueba",
                "route": "/administracion/usuarios/prueba"
              }
            ]
          },
          {
            "title": "Roles",
            "route": "/administracion/roles"
          },
          {
            "title": "Acciones",
            "route": "/administracion/acciones"
          }
        ]
      },
      {
        "title": "Movimientos Bancarios",
        "options": [
          {
            "title": "Consultar Movimientos Bancarios",
            "route": "/movimientos-bancarios/consultar-movimientos-bancarios"
          },
          {
            "title": "Gestión Movimientos Bancarios",
            "route": "/movimientos-bancarios/gestion-movimientos-bancarios"
          }
        ]
      },
      {
        "title": "Recobros",
        "options": [
          {
            "title": "Consultar Recobros PAP",
            "route": "/recobros/consultar-recobros-pap"
          },
          {
            "title": "Gestión Recobros PAP",
            "route": "/recobros/gestion-recobros-pap"
          }
        ]
      },
      {
        "title": "Parametrización",
        "options": [
          {
            "title": "Parametrización Bancos Propios",
            "route": "/parametrizacion/parametrizacion-bancos-propios"
          }
        ]
      }
    ]
  }
;
