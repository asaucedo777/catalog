import {
  Component,
  OnInit,
  OnDestroy
} from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import {
  CaFilterPipe,
  CaSortByPipe,
  SortConfig
} from '@global-front-components/common';
import { CaModalOverlayService } from '@global-front-components/ui';
import { BehaviorSubject, Subject } from 'rxjs';
import { debounceTime, takeUntil } from 'rxjs/operators';
import { ModalTableExampleComponent } from './modal-example/modal-example.component';

interface TableColumn   {
  field: string;
  value: string;
  width?: number;
  id?: number;
  sortAsc?: boolean;
}

@Component({
  templateUrl: 'cdk-table.view.html',
  styleUrls: ['cdk-table.view.scss'],
  providers: [ CaFilterPipe, CaSortByPipe ]
})
export class CdkTableView implements OnInit, OnDestroy {
  constructor(
    private _filterPipe: CaFilterPipe,
    private _sortByPipe: CaSortByPipe,
    private _modalService: CaModalOverlayService
  ) { }

  private _destroy$: Subject<void> = new Subject();
  private _filterChange$: BehaviorSubject<string> = new BehaviorSubject(undefined);
  private _sortChanges$: BehaviorSubject<SortConfig> = new BehaviorSubject(undefined);
  private _selectedRows = [];
  private _selectedRowsBis = [];

  importModule = `import { CdkTableModule } from '@angular/cdk/table';`;
  actionsToSelect = ['Abrir una modal de ejemplo'];
  actionSelected = '';
  displayedColumns: string[] = [];
  displayedActionsColumns: string[] = [];
  displayedMultiselectableColumns: string[] = [];
  queryFilter = '';
  columns: TableColumn[] = [
    {
      id: 0,
      field: 'atomicNumber',
      value: 'Número atómico'
    },
    {
      id: 1,
      field: 'name',
      value: 'Nombre'
    },
    {
      id: 2,
      field: 'symbol',
      value: 'Símbolo'
    },
    {
      id: 3,
      field: 'weight',
      value: 'Peso atómico'
    }
  ];
  actionColumns: TableColumn[] = [
    {
      id: 0,
      field: 'selectable',
      value: ''
    },
    {
      id: 1,
      field: 'atomicNumber',
      value: 'Número atómico'
    },
    {
      id: 2,
      field: 'name',
      value: 'Nombre'
    },
    {
      id: 3,
      field: 'symbol',
      value: 'Símbolo'
    },
    {
      id: 4,
      field: 'weight',
      value: 'Peso atómico'
    }
  ];
  multiselectableColumns = this.actionColumns;
  pageAllChecked: boolean;
  pageAllCheckedBis: boolean;
  dataSize: number;
  multiDataSize: number;
  multiDataSizeBis: number;
  actionsTableData: any[] = [];
  displayedTableData: any[] = [];
  paginatedTableData: any[] = [];
  multiselectableTableData: any[] = [];
  multiselectableTableDataBis: any[] = [];
  sortedTableData: any[] = [];
  page = 1;
  pageSize = 3;
  multiPage = 1;
  multiPageSize = 3;
  multiPageBis = 1;
  multiPageSizeBis = 3;
  selectedRow: any;
  preventSingleClick = false;
  singleClickTimer;
  tableData = [
    {
      atomicNumber: 1,
      name: 'Hidrógeno',
      symbol: 'H',
      weight: 1.00794
    },
    {
      atomicNumber: 2,
      name: 'Helio',
      symbol: 'He',
      weight: 4.002602
    },
    {
      atomicNumber: 3,
      name: 'Litio',
      symbol: 'Li',
      weight: 6.941
    },
    {
      atomicNumber: 4,
      name: 'Berilio',
      symbol: 'Be',
      weight: 9.012183
    },
    {
      atomicNumber: 5,
      name: 'Boro',
      symbol: 'B',
      weight: 10.811
    },
    {
      atomicNumber: 6,
      name: 'Carbono',
      symbol: 'C',
      weight: 12.0107
    },
    {
      atomicNumber: 7,
      name: 'Nitrógeno',
      symbol: 'N',
      weight: 14.0067
    },
    {
      atomicNumber: 8,
      name: 'Oxígeno',
      symbol: 'O',
      weight: 15.9994
    },
    {
      atomicNumber: 9,
      name: 'Flúor',
      symbol: 'F',
      weight: 18.9984032
    }
  ];
  tableDataBis = JSON.parse(JSON.stringify(this.tableData));

  caseSimple: ComponentDoc = {
    title: 'Tabla simple',
    codeExample: {
      html: `
    <table cdk-table [dataSource]="tableData" class="ca-table">
      <ng-container *ngFor="let column of columns; let i = index" [cdkColumnDef]="column.field">
        <th cdk-header-cell *cdkHeaderCellDef class="ca-table__header">
          <div class="ca-table__header-container justify-content-start">
            <span class="ca-table__header-wrapper">
              <span class="ca-table__header-text">{{ column.value }}</span>
            </span>
          </div>
        </th>
        <td cdk-cell *cdkCellDef="let row; let i = index" class="ca-table__cell">
          <div class="ca-table__cell-container">
            <span class="ca-table__cell-text">
              {{ row[column.field] }}
            </span>
          </div>
        </td>
      </ng-container>
      <thead class="ca-table__thead">
        <tr cdk-header-row *cdkHeaderRowDef="displayedColumns"
          class="ca-table__row ca-table__row--bordered ca-table__row--clean"></tr>
      </thead>
      <tbody class="ca-table__tbody">
        <tr cdk-row *cdkRowDef="let row; columns: displayedColumns; let i = index" class="ca-table__row"></tr>
      </tbody>
    </table>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      interface TableColumn {
        id: number;
        field: string;
        value: string;
      }
      @Component({
        selector: 'ca-simple-table',
        templateUrl: './simple-table.component.html',
        styleUrls: ['./simple-table.component.scss']
      })
      export class SimpleTableComponent implements OnInit {
        displayedColumns: string[] = [];
        columns: TableColumn[] = [
          {
            id: 0,
            field: 'atomicNumber',
            value: 'Número atómico'
          },
          {
            id: 1,
            field: 'name',
            value: 'Nombre'
          },
          {
            id: 2,
            field: 'symbol',
            value: 'Símbolo'
          },
          {
            id: 3,
            field: 'weight',
            value: 'Peso atómico'
          }
        ];

        tableData = [
          {
            atomicNumber: 1,
            name: 'Hidrógeno',
            symbol: 'H',
            weight: 1.00794
          },
          {
            atomicNumber: 2,
            name: 'Helio',
            symbol: 'He',
            weight: 4.002602
          },
          {
            atomicNumber: 3,
            name: 'Litio',
            symbol: 'Li',
            weight: 6.941
          },
          {
            atomicNumber: 4,
            name: 'Berilio',
            symbol: 'Be',
            weight: 9.012183
          },
          {
            atomicNumber: 5,
            name: 'Boro',
            symbol: 'B',
            weight: 10.811
          },
          {
            atomicNumber: 6,
            name: 'Carbono',
            symbol: 'C',
            weight: 12.0107
          },
          {
            atomicNumber: 7,
            name: 'Nitrógeno',
            symbol: 'N',
            weight: 14.0067
          },
          {
            atomicNumber: 8,
            name: 'Oxígeno',
            symbol: 'O',
            weight: 15.9994
          },
          {
            atomicNumber: 9,
            name: 'Flúor',
            symbol: 'F',
            weight: 18.9984032
          }
        ];

        private _setDisplayedColumns(): void {
          this.displayedColumns = this.columns.map((column) => column.field);
        }

        ngOnInit() {
          this._setDisplayedColumns();
        }
      }`,
      css: `
      .ca-table {
        width: 100%;
        font-size: 14px;
        border-collapse: collapse;
        border: 1px solid #d0d2d3;
        &__row {
          &:nth-child(odd) {
            background-color: #eef2f5;
          }
          &:nth-child(even) {
            background-color: #ffffff;
          }
          &:hover {
            background-color: #dcf1f0;
          }
          &--bordered {
            border-bottom: 1px solid #d0d2d3;
          }
          &--clean {
            &:nth-child(odd) {
              background-color: #ffffff;
            }
            &:hover {
              background-color: inherit;
            }
          }
        }
        &__header {
          padding: 6px 16px;
          text-align: left;
          background-color: #ffffff;

          &-container {
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          &-text {
            white-space: nowrap;
          }
        }
        &__cell {
          cursor: pointer;
          height: 32px;
          position: relative;
          padding: 0 16px;
          vertical-align: middle;
          max-width: 90px;
          &-container {
            overflow: hidden;
            text-overflow: ellipsis;
          }
          &-text {
            white-space: nowrap;
          }
        }
      }`
    }
  }

  caseFilter: ComponentDoc = {
    title: 'Tabla con filtrado',
    description: `En este ejemplo haremos uso del pipe <code class="attribute">CaFilterPipe</code>, así como del componente <code>CaFormField</code> y la directiva <code class="attribute">CaInput</code> sobre un <code>&lt;input&gt;</code> para el campo de búsqueda.`,
    codeExample: {
      html: `
      <div class="ca-table__container">
          <div class="ca-table__actions d-flex justify-content-end">
            <ca-form-field class="filter">
              <ca-label [visible]="false">Filtro</ca-label>
              <ca-icon>search</ca-icon>
              <input caInput type="text" placeholder="" [(ngModel)]="queryFilter" (ngModelChange)="onFilter($event)" />
            </ca-form-field>
          </div>
          <ng-container *ngIf="displayedTableData.length > 0; else noresult">
            <table cdk-table [dataSource]="displayedTableData" class="ca-table">
              <ng-container *ngFor="let column of columns; let i = index" [cdkColumnDef]="column.field">
                <th cdk-header-cell *cdkHeaderCellDef class="ca-table__header">
                  <div class="ca-table__header-container justify-content-start">
                    <span class="ca-table__header-wrapper">
                      <span class="ca-table__header-text">{{ column.value }}</span>
                    </span>
                  </div>
                </th>
                <td cdk-cell *cdkCellDef="let row; let i = index" class="ca-table__cell">
                  <div class="ca-table__cell-container">
                    <span class="ca-table__cell-text">
                      {{ row[column.field] }}
                    </span>
                  </div>
                </td>
              </ng-container>
              <thead class="ca-table__thead">
                <tr cdk-header-row *cdkHeaderRowDef="displayedColumns"
                  class="ca-table__row ca-table__row--bordered ca-table__row--clean"></tr>
              </thead>
              <tbody class="ca-table__tbody">
                <tr cdk-row *cdkRowDef="let row; columns: displayedColumns; let i = index" class="ca-table__row"></tr>
              </tbody>
            </table>
          </ng-container>
        </div>
        <ng-template #noresult>
          <p>No se han encontrado resultados</p>
        </ng-template>`,
      ts: `
      import { Component, OnInit, OnDestroy } from '@angular/core';
      import { CaFilterPipe } from '@global-front-components/common';
      import { BehaviorSubject Subject } from 'rxjs';
      import { debounceTime, takeUntil } from 'rxjs/operators';
      interface TableColumn {
        id: number;
        field: string;
        value: string;
      }
      @Component({
        selector: 'ca-filter-table',
        templateUrl: './filter-table.component.html',
        styleUrls: ['./filter-table.component.scss'],
        providers: [ CaFilterPipe ]
      })
      export class FilterTableComponent implmements OnInit, OnDestroy {
        constructor( private _filterPipe: CaFilterPipe ) { }

        private _destroy$: Subject<void> = new Subject();
        private _filterChange$: BehaviorSubject<string> = new BehaviorSubject(undefined);
        displayedColumns: string[] = [];
        displayedTableData: any[] = [];
        queryFilter = '';

        columns: TableColumn[] = [
          {
            id: 0,
            field: 'atomicNumber',
            value: 'Número atómico'
          },
          {
            id: 1,
            field: 'name',
            value: 'Nombre'
          },
          {
            id: 2,
            field: 'symbol',
            value: 'Símbolo'
          },
          {
            id: 3,
            field: 'weight',
            value: 'Peso atómico'
          }
        ];

        tableData = [
          {
            atomicNumber: 1,
            name: 'Hidrógeno',
            symbol: 'H',
            weight: 1.00794
          },
          {
            atomicNumber: 2,
            name: 'Helio',
            symbol: 'He',
            weight: 4.002602
          },
          {
            atomicNumber: 3,
            name: 'Litio',
            symbol: 'Li',
            weight: 6.941
          },
          {
            atomicNumber: 4,
            name: 'Berilio',
            symbol: 'Be',
            weight: 9.012183
          },
          {
            atomicNumber: 5,
            name: 'Boro',
            symbol: 'B',
            weight: 10.811
          },
          {
            atomicNumber: 6,
            name: 'Carbono',
            symbol: 'C',
            weight: 12.0107
          },
          {
            atomicNumber: 7,
            name: 'Nitrógeno',
            symbol: 'N',
            weight: 14.0067
          },
          {
            atomicNumber: 8,
            name: 'Oxígeno',
            symbol: 'O',
            weight: 15.9994
          },
          {
            atomicNumber: 9,
            name: 'Flúor',
            symbol: 'F',
            weight: 18.9984032
          }
        ];

        onFilter(query: string): void {
          this._filterChange$.next(query);
        }

        private _setDisplayedColumns(): void {
          this.displayedColumns = this.columns.map((column) => column.field);
        }

        ngOnInit() {
          this._setDisplayedColumns();
          this.displayedTableData= this.tableData;
          this._filterChange$.pipe(takeUntil(this._destroy$),debounceTime(200)).subscribe((value) => {
            this.displayedTableData = this._filterPipe.transform(this.tableData, value);
          })
        }

        ngOnDestroy() {
          this._destroy$.next();
          this._destroy$.complete();
        }
      }
      `,
      css: `
      .ca-table {
        &__container {
          display: flex;
          flex-direction: column;
          height: 100%;
        }

        &__actions {
          padding-bottom: 4px;
          margin-bottom: 8px;

          .filter {
            width: 206px;
          }
        }

        width: 100%;
        font-size: 14px;
        border-collapse: collapse;
        border: 1px solid #d0d2d3;
        &__row {
          &:nth-child(odd) {
            background-color: #eef2f5;
          }
          &:nth-child(even) {
            background-color: #ffffff;
          }
          &:hover {
            background-color: #dcf1f0;
          }
          &--bordered {
            border-bottom: 1px solid #d0d2d3;
          }
          &--clean {
            &:nth-child(odd) {
              background-color: #ffffff;
            }
            &:hover {
              background-color: inherit;
            }
          }
        }
        &__header {
          padding: 6px 16px;
          text-align: left;
          background-color: #ffffff;

          &-container {
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          &-text {
            white-space: nowrap;
          }
        }
        &__cell {
          cursor: pointer;
          height: 32px;
          position: relative;
          padding: 0 16px;
          vertical-align: middle;
          max-width: 90px;
          &-container {
            overflow: hidden;
            text-overflow: ellipsis;
          }
          &-text {
            white-space: nowrap;
          }
        }
      }`
    }
  }

  casePagination: ComponentDoc = {
    title: 'Tabla con paginación',
    description: `En este ejemplo haremos uso del componente <code>CaPagination</code>`,
    codeExample: {
      html: `
    <div class="ca-table__container">
      <table cdk-table [dataSource]="paginatedTableData" class="ca-table">
        <ng-container *ngFor="let column of columns; let i = index" [cdkColumnDef]="column.field">
          <th cdk-header-cell *cdkHeaderCellDef class="ca-table__header">
            <div class="ca-table__header-container justify-content-start">
              <span class="ca-table__header-wrapper">
                <span class="ca-table__header-text">{{ column.value }}</span>
              </span>
            </div>
          </th>
          <td cdk-cell *cdkCellDef="let row; let i = index" class="ca-table__cell">
            <div class="ca-table__cell-container">
              <span class="ca-table__cell-text">
                {{ row[column.field] }}
              </span>
            </div>
          </td>
        </ng-container>
        <thead class="ca-table__thead">
          <tr cdk-header-row *cdkHeaderRowDef="displayedColumns"
            class="ca-table__row ca-table__row--bordered ca-table__row--clean"></tr>
        </thead>
        <tbody class="ca-table__tbody">
          <tr cdk-row *cdkRowDef="let row; columns: displayedColumns; let i = index" class="ca-table__row"></tr>
        </tbody>
      </table>
      <div class="d-flex justify-content-center ca-table__pagination-wrapper">
        <ca-pagination [dataSize]="dataSize" [(page)]="page" [pageSize]="pageSize" (pageChange)="paginate()">
        </ca-pagination>
      </div>
    </div>`,
    ts: `
      import { Component, OnInit } from '@angular/core';
      interface TableColumn {
        id: number;
        field: string;
        value: string;
      }
      @Component({
        selector: 'ca-pagination-table',
        templateUrl: './pagination-table.component.html',
        styleUrls: ['./pagination-table.component.scss']
      })
      export class PaginationTableComponent implements OnInit {
        dataSize: number;
        displayedTableData: any[] = [];
        page = 1;
        pageSize = 3;
        paginatedTableData: any[] = [];

        columns: TableColumn[] = [
          {
            id: 0,
            field: 'atomicNumber',
            value: 'Número atómico'
          },
          {
            id: 1,
            field: 'name',
            value: 'Nombre'
          },
          {
            id: 2,
            field: 'symbol',
            value: 'Símbolo'
          },
          {
            id: 3,
            field: 'weight',
            value: 'Peso atómico'
          }
        ];

        tableData = [
          {
            atomicNumber: 1,
            name: 'Hidrógeno',
            symbol: 'H',
            weight: 1.00794
          },
          {
            atomicNumber: 2,
            name: 'Helio',
            symbol: 'He',
            weight: 4.002602
          },
          {
            atomicNumber: 3,
            name: 'Litio',
            symbol: 'Li',
            weight: 6.941
          },
          {
            atomicNumber: 4,
            name: 'Berilio',
            symbol: 'Be',
            weight: 9.012183
          },
          {
            atomicNumber: 5,
            name: 'Boro',
            symbol: 'B',
            weight: 10.811
          },
          {
            atomicNumber: 6,
            name: 'Carbono',
            symbol: 'C',
            weight: 12.0107
          },
          {
            atomicNumber: 7,
            name: 'Nitrógeno',
            symbol: 'N',
            weight: 14.0067
          },
          {
            atomicNumber: 8,
            name: 'Oxígeno',
            symbol: 'O',
            weight: 15.9994
          },
          {
            atomicNumber: 9,
            name: 'Flúor',
            symbol: 'F',
            weight: 18.9984032
          }
        ];

        private _setDisplayedColumns(): void {
          this.displayedColumns = this.columns.map((column) => column.field);
        }

        paginate(): void {
          this.paginatedTableData = this.tableData?.slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
        }

        ngOnInit() {
          this._setDisplayedColumns();
          this.paginatedTableData= this.tableData;
          this.dataSize = this.paginatedTableData.length;
          this.paginate();
        }
      }
    `,
    css: `
    .ca-table {
      &__container {
        display: flex;
        flex-direction: column;
        height: 100%;
      }
      width: 100%;
      font-size: 14px;
      border-collapse: collapse;
      border: 1px solid #d0d2d3;
      &__row {
        &:nth-child(odd) {
          background-color: #eef2f5;
        }
        &:nth-child(even) {
          background-color: #ffffff;
        }
        &:hover {
          background-color: #dcf1f0;
        }
        &--bordered {
          border-bottom: 1px solid #d0d2d3;
        }
        &--clean {
          &:nth-child(odd) {
            background-color: #ffffff;
          }
          &:hover {
            background-color: inherit;
          }
        }
      }
      &__header {
        padding: 6px 16px;
        text-align: left;
        background-color: #ffffff;

        &-container {
          display: flex;
          justify-content: center;
          align-items: center;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        &-text {
          white-space: nowrap;
        }
      }
      &__cell {
        cursor: pointer;
        height: 32px;
        position: relative;
        padding: 0 16px;
        vertical-align: middle;
        max-width: 90px;
        &-container {
          overflow: hidden;
          text-overflow: ellipsis;
        }
        &-text {
          white-space: nowrap;
        }
      }
      &__pagination-wrapper {
        margin-top: 16px;
        align-items: flex-end;
      }
    }`
    }
  }

  caseActions: ComponentDoc = {
    title: 'Tabla con acciones',
    description : `Para realizar acciones sobre una tabla deberá seleccionar una fila mediante un evento <em>click</em>.
    A continuación puede realizar una acción eligiéndola en el seleccionable o mediante un evento <em>dblclick</em> sobre una fila.
    Para evitar que ambos eventos no colisionen y puedan tener acciones diferenciadas, hay que añadir un delay de 300ms en el evento de single click, como se puede observar en este ejemplo.
    En este ejemplo haremos uso de los componentes <code>CaFormField</code>, <code>CaSelect</code> y <code>CaRadioButton</code>. Para mostrar la acción realizada también se ha hecho uso del servicio <code>CaModalOverlayService</code> para abrir una modal con la información de la acción realizada.`,
    codeExample: {
      html: `
    <div class="ca-table__container">
      <div class="ca-table__actions d-flex justify-content-end">
        <ca-form-field class="select">
          <ca-select placeholder="Seleccione una acción"
            [options]="actionsToSelect"
            [ngModel]="actionSelected"
            (ngModelChange)="onSelectedOption(selectedRow)"
            [disabled]="!selectedRow"></ca-select>
        </ca-form-field>
      </div>
        <table cdk-table [dataSource]="tableData" class="ca-table">
          <ng-container *ngFor="let column of columns; let i = index" [cdkColumnDef]="column.field">
            <th cdk-header-cell *cdkHeaderCellDef class="ca-table__header">
              <div class="ca-table__header-container justify-content-start">
                <span class="ca-table__header-wrapper">
                  <span class="ca-table__header-text">{{ column.value }}</span>
                </span>
              </div>
            </th>
            <td cdk-cell *cdkCellDef="let row; let i = index" class="ca-table__cell">
              <ng-container *ngIf="column.field !== 'selectable'; else selectableCell">
                <div class="ca-table__cell-container">
                  <span class="ca-table__cell-text">
                    {{ row[column.field] }}
                  </span>
                </div>
              </ng-container>
              <ng-template #selectableCell>
                <ca-radio-button
                  [value]="i"
                  [checked]="isSelectedRow(row)"
                ></ca-radio-button>
              </ng-template>
            </td>
          </ng-container>
          <thead class="ca-table__thead">
            <tr cdk-header-row *cdkHeaderRowDef="displayedColumns"
              class="ca-table__row ca-table__row--bordered ca-table__row--clean"></tr>
          </thead>
          <tbody class="ca-table__tbody">
            <tr cdk-row *cdkRowDef="let row; columns: displayedColumns; let i = index"
              class="ca-table__row"
              [class.ca-table__row--selected]="isSelectedRow(row)"
              (click)="onSelectedRow(row, i)"
              (dblclick)="onDblClick(row)"
            ></tr>
          </tbody>
        </table>
    </div>`,
    ts: `
    import { Component, OnInit } from '@angular/core';
    import { CaModalOverlayService } from '@global-front-components/ui';
    import { ModalTableExampleComponent } from './modal-example/modal-example.component';
    interface TableColumn   {
      id: number;
      field: string;
      value: string;
    }
    @Component({
      selector: 'ca-actions-table-page',
      templateUrl: './actions-table.component.html',
      styleUrls: ['./actions-table.component.scss']
    })
    export class ActionsTableComponent implements OnInit, OnDestroy {
      constructor( private _modalService: CaModalOverlayService ) { }

      actionsToSelect = ['Abrir una modal de ejemplo'];
      actionSelected = '';
      displayedColumns: string[] = [];
      selectedRow: any;
      preventSingleClick = false;
      singleClickTimer;
      columns: TableColumn[] = [
        {
          id: 0,
          field: 'selectable',
          value: ''
        },
        {
          id: 1,
          field: 'atomicNumber',
          value: 'Número atómico'
        },
        {
          id: 2,
          field: 'name',
          value: 'Nombre'
        },
        {
          id: 3,
          field: 'symbol',
          value: 'Símbolo'
        },
        {
          id: 4,
          field: 'weight',
          value: 'Peso atómico'
        }
      ];
      tableData = [
        {
          atomicNumber: 1,
          name: 'Hidrógeno',
          symbol: 'H',
          weight: 1.00794
        },
        {
          atomicNumber: 2,
          name: 'Helio',
          symbol: 'He',
          weight: 4.002602
        },
        {
          atomicNumber: 3,
          name: 'Litio',
          symbol: 'Li',
          weight: 6.941
        },
        {
          atomicNumber: 4,
          name: 'Berilio',
          symbol: 'Be',
          weight: 9.012183
        },
        {
          atomicNumber: 5,
          name: 'Boro',
          symbol: 'B',
          weight: 10.811
        },
        {
          atomicNumber: 6,
          name: 'Carbono',
          symbol: 'C',
          weight: 12.0107
        },
        {
          atomicNumber: 7,
          name: 'Nitrógeno',
          symbol: 'N',
          weight: 14.0067
        },
        {
          atomicNumber: 8,
          name: 'Oxígeno',
          symbol: 'O',
          weight: 15.9994
        },
        {
          atomicNumber: 9,
          name: 'Flúor',
          symbol: 'F',
          weight: 18.9984032
        }
      ];

      private _setDisplayedColumns(): void {
        this.displayedColumns = this.columns.map((column) => column.field);
      }

      isSelectedRow(row): boolean {
        return this.selectedRow && Object.keys(this.selectedRow).every((key) => this.selectedRow[key] === row[key]);
      }

      onSelectedRow(row: any): void {
        this.preventSingleClick = false;
        this.singleClickTimer = setTimeout(() => {
          if (this.preventSingleClick) {
            return;
          }

          if (!this.isSelectedRow(row)) {
            this.selectedRow = row;
          }
        }, 300);
      }

      onSelectedOption(row: any): void {
        this._modalService.open(ModalTableExampleComponent, {
          title: 'Modal de ejemplo',
          data: {
            type: 'select',
            info: row.name
          }
        });
      }

      onDblClick(row: any): void {
        this.preventSingleClick = true;
        clearTimeout(this.singleClickTimer);

        this._modalService.open(ModalTableExampleComponent, {
          title: 'Modal de ejemplo',
          data: {
            type: 'doble click',
            info: row.name
          }
        })
      }

      ngOnInit() {
        this._setDisplayedColumns();
      }
    }`,
    css: `.ca-table {
      &__container {
        display: flex;
        flex-direction: column;
        height: 100%;
      }

      &__actions {
        padding-bottom: 4px;
        margin-bottom: 8px;

        .select {
          width: 350px;
        }
      }

      width: 100%;
      font-size: 14px;
      border-collapse: collapse;
      border: 1px solid #d0d2d3;
      &__row {
        &:nth-child(odd) {
          background-color: #eef2f5;
        }
        &:nth-child(even) {
          background-color: #ffffff;
        }
        &:hover {
          background-color: #dcf1f0;
        }
        &--bordered {
          border-bottom: 1px solid #d0d2d3;
        }
        &--clean {
          &:nth-child(odd) {
            background-color: #ffffff;
          }
          &:hover {
            background-color: inherit;
          }
        }
        &--selected:nth-child(odd),
        &--selected:nth-child(even) {
          background-color: #ccede9;
        }
      }
      &__header {
        padding: 6px 16px;
        text-align: left;
        background-color: #ffffff;
        &-container {
          display: flex;
          justify-content: center;
          align-items: center;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        &-text {
          white-space: nowrap;
        }
        ::ng-deep ca-radio-button {
          .ca-radio-button {
            display: flex;
            &__label {
              margin: 0;
            }
          }
        }
      }
      &__cell {
        cursor: pointer;
        height: 32px;
        position: relative;
        padding: 0 16px;
        vertical-align: middle;
        max-width: 90px;
        &-container {
          overflow: hidden;
          text-overflow: ellipsis;
        }
        &-text {
          white-space: nowrap;
        }
      }
    }`
    }
  }

  caseMultiselection: ComponentDoc = {
    title: 'Tabla con multiselección de filas (1)',
    description: `<p>En estos dos ejemplos haremos uso del componente <code>CaPagination</code> y del componente <code>CaCheckbox</code>.</p> <p>En este primer ejemplo se mostrará la casuística en la que seleccionando el checkbox de la cabecera se seleccionan todos los registros.</p>`,
    codeExample: {
      html: `
    <div class="ca-table__container">
      <table cdk-table [dataSource]="multiselectableTableData" class="ca-table">
        <ng-container *ngFor="let column of columns; let i = index" [cdkColumnDef]="column.field">
          <th cdk-header-cell *cdkHeaderCellDef class="ca-table__header">
            <div class="ca-table__header-container justify-content-start">
            <ca-checkbox
              *ngIf="column.field === 'selectable'"
              [labelVisible]="false"
              (click)="selectAllCurrentRows($event)"
              [checked]="pageAllChecked">
              Seleccione todos los documentos
            </ca-checkbox>
            <span class="ca-table__header-wrapper">
                <span class="ca-table__header-text">{{ column.value }}</span>
              </span>
            </div>
          </th>
          <td cdk-cell *cdkCellDef="let row; let i = index" class="ca-table__cell">
            <ng-container *ngIf="column.field !== 'selectable'; else selectableCell">
              <div class="ca-table__cell-container">
                <span class="ca-table__cell-text">
                  {{ row[column.field] }}
                </span>
              </div>
            </ng-container>
            <ng-template #selectableCell>
              <ca-checkbox
                [checked]="isSelected(row)"
                [labelVisible]="false">
                Seleccionar documento
              </ca-checkbox>
            </ng-template>
          </td>
        </ng-container>
        <thead class="ca-table__thead">
          <tr cdk-header-row *cdkHeaderRowDef="displayedColumns"
            class="ca-table__row ca-table__row--bordered ca-table__row--clean"></tr>
        </thead>
        <tbody class="ca-table__tbody">
          <tr cdk-row
            *cdkRowDef="let row; columns: displayedColumns; let i = index"
            class="ca-table__row"
            [class.ca-table__row--selected]="isSelected(row)"
            (click)="handleRowClick(row, $event)">
          </tr>
        </tbody>
      </table>
      <div class="d-flex justify-content-center ca-table__pagination-wrapper">
        <ca-pagination [dataSize]="dataSize" [(page)]="page" [pageSize]="pageSize" (pageChange)="paginate()">
        </ca-pagination>
      </div>
    </div>`,
    ts: `
      import { Component, OnInit } from '@angular/core';
      interface TableColumn {
        id: number;
        field: string;
        value: string;
      }
      @Component({
        selector: 'ca-multiselection-table',
        templateUrl: './multiselection-table.component.html',
        styleUrls: ['./multiselection-table.component.scss']
      })
      export class MultiselectionTableComponent implements OnInit {
        private _selectedRows: any[] = [];
        dataSize: number;
        displayedTableData: any[] = [];
        page = 1;
        pageSize = 3;
        pageAllChecked = false;
        multiselectableTableData: any[] = [];

        columns: TableColumn[] = [
          {
            id: 0,
            field: 'selectable',
            value: ''
          },
          {
            id: 0,
            field: 'atomicNumber',
            value: 'Número atómico'
          },
          {
            id: 1,
            field: 'name',
            value: 'Nombre'
          },
          {
            id: 2,
            field: 'symbol',
            value: 'Símbolo'
          },
          {
            id: 3,
            field: 'weight',
            value: 'Peso atómico'
          }
        ];

        tableData = [
          {
            atomicNumber: 1,
            name: 'Hidrógeno',
            symbol: 'H',
            weight: 1.00794
          },
          {
            atomicNumber: 2,
            name: 'Helio',
            symbol: 'He',
            weight: 4.002602
          },
          {
            atomicNumber: 3,
            name: 'Litio',
            symbol: 'Li',
            weight: 6.941
          },
          {
            atomicNumber: 4,
            name: 'Berilio',
            symbol: 'Be',
            weight: 9.012183
          },
          {
            atomicNumber: 5,
            name: 'Boro',
            symbol: 'B',
            weight: 10.811
          },
          {
            atomicNumber: 6,
            name: 'Carbono',
            symbol: 'C',
            weight: 12.0107
          },
          {
            atomicNumber: 7,
            name: 'Nitrógeno',
            symbol: 'N',
            weight: 14.0067
          },
          {
            atomicNumber: 8,
            name: 'Oxígeno',
            symbol: 'O',
            weight: 15.9994
          },
          {
            atomicNumber: 9,
            name: 'Flúor',
            symbol: 'F',
            weight: 18.9984032
          }
        ];

        private _setDisplayedColumns(): void {
          this.displayedColumns = this.columns.map((column) => column.field);
        }

        private _findRowIndex(array: any[], row: any): number {
          return array.findIndex((item) => {
            return Object.keys(item).every((key) => item[key] === row[key]);
          });
        }

        private _onPageAllCheckedChange(): void {
          this.pageAllChecked = this.tableData.every(el =>
            this._findRowIndex(this._selectedRows,el) >= 0)
        }

        isSelected(row: any): boolean {
          return this._findRowIndex(this._selectedRows, row) !== -1;
        }

        handleRowClick(row: any, ev: Event): void {
          ev.preventDefault();
          const isSelected = this.isSelected(row);
          const tableDataIndex = this._findRowIndex(this.tableData, row);
          if (isSelected) {
            this._selectedRows.splice(this._findRowIndex(this._selectedRows, row), 1);
          } else {
            this._selectedRows.push(this.tableData[tableDataIndex]);
          }
          this._onPageAllCheckedChange();
        }

        selectAllCurrentRows(ev: Event): void {
          ev.preventDefault();
          this.pageAllChecked = !this.pageAllChecked;
          if (this.pageAllChecked) {
            this.tableData.map(element => {
              if(this._findRowIndex(this._selectedRows, element) === -1) {
                this._selectedRows.push(element);
              }
            });
          } else {
            this.tableData.forEach(element => {
              this._selectedRows.splice(this._findRowIndex(this._selectedRows, element), 1);
            });
          }
        }

        paginate(): void {
          this.multiselectableTableData = this.tableData?.slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
        }

        ngOnInit() {
          this._setDisplayedColumns();
          this.multiselectableTableData = this.tableData;
          this.dataSize = this.multiselectableTableData.length;
          this.paginate();
        }
      }
    `,
    css: `
    .ca-table {
      &__container {
        display: flex;
        flex-direction: column;
        height: 100%;
      }
      width: 100%;
      font-size: 14px;
      border-collapse: collapse;
      border: 1px solid #d0d2d3;
      &__row {
        &:nth-child(odd) {
          background-color: #eef2f5;
        }
        &:nth-child(even) {
          background-color: #ffffff;
        }
        &:hover {
          background-color: #dcf1f0;
        }
        &--bordered {
          border-bottom: 1px solid #d0d2d3;
        }
        &--clean {
          &:nth-child(odd) {
            background-color: #ffffff;
          }
          &:hover {
            background-color: inherit;
          }
        }
        &--selected:nth-child(odd),
        &--selected:nth-child(even) {
          background-color: #ccede9;
        }
      }
      &__header {
        padding: 6px 16px;
        text-align: left;
        background-color: #ffffff;

        &-container {
          display: flex;
          justify-content: center;
          align-items: center;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        &-text {
          white-space: nowrap;
        }
      }
      &__cell {
        cursor: pointer;
        height: 32px;
        position: relative;
        padding: 0 16px;
        vertical-align: middle;
        max-width: 90px;
        &-container {
          overflow: hidden;
          text-overflow: ellipsis;
        }
        &-text {
          white-space: nowrap;
        }
      }
      &__pagination-wrapper {
        margin-top: 16px;
        align-items: flex-end;
      }
    }`
    }
  }

  caseMultiselection2: ComponentDoc = {
    title: 'Tabla con multiselección de filas (2)',
    description: `<p>En este segundo ejemplo se mostrará la casuística en la que seleccionando el checkbox de la cabecera se seleccionan sólo los registros de la página actual.</p>`,
    codeExample: {
      html: `
    <div class="ca-table__container">
      <table cdk-table [dataSource]="multiselectableTableData" class="ca-table">
        <ng-container *ngFor="let column of columns; let i = index" [cdkColumnDef]="column.field">
          <th cdk-header-cell *cdkHeaderCellDef class="ca-table__header">
            <div class="ca-table__header-container justify-content-start">
            <ca-checkbox
              *ngIf="column.field === 'selectable'"
              [labelVisible]="false"
              (click)="selectAllCurrentRows($event)"
              [checked]="pageAllChecked">
              Seleccione todos los documentos
            </ca-checkbox>
            <span class="ca-table__header-wrapper">
                <span class="ca-table__header-text">{{ column.value }}</span>
              </span>
            </div>
          </th>
          <td cdk-cell *cdkCellDef="let row; let i = index" class="ca-table__cell">
            <ng-container *ngIf="column.field !== 'selectable'; else selectableCell">
              <div class="ca-table__cell-container">
                <span class="ca-table__cell-text">
                  {{ row[column.field] }}
                </span>
              </div>
            </ng-container>
            <ng-template #selectableCell>
              <ca-checkbox
                [checked]="isSelected(row)"
                [labelVisible]="false">
                Seleccionar documento
              </ca-checkbox>
            </ng-template>
          </td>
        </ng-container>
        <thead class="ca-table__thead">
          <tr cdk-header-row *cdkHeaderRowDef="displayedColumns"
            class="ca-table__row ca-table__row--bordered ca-table__row--clean"></tr>
        </thead>
        <tbody class="ca-table__tbody">
          <tr cdk-row
            *cdkRowDef="let row; columns: displayedColumns; let i = index"
            class="ca-table__row"
            [class.ca-table__row--selected]="isSelected(row)"
            (click)="handleRowClick(row, $event)">
          </tr>
        </tbody>
      </table>
      <div class="d-flex justify-content-center ca-table__pagination-wrapper">
        <ca-pagination [dataSize]="dataSize" [(page)]="page" [pageSize]="pageSize" (pageChange)="paginate()">
        </ca-pagination>
      </div>
    </div>`,
    ts: `
      import { Component, OnInit } from '@angular/core';
      interface TableColumn {
        id: number;
        field: string;
        value: string;
      }
      @Component({
        selector: 'ca-multiselection-table',
        templateUrl: './multiselection-table.component.html',
        styleUrls: ['./multiselection-table.component.scss']
      })
      export class MultiselectionTableComponent implements OnInit {
        private _selectedRows: any[] = [];
        dataSize: number;
        displayedTableData: any[] = [];
        page = 1;
        pageSize = 3;
        pageAllChecked = false;
        multiselectableTableData: any[] = [];

        columns: TableColumn[] = [
          {
            id: 0,
            field: 'selectable',
            value: ''
          },
          {
            id: 0,
            field: 'atomicNumber',
            value: 'Número atómico'
          },
          {
            id: 1,
            field: 'name',
            value: 'Nombre'
          },
          {
            id: 2,
            field: 'symbol',
            value: 'Símbolo'
          },
          {
            id: 3,
            field: 'weight',
            value: 'Peso atómico'
          }
        ];

        tableData = [
          {
            atomicNumber: 1,
            name: 'Hidrógeno',
            symbol: 'H',
            weight: 1.00794
          },
          {
            atomicNumber: 2,
            name: 'Helio',
            symbol: 'He',
            weight: 4.002602
          },
          {
            atomicNumber: 3,
            name: 'Litio',
            symbol: 'Li',
            weight: 6.941
          },
          {
            atomicNumber: 4,
            name: 'Berilio',
            symbol: 'Be',
            weight: 9.012183
          },
          {
            atomicNumber: 5,
            name: 'Boro',
            symbol: 'B',
            weight: 10.811
          },
          {
            atomicNumber: 6,
            name: 'Carbono',
            symbol: 'C',
            weight: 12.0107
          },
          {
            atomicNumber: 7,
            name: 'Nitrógeno',
            symbol: 'N',
            weight: 14.0067
          },
          {
            atomicNumber: 8,
            name: 'Oxígeno',
            symbol: 'O',
            weight: 15.9994
          },
          {
            atomicNumber: 9,
            name: 'Flúor',
            symbol: 'F',
            weight: 18.9984032
          }
        ];

        private _setDisplayedColumns(): void {
          this.displayedColumns = this.columns.map((column) => column.field);
        }

        private _findRowIndex(array: any[], row: any): number {
          return array.findIndex((item) => {
            return Object.keys(item).every((key) => item[key] === row[key]);
          });
        }

        private _onPageAllCheckedChange(): void {
          this.pageAllChecked = this.multiselectableTableData.every(el =>
            this._findRowIndex(this._selectedRows,el) >= 0)
        }

        isSelected(row: any): boolean {
          return this._findRowIndex(this._selectedRows, row) !== -1;
        }

        handleRowClick(row: any, ev: Event): void {
          ev.preventDefault();
          const isSelected = this.isSelected(row);
          const tableDataIndex = this._findRowIndex(this.tableData, row);
          if (isSelected) {
            this._selectedRows.splice(this._findRowIndex(this._selectedRows, row), 1);
          } else {
            this._selectedRows.push(this.tableData[tableDataIndex]);
          }
          this._onPageAllCheckedChange();
        }

        selectAllCurrentRows(ev: Event): void {
          ev.preventDefault();
          this.pageAllChecked = !this.pageAllChecked;
          if (this.pageAllChecked) {
            this.multiselectableTableData.map(element => {
              if(this._findRowIndex(this._selectedRows, element) === -1) {
                this._selectedRows.push(element);
              }
            });
          } else {
            this.multiselectableTableData.forEach(element => {
              this._selectedRows.splice(this._findRowIndex(this._selectedRows, element), 1);
            });
          }
        }

        paginate(): void {
          this.multiselectableTableData = this.tableData?.slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
          this._onPageAllCheckedChange();
        }

        ngOnInit() {
          this._setDisplayedColumns();
          this.multiselectableTableData = this.tableData;
          this.dataSize = this.multiselectableTableData.length;
          this.paginate();
        }
      }
    `,
    css: `
    .ca-table {
      &__container {
        display: flex;
        flex-direction: column;
        height: 100%;
      }
      width: 100%;
      font-size: 14px;
      border-collapse: collapse;
      border: 1px solid #d0d2d3;
      &__row {
        &:nth-child(odd) {
          background-color: #eef2f5;
        }
        &:nth-child(even) {
          background-color: #ffffff;
        }
        &:hover {
          background-color: #dcf1f0;
        }
        &--bordered {
          border-bottom: 1px solid #d0d2d3;
        }
        &--clean {
          &:nth-child(odd) {
            background-color: #ffffff;
          }
          &:hover {
            background-color: inherit;
          }
        }
        &--selected:nth-child(odd),
        &--selected:nth-child(even) {
          background-color: #ccede9;
        }
      }
      &__header {
        padding: 6px 16px;
        text-align: left;
        background-color: #ffffff;

        &-container {
          display: flex;
          justify-content: center;
          align-items: center;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        &-text {
          white-space: nowrap;
        }
      }
      &__cell {
        cursor: pointer;
        height: 32px;
        position: relative;
        padding: 0 16px;
        vertical-align: middle;
        max-width: 90px;
        &-container {
          overflow: hidden;
          text-overflow: ellipsis;
        }
        &-text {
          white-space: nowrap;
        }
      }
      &__pagination-wrapper {
        margin-top: 16px;
        align-items: flex-end;
      }
    }`
    }
  }

  caseSortResize: ComponentDoc = {
    title: 'Tabla con tamaño de columnas reajustable y ordenación',
    description: `Para la ordenación haremos uso del pipe <code>CaSortByPipe</code> y para que el tamaño de las columnas sea reajustable emplearemos las directivas
    <code class="attribute">CaResizeColumnModule</code>con valor a <code>true</code> sobre los elementos <code>&lt;th&gt;</code>, añadiremos tambien el atributo<code class="attribute">index</code>con el indicide de la columna.
    <p> Si la tabla se va a renderizar con scroll horizontal hemos de incluir el atributto <code class="attribute">resizeWithScroll</code></p>.

    <pre> import { CaResizableTableModule } from '@global-front-components/common';</pre>`,
    codeExample: {
      html: `
    <table
      cdk-table
      [dataSource]="displayedTableData"
      class="ca-table">
      <ng-container *ngFor="let column of columns; let i = index" [cdkColumnDef]="column.field">
        <th
          cdk-header-cell
          *cdkHeaderCellDef
          [caResizeColumn]="true"
          [index]="i"
          class="ca-table__header">
          <div class="ca-table__header-container justify-content-start">
            <span class="ca-table__header-wrapper">
              <span class="ca-table__header-text">{{ column.value }}</span>
            </span>
            <button ca-button-icon
              class="ca-button-icon ml-2" (click)="sortColumn(column)">
              <span class="material-icons size-xl">unfold_more</span>
            </button>
          </div>
        </th>
        <td
          cdk-cell
          *cdkCellDef="let row; let i = index"
          class="ca-table__cell">
          <div class="ca-table__cell-container">
            <span class="ca-table__cell-text">
              {{ row[column.field] }}
            </span>
          </div>
        </td>
      </ng-container>
      <thead class="ca-table__thead">
        <tr cdk-header-row *cdkHeaderRowDef="displayedColumns"
          class="ca-table__row ca-table__row--bordered ca-table__row--clean"></tr>
      </thead>
      <tbody class="ca-table__tbody">
        <tr cdk-row *cdkRowDef="let row; columns: displayedColumns; let i = index" class="ca-table__row"></tr>
      </tbody>
    </table>`,
    ts: `
    import {
      Component,
      ElementRef,
      OnInit,
      OnDestroy
    } from '@angular/core';
    import { CaSortByPipe, SortConfig } from '@global-front-components/common';
    import { BehaviorSubject, Subject } from 'rxjs';
    import { takeUntil } from 'rxjs/operators';

    interface TableColumn   {
      id: number;
      field: string;
      value: string;
      sortAsc?: boolean;
    }

    @Component({
      selector: 'ca-sort-resize.table-page',
      templateUrl: './sort-resize.table-page.component.html',
      styleUrls: ['./sort-resize.table-page.component.scss'],
      providers: [ CaSortByPipe ]
    })
    export class SortResizeTableComponent implements OnInit, OnDestroy {
      constructor( private _sortByPipe: CaSortByPipe ) { }

      private _destroy$: Subject<void> = new Subject();
      private _sortChanges$: BehaviorSubject<SortConfig> = new BehaviorSubject(undefined);
      displayedColumns: string[] = [];
      displayedTableData: any[] = [];

      columns: TableColumn[] = [
        {
          id: 0,
          field: 'atomicNumber',
          value: 'Número atómico'
        },
        {
          id: 1,
          field: 'name',
          value: 'Nombre'
        },
        {
          id: 2,
          field: 'symbol',
          value: 'Símbolo'
        },
        {
          id: 3,
          field: 'weight',
          value: 'Peso atómico'
        }
      ];

      tableData = [
        {
          atomicNumber: 1,
          name: 'Hidrógeno',
          symbol: 'H',
          weight: 1.00794
        },
        {
          atomicNumber: 2,
          name: 'Helio',
          symbol: 'He',
          weight: 4.002602
        },
        {
          atomicNumber: 3,
          name: 'Litio',
          symbol: 'Li',
          weight: 6.941
        },
        {
          atomicNumber: 4,
          name: 'Berilio',
          symbol: 'Be',
          weight: 9.012183
        },
        {
          atomicNumber: 5,
          name: 'Boro',
          symbol: 'B',
          weight: 10.811
        },
        {
          atomicNumber: 6,
          name: 'Carbono',
          symbol: 'C',
          weight: 12.0107
        },
        {
          atomicNumber: 7,
          name: 'Nitrógeno',
          symbol: 'N',
          weight: 14.0067
        },
        {
          atomicNumber: 8,
          name: 'Oxígeno',
          symbol: 'O',
          weight: 15.9994
        },
        {
          atomicNumber: 9,
          name: 'Flúor',
          symbol: 'F',
          weight: 18.9984032
        }
      ];

      private _setDisplayedColumns(): void {
        this.displayedColumns = this.columns.map((column) => column.field);
      }

      sortColumn(column: TableColumn): void {
        this._sortChanges$.next({
          field: column.field,
          isAsc: column.sortAsc = !column.sortAsc
        });
      }

      ngOnInit() {
        this._setDisplayedColumns();
        this.displayedTableData= this.tableData;
        this._sortChanges$.pipe(takeUntil(this._destroy$)).subscribe((value) => {
          this.displayedTableData = this._sortByPipe.transform(this.tableData, value);
        })
      }

      ngOnDestroy() {
        this._destroy$.next();
        this._destroy$.complete();
      }
    }`,
    css: `
    .ca-table {
      width: 100%;
      font-size: 14px;
      border-collapse: collapse;
      border: 1px solid #d0d2d3;
      &__row {
        &:nth-child(odd) {
          background-color: #eef2f5;
        }
        &:nth-child(even) {
          background-color: #ffffff;
        }
        &:hover {
          background-color: #dcf1f0;
        }
        &--bordered {
          border-bottom: 1px solid #d0d2d3;
        }
        &--clean {
          &:nth-child(odd) {
            background-color: #ffffff;
          }
          &:hover {
            background-color: inherit;
          }
        }
      }
      &__header {
        padding: 6px 16px;
        text-align: left;
        background-color: #ffffff;
        position: relative;

        &-container {
          display: flex;
          justify-content: center;
          align-items: center;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        &-text {
          white-space: nowrap;
        }
        .ca-button-icon {
          flex-grow: 0;
          flex-shrink: 0;
          flex-basis: auto;
        }
      }
      &__cell {
        cursor: pointer;
        height: 32px;
        position: relative;
        padding: 0 16px;
        vertical-align: middle;
        max-width: 90px;
        &-container {
          overflow: hidden;
          text-overflow: ellipsis;
        }
        &-text {
          white-space: nowrap;
        }
      }
    }`
    }
  }

  caseDragDrop: ComponentDoc = {
    title: 'Tabla con Drag&Drop',
    codeExample: {
      html: `
    <table
      class="ca-table"
      cdk-table
      cdkDropList
      cdkDropListOrientation="horizontal"
      [dataSource]="tableData"
      (cdkDropListDropped)="tableDrop($event)">
      <ng-container *ngFor="let column of columns; let i = index" [cdkColumnDef]="column.field">
        <th
          class="ca-table__header"
          cdk-header-cell
          *cdkHeaderCellDef
          cdkDrag
          cdkDropListLockAxis="x">
          <div class="ca-table__header-container justify-content-start">
            <span class="ca-table__header-wrapper">
              <span class="ca-table__header-text">{{ column.value }}</span>
            </span>
          </div>
        </th>
        <td cdk-cell *cdkCellDef="let row; let i = index" class="ca-table__cell">
          <div class="ca-table__cell-container">
            <span class="ca-table__cell-text">
              {{ row[column.field] }}
            </span>
          </div>
        </td>
      </ng-container>
      <thead class="ca-table__thead">
        <tr cdk-header-row *cdkHeaderRowDef="displayedColumns"
          class="ca-table__row ca-table__row--bordered ca-table__row--clean"></tr>
      </thead>
      <tbody class="ca-table__tbody">
        <tr cdk-row *cdkRowDef="let row; columns: displayedColumns; let i = index" class="ca-table__row"></tr>
      </tbody>
    </table>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
      interface TableColumn {
        id: number;
        field: string;
        value: string;
      }
      @Component({
        selector: 'ca-simple-table',
        templateUrl: './simple-table.component.html',
        styleUrls: ['./simple-table.component.scss']
      })
      export class SimpleTableComponent implements OnInit {
        displayedColumns: string[] = [];
        columns: TableColumn[] = [
          {
            id: 0,
            field: 'atomicNumber',
            value: 'Número atómico'
          },
          {
            id: 1,
            field: 'name',
            value: 'Nombre'
          },
          {
            id: 2,
            field: 'symbol',
            value: 'Símbolo'
          },
          {
            id: 3,
            field: 'weight',
            value: 'Peso atómico'
          }
        ];

        tableData = [
          {
            atomicNumber: 1,
            name: 'Hidrógeno',
            symbol: 'H',
            weight: 1.00794
          },
          {
            atomicNumber: 2,
            name: 'Helio',
            symbol: 'He',
            weight: 4.002602
          },
          {
            atomicNumber: 3,
            name: 'Litio',
            symbol: 'Li',
            weight: 6.941
          },
          {
            atomicNumber: 4,
            name: 'Berilio',
            symbol: 'Be',
            weight: 9.012183
          },
          {
            atomicNumber: 5,
            name: 'Boro',
            symbol: 'B',
            weight: 10.811
          },
          {
            atomicNumber: 6,
            name: 'Carbono',
            symbol: 'C',
            weight: 12.0107
          },
          {
            atomicNumber: 7,
            name: 'Nitrógeno',
            symbol: 'N',
            weight: 14.0067
          },
          {
            atomicNumber: 8,
            name: 'Oxígeno',
            symbol: 'O',
            weight: 15.9994
          },
          {
            atomicNumber: 9,
            name: 'Flúor',
            symbol: 'F',
            weight: 18.9984032
          }
        ];

        private _setDisplayedColumns(): void {
          this.displayedColumns = this.columns.map((column) => column.field);
        }

        tableDrop(event: CdkDragDrop<string[]>): void {
          moveItemInArray(this.displayedColumns, event.previousIndex, event.currentIndex)
        }

        ngOnInit() {
          this._setDisplayedColumns();
        }
      }`,
      css: `
      .ca-table {
        width: 100%;
        font-size: 14px;
        border-collapse: collapse;
        border: 1px solid #d0d2d3;
        &__row {
          &:nth-child(odd) {
            background-color: #eef2f5;
          }
          &:nth-child(even) {
            background-color: #ffffff;
          }
          &:hover {
            background-color: #dcf1f0;
          }
          &--bordered {
            border-bottom: 1px solid #d0d2d3;
          }
          &--clean {
            &:nth-child(odd) {
              background-color: #ffffff;
            }
            &:hover {
              background-color: inherit;
            }
          }
        }
        &__header {
          padding: 6px 16px;
          text-align: left;
          background-color: #ffffff;
          position: relative;
          cursor: pointer;

          &-container {
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          &-text {
            white-space: nowrap;
          }
        }
        &__cell {
          cursor: pointer;
          height: 32px;
          position: relative;
          padding: 0 16px;
          vertical-align: middle;
          max-width: 90px;
          &-container {
            overflow: hidden;
            text-overflow: ellipsis;
          }
          &-text {
            white-space: nowrap;
          }
        }
      }

      .cdk-drag-preview {
        font-family: Lato;
        font-size: 14px;
        color: #717578;
        font-weight: bold;
        display: flex;
        align-items: center;
      }

      .cdk-drag-placeholder {
        opacity: 0;
        cursor: e-resize;
      }`
    }
  }


  private _setDisplayedColumns(): void {
    this.displayedColumns = this.columns.map((column) => column.field);
    this.displayedActionsColumns = this.actionColumns.map((column) => column.field);
    this.displayedMultiselectableColumns = this.multiselectableColumns.map((column) => column.field);
  }

  private _findRowIndex(array: any[], row: any): number {
    return array.findIndex((item) => {
      return Object.keys(item).every((key) => item[key] === row[key]);
    });
  }

  private _onPageAllCheckedChange(): void {
    this.pageAllChecked = this.tableData.every(el =>
      this._findRowIndex(this._selectedRows,el) >= 0)
  }

  isSelected(row: any): boolean {
    return this._findRowIndex(this._selectedRows, row) !== -1;
  }

  handleRowClick(row: any, ev: Event): void {
    ev.preventDefault();
    const isSelected = this.isSelected(row);
    const tableDataIndex = this._findRowIndex(this.tableData, row);
    if (isSelected) {
      this._selectedRows.splice(this._findRowIndex(this._selectedRows, row), 1);
    } else {
      this._selectedRows.push(this.tableData[tableDataIndex]);
    }
    this._onPageAllCheckedChange();
  }

  selectAllCurrentRows(ev: Event): void {
    ev.preventDefault();
    this.pageAllChecked = !this.pageAllChecked;
    if (this.pageAllChecked) {
      this.tableData.map(element => {
        if(this._findRowIndex(this._selectedRows, element) === -1) {
          this._selectedRows.push(element);
        }
      });
    } else {
      this.tableData.forEach(element => {
        this._selectedRows.splice(this._findRowIndex(this._selectedRows, element), 1);
      });
    }
  }

  private _onPageAllCheckedChangeBis(): void {
    this.pageAllCheckedBis = this.multiselectableTableDataBis.every(el =>
      this._findRowIndex(this._selectedRowsBis,el) >= 0)
  }

  isSelectedBis(row: any): boolean {
    return this._findRowIndex(this._selectedRowsBis, row) !== -1;
  }

  handleRowClickBis(row: any, ev: Event): void {
    ev.preventDefault();
    const isSelected = this.isSelectedBis(row);
    const tableDataIndex = this._findRowIndex(this.tableDataBis, row);
    if (isSelected) {
      this._selectedRowsBis.splice(this._findRowIndex(this._selectedRowsBis, row), 1);
    } else {
      this._selectedRowsBis.push(this.tableDataBis[tableDataIndex]);
    }
    this._onPageAllCheckedChangeBis();
  }

  selectAllCurrentRowsBis(ev: Event): void {
    ev.preventDefault();
    this.pageAllCheckedBis = !this.pageAllCheckedBis;
    if (this.pageAllCheckedBis) {
      this.multiselectableTableDataBis.map(element => {
        if(this._findRowIndex(this._selectedRowsBis, element) === -1) {
          this._selectedRowsBis.push(element);
        }
      });
    } else {
      this.multiselectableTableDataBis.forEach(element => {
        this._selectedRowsBis.splice(this._findRowIndex(this._selectedRowsBis, element), 1);
      });
    }
  }

  tableDrop(event: CdkDragDrop<string[]>): void {
    moveItemInArray(this.displayedColumns, event.previousIndex, event.currentIndex)
  }

  onFilter(query: string) {
		this._filterChange$.next(query);
	}

  paginate(): void {
    this.paginatedTableData = this.tableData?.slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }

  paginateMulti(): void {
    this.multiselectableTableData = this.tableData?.slice((this.multiPage - 1) * this.multiPageSize, (this.multiPage - 1) * this.multiPageSize + this.multiPageSize);
  }

  paginateMultiBis(): void {
    this.multiselectableTableDataBis = this.tableDataBis?.slice((this.multiPageBis - 1) * this.multiPageSizeBis, (this.multiPageBis - 1) * this.multiPageSizeBis + this.multiPageSizeBis);
    this._onPageAllCheckedChangeBis();
  }

  isSelectedRow(row): boolean {
		return this.selectedRow && Object.keys(this.selectedRow).every((key) => this.selectedRow[key] === row[key]);
	}

  onSelectedRow(row: any): void {
    this.preventSingleClick = false;
    this.singleClickTimer = setTimeout(() => {
      if (this.preventSingleClick) {
        return;
      }

      if (!this.isSelectedRow(row)) {
        this.selectedRow = row;
      }
    }, 300);
	}

  onSelectedOption(row: any): void {
    this._modalService.open(ModalTableExampleComponent, {
      title: 'Modal de ejemplo',
      data: {
        type: 'select',
        info: row.name
      }
    });
  }

  onDblClick(row: any): void {
    this.preventSingleClick = true;
    clearTimeout(this.singleClickTimer);

    this._modalService.open(ModalTableExampleComponent, {
      title: 'Modal de ejemplo',
      data: {
        type: 'doble click',
        info: row.name
      }
    })
  }

  sortColumn(column: TableColumn): void {
		this._sortChanges$.next({
			field: column.field,
			isAsc: column.sortAsc = !column.sortAsc
		});
	}

  ngOnInit() {
    this._setDisplayedColumns();
    this.displayedTableData= this.tableData;
    this.paginatedTableData= this.tableData;
    this.multiselectableTableData = this.tableData;
    this.multiselectableTableDataBis = this.tableDataBis;
    this.dataSize = this.paginatedTableData.length;
    this.multiDataSize = this.multiselectableTableData.length;
    this.multiDataSizeBis = this.multiselectableTableDataBis.length;
    this.paginate();
    this.paginateMulti();
    this.paginateMultiBis();
    this.actionsTableData = this.tableData;
    this.sortedTableData = this.tableData;
    this._filterChange$.pipe(takeUntil(this._destroy$),debounceTime(200)).subscribe((value) => {
      this.displayedTableData = this._filterPipe.transform(this.tableData, value);
    });
    this._sortChanges$.pipe(takeUntil(this._destroy$)).subscribe((value) => {
      this.sortedTableData = this._sortByPipe.transform(this.tableData, value);
    })
  }

	ngOnDestroy() {
		this._destroy$.next();
		this._destroy$.complete();
	}
}
