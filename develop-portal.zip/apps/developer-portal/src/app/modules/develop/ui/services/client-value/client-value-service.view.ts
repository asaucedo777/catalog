import { Component } from '@angular/core';

@Component({
  templateUrl: 'client-value-service.view.html',
  styleUrls: ['client-value-service.view.scss']
})
export class ClientValueServiceView {
  moduleContent = `
  import { CaClientValueService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaClientValueService ],
    ...
  })`;
}
