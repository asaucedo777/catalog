import { SubmodaResponse } from "@global-front-components/common";


export const SUBMODA_RESPONSE_MOCK: SubmodaResponse = {
	serviceId: 'ConsultaSubmodasSrv',
	outputMap: {
		mapacoddescripcion: [
			{
				codigo: '000',
				descripcion: 'POLIZA MARFIL GENERICO'
			}
		]
	}
};
