import { ProvincesResponse } from '@global-front-components/common';

export const PROVINCES_RESPONSE_MOCK: ProvincesResponse = {
  "serviceId": "BuscarProvinciaPorNombreSRV",
  "outputMap": {
    "provincias": [
      {
        "tdescripcion": "ALAVA",
        "ccodigo": 1,
        "tdescripcionC": "ALAVA"
      },
      {
        "tdescripcion": "ALBACETE",
        "ccodigo": 2,
        "tdescripcionC": "ALBACETE"
      },
      {
        "tdescripcion": "ALICANTE",
        "ccodigo": 3,
        "tdescripcionC": "ALACANT"
      },
      {
        "tdescripcion": "ALMERIA",
        "ccodigo": 4,
        "tdescripcionC": "ALMERIA"
      },
      {
        "tdescripcion": "AVILA",
        "ccodigo": 5,
        "tdescripcionC": "AVILA"
      },
      {
        "tdescripcion": "BADAJOZ",
        "ccodigo": 6,
        "tdescripcionC": "BADAJOZ"
      },
      {
        "tdescripcion": "ILLES BALEARS",
        "ccodigo": 7,
        "tdescripcionC": "BALEARES"
      },
      {
        "tdescripcion": "BARCELONA",
        "ccodigo": 8,
        "tdescripcionC": "BARCELONA"
      },
      {
        "tdescripcion": "BURGOS",
        "ccodigo": 9,
        "tdescripcionC": "BURGOS"
      },
      {
        "tdescripcion": "CACERES",
        "ccodigo": 10,
        "tdescripcionC": "CACERES"
      },
      {
        "tdescripcion": "CADIZ",
        "ccodigo": 11,
        "tdescripcionC": "CADIZ"
      },
      {
        "tdescripcion": "CASTELLON-CASTELLO",
        "ccodigo": 12,
        "tdescripcionC": "CASTELLON"
      },
      {
        "tdescripcion": "CIUDAD REAL",
        "ccodigo": 13,
        "tdescripcionC": "CIUDAD REAL"
      },
      {
        "tdescripcion": "CORDOBA",
        "ccodigo": 14,
        "tdescripcionC": "CORDOBA"
      },
      {
        "tdescripcion": "A CORUÑA",
        "ccodigo": 15,
        "tdescripcionC": "LA CORUÑA"
      },
      {
        "tdescripcion": "CUENCA",
        "ccodigo": 16,
        "tdescripcionC": "CUENCA"
      },
      {
        "tdescripcion": "GIRONA",
        "ccodigo": 17,
        "tdescripcionC": "GERONA"
      },
      {
        "tdescripcion": "GRANADA",
        "ccodigo": 18,
        "tdescripcionC": "GRANADA"
      },
      {
        "tdescripcion": "GUADALAJARA",
        "ccodigo": 19,
        "tdescripcionC": "GUADALAJARA"
      },
      {
        "tdescripcion": "GUIPUZCOA",
        "ccodigo": 20,
        "tdescripcionC": "GUIPUZCOA"
      },
      {
        "tdescripcion": "HUELVA",
        "ccodigo": 21,
        "tdescripcionC": "HUELVA"
      },
      {
        "tdescripcion": "HUESCA",
        "ccodigo": 22,
        "tdescripcionC": "HUESCA"
      },
      {
        "tdescripcion": "JAEN",
        "ccodigo": 23,
        "tdescripcionC": "JAEN"
      },
      {
        "tdescripcion": "LEON",
        "ccodigo": 24,
        "tdescripcionC": "LEON"
      },
      {
        "tdescripcion": "LLEIDA",
        "ccodigo": 25,
        "tdescripcionC": "LERIDA"
      },
      {
        "tdescripcion": "LA RIOJA",
        "ccodigo": 26,
        "tdescripcionC": "LA RIOJA"
      },
      {
        "tdescripcion": "LUGO",
        "ccodigo": 27,
        "tdescripcionC": "LUGO"
      },
      {
        "tdescripcion": "MADRID",
        "ccodigo": 28,
        "tdescripcionC": "MADRID"
      },
      {
        "tdescripcion": "MALAGA",
        "ccodigo": 29,
        "tdescripcionC": "MALAGA"
      },
      {
        "tdescripcion": "MURCIA",
        "ccodigo": 30,
        "tdescripcionC": "MURCIA"
      },
      {
        "tdescripcion": "NAVARRA",
        "ccodigo": 31,
        "tdescripcionC": "NAVARRA"
      },
      {
        "tdescripcion": "OURENSE",
        "ccodigo": 32,
        "tdescripcionC": "ORENSE"
      },
      {
        "tdescripcion": "ASTURIAS",
        "ccodigo": 33,
        "tdescripcionC": "ASTURIAS"
      },
      {
        "tdescripcion": "PALENCIA",
        "ccodigo": 34,
        "tdescripcionC": "PALENCIA"
      },
      {
        "tdescripcion": "LAS PALMAS",
        "ccodigo": 35,
        "tdescripcionC": "LAS PALMAS"
      },
      {
        "tdescripcion": "PONTEVEDRA",
        "ccodigo": 36,
        "tdescripcionC": "PONTEVEDRA"
      },
      {
        "tdescripcion": "SALAMANCA",
        "ccodigo": 37,
        "tdescripcionC": "SALAMANCA"
      },
      {
        "tdescripcion": "SANTA CRUZ DE TENERIFE",
        "ccodigo": 38,
        "tdescripcionC": "S,C,TENERIFE"
      },
      {
        "tdescripcion": "CANTABRIA",
        "ccodigo": 39,
        "tdescripcionC": "CANTABRIA"
      },
      {
        "tdescripcion": "SEGOVIA",
        "ccodigo": 40,
        "tdescripcionC": "SEGOVIA"
      },
      {
        "tdescripcion": "SEVILLA",
        "ccodigo": 41,
        "tdescripcionC": "SEVILLA"
      },
      {
        "tdescripcion": "SORIA",
        "ccodigo": 42,
        "tdescripcionC": "SORIA"
      },
      {
        "tdescripcion": "TARRAGONA",
        "ccodigo": 43,
        "tdescripcionC": "TARRAGONA"
      },
      {
        "tdescripcion": "TERUEL",
        "ccodigo": 44,
        "tdescripcionC": "TERUEL"
      },
      {
        "tdescripcion": "TOLEDO",
        "ccodigo": 45,
        "tdescripcionC": "TOLEDO"
      },
      {
        "tdescripcion": "VALENCIA",
        "ccodigo": 46,
        "tdescripcionC": "VALENCIA"
      },
      {
        "tdescripcion": "VALLADOLID",
        "ccodigo": 47,
        "tdescripcionC": "VALLADOLID"
      },
      {
        "tdescripcion": "VIZCAYA",
        "ccodigo": 48,
        "tdescripcionC": "BIZKAIA"
      },
      {
        "tdescripcion": "ZAMORA",
        "ccodigo": 49,
        "tdescripcionC": "ZAMORA"
      },
      {
        "tdescripcion": "ZARAGOZA",
        "ccodigo": 50,
        "tdescripcionC": "ZARAGOZA"
      },
      {
        "tdescripcion": "CEUTA",
        "ccodigo": 51,
        "tdescripcionC": "CEUTA"
      },
      {
        "tdescripcion": "MELILLA",
        "ccodigo": 52,
        "tdescripcionC": "MELILLA"
      },
      {
        "tdescripcion": "ANDORRA",
        "ccodigo": 53,
        "tdescripcionC": "ANDORRA"
      }
    ]
  }
}
