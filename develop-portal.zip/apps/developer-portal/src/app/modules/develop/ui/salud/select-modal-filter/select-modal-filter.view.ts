import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CaSelectModalFilterConfig } from '@global-front-components/salud';
import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';
import { ExampleModalComponent } from './example-modal/example-modal.component';
@Component({
	templateUrl: 'select-modal-filter.view.html'
})
export class SelectModalFilterView implements OnInit {
	constructor(private _formBuilder: FormBuilder) {}
	importModule = `import { CaSelectModalFilterService } from '@global-front-components/salud';`;

	caseSimple: ComponentDoc = {
		title: `Uso simple`,
		codeExample: {
			html: `
      <ca-select-modal-filter formControlName="policy" [labelName]="labelName" [selectPlaceHolder]="selectPlaceHolder"
        [selectModalConfig]="modalConfig">
      </ca-select-modal-filter>
    `,
			ts: `import { Component, OnInit } from '@angular/core';
      import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';
      import { ExampleModalComponent } from './modal-punto-venta/modal-punto-venta.component';

      @Component({
          selector: 'punto-venta',
          templateUrl: 'punto-venta.component.html'
      })

      export class PuntoVentaComponent implements OnInit {

        modalConfig = {
        component: ExampleModalComponent,
        modalConfig: {
          title: 'Modal Punto de Venta',
          windowDrag: false,
          backdropClick: false
        }
      };
        labelName = 'Código de punto de venta';
        selectPlaceHolder = 'Seleccione punto de venta';

        constructor() { }

        ngOnInit() {

        }
    }
`
		}
	};
	caseReactive: ComponentDoc = {
		title: `Uso reactivo`,
		codeExample: {
			html: `<form [formGroup]="form">
      <ca-select-modal-filter formControlName="salePoint" [labelName]="labelName" [selectPlaceHolder]="selectPlaceHolder"
        [selectModalConfig]="modalConfig">
      </ca-select-modal-filter>
    </form>`,
			ts: `import { Component, OnInit } from '@angular/core';
      import { FormBuilder, FormGroup } from '@angular/forms';
      import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';
      import { ExampleModalComponent } from './modal-punto-venta/modal-punto-venta.component';

      @Component({
          selector: 'punto-venta',
          templateUrl: 'punto-venta.component.html'
      })

      export class PuntoVentaComponent implements OnInit {
        form: FormGroup;
        modalConfig = {
        component: ExampleModalComponent,
        modalConfig: {
          title: 'Modal Punto de Venta',
          windowDrag: false,
          backdropClick: false
        }
      };
        labelName = 'Código de punto de venta';
        selectPlaceHolder = 'Seleccione punto de venta';

        constructor(private _formBuilder: FormBuilder) { }

        ngOnInit() {

          this.form = this._formBuilder.group({
            salePoint: ['', [Validators.required]]
          });
        }
    }
`
		}
	};
	caseSimpleWithInitialValues: ComponentDoc = {
		title: `Uso simple con valores iniciales en el select`,
		codeExample: {
			html: `
      <ca-select-modal-filter [formOptions]="optionsValue" [labelName]="labelName"
      [selectPlaceHolder]="selectPlaceHolder" [selectModalConfig]="modalConfig">
    </ca-select-modal-filter>
    `,
			ts: `import { Component, OnInit } from '@angular/core';
      import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';
      import { ExampleModalComponent } from './modal-punto-venta/modal-punto-venta.component';

      @Component({
          selector: 'punto-venta',
          templateUrl: 'punto-venta.component.html'
      })

      export class PuntoVentaComponent implements OnInit {

        modalConfig = {
        component: ExampleModalComponent,
        modalConfig: {
          title: 'Modal Punto de Venta',
          windowDrag: false,
          backdropClick: false
        }
      };
        labelName = 'Código de punto de venta';
        selectPlaceHolder = 'Seleccione punto de venta';
        public optionsValue = [
          {
            value: 0,
            textValue: 'Primera opción'
          },
          {
            value: 1,
            textValue: 'Segunda opción'
          },
          {
            value: 2,
            textValue: 'Tercera opción'
          }
        ];
        constructor() { }

        ngOnInit() {

        }
    }
`
		}
	};
	caseReactiveWithInitialValues: ComponentDoc = {
		title: `Uso reactivo con valores iniciales en el select`,
		codeExample: {
			html: `<form [formGroup]="form">
      <ca-select-modal-filter formControlName="salePoint" [formOptions]="optionsValue" [value]="optionsDefaultValue" [labelName]="labelName"
        [selectPlaceHolder]="selectPlaceHolder" [selectModalConfig]="modalConfig">
      </ca-select-modal-filter>
    </form>`,
			ts: `import { Component, OnInit } from '@angular/core';
      import { FormBuilder, FormGroup } from '@angular/forms';
      import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';
      import { ExampleModalComponent } from './modal-punto-venta/modal-punto-venta.component';

      @Component({
          selector: 'punto-venta',
          templateUrl: 'punto-venta.component.html'
      })

      export class PuntoVentaComponent implements OnInit {
        form: FormGroup;
        modalConfig = {
        component: ExampleModalComponent,
        modalConfig: {
          title: 'Modal Punto de Venta',
          windowDrag: false,
          backdropClick: false
        }
      };
        labelName = 'Código de punto de venta';
        selectPlaceHolder = 'Seleccione punto de venta';
        public optionsValue = [
          {
            value: 0,
            textValue: 'Primera opción'
          },
          {
            value: 1,
            textValue: 'Segunda opción'
          },
          {
            value: 2,
            textValue: 'Tercera opción'
          }
        ];
        constructor(private _formBuilder: FormBuilder) { }

        ngOnInit() {

          this.form = this._formBuilder.group({
            salePoint: ['', [Validators.required]]
          });
        }
    }
`
		}
	};
	caseSimpleDisabled: ComponentDoc = {
		title: `Uso simple con select deshabilitado`,
		codeExample: {
			html: `
      <ca-select-modal-filter formControlName="policy" [labelName]="labelName" [selectPlaceHolder]="selectPlaceHolder"
        [selectModalConfig]="modalConfig">
      </ca-select-modal-filter>
    `,
			ts: `import { Component, OnInit } from '@angular/core';
      import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';
      import { ExampleModalComponent } from './modal-punto-venta/modal-punto-venta.component';

      @Component({
          selector: 'punto-venta',
          templateUrl: 'punto-venta.component.html'
      })

      export class PuntoVentaComponent implements OnInit {

        modalConfig = {
        component: ExampleModalComponent,
        modalConfig: {
          title: 'Modal Punto de Venta',
          windowDrag: false,
          backdropClick: false
        }
      };
        labelName = 'Código de punto de venta';
        selectPlaceHolder = 'Seleccione punto de venta';
        disabled = true;
        constructor() { }

        ngOnInit() {

        }
    }
`
		}
	};
  caseExampleModal: ComponentDoc = {
		title: `Modal Punto de Venta`,
		codeExample: {
			html: `<form [formGroup]="form" class="form">
      <ca-form-field class="ca-form-field-1">
        <ca-label>NIF</ca-label>
        <input caInput formControlName="NIF" placeholder="NIF" type="text" />
      </ca-form-field>
      <button ca-button-secondary  >
        <i class="material-icons">search</i>
      </button>
      <ca-form-field class="ca-form-field-1">
        <ca-label>Código de punto de venta</ca-label>
        <input caInput formControlName="salePoint" placeholder="Código de punto de venta" type="text" />
      </ca-form-field>
      <button ca-button-secondary >
        <i class="material-icons">search</i>
      </button>
    </form>
    <div class="mt-3">
    <table cdk-table [dataSource]="tableData" class="ca-table">
        <ng-container *ngFor="let column of columns; let i = index" [cdkColumnDef]="column.field">
          <th cdk-header-cell *cdkHeaderCellDef class="ca-table__header">
            <div class="ca-table__header-container justify-content-start">
              <span class="ca-table__header-wrapper">
                <span class="ca-table__header-text">{{ column.value }}</span>
              </span>
            </div>
          </th>
          <td cdk-cell *cdkCellDef="let row; let i = index" class="ca-table__cell">
            <div class="ca-table__cell-container">
              <span class="ca-table__cell-text">
                {{ row[column.field] }}
              </span>
            </div>
          </td>
        </ng-container>
        <thead class="ca-table__thead">
          <tr cdk-header-row *cdkHeaderRowDef="displayedColumns"
            class="ca-table__row ca-table__row--bordered ca-table__row--clean"></tr>
        </thead>
        <tbody class="ca-table__tbody">
          <tr cdk-row *cdkRowDef="let row; columns: displayedColumns; let i = index" class="ca-table__row"></tr>
        </tbody>
      </table>
    </div>
      <div class="d-flex justify-content-between mt-3">
        <button ca-button-secondary (click)="closeDialog()">Salir</button>
        <button ca-button (click)="closeDialog()">Aceptar</button>
      </div>`,
			ts: `import { Component, OnInit } from '@angular/core';
      import { FormBuilder, FormGroup, Validators } from '@angular/forms';
      import { CaModalOverlayRef } from '@global-front-components/ui';
      import { Subject } from 'rxjs';
      interface TableColumn {
        id: number;
        field: string;
        value: string;
      }

      @Component({
        selector: 'modal-punto-venta',
        templateUrl: 'modal-punto-venta.component.html',
        styleUrls: ['./modal-punto-venta.component.scss']
      })
      export class ExampleModalComponent implements OnInit {
        constructor(
          private _formBuilder: FormBuilder,
          private _caModalOverlayRef: CaModalOverlayRef<ExampleModalComponent>
        ) {}
        private _destroy$: Subject<void> = new Subject();

        public form: FormGroup;
        displayedColumns: string[] = [];
        columns: TableColumn[] = [
          {
            id: 0,
            field: 'code',
            value: 'Código'
          },
          {
            id: 1,
            field: 'salePoint',
            value: 'Descripción'
          }
        ];

        tableData = [
          {
            code: 1,
            salePoint: 'Punto de venta 1'
          },
          {
            code: 2,
            salePoint: 'Punto de venta 2'
          }
        ];
        private _form(): void {
          this.form = this._formBuilder.group({
            NIF: ['', [Validators.required]],
            salePoint: ['', [Validators.required]]
          });
        }
        private _setDisplayedColumns(): void {
          this.displayedColumns = this.columns.map((column) => column.field);
        }
        closeDialog(): void {
              const arrayData = [
                  {
                      value: 0,
                      textValue: '33300100 - Punto de venta 1'
              },
                  {
                      value: 1,
                      textValue: '33300101 - Punto de venta 2'
              }
              ];
          this._caModalOverlayRef.close(arrayData);
        }

        ngOnInit() {
          this._form();
          this._setDisplayedColumns();
        }
        ngOnDestroy() {
          this._destroy$.next();
          this._destroy$.complete();
        }
      }
      `,
			css: `.ca-table {
        width: 100%;
        font-size: 14px;
        border-collapse: collapse;
        border: 1px solid #d0d2d3;
        &__row {
          &:nth-child(odd) {
            background-color: #eef2f5;
          }
          &:nth-child(even) {
            background-color: #ffffff;
          }
          &:hover {
            background-color: #dcf1f0;
          }
          &--bordered {
            border-bottom: 1px solid #d0d2d3;
          }
          &--clean {
            &:nth-child(odd) {
              background-color: #ffffff;
            }
            &:hover {
              background-color: inherit;
            }
          }
        }
        &__header {
          padding: 6px 16px;
          text-align: left;
          background-color: #ffffff;

          &-container {
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          &-text {
            white-space: nowrap;
          }
        }
        &__cell {
          cursor: pointer;
          height: 32px;
          position: relative;
          padding: 0 16px;
          vertical-align: middle;
          max-width: 90px;
          &-container {
            overflow: hidden;
            text-overflow: ellipsis;
          }
          &-text {
            white-space: nowrap;
          }
        }
      }

      .filter-container {
        display: flex;
        align-items: flex-end;
        .ca-form-field {
            margin-right: 4px;

          &:first-child {
            width: 500px;
          }
        }
        button.ca-button-secondary {
          min-width: 32px;
          margin-right: 4px;
          margin-left: 4px;
          padding: 0;
          height: 32px;
          i.material-icons {
            font-size: 20px;
          }
        }
      }
      `
		}
	};

  public optionsValue = [
    {
      value: 0,
      textValue: 'Primera opción'
    },
    {
      value: 1,
      textValue: 'Segunda opción'
    },
    {
      value: 2,
      textValue: 'Tercera opción'
    }
  ];
	form: FormGroup;
	modalConfig: CaSelectModalFilterConfig = {
		component: ExampleModalComponent,
		modalConfig: {
			title: 'Modal Punto de Venta',
			windowDrag: false,
			backdropClick: false
		}
	};
	labelName = 'Código de punto de venta';
	selectPlaceHolder = 'Seleccione punto de venta';
	optionsDefaultValue: any;
	private;
	disabled = true;

	ngOnInit() {
		this.form = this._formBuilder.group({
			salePoint: ['', [Validators.required]]
		});
	}
}
