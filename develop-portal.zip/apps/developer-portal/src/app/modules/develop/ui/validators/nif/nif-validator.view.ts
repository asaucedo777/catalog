import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import {
  CaDniValidator,
  CaNieValidator,
  CaCifValidator,
  CaNifValidator
} from '@global-front-components/common';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
@Component({
  templateUrl: 'nif-validator.view.html',
  styleUrls: ['nif-validator.view.scss']
})
export class NifValidatorView implements OnInit{
  constructor(private _formBuilder: FormBuilder) {}
  form: FormGroup;

  caseDni: ComponentDoc = {
    title: 'Validador de DNI',
    codeExample: {
      html: `
      <form [formGroup]="form">
        <ca-form-field>
          <ca-label>DNI</ca-label>
          <input type="text" caInput formControlName="dni">
          <ca-error *ngIf="form.get('dni').errors?.invalidDni">DNI inválido</ca-error>
        </ca-form-field>
      </form>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { FormBuilder, FormGroup } from '@angular/forms';
      import { CaDniValidator } from '@global-front-components/common';

      @Component({
        selector: 'dni-validator-example'
        templateUrl: 'dni-validator-example.component.html',
        styleUrls: ['dni-validator-example.component.scss']
      })
      export class DniValidatorExampleComponent implements OnInit {
        constructor(private _formBuilder: FormBuilder) {}
        form: FormGroup;

        ngOnInit() {
          this.form = this._formBuilder.group({
            dni: ['',CaDniValidator('invalidDni')]
          });
        }
      }`
    }
  };

  caseNie: ComponentDoc = {
    title: 'Validador de NIE',
    codeExample: {
      html: `
      <form [formGroup]="form">
        <ca-form-field>
          <ca-label>NIE</ca-label>
          <input type="text" caInput formControlName="nie">
          <ca-error *ngIf="form.get('nie').errors?.invalidNie">NIE inválido</ca-error>
        </ca-form-field>
      </form>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { FormBuilder, FormGroup } from '@angular/forms';
      import { CaNieValidator } from '@global-front-components/common';

      @Component({
        selector: 'nie-validator-example'
        templateUrl: 'nie-validator-example.component.html',
        styleUrls: ['nie-validator-example.component.scss']
      })
      export class NieValidatorExampleComponent implements OnInit {
        constructor(private _formBuilder: FormBuilder) {}
        form: FormGroup;

        ngOnInit() {
          this.form = this._formBuilder.group({
            nie: ['',CaNieValidator('invalidNie')]
          });
        }
      }`
    }
  };

  caseCif: ComponentDoc = {
    title: 'Validador de CIF',
    codeExample: {
      html: `
      <form [formGroup]="form">
        <ca-form-field>
          <ca-label>CIF</ca-label>
          <input type="text" caInput formControlName="cif">
          <ca-error *ngIf="form.get('cif').errors?.invalidCif">CIF inválido</ca-error>
        </ca-form-field>
      </form>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { FormBuilder, FormGroup } from '@angular/forms';
      import { CaCifiValidator } from '@global-front-components/common';

      @Component({
        selector: 'cif-validator-example'
        templateUrl: 'cif-validator-example.component.html',
        styleUrls: ['cif-validator-example.component.scss']
      })
      export class CifValidatorExampleComponent implements OnInit {
        constructor(private _formBuilder: FormBuilder) {}
        form: FormGroup;

        ngOnInit() {
          this.form = this._formBuilder.group({
            cif: ['',CaCifValidator('invalidCif')]
          });
        }
      }`
    }
  };

  caseNif: ComponentDoc = {
    title: 'Validador de NIF',
    description: `Este validador incluye a los anteriores, es decir, valida si el campo es un DNI, NIE o CIF.`,
    codeExample: {
      html: `
      <form [formGroup]="form">
        <ca-form-field>
          <ca-label>NIF</ca-label>
          <input type="text" caInput formControlName="nif">
          <ca-error *ngIf="form.get('nif').errors?.invalidNif">NIF inválido</ca-error>
        </ca-form-field>
      </form>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { FormBuilder, FormGroup } from '@angular/forms';
      import { CaNifiValidator } from '@global-front-components/common';

      @Component({
        selector: 'nif-validator-example'
        templateUrl: 'nif-validator-example.component.html',
        styleUrls: ['nif-validator-example.component.scss']
      })
      export class NifValidatorExampleComponent implements OnInit {
        constructor(private _formBuilder: FormBuilder) {}
        form: FormGroup;

        ngOnInit() {
          this.form = this._formBuilder.group({
            nif: ['',CaNifValidator('invalidNif')]
          });
        }
      }`
    }
  };

  ngOnInit() {
    this.form = this._formBuilder.group({
      dni: ['',CaDniValidator('invalidDni')],
      nie: ['',CaNieValidator('invalidNie')],
      cif: ['',CaCifValidator('invalidCif')],
      nif: ['',CaNifValidator('invalidNif')]
    });
  }
}
