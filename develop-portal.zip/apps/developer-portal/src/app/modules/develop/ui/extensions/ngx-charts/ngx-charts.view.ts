import { Component } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
  templateUrl: 'ngx-charts.view.html',
  styleUrls: ['ngx-charts.view.scss']
})
export class NgxChartsView {
  installContent = 'npm install @swimlane/ngx-charts';
  moduleContent = `import { NgxChartsModule } from '@swimlane/ngx-charts';`
  animationsModule = `import { BrowserAnimationsModule } from '@angular/platform-browser/animations'`;

  multi =  [
    {
      "name": "Alemania",
      "series": [
        {
          "name": "2010",
          "value": 7300000
        },
        {
          "name": "2011",
          "value": 8940000
        }
      ]
    },

    {
      "name": "EEUU",
      "series": [
        {
          "name": "2010",
          "value": 7870000
        },
        {
          "name": "2011",
          "value": 8270000
        }
      ]
    },

    {
      "name": "Francia",
      "series": [
        {
          "name": "2010",
          "value": 5000002
        },
        {
          "name": "2011",
          "value": 5800000
        }
      ]
    }
  ];
  view = [700, 400];
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  legendTitle = 'Leyenda';
  showLegend = true;
  showXAxisLabel = true;
  xAxisLabel= 'País';
  showYAxisLabel = true;
  yAxisLabel= 'Población';
  animations = true;

  colorScheme = {
    domain: ['#5AA454', '#C7B42C', '#AAAAAA']
  };

  caseBarVerticalStacked: ComponentDoc = {
    title: 'Gráfico de barras verticales',
    description: `En este caso se muestra un ejemplo de un gráafico de barras verticales apiladas.`,
    codeExample: {
      html: `
<ngx-charts-bar-vertical-stacked
  [view]="view"
  [scheme]="colorScheme"
  [results]="multi"
  [gradient]="gradient"
  [xAxis]="showXAxis"
  [yAxis]="showYAxis"
  [legend]="showLegend"
  [legendTitle]="legendTitle"
  [showXAxisLabel]="showXAxisLabel"
  [showYAxisLabel]="showYAxisLabel"
  [xAxisLabel]="xAxisLabel"
  [yAxisLabel]="yAxisLabel"
  [animations]="animations">
</ngx-charts-bar-vertical-stacked>`,
      ts: `
      multi =  [
        {
          "name": "Alemania",
          "series": [
            {
              "name": "2010",
              "value": 7300000
            },
            {
              "name": "2011",
              "value": 8940000
            }
          ]
        },

        {
          "name": "EEUU",
          "series": [
            {
              "name": "2010",
              "value": 7870000
            },
            {
              "name": "2011",
              "value": 8270000
            }
          ]
        },

        {
          "name": "Francia",
          "series": [
            {
              "name": "2010",
              "value": 5000002
            },
            {
              "name": "2011",
              "value": 5800000
            }
          ]
        }
      ];
      view = [700, 400];
      showXAxis = true;
      showYAxis = true;
      gradient = false;
      legendTitle = 'Leyenda';
      showLegend = true;
      showXAxisLabel = true;
      xAxisLabel= 'País';
      showYAxisLabel = true;
      yAxisLabel= 'Población';
      animations = true;

      colorScheme = {
        domain: ['#5AA454', '#C7B42C', '#AAAAAA']
      };`
    }
  };
}
