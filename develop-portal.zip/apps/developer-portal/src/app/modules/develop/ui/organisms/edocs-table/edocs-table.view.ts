import { Component, OnInit } from '@angular/core';
import { Property } from '@global-front-components/ui';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
  selector: 'ca-edocs-table',
  templateUrl: './edocs-table.view.html',
  styleUrls: ['./edocs-table.view.scss']
})
export class EdocsTableView implements OnInit {
  public moduleContent = `import { CaEdocsTableModule } from '@global-front-components/ui';`;

  userName:string;
  password: string;
  searchProperties: Property[] =  [
    { Key: 'CIA_ID', Value: '0001' },
    { Key: 'RAMO_ID', Value: '30' },
    { Key: 'MODA_ID', Value: '92' },
    { Key: 'SUBMODA_ID', Value: '000' },
    { Key: 'COLECTIVA', Value: '0' },
    { Key: 'CERTIFICADO', Value: '00000000' }
  ]
  seed = 'RE0xMElOVEU6Q0J2eWlkSFRheVRiWkZOUGNrME9tdz09';

  caseEdocTable: ComponentDoc = {
    title: "Uso de la tabla",
    description: `
      <p>Para utilizar en compoenete añadiremos la etiqueta  <code class="tag">ca-ed-table</code>.</p>
      <p>Recibe como input <code class="attribute">searchProperties</code>, un array de tipo <code class="attribute">Property</code> . con la propiedades en base a las cuales realizara la busqueda de documentos.</p>
      <p>Opcionalmente podemos pasarela por los inputs <code class="attribute">userName</code> <code class="attribute">password</code> las credenciales para que realice el login de forma automática</p>

      <p>Las aplicaciones que hagan uso del componente de Gestión Documental de Caser deberán incluir en sus ficheros las semillas de <code class="attribute">Authorization</code> de los diferentes entornos de eDOCs por necesidades del propio entorno. Para conocer dichas semillas
      consultar con el departamente de eDOCs</p>
    `,
    codeExample: {
      html : '<ca-ed-table [userName]="userName" [password]="password" [searchProperties]="searchProperties" [seed]="seed"></ca-ed-table>',
      ts: `
      import { Property } from '@caser-architecture/ui';
      import { environment } from '../environment'; // La ruta varia según el proyecto

      export class MyClass{

        userName = 'myUser';
        password = 'myPassword;
        searchProperties:  Property[] =  [
          { Key: 'CIA_ID', Value: '0001' },
          { Key: 'RAMO_ID', Value: '30' },
          { Key: 'MODA_ID', Value: '92' },
          { Key: 'SUBMODA_ID', Value: '000' },
          { Key: 'COLECTIVA', Value: '0' },
          { Key: 'CERTIFICADO', Value: '00000000' }
        ]
        seed = environment.edocs.seed // La posición del valor de la semilla varía según el proyecto.
      }
      `
    }
  }

  constructor() { }

  ngOnInit(): void {
  }

}
