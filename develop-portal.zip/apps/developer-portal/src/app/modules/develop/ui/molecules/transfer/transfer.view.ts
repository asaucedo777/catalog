import { Component } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { CaTransferValue, CaTreeNode, CaTransferColumn } from '@global-front-components/ui';

@Component({
	templateUrl: 'transfer.view.html',
	styleUrls: ['transfer.view.scss']
})
export class TransferView {
	registros = [
		'Consulta XML modelos presentados',
		'Comparación información modelo 190',
		'Comparación información modelo 188',
		'Consulta por NIF de AEAT',
		'Administración'
	];
	registrosDerecha = ['Administración usuarios', 'Acceso al tratamiento del modelo 290'];
	registrosConObjetos = [
		{ text: 'Consulta XML modelos presentados', code: '001' },
		{ text: 'Comparación información modelo 190', code: '002' },
		{ text: 'Comparación información modelo 188', code: '003' },
		{ text: 'Consulta por NIF de AEAT', code: '004' },
		{ text: 'Administración', code: '005' },
		{ text: 'Administración usuarios', code: '006' },
		{ text: 'Acceso al tratamiento del modelo 290', code: '007' }
	];

	columns: CaTransferColumn[] = [
		{
			header: 'Código',
			columnDef: 'code'
		},
		{
			header: 'Descripción',
			columnDef: 'text'
		}
	];

	treeLeft: CaTreeNode[] = [
		{
			label: 'Prueba 1',
			expanded: false,
			selected: false,
			children: [
				{
					label: 'Prueba hijo 1',
					expanded: false,
					selected: false,
					children: [
						{
							label: 'Prueba hijo 1 hijo 1',
							expanded: false,
							selected: false
						}
					]
				},
				{
					label: 'Prueba hijo 2',
					expanded: false,
					selected: false
				},
				{
					label: 'Prueba hijo 3',
					expanded: false,
					selected: false
				},
				{
					label: 'Prueba hijo 4',
					expanded: false,
					selected: false
				}
			]
		},
		{
			label: 'Prueba 2',
			expanded: false,
			selected: false
		},
		{
			label: 'Prueba 3',
			expanded: false,
			selected: false,
			children: [
				{
					label: 'Prueba 3 hijo 1',
					expanded: false,
					selected: false,
					children: [
						{
							label: 'Prueba 3  hijo 1 hijo 2',
							expanded: false,
							selected: false,
							children: [
								{
									label: 'Prueba 3 hijo 2 hijo 3',
									expanded: false,
									selected: false,
									children: [
										{
											label: 'Prueba 3 hijo 3 hijo 4',
											expanded: false,
											selected: false
										}
									]
								}
							]
						}
					]
				}
			]
		}
	];

	treeRight: CaTreeNode[] = [];

	moduleContent = `import { CaTransferModule } from '@global-front-components/ui';`;
	caseOne: ComponentDoc = {
		title: 'Uso con array de strings',
		description: `<p>Uso pasando un array de string al Input elements.</p>`,
		codeExample: {
			html: `
      <ca-transfer
        [leftPanelElements]="registros"
        leftPanelHeader="Menús disponibles"
        rightPanelHeader="Menús por rol"
        (valueChange)="onValueChange($event)"
      ></ca-transfer>`,
			ts: `
      import { Component } from '@angular/core';
      import { CaTransferValue } from '@global-front-components/ui';

      @Component({
        selector: 'ca-transfer-view',
        templateUrl: 'transfer-view.component.html'
      })
      export class TransferPageComponent {
        registros = [
          "Consulta XML modelos presentados",
          "Comparación información modelo 190",
          "Comparación información modelo 188",
          "Consulta por NIF de AEAT",
          "Administración",
          "Administración usuarios",
          "Acceso al tratamiento del modelo 290"
        ];

        onValueChange(event: CaTransferValue): void {
          console.log(event);
        }
      }`
		}
	};

	caseTwo: ComponentDoc = {
		title: 'Uso con array de objetos',
		description: `<p>Uso pasando un array de objetos y el valor de la clave a usar en cada objeto.</p>`,
		codeExample: {
			html: `
      <ca-transfer
        [leftPanelElements]="registrosConObjetos"
        keyValue="text"
        leftPanelHeader="Menús disponibles"
        rightPanelHeader="Menús por rol"
        (valueChange)="onValueChange($event)"
      ></ca-transfer>`,
			ts: `
      import { Component } from '@angular/core';
      import { CaTransferValue } from '@global-front-components/ui';

      @Component({
        selector: 'ca-transfer-view',
        templateUrl: 'transfer-view.component.html'
      })
      export class TransferPageComponent {
        registrosConObjetos = [
          {text: "Consulta XML modelos presentados" },
          {text: "Comparación información modelo 190" },
          {text: "Comparación información modelo 188" },
          {text: "Consulta por NIF de AEAT" },
          {text: "Administración" },
          {text: "Administración usuarios" },
          {text: "Acceso al tratamiento del modelo 290" }
        ];

        onValueChange(event: CaTransferValue): void {
          console.log(event);
        }
      }`
		}
	};

	caseTable: ComponentDoc = {
		title: 'Uso con array de objetos 2',
		description: `<p>Si necesetimos visualizar mas de un campo del objeto, podemos renderizar una tabla dentro del transfer. Le indicaremos que columnas ha de mostrar a traves el imput "colums"</p>`,
		codeExample: {
			html: `
      <ca-transfer
        [leftPanelElements]="registrosConObjetos"
        [columns]="columns"
        leftPanelHeader="Menús disponibles"
        rightPanelHeader="Menús por rol"
        (valueChange)="onValueChange($event)"
      ></ca-transfer>`,
			ts: `
      import { Component } from '@angular/core';
      import { CaTransferValue, CaTransferColumn } from '@global-front-components/ui';

      @Component({
        selector: 'ca-transfer-view',
        templateUrl: 'transfer-view.component.html'
      })
      export class TransferPageComponent {
        registrosConObjetos = [
          { text: 'Consulta XML modelos presentados', code: '001' },
          { text: 'Comparación información modelo 190', code: '002' },
          { text: 'Comparación información modelo 188', code: '003' },
          { text: 'Consulta por NIF de AEAT', code: '004' },
          { text: 'Administración', code: '005' },
          { text: 'Administración usuarios', code: '006' },
          { text: 'Acceso al tratamiento del modelo 290', code: '007' }
        ];

        columns: CaTransferColumn[] = [
          {
            header: 'Código',
            columnDef: 'code'
          },
          {
            header: 'Descripción',
            columnDef: 'text'
          }
        ];

        onValueChange(event: CaTransferValue): void {
          console.log(event);
        }
      }`
		}
	};

	caseThree: ComponentDoc = {
		title: 'Uso con elementos iniciales en ambos paneles',
		description: `<p>Se pasan dos arrays a su input correspondiente, uno para los elementos del panel izquierdo y otro para el del derecho.</p>`,
		codeExample: {
			html: `
      <ca-transfer
       [leftPanelElements]="registros"
       [rightPanelElements]="registrosDerecha"
       leftPanelHeader="Menús disponibles"
       rightPanelHeader="Menús por rol"
       (valueChange)="onValueChange($event)"
      ></ca-transfer>`,
			ts: `
      import { Component } from '@angular/core';
      import { CaTransferValue } from '@global-front-components/ui';

      @Component({
        selector: 'ca-transfer-view',
        templateUrl: 'transfer-view.component.html'
      })
      export class TransferPageComponent {
        registros = [
          "Consulta XML modelos presentados",
          "Comparación información modelo 190",
          "Comparación información modelo 188",
          "Consulta por NIF de AEAT",
          "Administración",
          "Administración usuarios",
          "Acceso al tratamiento del modelo 290"
        ];
        registrosDerecha = [
          "Administración usuarios",
          "Acceso al tratamiento del modelo 290"
        ];
        onValueChange(event: CaTransferValue): void {
          console.log(event);
        }
      }`
		}
	};

	caseFour: ComponentDoc = {
		title: 'Uso con estado deshabilitado',
		description: `<p>Para simplemente visualizar el componente sin poder interactuar con él, bastará con añadirle el atributo <code class="attribute">disabled</code>.</p>`,
		codeExample: {
			html: `
      <ca-transfer
        disabled
        [leftPanelElements]="registros"
        [rightPanelElements]="registrosDerecha"
        leftPanelHeader="Menús disponibles"
        rightPanelHeader="Menús por rol"
      ></ca-transfer>`,
			ts: `
      import { Component } from '@angular/core';

      @Component({
        selector: 'ca-transfer-view',
        templateUrl: 'transfer-view.component.html'
      })
      export class TransferPageComponent {
        registros = [
          "Consulta XML modelos presentados",
          "Comparación información modelo 190",
          "Comparación información modelo 188",
          "Consulta por NIF de AEAT",
          "Administración",
          "Administración usuarios",
          "Acceso al tratamiento del modelo 290"
        ];
        registrosDerecha = [
          "Administración usuarios",
          "Acceso al tratamiento del modelo 290"
        ];
      }`
		}
	};

	caseTree: ComponentDoc = {
		title: 'Uso del tarnsfer con arbol',
		description: `<p>Para utilizar el componente Transfer con arbol, tan solo debemos pasarle como valor a los inputs <code class="attribute">leftPanelElements</code> y/o <code class="attribute">rigthPanelElements</code> un array de objetos de tipo <code class="tag">CaTreeNode</code> y agregar el atributo  <code class="attribute">treeTransfer</code></p>`,
		codeExample: {
			html: `
      <ca-transfer
        [leftPanelElements]="treeLeft"
        [rightPanelElements]="treeRigth"
        treeTransfer
      ></ca-transfer>`,
			ts: `
      import { Component } from '@angular/core';
      import { CaTransferValue, CaTreeNode } from '@global-front-components/ui';

      @Component({
        selector: 'ca-transfer-view',
        templateUrl: 'transfer-view.component.html'
      })
      export class TransferPageComponent {

	treeLeft: CaTreeNode[] = [
		{
			label: 'Prueba 1',
			expanded: false,
			selected: false,
			children: [
				{
					label: 'Prueba hijo 1',
					expanded: false,
					selected: false,
					children: [
						{
							label: 'Prueba hijo 1 hijo 1',
							expanded: false,
							selected: false
						}
					]
				},
				{
					label: 'Prueba hijo 2',
					expanded: false,
					selected: false
				},
				{
					label: 'Prueba hijo 3',
					expanded: false,
					selected: false
				},
				{
					label: 'Prueba hijo 4',
					expanded: false,
					selected: false
				}
			]
		},
		{
			label: 'Prueba 2',
			expanded: false,
			selected: false
		},
		{
			label: 'Prueba 3',
			expanded: false,
			selected: false,
			children: [
				{
					label: 'Prueba 3 hijo 1',
					expanded: false,
					selected: false
				}
			]
		}
	];

  treeRight: CaTreeNode[] = [];
      }`
		}
	};

	onValueChange(event: CaTransferValue) {
		console.log(event);
	}
}
