import { FondosResponse } from "@global-front-components/common";

export const FONDOS_RESPONSE_MOCK: FondosResponse = {
  "serviceId": "ConsultaFondosPenSrv",
  "outputMap": {
      "mapacoddescripcion": [
          {
              "codigo": "0",
              "descripcion": "AHORROPENSION TREINTA Y UNO, F.P."
          },
          {
              "codigo": "0",
              "descripcion": "AHORROPENSIÓN 52, F.P."
          },
          {
              "codigo": "0",
              "descripcion": "CAJASOL PROTEGIDO, F.P."
          },
          {
              "codigo": "0",
              "descripcion": "CAJASOL RF, F.P."
          },
          {
              "codigo": "0",
              "descripcion": "CAJASOL 30, FP.P"
          },
          {
              "codigo": "0",
              "descripcion": "CAJASOL 50,F.P."
          },
          {
              "codigo": "0",
              "descripcion": "CAJASOL 75,F.P."
          },
          {
              "codigo": "0",
              "descripcion": "CASER PREVISION EPSV-RECURSOS PROPIOS"
          },
          {
              "codigo": "0",
              "descripcion": "FONCANARIAS RFC, F.P."
          },
          {
              "codigo": "0",
              "descripcion": "FONDCANARIAS DEPOSITOS, F.P."
          },
          {
              "codigo": "0",
              "descripcion": "FONDCANARIAS MIXTO, F.P."
          },
          {
              "codigo": "0",
              "descripcion": "FONDCANARIAS RV, F.P."
          },
          {
              "codigo": "0",
              "descripcion": "FONDO CANARIO PENSIONES F.P."
          },
          {
              "codigo": "0",
              "descripcion": "FONDO CONTROL PRECIOS"
          },
          {
              "codigo": "0",
              "descripcion": "FONFUTURO 3 SA NOSTRA FONDO DE PENSIONES"
          },
          {
              "codigo": "0",
              "descripcion": "FONFUTURO 4 SA NOSTRA, FONDO DE PENSIONES"
          },
          {
              "codigo": "0",
              "descripcion": "FONS EMPLEATS SA NOSTRA FONDO DE PENSIONES"
          },
          {
              "codigo": "0",
              "descripcion": "PENEDES PENSIO EMPLEATS FONDO DE PENSIONES"
          },
          {
              "codigo": "67",
              "descripcion": "FONDO FERIOJA II, F.P."
          },
          {
              "codigo": "107",
              "descripcion": "AH.CUARENTA Y NUEVE"
          },
          {
              "codigo": "145",
              "descripcion": "AH.CUARENTA Y OCHO"
          },
          {
              "codigo": "147",
              "descripcion": "AH.CINCUENTA Y CINCO"
          },
          {
              "codigo": "359",
              "descripcion": "N.C.G PREVISIÓN I"
          },
          {
              "codigo": "361",
              "descripcion": "AHORROPENSIÓN 51, F.P."
          },
          {
              "codigo": "369",
              "descripcion": "AH. SETENTA Y OCHO"
          },
          {
              "codigo": "381",
              "descripcion": "AH. SESENTA, FP"
          },
          {
              "codigo": "383",
              "descripcion": "AHORROPENSION 58 F.P."
          },
          {
              "codigo": "385",
              "descripcion": "AH.CINCUENTA Y NUEVE"
          },
          {
              "codigo": "387",
              "descripcion": "AH. SESENTA Y UNO"
          },
          {
              "codigo": "389",
              "descripcion": "AH. SESENTA Y DOS"
          },
          {
              "codigo": "391",
              "descripcion": "AH. SESENTA Y TRES"
          },
          {
              "codigo": "393",
              "descripcion": "AH. SESENTA Y CUATRO"
          },
          {
              "codigo": "395",
              "descripcion": "AHORROPENSION 68 F.P."
          },
          {
              "codigo": "397",
              "descripcion": "AH. SETENTA Y UNO"
          },
          {
              "codigo": "399",
              "descripcion": "AH.SETENTA Y DOS,FP"
          },
          {
              "codigo": "403",
              "descripcion": "CAJASOL EMPLEADOS, FP"
          },
          {
              "codigo": "405",
              "descripcion": "AH.CUARENTA Y CUATRO"
          },
          {
              "codigo": "407",
              "descripcion": "AHORROPENSION 46 F.P."
          },
          {
              "codigo": "409",
              "descripcion": "AHORROPENSION 47 F.P."
          },
          {
              "codigo": "411",
              "descripcion": "EMPL.PUBL.COMUN.AUTONOMA DE CANARIAS,F.P"
          },
          {
              "codigo": "413",
              "descripcion": "AHORROPENSION OCHENTA, FP"
          },
          {
              "codigo": "415",
              "descripcion": "AHORROPENSION SETENTA"
          },
          {
              "codigo": "417",
              "descripcion": "AHORROPENSION 75 F.P."
          },
          {
              "codigo": "419",
              "descripcion": "AHORROPENSION 76 F.P"
          },
          {
              "codigo": "421",
              "descripcion": "AHORROPENSION 77 F.P."
          },
          {
              "codigo": "423",
              "descripcion": "NCG PREVISION II"
          },
          {
              "codigo": "460",
              "descripcion": "CEP FONDO DE PENSIONES"
          },
          {
              "codigo": "461",
              "descripcion": "PENEDES PENSIO MIXT FONDO DE PENSIONES"
          },
          {
              "codigo": "462",
              "descripcion": "PENEDES PENSIO VARIABLE MIXT FONDO DE PENSIONES"
          },
          {
              "codigo": "463",
              "descripcion": "PENEDES PENSIO BORSA FONDO DE PENSIONES"
          },
          {
              "codigo": "464",
              "descripcion": "PENEDES PENSIO EUROBORSA 100 FONDO DE PENSIONES"
          },
          {
              "codigo": "465",
              "descripcion": "PENEDES PENSIO GARANTIT FP"
          },
          {
              "codigo": "466",
              "descripcion": "PENEDES PENSIO GII FP"
          },
          {
              "codigo": "467",
              "descripcion": "PENEDES PENSIO GIII FP"
          },
          {
              "codigo": "469",
              "descripcion": "PENEDES PENSIO GV FP"
          },
          {
              "codigo": "470",
              "descripcion": "PENEDES PENSIO GVI FP"
          },
          {
              "codigo": "471",
              "descripcion": "PENEDES PENSIO GVII FP"
          },
          {
              "codigo": "472",
              "descripcion": "PENEDES PENSIO G-IV"
          },
          {
              "codigo": "473",
              "descripcion": "PENEDES PENSIO 1 FP"
          },
          {
              "codigo": "474",
              "descripcion": "PENEDES PENSIO 2 FP"
          },
          {
              "codigo": "475",
              "descripcion": "PENEDES PENSIO 4 FP"
          },
          {
              "codigo": "476",
              "descripcion": "PENEDES PENSIO 5 FP"
          },
          {
              "codigo": "477",
              "descripcion": "PENEDES PENSIO 6 FP"
          },
          {
              "codigo": "478",
              "descripcion": "PENEDES PENSIO 7 FP"
          },
          {
              "codigo": "479",
              "descripcion": "PENEDES PENSIO 8 FP"
          },
          {
              "codigo": "480",
              "descripcion": "PENEDES PENSIO 9 FP"
          },
          {
              "codigo": "481",
              "descripcion": "PENEDES PENSIO 10 FP"
          },
          {
              "codigo": "482",
              "descripcion": "AHORROPENSION SETENTA Y NUEVE FP"
          },
          {
              "codigo": "501",
              "descripcion": "AHORROPENS. UNO, F.P."
          },
          {
              "codigo": "502",
              "descripcion": "AHORROPENSION DOS F.P."
          },
          {
              "codigo": "504",
              "descripcion": "AHORRO CR III, F.P."
          },
          {
              "codigo": "507",
              "descripcion": "CAIXANOVA II"
          },
          {
              "codigo": "508",
              "descripcion": "CAJA CANTABRIA FP"
          },
          {
              "codigo": "517",
              "descripcion": "CAJA BURGOS, F.P."
          },
          {
              "codigo": "533",
              "descripcion": "F.P. EMPLEADOS DE AHORROCORPORACIÓN"
          },
          {
              "codigo": "545",
              "descripcion": "AHORROVIDA III, F.P."
          },
          {
              "codigo": "546",
              "descripcion": "AHORROPENS. TRES, F.P."
          },
          {
              "codigo": "547",
              "descripcion": "AHORROPENSION CUATRO F.P."
          },
          {
              "codigo": "548",
              "descripcion": "CASER PREVIS.TESO,EPSV"
          },
          {
              "codigo": "550",
              "descripcion": "CASER PREVISION EPSV"
          },
          {
              "codigo": "551",
              "descripcion": "CIRCULO DE BURGOS"
          },
          {
              "codigo": "552",
              "descripcion": "AHORRO FUTURO, F.P."
          },
          {
              "codigo": "555",
              "descripcion": "MUT.MONT.MINE.ASTURI"
          },
          {
              "codigo": "556",
              "descripcion": "F.P.EMPLEADOS ADMON.PRINCIPADO ASTURIAS"
          },
          {
              "codigo": "557",
              "descripcion": "CAJABURGOS II, F.P."
          },
          {
              "codigo": "558",
              "descripcion": "JAENPENSIONES, FP"
          },
          {
              "codigo": "560",
              "descripcion": "CAJA BADAJOZ, FP"
          },
          {
              "codigo": "576",
              "descripcion": "CAJA MURCIA II FP"
          },
          {
              "codigo": "580",
              "descripcion": "AHORRO CR IV,F.P."
          },
          {
              "codigo": "585",
              "descripcion": "AHORRO CR II, FP"
          },
          {
              "codigo": "590",
              "descripcion": "CAJASOL INSTITUCIONES UNO,F.P."
          },
          {
              "codigo": "591",
              "descripcion": "ESTIBA FUTURO, FP"
          },
          {
              "codigo": "595",
              "descripcion": "CAIXANOVA I FP"
          },
          {
              "codigo": "600",
              "descripcion": "AHORROVIDA 1,F.P."
          },
          {
              "codigo": "601",
              "descripcion": "EMPLEADOS CECA-APORTACION DEFINIDA FP"
          },
          {
              "codigo": "603",
              "descripcion": "AVILA EMPLEADOS CAJA,F.P."
          },
          {
              "codigo": "604",
              "descripcion": "FONGENERAL, F.P."
          },
          {
              "codigo": "605",
              "descripcion": "FP.C.AH.CANARIAS"
          },
          {
              "codigo": "606",
              "descripcion": "EMP.CAJA SAN FERNANDO-SEVILLA-JEREZ"
          },
          {
              "codigo": "608",
              "descripcion": "CAJA PONTEVEDRA SEGUNDO,F.P."
          },
          {
              "codigo": "610",
              "descripcion": "FONDEM-CANTABRIA, F.P."
          },
          {
              "codigo": "611",
              "descripcion": "F.P.EMPLEADOS COLONYA-C.E.POLLENSA, F.P."
          },
          {
              "codigo": "612",
              "descripcion": "F.P.EMP.CAJA AH.PROV.JAEN"
          },
          {
              "codigo": "625",
              "descripcion": "EMPLEADOS M.P. Y C.GRAL. AHORROS BADAJOZ"
          },
          {
              "codigo": "626",
              "descripcion": "CAIXANOVA PREVISION, F.P."
          },
          {
              "codigo": "627",
              "descripcion": "EMPLEADOS CAJA DE AHORROS DE LA RIOJA FP"
          },
          {
              "codigo": "628",
              "descripcion": "EMP.CAJA GRAL CANARIAS,F.P."
          },
          {
              "codigo": "630",
              "descripcion": "AHORROVIDA 2, FP"
          },
          {
              "codigo": "638",
              "descripcion": "AHORROPENSION 17 F.P."
          },
          {
              "codigo": "639",
              "descripcion": "AHORROVIDA VI"
          },
          {
              "codigo": "640",
              "descripcion": "AHORROPENSION 20 F.P."
          },
          {
              "codigo": "641",
              "descripcion": "AHORROPENSION 21 F.P."
          },
          {
              "codigo": "642",
              "descripcion": "AHORROPENSION 25 F.P."
          },
          {
              "codigo": "643",
              "descripcion": "AHORROPENSION 27 F.P."
          },
          {
              "codigo": "644",
              "descripcion": "AHORROPENSION 29 F.P."
          },
          {
              "codigo": "645",
              "descripcion": "AHORROPENSION 33 F.P."
          },
          {
              "codigo": "646",
              "descripcion": "AHORROPENSION 35 F.P."
          },
          {
              "codigo": "651",
              "descripcion": "EMPLEADOS CAJA CÍRCULO, F.P."
          },
          {
              "codigo": "652",
              "descripcion": "AHORROPENSION 5 F.P."
          },
          {
              "codigo": "653",
              "descripcion": "AHORROPENSION 6 F.P."
          },
          {
              "codigo": "654",
              "descripcion": "CAJA SEGOVIA EMP.,F.P."
          },
          {
              "codigo": "655",
              "descripcion": "CAJAMURCIA EMPLEADOS,F.P."
          },
          {
              "codigo": "656",
              "descripcion": "MONTE EMPLEADOS"
          },
          {
              "codigo": "658",
              "descripcion": "AHORROPENSION 7 F.P."
          },
          {
              "codigo": "659",
              "descripcion": "AHORROPENSION 8 F.P."
          },
          {
              "codigo": "660",
              "descripcion": "AHORROPENSION 9 F.P."
          },
          {
              "codigo": "671",
              "descripcion": "CAJA CANARIAS I FP"
          },
          {
              "codigo": "672",
              "descripcion": "F.P.ADMON. PUBLICA C.A. REGION DE MURCIA"
          },
          {
              "codigo": "673",
              "descripcion": "AHORROPENSION VEINTIDOS,F.P."
          },
          {
              "codigo": "674",
              "descripcion": "AHORRO. DIECINUEVE"
          },
          {
              "codigo": "676",
              "descripcion": "CAJAMURCIA VIII, F.P."
          },
          {
              "codigo": "680",
              "descripcion": "AHORRO. DIEZ, FP"
          },
          {
              "codigo": "681",
              "descripcion": "AHORRO. ONCE, FP"
          },
          {
              "codigo": "682",
              "descripcion": "AHORROPENSION 12 F.P."
          },
          {
              "codigo": "683",
              "descripcion": "AHORROVIDA IV, FP"
          },
          {
              "codigo": "684",
              "descripcion": "AHORROVIDA V, F.P."
          },
          {
              "codigo": "688",
              "descripcion": "AHORROPENS. CATORCE FP"
          },
          {
              "codigo": "689",
              "descripcion": "AHORRO. QUINCE, FP"
          },
          {
              "codigo": "690",
              "descripcion": "FONDOCANARIAS EMPLEO, F.P."
          },
          {
              "codigo": "691",
              "descripcion": "F.P.ENT.LOCALES PRINCIPADO DE ASTURIAS"
          },
          {
              "codigo": "692",
              "descripcion": "F.P.EMPLEADOS CECA-PRESTACION DEFINIDA"
          },
          {
              "codigo": "693",
              "descripcion": "CAJAMURCIA III,F.P."
          },
          {
              "codigo": "694",
              "descripcion": "CAJAMURCIA IV, F.P."
          },
          {
              "codigo": "695",
              "descripcion": "CAJA BURGOS RENTA FIJA 5, F.P."
          },
          {
              "codigo": "696",
              "descripcion": "AHORROPENSION DIECISEIS,F.P."
          },
          {
              "codigo": "700",
              "descripcion": "NCG PREVISION III"
          },
          {
              "codigo": "701",
              "descripcion": "AH. OCHENTA Y OCHO"
          },
          {
              "codigo": "702",
              "descripcion": "AHORROPENSION 90, FP"
          },
          {
              "codigo": "703",
              "descripcion": "ABANTE RENTA PENSIONES, FP"
          },
          {
              "codigo": "704",
              "descripcion": "AHORROPENSION NOVENTA Y DOS, FP"
          },
          {
              "codigo": "705",
              "descripcion": "AHORROPENSION NOVENTA Y CINCO, FP"
          },
          {
              "codigo": "706",
              "descripcion": "AHORROPENSION NOVENTA Y SEIS, FP"
          },
          {
              "codigo": "707",
              "descripcion": "AHORROPENSION NOVENTA Y SIETE, F.P,"
          },
          {
              "codigo": "709",
              "descripcion": "AHORROPENSION 98, FP"
          },
          {
              "codigo": "710",
              "descripcion": "AHORROPENSION 99, FP"
          },
          {
              "codigo": "712",
              "descripcion": "FINIZENS 1, FONDO DE PENSIONES"
          },
          {
              "codigo": "714",
              "descripcion": "FINIZENS 3, FONDO DE PENSIONES"
          },
          {
              "codigo": "716",
              "descripcion": "FINIZENS 5, FONDO DE PENSIONES"
          },
          {
              "codigo": "723",
              "descripcion": "AHORROPENSION NOVENTA Y CINCO F.P."
          },
          {
              "codigo": "725",
              "descripcion": "AHORROPENSION CIENTO DIECISEIS, FP"
          },
          {
              "codigo": "726",
              "descripcion": "AHORROPENSION CIENTO DOCE, FP"
          },
          {
              "codigo": "727",
              "descripcion": "AHORROPENSION CIENTO TRECE, FP"
          },
          {
              "codigo": "728",
              "descripcion": "AHORROPENSION CIENTO ONCE, FP"
          },
          {
              "codigo": "729",
              "descripcion": "AHORROPENSION CIENTO CATORCE, F.P."
          },
          {
              "codigo": "729",
              "descripcion": "AHORROPENSION CIENTO CATORCE, F.P."
          },
          {
              "codigo": "729",
              "descripcion": "AHORROPENSION CIENTO CATORCE, F.P."
          },
          {
              "codigo": "730",
              "descripcion": "AHORROPENSION CIENTO QUINCE, F.P."
          },
          {
              "codigo": "730",
              "descripcion": "AHORROPENSION CIENTO QUINCE, F.P."
          },
          {
              "codigo": "730",
              "descripcion": "AHORROPENSION CIENTO QUINCE, F.P."
          },
          {
              "codigo": "731",
              "descripcion": "AHORROPENSION CIENTO VEINTIDOS, FP"
          },
          {
              "codigo": "732",
              "descripcion": "AHORROPENSION CIENTO VEINTITRES, FP"
          },
          {
              "codigo": "733",
              "descripcion": "AHORROPENSION CIENTO DIECISIETE, F.P."
          },
          {
              "codigo": "821",
              "descripcion": "AHORROPENSION CUARENTA Y TRES, F.P."
          },
          {
              "codigo": "880",
              "descripcion": "AH. CUARENTA Y UNO"
          },
          {
              "codigo": "882",
              "descripcion": "AH. CUARENTA Y DOS"
          },
          {
              "codigo": "900",
              "descripcion": "SA NOSTRA FONDO DE PENSIONES"
          },
          {
              "codigo": "901",
              "descripcion": "FONTOMIR SA NOSTRA, FONDO DE PENSIONES"
          },
          {
              "codigo": "902",
              "descripcion": "FONFUTURO 3 SA NOSTRA FONDO DE PENSIONES"
          },
          {
              "codigo": "903",
              "descripcion": "FONFUTURO 5 SA NOSTRA FONDO DE PENSIONES"
          },
          {
              "codigo": "904",
              "descripcion": "FONFUTURO 6 SA NOSTRA FONDO DE PENSIONES"
          },
          {
              "codigo": "905",
              "descripcion": "FONFUTURO 7 SA NOSTRA FONDO DE PENSIONES"
          },
          {
              "codigo": "906",
              "descripcion": "FONFUTUR 100 SA NOSTRA FONDO DE PENSIONES"
          },
          {
              "codigo": "907",
              "descripcion": "FONFUTURO 200 SA NOSTRA FONDO DE PENSIONES"
          },
          {
              "codigo": "908",
              "descripcion": "AHORROPENSION CINCUENTA FP"
          },
          {
              "codigo": "909",
              "descripcion": "AHORROPENSION SESENTA Y SEIS FP"
          },
          {
              "codigo": "910",
              "descripcion": "AHORROPENSION SESENTA Y SIETE FP"
          },
          {
              "codigo": "911",
              "descripcion": "FONS DE PENSIONS D OCUPACIÓ DE BALEARS FP"
          },
          {
              "codigo": "912",
              "descripcion": "AHORROPENSION SETENTA Y TRES FP"
          },
          {
              "codigo": "913",
              "descripcion": "AHORROPENSION SETENTA Y CUATRO FP"
          },
          {
              "codigo": "914",
              "descripcion": "AHORROPENSION OCHENTA Y UNO FP"
          },
          {
              "codigo": "915",
              "descripcion": "AHORROPENSION OCHENTA Y DOS FP"
          },
          {
              "codigo": "953",
              "descripcion": "AHORROPENSION CUARENTA Y CINCO FP"
          }
      ]
  }
}
