import { Component } from '@angular/core';

@Component({
  templateUrl: 'container.view.html'
})
export class ContainerView {

  accordionsGroup = [
    {
      title: 'Introducción',
      dependency: '', 
      disabled: false, 
      link: '',
      contentHeader: '',
      children: [
        {
          title: '¿Qué es?', 
          dependency: '',
          description: 'Es nuestro conjunto de temas, actualmente tenemos tres con grandes diferencias:', 
          class: '',
          disabled: false,
          link: '',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'Base-theme', 
              description: 'Es importante destacar que siempre usaremos el tema Base para las apliaciones internas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'Base-small-theme', 
              description: 'El tema mínimo solo debe usarse en ocasiones excepcionales teniendo en cuenta que penalizará el estilo global de la aplicación.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'Umbrela', 
              description: 'Por último tenemos el tema de Umbrela, usado en aplicaciones destinadas a cliente, es decir de uso externo.', 
              link: 'Refenrencia a sitio bootstrap'
            },
          ]
        },
        {
          title: '¿Cómo funciona Caser Styles?', 
          dependency: '',
          description: 'Como cualquier librería de estilos que encontremos en el mercado. Es fácil de consumir gracias a la instalación de dependencias npm, brindando a los equipos de desarrollo consistencia y agilidad en la composición de las vistas.', 
          class: '',
          disabled: false,
          link: '',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: false,
          childList: []
        }
      ]
    },
    {
      title: 'Primeros pasos',
      dependency: '', 
      disabled: false, 
      link: '',
      contentHeader: '',
      children: [
        {
          title: 'NPM Instalación', 
          dependency: 'npm install --save @global-front-components/themes',
          description: 'Instalación de dependencias en tu proyecto', 
          class: '',
          disabled: false,
          link: '',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: false,
          childList: []
        },
        {
          title: 'Añadir link de estilos', 
          dependency: "node_modules/@global-front-components/themes/styles/css/base-theme.min.css",
          description: "Añadir el link del tema seleccionado en el archivo angular.json", 
          class: '',
          disabled: false,
          link: '',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: false,
          childList: []
        }
      ]
    },
    {
      title: 'Utilidades',
      dependency: '', 
      disabled: false, 
      link: '',
      contentHeader: '',
      children: [
        {
          title: 'Border', 
          dependency: '',
          description: '', 
          class: '',
          disabled: false,
          link: '',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'ca-border', 
              description: '	Crea un borde sólido de 1 px de color neutro en un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-border-2', 
              description: 'Crea un borde sólido de 2 px de color neutro en un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-border-primary', 
              description: 'Crea un borde sólido de color primario light en un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-border-secondary', 
              description: 'Crea un borde sólido de color secundario light en un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-border-ui', 
              description: 'Crea un borde sólido de color de apoyo UI-01 en un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-border-top', 
              description: 'Crea un borde sólido de color neutro en el lado superior de un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-border-left', 
              description: 'Crea un borde sólido de color neutro en el lado izquierdo de un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-border-bottom', 
              description: 'Crea un borde sólido de color neutro en el lado inferior de un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-border-right', 
              description: 'Crea un borde sólido de color neutro en el lado derecho de un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-border-dashed-left', 
              description: 'Crea un borde a rayas de color neutro en el lado izquierdo de un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-border-radius-small', 
              description: 'Añade esta clase para redondear 6px las esquinas de un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-border-radius-medium', 
              description: 'Añade esta clase para redondear 12px las esquinas de un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-border-radius-large', 
              description: 'Añade esta clase para redondear 18px las esquinas de un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-border-radius-cicle', 
              description: 'Añade esta clase para aplicar una forma de círculo a un elemento.', 
              link: 'Refenrencia a sitio bootstrap'
            }
          ]
        },
        {
          title: 'Background', 
          dependency: '',
          description: '', 
          class: '',
          disabled: false,
          link: '',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'ca-background-primary', 
              description: 'Agrega un color de fondo primario a un bloque.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-background-primary-light', 
              description: 'Agrega un color de fondo primario light a un bloque.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-background-primary-dark', 
              description: 'Agrega un color de fondo primario dark a un bloque.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-background-secondary', 
              description: 'Agrega un color de fondo secundario a un bloque.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-background-secondary-light', 
              description: 'Agrega un color de fondo secundario light a un bloque.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-background-secondary-dark', 
              description: 'Agrega un color de fondo secundario dark a un bloque.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-background-muted', 
              description: 'Agrega un color de fondo de apoyo a un bloque.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-background-white', 
              description: 'Agrega un color de fondo blanco a un bloque.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-background-ui-1', 
              description: 'Agrega un color de apoyo UI-01 a un bloque.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-background-ui-2', 
              description: 'Agrega un color de apoyo UI-02 a un bloque.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-background-ui-3', 
              description: 'Agrega un color de apoyo UI-03 a un bloque.', 
              link: 'Refenrencia a sitio bootstrap'
            }
          ]
        },
        {
          title: 'Orden semántico de los elementos', 
          dependency: '',
          description: '', 
          class: '',
          disabled: false,
          link: '',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'h1', 
              description: 'font-size: 2.5rem;', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'h2', 
              description: 'font-size: 2rem;', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'h3', 
              description: 'font-size: 1.75rem;', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'h4', 
              description: 'font-size: 1.5rem;', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'h5', 
              description: 'font-size: 1.25rem;', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'h6', 
              description: 'font-size: 1rem;', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'p', 
              description: 'font-size: 0.875rem;', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'a', 
              description: 'font-size: 0.875rem;', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'label', 
              description: 'font-size: 0.875rem;', 
              link: 'Refenrencia a sitio bootstrap'
            }
          ]
        },
        {
          title: 'Modificadores de texto', 
          dependency: '',
          description: '', 
          class: '',
          disabled: false,
          link: '',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'ca-heading-main', 
              description: 'Encabezado h1', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-heading-large', 
              description: 'Encabezado h2', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-heading-medium', 
              description: 'Encabezado H3', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-heading-small', 
              description: 'Encabezado H4', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-heading-small ca-heading--border', 
              description: 'Encabezado con borde', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-text-lead', 
              description: 'Añade esta clase para resaltar texto, por ejemplo en subtítulos de artículos.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-text-meta', 
              description: 'Añade esta clase a un párrafo que contenga metadatos sobre un artículo o similar.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-text-underline', 
              description: 'Añade esta clase para subrayar un texto.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-text-through', 
              description: 'Añade esta clase para tachar un texto.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-text-highlight', 
              description: 'Añade esta clase para resaltar un texto.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-text-uppercase', 
              description: 'AÑADE ESTA CLASE PARA TRANSFORMAR EL TEXTO EN MAYÚSCULAS.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-text-capitalize', 
              description: 'Añade Esta Para Transformar La Primera Letra De Cada Palabra En Mayúscula.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-text-lowercase', 
              description: 'añade esta clase para transformar el texto en minúsculas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-text-medium', 
              description: 'Añade esta clase para cambiar a un peso medio el texto.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'ca-text-bold', 
              description: '	Añade esta clase para cambiar a negrita un texto.', 
              link: 'Refenrencia a sitio bootstrap'
            }
          ]
        }
      ]
    }
  ];

  toggleAccordion(child): void {
    child.openItem = !child.openItem;
    if (child.openItem) {
      child.iconTextAccordion = 'keyboard_arrow_up';
    } else {
      child.iconTextAccordion = 'keyboard_arrow_down';
    }
  }

  onChangeTab(e) {
    console.log(e);
    console.log(this.accordionsGroup);
  }

}