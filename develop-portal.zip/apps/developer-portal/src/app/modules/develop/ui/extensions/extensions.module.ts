import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CaFormFieldModule, CaInputModule } from '@global-front-components/ui';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxMaskModule } from 'ngx-mask';
import { ComponentDocModule } from '../../../../components/component-doc/component-doc.module';
import { ExtensionsRoutingModule } from './extensions-routing.module';
import { ExtensionsView } from './extensions.view';
import { MaskView } from './mask/mask.view';
import { NgxChartsView } from './ngx-charts/ngx-charts.view';

@NgModule({
  declarations: [ExtensionsView, MaskView, NgxChartsView],
  imports: [
    CommonModule,
    ExtensionsRoutingModule,
    NgxMaskModule.forChild(),
    NgbModule,
		ComponentDocModule,
    CaFormFieldModule,
    CaInputModule,
    NgxChartsModule,
  ]
})
export class ExtensionsModule { }
