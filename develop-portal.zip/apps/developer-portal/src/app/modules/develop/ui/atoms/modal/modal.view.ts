import { Component, Input, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CaModalOverlayService, CaModalOverlayRef, ModalConfig } from '@global-front-components/ui';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
  template: `
    <div class="container p-0">
      <p>Información de la vista: {{ data.exampleInput }}</p>
      <ca-form-field>
        <ca-label>Escribe y dale a Aceptar</ca-label>
        <input type="text" caInput
          placeholder="Información que se enviará"
          (input)="getInfo($event.target.value)">
      </ca-form-field>
      <div class="d-flex justify-content-between mt-3">
        <button ca-button-secondary (click)="closeDialog()">Cancelar</button>
        <button ca-button (click)="closeDialog(text)">Aceptar</button>
      </div>
    </div>
  `
})
export class ExampleModalComponent {
  constructor(private _modalRef: CaModalOverlayRef<ExampleModalComponent>) { }
  text = '';
  @Input() data: any;

  getInfo(info: string): void {
    this.text = info;
  }

  closeDialog(text?: string): void {
    if (text) {
      this._modalRef.close(text);
    } else {
      this._modalRef.close();
    }
  }
}


@Component({
    templateUrl: 'modal.view.html',
    styleUrls: ['modal.view.scss']
})
export class ModalView implements OnDestroy {
    importModule = `import { CaModalOverlayModule } from '@global-front-components/ui';
import { CaModalOverlayService,  ModalConfig } from '@global-front-components/ui';`;

  cssNote = `@import '~@angular/cdk/overlay-prebuilt.css';
.cdk-overlay-backdrop.cdk-overlay-backdrop-showing {
  &.dark-backdrop {
    background: rgba(83, 87, 90, 0.4);
  }
}`

    caseModal: ComponentDoc = {
        title: `Modal`,
        description: `Ejemplo de renderizado de componentes en una modal`,
        codeExample: {
            html: `<button ca-button (click)="openDialog()">
  Abrir modal
</button>
<p> Información recibida de la modal: {{info}}</p> `,
            ts: `import { Component, Input } from '@angular/core';
import { CaModalOverlayService, ModalConfig, CaModalOverlayRef } from '@global-front-components/ui';
import { ExampleModalComponent } from './example-modal.component.ts';

@Component({
  selector: 'ca-example-view',
  templateUrl: './example-view.component.html',
  styleUrls: ['./example-view.component.scss']
})
export class ExampleViewComponent {
  constructor(private _modalService: CaModalOverlayService) {}
  private _destroy$: Subject<void> = new Subject<void>();
  info = '';
  modalConfig: ModalConfig = {
    title: 'Modal de ejemplo',
    windowDrag: true,
    backdropClick: true,
    data: { exampleInput: 'Texto' },
    size: 'm'
}

  openDialog(): void {
      const modalRef = this._modalService.open(ExampleModalComponent, modalConfig);

      modalRef.afterClosed()
      .pipe(takeUntil(this._destroy$))
      .subscribe((data)=>{
        this.info = data;
      })
  }

  ngOnDestroy() {
    this._destroy$.next();
    this._destroy$.unsubscribe();
  }
}

@Component({
  template: \`
    <div class="container p-0">
      <p>Información de la vista: {{ data.exampleInput }}</p>
      <ca-form-field>
        <ca-label>Escribe y dale a Aceptar</ca-label>
        <input type="text" caInput
          placeholder="Información que se enviará"
          (input)="getInfo($event.target.value)">
      </ca-form-field>
      <div class="d-flex justify-content-between mt-3">
        <button ca-button-secondary (click)="closeDialog()">Cancelar</button>
        <button ca-button (click)="closeDialog(text)">Aceptar</button>
      </div>
    </div>
  \`
})
export class ExampleModalComponent {
  constructor(private _modalRef: CaModalOverlayRef<ExampleModalComponent>) { }
  text = '';
  @Input() data: any;

  getInfo(info: string): void {
    this.text = info;
  }

  closeDialog(text?: string): void {
    if (text) {
      this._modalRef.close(text);
    } else {
      this._modalRef.close();
    }
  }
}`
        }
    };



  constructor(private _modalService: CaModalOverlayService) {}
  private _destroy$: Subject<void> = new Subject<void>();
  info = '';
  modalConfig: ModalConfig = {
    title: 'Modal de ejemplo',
    windowDrag: true,
    backdropClick: true,
    data: { exampleInput: 'Texto' }
}

  openDialog(): void {
      const modalRef = this._modalService.open(ExampleModalComponent, this.modalConfig);

      modalRef.afterClosed()
      .pipe(takeUntil(this._destroy$))
      .subscribe((data)=>{
        this.info = data;
      })
  }
  ngOnDestroy() {
    this._destroy$.next();
    this._destroy$.unsubscribe();
  }
}
