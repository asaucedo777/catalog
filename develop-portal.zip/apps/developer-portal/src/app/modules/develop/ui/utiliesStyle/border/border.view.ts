import { Component } from '@angular/core';

@Component({
  templateUrl: 'border.view.html'
})
export class BorderView {

  borderClassList = [
    {type: 'colors', title: 'Colors', listItem: [
      {className: 'ca-border', description: 'Crea un borde sólido de 1 px de color neutro en un elemento.'},
      {className: 'ca-border-2', description: 'Crea un borde sólido de 2 px de color neutro en un elemento.'},
      {className: 'ca-border-primary', description: 'Crea un borde sólido de color primario light en un elemento.'},
      {className: 'ca-border-secondary', description: 'Crea un borde sólido de color secundario light en un elemento.'},
      {className: 'ca-border-ui', description: 'Crea un borde sólido de color de apoyo UI-01 en un elemento.'},
    ]},
    {type: 'position', title: 'Position', listItem: [
      {className: 'ca-border-top', description: 'Crea un borde sólido de color neutro en el lado superior de un elemento.'},
      {className: 'ca-border-left', description: 'Crea un borde sólido de color neutro en el lado izquierdo de un elemento.'},
      {className: 'ca-border-bottom', description: 'Crea un borde sólido de color neutro en el lado inferior de un elemento.'},
      {className: 'ca-border-right', description: 'Crea un borde sólido de color neutro en el lado derecho de un elemento.'},
    ]},
    {type: 'dashed', title: 'Dashed', listItem: [
      {className: 'ca-border-dashed-left', description: 'Crea un borde a rayas de color neutro en el lado izquierdo de un elemento.'},
      {className: 'ca-border-dashed-right', description: 'Crea un borde a rayas de color neutro en el lado derecho de un elemento.'}
    ]},
    {type: 'radius', title: 'Radius', listItem: [
      {className: 'ca-border ca-border-radius-small', description: 'Añade esta clase para redondear 6px las esquinas de un elemento.'},
      {className: 'ca-border ca-border-radius-medium', description: 'Añade esta clase para redondear 12px las esquinas de un elemento.'},
      {className: 'ca-border ca-border-radius-large', description: 'Añade esta clase para redondear 18px las esquinas de un elemento.'},
      {className: 'ca-border ca-border-radius-cicle', description: 'Añade esta clase para aplicar una forma de círculo a un elemento.'}
    ]},
  ];

}
