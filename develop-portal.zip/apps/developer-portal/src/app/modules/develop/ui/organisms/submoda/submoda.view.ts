import { Component, OnInit } from '@angular/core';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
import { SubmodaRequest, SubmodaResponse, CaSubmodaService, Submoda } from '@global-front-components/common';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { SUBMODA_RESPONSE_MOCK } from './_mock_/submoda-list.response';


@Component({
	templateUrl: 'submoda.view.html',
	styleUrls: ['submoda.view.scss']
})
export class SubmodaView implements OnInit {
	constructor(private _CaSubmodasService: CaSubmodaService) {}
	submodas: Submoda[];
	submoda: Submoda;
	submodaFound: Submoda;
	selectedsubmoda: Submoda;

	caseSubmodasSelect: ComponentDoc = {
		title: 'Componente Seleccionable de Submodas',
		description: `
    `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-select
          placeholder="Seleccione su Submoda"
          keyValue="descripcion"
          [options]="submodas"
          [(ngModel)]="selectedSubmoda"
        ></ca-select>
        <pre class="mt-2" *ngIf="selectedSubmoda">
          {{ selectedSubmoda | json }}
        </pre>
      </ca-form-field>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { Submoda, SubmodaRequest, SubmodaResponse, CaSubmodaService } from '@global-front-components/common';

      @Component({
        selector: 'submoda-select-example',
        templateUrl: 'submoda-select-example.component.html',
        styleUrls: ['submoda-select-example.component.scss']
      })

      export class SubmodaSelectExampleComponent implements OnInit {
        constructor( private _caSubmodasService: CaSubmodaService ) { }

        submodas: Submoda[];
        selectedSubmoda: Submoda;

        ngOnInit() {
          const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
          const request: SubmodaRequest = {
            serviceId: 'ConsultaSubmodasSrv',
            inputMap: {
              codCia: '0001',
              codRamo: '14',
              codModa: '10',
            }
          };
          this._caSubmodasService.getSubmodas(endpoint, request).subscribe((response: SubmodaResponse) => {
            this.submodas = response.outputMap.mapacoddescripcion;
          })
        }
      }`
		}
	};

	codeSubmodasTypeahead: ComponentDoc = {
		title: 'Componente Predictivo de submodas',
		description: `Hay dos formas de emplear este componente predictivo. Por un lado se puede hacer una única llamada al servicio de submodas que nos devuelva toda la lista y filtrar a través del componente,
    o bien, llamar al servicio cada vez que el usuario introduce un valor en el <code class="tag">input</code>.
    <br />
    Primeramente se describe como implementarlo con una única llamada incial.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Submoda</ca-label>
        <input
          type="text"
          placeholder="Busque una submoda"
          [caTypeahead]="search"
          [inputFormatter]="submodaFormatter"
          [(ngModel)]="submoda"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="submoda">
        {{ submoda | json }}
      </pre>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
      import { Submoda, SubmodaRequest, SubmodaResponse, CaSubmodaService } from '@global-front-components/common';

      @Component({
        selector: 'submoda-typeahead-example',
        templateUrl: 'submoda-typeahead-example.component.html',
        styleUrls: ['submoda-typeahead-example.component.scss']
      })

      export class SubmodaTypeaheadExampleComponent implements OnInit {
        constructor( private _caSubmodasService: CaSubmodaService ) { }

        submodas: Submoda[];
        submoda: Submoda;

        submodaFormatter = (x:{descripcion: string}) => x.descripcion;

        search = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            map(term => term === '' ? []
              : this.submodas.filter(v => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1))
          )

        ngOnInit() {
          const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
          const request: SubmodaRequest = {
            serviceId: 'ConsultaSubmodasSrv',
            inputMap: {
              codCia: '0001',
              codRamo: '14',
              codModa: '10'
            }
          };
          this._caSubmodasService.getSubmodas(endpoint, request).subscribe((response: SubmodaResponse) => {
            this.submodas = response.outputMap.mapacoddescripcion;
          })
        }
      }`
		}
	};

	codeSubmodasTypeaheadService: ComponentDoc = {
		description: `A continuación se describe como implementarlo con llamadas al servicio cuando el usuario interactúe.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Moda</ca-label>
        <input
          type="text"
          placeholder="Busque una submoda"
          [caTypeahead]="searchsubmodas"
          [inputFormatter]="submodaFormatter"
          [(ngModel)]="submodaFound"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="submodaFound">
        {{ submodaFound | json }}
      </pre>`,
			ts: `
      import { Component } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
      import { Submoda, SubmodaRequest, SubmodaResponse, CaSubmodaService } from '@global-front-components/common';

      @Component({
        selector: 'submoda-typeahead-example',
        templateUrl: 'submoda-typeahead-example.component.html',
        styleUrls: ['submoda-typeahead-example.component.scss']
      })

      export class SubmodaTypeaheadExampleComponent {
        constructor( private _caSubmodasService: CaSubmodaService ) { }

        submodaFound: Submoda;

        submodaFormatter = (x:{descripcion: string}) => x.descripcion;

        searchSubmodas = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            switchMap(term => {
              const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
              const request: SubmodaRequest = {
                serviceId: 'ConsultaSubmodasSrv',
                inputMap: {
                  codCia: '0001',
                  codRamo: '14',
                  codModa: '10',
                }
              };
              return this._caSubmodasService.getSubmodas(endpoint, request)
            })
            ).pipe(map((response: SubmodaResponse) => response.outputMap.mapacoddescripcion)
          );
      }`
		}
	};

	submodaFormatter = (x: { descripcion: string }) => x.descripcion;
  
	search = (text$: Observable<string>) =>
		text$.pipe(
			debounceTime(300),
			distinctUntilChanged(),
			map((term) =>
				term === '' ? [] : this.submodas.filter((v) => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1)
			)
		);

	searchSubmodas = (text$: Observable<string>) =>
		text$
			.pipe(
				debounceTime(300),
				distinctUntilChanged(),
				switchMap((term) => {
					const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
					const request: SubmodaRequest = {
						serviceId: 'ConsultaSubmodasSrv',
						inputMap: {
							codCia: '0001',
							codRamo: '14',
              codModa: '10',
						}
					};
					return combineLatest([this._getSubmodasMock(endpoint, request), of(term)]);
				})
			)
			.pipe(
				map(([response, term]) =>
					term === '' ? [] : this.submodas.filter((v) => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1)
				)
			);

	private _getSubmodasMock(endpoint: string, request: SubmodaRequest): Observable<SubmodaResponse> {
		return this._CaSubmodasService.getSubmoda(endpoint, request).pipe(
			catchError(() => {
				return of(<SubmodaResponse>SUBMODA_RESPONSE_MOCK);
			})
		);
	}

	ngOnInit() {
    const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
    const request: SubmodaRequest = {
      serviceId: 'ConsultaSubmodasSrv',
      inputMap: {
        codCia: '0001',
        codRamo: '14',
        codModa: '10',
      }
    };
		this._getSubmodasMock(endpoint, request).subscribe((response: SubmodaResponse) => {
			this.submodas = response.outputMap.mapacoddescripcion;
		});
	}
}