import { Component, Input } from '@angular/core';
import { CaModalOverlayRef } from '@global-front-components/ui';

@Component({
  selector: 'ca-client-value-modal-example',
  templateUrl: 'client-value-modal-example.component.html',
  styleUrls: ['client-value-modal-example.component.scss']
})
export class CaClientValueModalExampleComponent {
  constructor(private _modalRef: CaModalOverlayRef<CaClientValueModalExampleComponent>) {}

  @Input() data: any;

  close(): void {
    this._modalRef.close();
  }
}
