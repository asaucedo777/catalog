import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SaludView } from './salud.view';

import { InputModalFilterView } from './input-modal-filter/input-modal-filter.view';
import { SelectModalFilterView } from './select-modal-filter/select-modal-filter.view';
import { ProtocoloViewComponent } from './protocolo/protocolo.view';

const routes: Routes = [{
  path: '',
  component: SaludView,
  children: [{
    path: 'input-modal-filter',
    component: InputModalFilterView
  }, {
    path: 'protocolo',
    component: ProtocoloViewComponent
  }, {
    path: 'select-modal-filter',
    component: SelectModalFilterView
  }]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SaludRoutingModule { }
