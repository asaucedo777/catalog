import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {
	CaButtonModule,
	CaClientValueModule,
	CaEdocsTableModule,
	CaFormFieldModule,
	CaInputModule,
	CaModalOverlayModule,
	CaModalOverlayService,
	CaSelectModule,
	CaSidebarModule,
	CaTypeaheadModule
} from '@global-front-components/ui';
import {
	CaCompaniesService,
	CaProvincesService,
	CaClientValueService,
	CaGlobalPositionService,
	CaModasService,
	CaPlanService,
	CaFondosService,
	CaRoadTypeService,
	CaSubmodaService
} from '@global-front-components/common';
import { ComponentDocModule } from '../../../../components/component-doc/component-doc.module';
import { ClientValueView } from './client-value/client-value.view';
import { CaClientValueModalExampleComponent } from './client-value/client-value-modal-example/client-value-modal-example.component';
import { CompanyView } from './company/company.view';
import { ProvincesView } from './provinces/provinces.view';
import { GlobalPositionView } from './global-position/global-position.view';
import { EdocsTableView } from './edocs-table/edocs-table.view';
import { OrganismsRoutingModule } from './organisms-routing.module';
import { OrganismsView } from './organisms.view';
import { DocumentView } from './document/document.view';
import { DocumentTypeView } from './document-type/document-type.view';
import { RamoView } from './ramo/ramo.view';
import { ModaView } from './moda/moda.view';
import { PlanPenView } from './plan/plan.view';
import { FondoView } from './fondo/fondo.view';
import { RoadTypeView } from './road-type/road-type.view';
import { SubmodaView } from './submoda/submoda.view';
import { SubPlanView } from './sub-plan/sub-plan.view';

@NgModule({
	declarations: [
		CaClientValueModalExampleComponent,
		ClientValueView,
		CompanyView,
		EdocsTableView,
		GlobalPositionView,
		OrganismsView,
		ProvincesView,
		DocumentView,
		DocumentTypeView,
		RamoView,
		ModaView,
		PlanPenView,
		FondoView,
		RoadTypeView,
		SubmodaView,
		SubPlanView
	],
	imports: [
		CaButtonModule,
		CaClientValueModule,
		CaEdocsTableModule,
		CaFormFieldModule,
		CaInputModule,
		CaModalOverlayModule,
		CaSelectModule,
		CaSidebarModule,
		CaTypeaheadModule,
		CommonModule,
		ComponentDocModule,
		FormsModule,
		HttpClientModule,
		NgbModule,
		OrganismsRoutingModule,
		ReactiveFormsModule,
		RouterModule
	],
	providers: [
		CaModalOverlayService,
		CaCompaniesService,
		CaProvincesService,
		CaClientValueService,
		CaGlobalPositionService,
		CaModasService,
		CaPlanService,
		CaFondosService,
		CaRoadTypeService,
		CaSubmodaService
	]
})
export class OrganismsModule {}
