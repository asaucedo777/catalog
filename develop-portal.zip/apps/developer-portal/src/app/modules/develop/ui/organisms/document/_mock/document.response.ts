import { DocumentResponse } from "@global-front-components/common";

export const DOCUMENT_RESPONSE_MOCK: DocumentResponse = {
	serviceId: 'NormalizarDocumento',
	outputMap: {
		letraNormalizado: 'C',
		numeroNormalizado: '4567843',
		letraSN: 'B',
		numeroSN: '4567843',
		codigoError: -19,
		desError: 'Formato incorrecto: Dígito de Control NIF Incorrecto, se calcula.'
	}
};

export const INVALID_DOCUMENT_RESPONSE_MOCK: DocumentResponse = {
	serviceId: 'NormalizarDocumento',
	outputMap: {
		letraNormalizado: '',
		numeroNormalizado: '',
		letraSN: 'B',
		numeroSN: '4567843',
		codigoError: -27,
		desError: 'Formato incorrecto: Dígito de Control CIF Incorrecto'
	}
};
