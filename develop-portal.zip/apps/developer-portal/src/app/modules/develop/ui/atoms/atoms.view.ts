import { Component } from '@angular/core';

@Component({
  templateUrl: 'atoms.view.html',
  styleUrls: ['atoms.view.scss']
})
export class AtomsView {}
