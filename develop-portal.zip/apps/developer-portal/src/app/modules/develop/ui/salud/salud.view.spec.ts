import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaludView } from './salud.view';

describe('SaludView', () => {
  let component: SaludView;
  let fixture: ComponentFixture<SaludView>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaludView ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaludView);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
