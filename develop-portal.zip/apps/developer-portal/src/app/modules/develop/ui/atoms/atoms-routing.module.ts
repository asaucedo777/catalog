import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AtomsView } from './atoms.view';
import { ButtonView } from './button/button.view';
import { CardView } from './card/card.view';
import { CdkTableView } from './cdk-table/cdk-table.view';
import { CheckboxView } from './checkbox/checkbox.view';
import { ClientValueView } from './client-value/client-value.view';
import { DatepickerView } from './datepicker/datepicker.view';
import { FormFieldView } from './form-field/form-field.view';
import { InputView } from './input/input.view';
import { InputFileView } from './input-file/input-file.view';
import { MenuView } from './menu/menu.view';
import { ModalView } from './modal/modal.view';
import { PaginationView } from './pagination/pagination.view';
import { RadioButtonView } from './radio-button/radio-button.view';
import { SelectView } from './select/select.view';
import { SlideToggleView } from './slide-toggle/slide-toggle.view';
import { SnackbarView } from './snackbar/snackbar.view';
import { SpinnerView } from './spinner/spinner.view';
import { TabsView } from './tabs/tabs.view';
import { TextareaView } from './textarea/textare.view';
import { TooltipView } from './tooltip/tooltip.view';
import { TypeaheadView } from './typeahead/typeahead.view';
import { BreadCrumbView } from './breadcrumb/breadcrumb.view';
import { IbanView } from './iban/iban.view';
import { TreeView } from './tree/tree.view';
import { SidenavMenuView } from './sidenav-menu/sidenav-menu.view';
import { HeaderView } from './header/header.view';
import { DownloadView } from './download/download.view';

const routes: Routes = [
	{
		path: '',
		component: AtomsView,
		children: [
			{
				path: 'button',
				component: ButtonView
			},
			{
				path: 'breadcrumb/:id/:id2/:id3',
				component: BreadCrumbView
			},
			{
				path: 'card',
				component: CardView
			},
			{
				path: 'cdk-table',
				component: CdkTableView
			},
			{
				path: 'checkbox',
				component: CheckboxView
			},
			{
				path: 'client-value',
				component: ClientValueView
			},
			{
				path: 'datepicker',
				component: DatepickerView
			},
			{
				path: 'download',
				component: DownloadView
			},
			{
				path: 'form-field',
				component: FormFieldView
			},

			{
				path: 'header',
				component: HeaderView
			},
			{
				path: 'iban',
				component: IbanView
			},
			{
				path: 'input',
				component: InputView
			},
			{
				path: 'input-file',
				component: InputFileView
			},
			{
				path: 'menu',
				component: MenuView
			},
			{
				path: 'modal',
				component: ModalView
			},
			{
				path: 'pagination',
				component: PaginationView
			},
			{
				path: 'radio-button',
				component: RadioButtonView
			},
			{
				path: 'select',
				component: SelectView
			},
			{
				path: 'sidenav-menu',
				component: SidenavMenuView
			},
			{
				path: 'slide-toggle',
				component: SlideToggleView
			},
			{
				path: 'snackbar',
				component: SnackbarView
			},
			{
				path: 'spinner',
				component: SpinnerView
			},
			{
				path: 'tabs',
				component: TabsView
			},
			{
				path: 'textarea',
				component: TextareaView
			},
			{
				path: 'tooltip',
				component: TooltipView
			},
			{
				path: 'tree',
				component: TreeView
			},
			{
				path: 'typeahead',
				component: TypeaheadView
			}
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class AtomsRoutingModule {}
