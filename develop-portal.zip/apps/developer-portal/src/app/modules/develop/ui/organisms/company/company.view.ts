import { Component, OnInit } from '@angular/core';
import {
  combineLatest,
  Observable,
  of
} from 'rxjs';
import {
  catchError,
  debounceTime,
  distinctUntilChanged,
  map,
  switchMap
} from 'rxjs/operators';
import {
  CompaniesRequest,
  CompaniesResponse,
  CaCompaniesService,
  Company
} from '@global-front-components/common';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { COMPANIES_RESPONSE_MOCK } from './_mock_/companies-list.response';

@Component({
  templateUrl: 'company.view.html',
  styleUrls: ['company.view.scss']
})

export class CompanyView implements OnInit {
  constructor(
    private _caCompaniesService: CaCompaniesService
  ) { }
  companies: Company[];
  company: Company;
  companyFound: Company;
  selectedCompany: Company;

  caseCompaniesSelect: ComponentDoc = {
    title: 'Componente Seleccionable de Compañías',
    description: `
    `,
    codeExample: {
      html: `
      <ca-form-field>
        <ca-select
          placeholder="Seleccione su compañía"
          keyValue="denCia"
          [options]="companies"
          [(ngModel)]="selectedCompany"
        ></ca-select>
        <pre class="mt-2" *ngIf="selectedCompany">
         {{ selectedCompany | json }}
        </pre>
      </ca-form-field>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { Company, CompaniesRequest, CompaniesResponse, CaCompaniesService } from '@global-front-components/common';

      @Component({
        selector: 'company-select-example',
        templateUrl: 'company-select-example.component.html',
        styleUrls: ['company-select-example.component.scss']
      })

      export class CompanySelectExampleComponent implements OnInit {
        constructor( private _caCompaniesService: CaCompaniesService ) { }

        companies: Company[];
        selectedCompany: Company;

        ngOnInit() {
          const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
          const request: CompaniesRequest = {
            serviceId: 'BuscarCompaniaPorCodCiaDgs',
            inputMap: {
              dencia: '',
              aplicacion: 'AquiIraSuAplicacion',
              usuario: 'UsuarioLogado'
            }
          }
          this._caCompaniesService.getCompanies(endpoint, request).subscribe((response: CompaniesResponse) => {
            this.companies = response.outputMap.lista;
          })
        }
      }`
    }
  }

  codeCompaniesTypeahead: ComponentDoc = {
    title: 'Componente Predictivo de compañías',
    description: `Hay dos formas de emplear este componente predictivo. Por un lado se puede hacer una única llamada al servicio de compañías que nos devuelva toda la lista y filtrar a través del componente,
    o bien, llamar al servicio cada vez que el usuario introduce un valor en el <code class="tag">input</code>.
    <br />
    Primeramente se describe como implementarlo con una única llamada incial.`,
    codeExample: {
      html: `
      <ca-form-field>
        <ca-label>Compañía</ca-label>
        <input
          type="text"
          placeholder="Busque una compañía"
          [caTypeahead]="search"
          [inputFormatter]="companyFormatter"
          [(ngModel)]="company"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="company">
        {{ company | json }}
      </pre>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
      import { Company, CompaniesRequest, CompaniesResponse, CaCompaniesService } from '@global-front-components/common';

      @Component({
        selector: 'company-typeahead-example',
        templateUrl: 'company-typeahead-example.component.html',
        styleUrls: ['company-typeahead-example.component.scss']
      })

      export class CompanyTypeaheadExampleComponent implements OnInit {
        constructor( private _caCompaniesService: CaCompaniesService ) { }

        companies: Company[];
        company: Company;

        companyFormatter = (x:{denCia: string}) => x.denCia;

        search = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            map(term => term === '' ? []
              : this.companies.filter(v => v.denCia.toLowerCase().indexOf(term.toLowerCase()) > -1))
          )

        ngOnInit() {
          const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
          const request: CompaniesRequest = {
            serviceId: 'BuscarCompaniaPorCodCiaDgs',
            inputMap: {
              dencia: '',
              aplicacion: 'AquiIraSuAplicacion',
              usuario: 'UsuarioLogado'
            }
          }
          this._caCompaniesService.getCompanies(endpoint, request).subscribe((response: CompaniesResponse) => {
            this.companies = response.outputMap.lista;
          })
        }
      }`

    }
  }

  codeCompaniesTypeaheadService: ComponentDoc = {
    description: `A continuación se describe como implementarlo con llamadas al servicio cuando el usuario interactúe.`,
    codeExample: {
      html: `
      <ca-form-field>
        <ca-label>Compañía</ca-label>
        <input
          type="text"
          placeholder="Busque una compañía"
          [caTypeahead]="searchCompanies"
          [inputFormatter]="companyFormatter"
          [(ngModel)]="companyFound"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="companyFound">
        {{ companyFound | json }}
      </pre>`,
      ts: `
      import { Component } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
      import { Company, CompaniesRequest, CompaniesResponse, CaCompaniesService } from '@global-front-components/common';

      @Component({
        selector: 'company-typeahead-example',
        templateUrl: 'company-typeahead-example.component.html',
        styleUrls: ['company-typeahead-example.component.scss']
      })

      export class CompanyTypeaheadExampleComponent {
        constructor( private _caCompaniesService: CaCompaniesService ) { }

        companyFound: Company;

        companyFormatter = (x:{denCia: string}) => x.denCia;

        searchCompanies = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            switchMap(term => {
              const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
              const request: CompaniesRequest = {
                serviceId: 'BuscarCompaniaPorCodCiaDgs',
                inputMap: {
                  dencia: term,
                  aplicacion: 'AquiIraSuAplicacion',
                  usuario: 'UsuarioLogado'
                }
              }
              return this._caCompaniesService.getCompanies(endpoint, request)
            })
            ).pipe(map((response: CompaniesResponse) => response.outputMap.lista)
          );
      }`
    }
  }

  companyFormatter = (x:{denCia: string}) => x.denCia;

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      map(term => term === '' ? []
        : this.companies.filter(v => v.denCia.toLowerCase().indexOf(term.toLowerCase()) > -1))
    )

  searchCompanies = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      switchMap(term => {
        const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
        const request: CompaniesRequest = {
          serviceId: 'BuscarCompaniaPorCodCiaDgs',
          inputMap: {
            dencia: term.toUpperCase(),
            aplicacion: 'AquiIraSuAplicacion',
            usuario: 'UsuarioLogado'
          }
        }
        return combineLatest([this._getCompaniesMock(endpoint, request), of(term)])
       })
      )
      .pipe(map(([response, term]) => term === '' ? []
          : this.companies.filter(v => v.denCia.toLowerCase().indexOf(term.toLowerCase()) > -1))
      );

  private _getCompaniesMock(endpoint: string, request: CompaniesRequest): Observable<CompaniesResponse> {
    return this._caCompaniesService.getCompanies(endpoint, request).pipe(catchError(() => {
      return of (<CompaniesResponse>COMPANIES_RESPONSE_MOCK);
    }))
  }

  ngOnInit() {
    const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
    const request: CompaniesRequest = {
      serviceId: 'BuscarCompaniaPorCodCiaDgs',
      inputMap: {
        dencia: '',
        aplicacion: 'AquiIraSuAplicacion',
        usuario: 'UsuarioLogado'
      }
    }
    this._getCompaniesMock(endpoint, request).subscribe((response: CompaniesResponse) => {
      this.companies = response.outputMap.lista;
    })
  }
}
