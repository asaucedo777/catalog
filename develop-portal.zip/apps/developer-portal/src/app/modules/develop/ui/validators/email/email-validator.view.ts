import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
@Component({
  templateUrl: 'email-validator.view.html',
  styleUrls: ['email-validator.view.scss']
})
export class EmailValidatorView implements OnInit{
  constructor(private _formBuilder: FormBuilder) {}
  form: FormGroup;

  EMAIL_REG_EXP = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

  caseEmail: ComponentDoc = {
    codeExample: {
      html: `
      <form [formGroup]="form">
        <ca-form-field>
          <ca-label>Email</ca-label>
          <input type="text" caInput formControlName="email">
          <ca-error *ngIf="form.get('email').errors?.pattern">Correo electrónico inválido</ca-error>
        </ca-form-field>
      </form>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { FormBuilder, FormGroup, Validators } from '@angular/forms';

      const EMAIL_REG_EXP = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

      @Component({
        selector: 'email-validator-example'
        templateUrl: 'email-validator-example.component.html',
        styleUrls: ['email-validator-example.component.scss']
      })
      export class EmailValidatorExampleComponent implements OnInit {
        constructor(private _formBuilder: FormBuilder) {}
        form: FormGroup;

        ngOnInit() {
          this.form = this._formBuilder.group({
            email: ['', Validators.pattern(EMAIL_REG_EXP)]
          });
        }
      }`
    }
  };

  ngOnInit() {
    this.form = this._formBuilder.group({
      email: ['', Validators.pattern(this.EMAIL_REG_EXP)],
    });
  }
}
