import { Component, OnInit } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: './mask.view.html',
	styleUrls: ['./mask.view.scss']
})
export class MaskView implements OnInit {
	constructor() {}
  date = '05-09-1980'
	installContent = 'npm install --save ngx-mask';
	moduleContent = `
  import { NgxMaskModule, IConfig } from 'ngx-mask'

  export const options: Partial<IConfig> | (() => Partial<IConfig>) = null;

  @NgModule({
    imports: [
      NgxMaskModule.forRoot(),
    ],
  })
  `;
	moduleChildContent = `
  import { NgxMaskModule } from 'ngx-mask'

  @NgModule({
    imports: [
      NgxMaskModule.forChild(),
    ],
  })
  `;

	caseDate: ComponentDoc = {
		title: 'Máscara para fechas en un iput',
		description:
			'A continuación mostraremos como se implementa una máscara de fechas en un input, para ello vamos a hacer uso del input de la librería',
		codeExample: {
			html: `
      <ca-form-field>
        <input caInput placeholder="inserte una fecha" mask="d0/m0/0000" [dropSpecialCharacters]="false" / >
      </ca-form-field>
      `
		}
	};
	caseThousand: ComponentDoc = {
		title: 'Máscara separador de miles y decimales',
		description:
			'En el siguiente ejemplo veremos como crear una máscara que nos separe con punto los miles y nos muestre dos decimales.',
		codeExample: {
			html: `
      <ca-form-field>
        <input caInput mask="separator.2" thousandSeparator="."/>
      </ca-form-field>
      `
		}
	};
	caseSuffix: ComponentDoc = {
		title: 'Máscara para añadir sufijos y limitar el número de caracteres',
		description:
			'En este otro ejemplo veremos coño añadir el símbolo € cómo sufijo y limitar en 6 el número de digitos',
		codeExample: {
			html: `
      <ca-form-field>
        <input caInput mask="0{6}" suffix="€" thousandSeparator="."/>
      </ca-form-field>
      `
		}
	};
	casePipe: ComponentDoc = {
		title: 'Usando el pipe para crear mascaras',
		description:
			'Para generar una máscara en cualquier otro elemento HTML que contenga texto, podremos hacer uso del pipe, tal como muestra el siguiente ejemplo',
		codeExample: {
			html: `
      <span>{{date | mask : 'd0/m0/0000'}}</span>
      `,
      ts: `
      const date = '05-09-1980'
      `
		}
	};

	ngOnInit(): void {}
}
