import {
  FormGroup,
  FormBuilder
} from '@angular/forms';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
  templateUrl: 'slide-toggle.view.html',
  styleUrls: ['slide-toggle.view.scss']
})
export class SlideToggleView implements OnInit, OnDestroy {
  importModule = `import { CaSlideToggleModule } from '@global-front-components/ui';`;

  caseSimple: ComponentDoc = {
    title: `Uso simple`,
    codeExample: {
      html: `<ca-slide-toggle>Slide toggle</ca-slide-toggle>`
    }
  };

  caseTrue: ComponentDoc = {
    title: `Uso con valor predeterminado`,
    description: `A través del atributo <code class="attribute">value</code> se puede prestablecer un valor. Por defecto es <em>false</em>.`,
    codeExample: {
      html: `<ca-slide-toggle [value]="true">Slide toggle predeterminado</ca-slide-toggle>`
    }
  };

  caseLabels: ComponentDoc = {
    title: `Uso con diferente posición de label`,
    description: `A través del atributo <code class="attribute">labelPosition</code> podemos situar el texto delante o detrás del slide. Por defecto es <em>before</em>.`,
    codeExample: {
      html:`<ca-slide-toggle>Label a la izquierda</ca-slide-toggle>
<ca-slide-toggle labelPosition="after">Label a la derecha</ca-slide-toggle>`
    }
  };

  caseNoLabel: ComponentDoc = {
    title: `Uso sin label`,
    description: `Si queremos añadir un componente <code class="tag">ca-slide-toggle</code> sin asociar un label al mismo,
    por cuestiones de accesibilidad el <code class="tag">label</code> siempre debe renderizarse a nivel de DOM así que lo que haremos
    será ocultar el mismo a través del atributo <code class="attribute">labelVisible</code>.`,
    codeExample: {
      html: `<ca-slide-toggle [labelVisible]="false">Label invisible</ca-slide-toggle>`
    }
  };

  caseDisabled: ComponentDoc = {
    title: `Estado disabled`,
    description: `Siempre que nuestro elemento este deshabilitado a través del atributo <code class="attribute>disabled</code> se marcara como tal a nivel visual.`,
    codeExample: {
      html: `<ca-slide-toggle [disabled]="true">Slide toggle disabled</ca-slide-toggle>`
    }
  };

  caseTemplateForm: ComponentDoc = {
    title: `Uso en formularios de plantilla`,
    description: `El componente <code class="tag">ca-slide-toggle</code> puede emplearse en formularios de plantilla
    mediante la directiva <code class="attribute">ngModel</code>
    del módulo <code class="module">@angular/forms</code>.`,
    codeExample: {
      ts: `import { Component } from '@angular/core';
@Component({
  selector: 'ca-template-form-view',
  templateUrl: './template-form-view.component.html',
  styleUrls: ['./template-form-view.component.scss']
})
export class TemplateFormViewComponent {
  model = false;
}`,
      html: `<ca-slide-toggle [(ngModel)]="model">Slide en formulario de plantilla</ca-slide-toggle>
<p>Valor en el formulario: <i>{{model}}</i></p>`
    }
  };

  caseReactiveForm: ComponentDoc = {
    title: `Uso en formularios reactivos`,
    description: `El componente <code class="tag">ca-slide-toggle</code> puede emplearse en formularios reactivos
     mediante la directiva <code class="attribute">formControlName</code>
    del módulo <code class="module">@angular/forms</code>.`,
    codeExample: {
      ts: `import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup} from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'ca-reactive-form-view',
  templateUrl: './reactive-form-view.component.html',
  styleUrls: ['./reactive-form-view.component.scss']
})
export class ReactiveFormViewComponent implements OnInit, OnDestroy {
  constructor(private formBuild: FormBuilder) {}
  private _destroy$: Subject<void> = new Subject<void>();
  public form: FormGroup;

  ngOnInit() {
    this.form = this.formBuild.group({
      controlOne: false,
      controlTwo: [{value: true, disabled: true}]
    });
    this.form.get('controlOne').valueChanges
      .pipe(takeUntil(this._destroy$))
      .subscribe((value)=>{
      if (value) {
        this.form.get('controlTwo').enable();
      } else {
        this.form.get('controlTwo').disable();
      }
    })
  }

  ngOnDestroy() {
   this._destroy$.next();
    this._destroy$.unsubscribe();
  }
}`,
      html: `form [formGroup]="form">
  <ca-slide-toggle
    formControlName="controlOne"
    labelPosition="after">
      Habilita o deshabilita el slide inferior
  </ca-slide-toggle>
  <ca-slide-toggle
    formControlName="controlTwo"
    labelPosition="after">
      Slide inferior
  </ca-slide-toggle>
</form>`
    }
  }

  caseMinimumSize: ComponentDoc = {
    title: `Tamaños mínimos`,
    description: `A través la directiva <code class="attribute">ca-min-component</code> podemos hacer que el slide toggle adquiera el tamaño mínimo.`,
    codeExample: {
      html: `<div class="d-flex">
      <ca-slide-toggle ca-min-component class="mr-4">Slide toggle</ca-slide-toggle>
      <ca-slide-toggle ca-min-component [value]="true" class="mr-4">Slide toggle predeterminado</ca-slide-toggle>
      <div>
        <ca-slide-toggle ca-min-component class="mr-4">Label a la izquierda</ca-slide-toggle>
        <ca-slide-toggle ca-min-component labelPosition="after" class="mr-4">Label a la derecha</ca-slide-toggle>
      </div>
      <ca-slide-toggle ca-min-component [labelVisible]="false" class="mr-4">Label invisible</ca-slide-toggle>
      <ca-slide-toggle ca-min-component [disabled]="true" class="mr-4">Slide toggle disabled</ca-slide-toggle>
    </div>
            `
    }
  };

  model = false;

  constructor(private formBuilder: FormBuilder) {}
  public form: FormGroup;
  private _destroy$: Subject<void> = new Subject<void>();

  ngOnInit() {
    this.form = this.formBuilder.group({
      controlOne: false,
      controlTwo: [{value: true, disabled: true}]
    });

    this.form.get('controlOne').valueChanges
      .pipe(takeUntil(this._destroy$))
      .subscribe((value)=>{
      if (value) {
        this.form.get('controlTwo').enable();
      } else {
        this.form.get('controlTwo').disable();
      }
    })
  }

  ngOnDestroy() {
    this._destroy$.next();
    this._destroy$.unsubscribe();
  }
}
