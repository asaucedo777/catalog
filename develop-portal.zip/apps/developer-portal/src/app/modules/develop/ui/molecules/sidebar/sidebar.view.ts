import { Component, OnInit } from '@angular/core';
import { Sidebar } from '@global-front-components/ui';
import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';

@Component({
  templateUrl: './sidebar.view.html',
  styleUrls: ['./sidebar.view.scss']
})
export class SidebarView implements OnInit {

  constructor() { }
  moduleContent = `import { CaSidenbarModules } from '@global-front-components/ui';`;
  sidebarItems: Sidebar[] = [
    {
      title: 'Item 1',
      link: '/path/where/will/navigate'
    },
    {
      title: 'Item 2',
      subItems: [
        {
          title: 'Sidebar Doc',
          link: '/develop/molecules/sidebar'
        },
        {
          title: 'Subitem 1',
          link: '/path/where/will/navigate'
        },
        {
          title: 'Subitem 3',
          link: '/path/where/will/navigate'
        },
        {
          title: 'Subitem 4',
          link: '/path/where/will/navigate'

        }
      ]
    },
    {
      title: 'Item 3',
      link: '/path/where/will/navigate'
    },    {
      title: 'Item 4',
      link: '/path/where/will/navigate'
    },    {
      title: 'Item 5',
      link: '/path/where/will/navigate'
    },    {
      title: 'Item 6',
      link: '/path/where/will/navigate'
    },    {
      title: 'Item 7',
      link: '/path/where/will/navigate'
    },    {
      title: 'Item 8',
      link: '/path/where/will/navigate'
    },
  ]
  sidebarItemsAutoOpen: Sidebar[] = [
    {
      title: 'Item 1',
      link: '/path/where/will/navigate'
    },
    {
      title: 'Item 2',
      subItems: [
        {
          title: 'Sidebar Doc',
          link: '/develop/molecules/sidebar'
        },
        {
          title: 'Subitem 1',
          link: '/path/where/will/navigate'
        },
        {
          title: 'Subitem 3',
          link: '/path/where/will/navigate'
        },
        {
          title: 'Subitem 4',
          link: '/path/where/will/navigate'

        }
      ]
    },
    {
      title: 'Item 3',
      link: '/path/where/will/navigate'
    },    {
      title: 'Item 4',
      link: '/path/where/will/navigate'
    },    {
      title: 'Item 5',
      link: '/path/where/will/navigate'
    },    {
      title: 'Item 6',
      link: '/path/where/will/navigate'
    },    {
      title: 'Item 7',
      link: '/path/where/will/navigate'
    },    {
      title: 'Item 8',
      link: '/path/where/will/navigate'
    },
  ]



  caseBasic: ComponentDoc = {
    title: 'Uso básico sico del Sidebar',
    description: 'Para utilizar el el Componente Sidebar, tan solo hemos de anadir la etiqueta <code class="tag">ca-sidebar</code> en nuestro html, y pasarle al input <code class="attribute">data</code> un array de tipo <code> Sidebar </code>. en la pestaña API podemos ver la informacion de este tipo.',
    codeExample: {
      html: `
      <div class="sidebar-wrapper">
        <ca-sidebar [data]="sidebarItems"></ca-sidebar>
      </div
      `,
      ts: `
      sidebarItems: Sidebar[] = [
        {
          title: 'Item 1',
          link: '/path/where/will/navigate'
        },
        {
          title: 'Item 2',
          subItems: [
            {
              title: 'Sidebar Doc',
              link: '/develop/molecules/sidebar'
            },
            {
              title: 'Subitem 1',
              link: '/path/where/will/navigate'
            },
            {
              title: 'Subitem 3',
              link: '/path/where/will/navigate'
            },
            {
              title: 'Subitem 4',
              link: '/path/where/will/navigate'

            }
          ]
        },
        {
          title: 'Item 3',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 4',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 5',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 6',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 7',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 8',
          link: '/path/where/will/navigate'
        },
      ]
      `,
      css: `
      .sidebar-wrapper{
        height: 500px;
        width: 200px;
        border: 1px solid #d5d5d5;
      }
      `
    }
  }

  caseAutoOpen: ComponentDoc = {
    title: 'Auto Open',
    description: `
    <p>Añadienle el atributo <code class="attribute">autoOpen</code>, el componente chequeará la ruta y buscará coincidencáas dentro del array para marcar el elemento como activo y desplegar el sua ntecesor si este se encuentra anidado.</p>
    `,
    codeExample: {
      html: `
      <div class="sidebar-wrapper">
        <ca-sidebar autoOpen [data]="sidebarItems"></ca-sidebar>
      </div
      `,
      ts: `
      sidebarItems: Sidebar[] = [
        {
          title: 'Item 1',
          link: '/path/where/will/navigate'
        },
        {
          title: 'Item 2',
          subItems: [
            {
              title: 'Sidebar Doc',
              link: '/develop/molecules/sidebar'
            },
            {
              title: 'Subitem 1',
              link: '/path/where/will/navigate'
            },
            {
              title: 'Subitem 3',
              link: '/path/where/will/navigate'
            },
            {
              title: 'Subitem 4',
              link: '/path/where/will/navigate'

            }
          ]
        },
        {
          title: 'Item 3',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 4',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 5',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 6',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 7',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 8',
          link: '/path/where/will/navigate'
        },
      ]
      `,
      css: `
      .sidebar-wrapper{
        height: 500px;
        width: 200px;
        border: 1px solid #d5d5d5;
      }
      `
    }
  }

  caseFilter: ComponentDoc = {
    title: 'Siberdar con busqueda rápida',
    description: `
    <p>Podemos habilitar un campo para la busqueda rápida de elementos. Para ello tan sólo debemos añadir el atributo <code class="attribute">filter</code></p>
    <p>Esta hara que se muestre un typeahead, en el que nos irá mostrando todas las coincidencias a medida que vayamos escribiendo en el input
    `,
    codeExample: {
      html: `
      <div class="sidebar-wrapper">
        <ca-sidebar filter [data]="sidebarItems"></ca-sidebar>
      </div
      `,
      ts: `
      sidebarItems: Sidebar[] = [
        {
          title: 'Item 1',
          link: '/path/where/will/navigate'
        },
        {
          title: 'Item 2',
          subItems: [
            {
              title: 'Sidebar Doc',
              link: '/develop/molecules/sidebar'
            },
            {
              title: 'Subitem 1',
              link: '/path/where/will/navigate'
            },
            {
              title: 'Subitem 3',
              link: '/path/where/will/navigate'
            },
            {
              title: 'Subitem 4',
              link: '/path/where/will/navigate'

            }
          ]
        },
        {
          title: 'Item 3',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 4',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 5',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 6',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 7',
          link: '/path/where/will/navigate'
        },    {
          title: 'Item 8',
          link: '/path/where/will/navigate'
        },
      ]
      `,
      css: `
      .sidebar-wrapper{
        height: 500px;
        width: 200px;
        border: 1px solid #d5d5d5;
      }
      `
    }
  }

  ngOnInit(): void {
  }

}
