import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { MenuItem } from '@global-front-components/ui';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: './sidenav-menu.view.html',
	styleUrls: ['./sidenav-menu.view.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class SidenavMenuView implements OnInit {
	constructor() {}
	moduleContent = `import { CaSidenavMenuModules } from '@global-front-components/ui';`;

	caseStyleScss = `@import '~@angular/cdk/overlay-prebuilt.css';

cdk-virtual-scroll-viewport {
  .cdk-virtual-scroll-content-wrapper {
    position: relative;
    overflow-x: scroll;
  }
}

.cdk-overlay-container {
  z-index: 9999;
}`;

	caseBasic: ComponentDoc = {
		title: 'Uso de compoemente Sidenav Menu',
		description: `
    <p>Para utilizar el componente basta con pasarle un array de objetos de tipo <code class="tag">MenuItem</code> a traves del imput <code class="attribute">menuItems</code>.</p>
    <p> Con el input <code class="attribute">open</code> le indicaremos con un booleano si se ha de desplegar o collapsar</p>
    <p>Al seleccionar un item con hijos se desplegara otro nuevo panel, puediendo desplegar hasta cuatro paneles</p>
    <p>Si el elemento seleccionado no tienes descendientes, el componente emitirá este elemento a traves del output <code class="attribute">itemSelected</code></p>
    `,
		codeExample: {
      html: `
      <button ca-button-icon (click)="toggleMenu()">
        <span class="material-icons">
          menu
        </span>
      </button>

      <ca-sidenav-menu
        [menuItems]="sidenavItems"
        [open]="menuOpen"
        (itemSelected)="onselectedMenuItem($event)"
      ></ca-sidenav-menu
      `,
			ts: `
      menuOpen = false;

      sidenavItems: MenuItem[] = [
        {
          textContent: 'Item 1',
          routerLink: '/item1'
        },
        {
          textContent: 'Item 2',
          routerLink: '/item2',
          items: [
            {
              textContent: 'Child 1',
              routerLink: '/item2/Child1'
            },
            { textContent: 'Child 2', routerLink: '/item2/Child2' },
            { textContent: 'Child 3', routerLink: '/item2/Child2' },
            {
              textContent: 'Child 4 con titulo largo ',
              routerLink: '/item2/Child4',
              items: [
                { textContent: 'Grandchild 1', routerLink: '/item2/Child4/Grandchild1' },
                { textContent: 'Grandchild 2', routerLink: '/item2/Child4/Grandchild2' },
                { textContent: 'Grandchild 3', routerLink: '/item2/Child4/Grandchild3' },
                { textContent: 'Grandchild 4',routerLink: '/item2/Child4/Grandchild4' },
                { textContent: 'Grandchild 5', routerLink: '/item2/Child4/Grandchild5' },
                { textContent: 'Grandchild 6', routerLink: '/item2/Child4/Grandchild6' },
                { textContent: 'Grandchild 7', routerLink: '/item2/Child4/Grandchild7' },
                { textContent: 'Grandchild 8', routerLink: '/item2/Child4/Grandchild8' },
                { textContent: 'Grandchild 9', routerLink: '/item2/Child4/Grandchild9'},
                {
                  textContent: 'Grandchild 10',
                  routerLink: '/item2/Child4/Grandchild10',
                  items: [
                    { textContent: 'Great-grandson 1', routerLink: '/item2/Child4/Grandchild1/Great-grandson-1' },
                    { textContent: 'Great-grandson 2',routerLink: '/item2/Child4/Grandchild1/Great-grandson-2' },
                    { textContent: 'Great-grandson 3', routerLink: '/item2/Child4/Grandchild1/Great-grandson-3' }
                  ]
                }

              ]
            }
          ]
        },
        {
          textContent: 'Item 3',
          routerLink: '/item3'

        },
        {
          textContent: 'Item 4',
          routerLink: '/item3'
        },
        {
          textContent: 'Item 5',
          routerLink: '/item3'
        },
        {
          textContent: 'Item 6',
          routerLink: '/item3'
        }
      ];

      toggleMenu() {
        this.menuOpen = !this.menuOpen;
      }

      onselectedMenuItem(item: MenuItem) {
        if (item) {
         // implementar la lógica deseada
        }
        this.menuOpen = false;
      }
      `
		}
	};
	menuOpen = false;

	sidenavItems: MenuItem[] = [
		{
			textContent: 'Item 1',
			routerLink: '/item1'
		},
		{
			textContent: 'Item 2',
			routerLink: '/item2',
			items: [
				{
					textContent: 'Child 1',
					routerLink: '/item2/Child1'
				},
				{ textContent: 'Child 2', routerLink: '/item2/Child2' },
				{ textContent: 'Child 3', routerLink: '/item2/Child2' },
				{
					textContent: 'Child 4 con titulo largo ',
					routerLink: '/item2/Child4',
					items: [
						{ textContent: 'Grandchild 1', routerLink: '/item2/Child4/Grandchild1' },
						{ textContent: 'Grandchild 2', routerLink: '/item2/Child4/Grandchild2' },
						{ textContent: 'Grandchild 3', routerLink: '/item2/Child4/Grandchild3' },
						{ textContent: 'Grandchild 4',routerLink: '/item2/Child4/Grandchild4' },
						{ textContent: 'Grandchild 5', routerLink: '/item2/Child4/Grandchild5' },
						{ textContent: 'Grandchild 6', routerLink: '/item2/Child4/Grandchild6' },
						{ textContent: 'Grandchild 7', routerLink: '/item2/Child4/Grandchild7' },
						{ textContent: 'Grandchild 8', routerLink: '/item2/Child4/Grandchild8' },
						{ textContent: 'Grandchild 9', routerLink: '/item2/Child4/Grandchild9'},
						{
							textContent: 'Grandchild 10',
              routerLink: '/item2/Child4/Grandchild10',
							items: [
								{ textContent: 'Great-grandson 1', routerLink: '/item2/Child4/Grandchild1/Great-grandson-1' },
								{ textContent: 'Great-grandson 2',routerLink: '/item2/Child4/Grandchild1/Great-grandson-2' },
								{ textContent: 'Great-grandson 3', routerLink: '/item2/Child4/Grandchild1/Great-grandson-3' }
							]
						}

					]
				}
			]
		},
		{
			textContent: 'Item 3',
      routerLink: '/item3'

		},
		{
			textContent: 'Item 4',
      routerLink: '/item3'
		},
		{
			textContent: 'Item 5',
      routerLink: '/item3'
		},
		{
			textContent: 'Item 6',
      routerLink: '/item3'
		}
	];

	onselectedMenuItem(item: MenuItem) {
		if (item) {
			console.log('🚀 ~ onselectedMenuItem ~ item', item);
		}
		this.menuOpen = false;
	}

	toggleMenu() {
		this.menuOpen = !this.menuOpen;
	}

	ngOnInit(): void {}
}
