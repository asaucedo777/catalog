import { Component } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: './download.view.html',
	styleUrls: ['./download.view.scss']
})
export class DownloadView {
	constructor() {}
	moduleContent = `import { CaDownloadModule } from '@global-front-components/common';`;
	caButtonModule = `import { CaButtonModule } from '@global-front-components/ui';`;

	href =
		'https://firebasestorage.googleapis.com/v0/b/wizdm-experiments.appspot.com/o/shared%2F200602-647172.jpeg?alt=media&token=aaca2931-7d86-4004-aa98-213ea381f4a8';

	caseButton: ComponentDoc = {
		title: 'Ejemplos de creación de un botónes de descarga de ficheros',
		description: `
    <p>Añadiendo la directiva La directiva <code class="attribute">caDownload</code> a un elemento <code class="tag">button</code> nos dará todo la funcionalidad para generar un buton de decarga de fichero de una forma fácil y segura</p>
    <p>la ruta del archivo a decargar se le pasara como valor al atributo<code class="attribute">caDownload</code>
    `,
		codeExample: {
			html: `
      <button ca-button caDownload="rute-del-archivo-a-descargar">Download</button>

      <button ca-button-icon caDownload="rute-del-archivo-a-descargar">
        <ca-icon>
          file_download
        </ca-icon>
      </button>

      <button ca-button-icon-primary caDownload="rute-del-archivo-a-descargar">
        <ca-icon>
          file_download
        </ca-icon>
      </button>

      `
		}
	};
}
