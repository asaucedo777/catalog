import { InputModalFilterView } from './input-modal-filter/input-modal-filter.view';
import { SaludModalComponent } from './input-modal-filter/exmple-modal-policy/salud-modal.component';
import { SelectModalFilterView } from './select-modal-filter/select-modal-filter.view';
import { ExampleModalComponent } from './select-modal-filter/example-modal/example-modal.component';
import { ProtocoloViewComponent } from './protocolo/protocolo.view';

export const COMPONENTS = [
  InputModalFilterView,
  SaludModalComponent,
  SelectModalFilterView,
  ExampleModalComponent,
  ProtocoloViewComponent
]
