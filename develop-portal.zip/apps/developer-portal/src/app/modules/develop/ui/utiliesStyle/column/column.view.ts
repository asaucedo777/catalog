import { Component } from '@angular/core';

@Component({
  templateUrl: 'column.view.html'
})
export class ColumnView {

  accordionsGroup = [
    {
      title: 'Introducción',
      dependency: '', 
      disabled: false, 
      link: '',
      contentHeader: '',
      children: [
        {
          title: '¿Qué es?', 
          dependency: '',
          description: 'Bootstrap es un framework CSS desarrollado por Twitter en 2010, para estandarizar las herramientas de la compañía. Inicialmente, se llamó Twitter Blueprint y, un poco más tarde, en 2011, se transformó en código abierto y su nombre cambió para Bootstrap. Desde entonces fue actualizado varias veces y ya se encuentra en la versión 5.1., pero en nuestro caso haremos uso de la versión 4.5. El framework combina CSS y JavaScript para estilizar los elementos de una página HTML, en el caso de las aplicaciones que desarrollamos para Caser solo haremos uso de los css. Permite mucho más que, simplemente, cambiar el color de los botones y los enlaces. Esta es una herramienta que proporciona interactividad en la página, por lo que ofrece una serie de componentes que facilitan la comunicación con el usuario, como menús de navegación, controles de página, barras de progreso y más. Además de todas las características que ofrece el framework, su principal objetivo es permitir la construcción de sitios web responsive para dispositivos móviles. Esto significa que las páginas están diseñadas para funcionar en desktop, tablets y smartphones, de una manera muy simple y organizada.', 
          class: '',
          disabled: false,
          link: 'https://getbootstrap.com/docs/4.5/getting-started/introduction/',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: false,
          childList: []
        },
        {
          title: '¿Cómo funciona Bootstrap?', 
          dependency: '',
          description: 'Bootstrap está constituido por una serie de archivos CSS y JavaScript responsables de asignar características específicas a los elementos de la página. Hay un archivo principal llamado bootstrap.css, que contiene una definición para todos los estilos utilizados. Básicamente, la estructura del framework se compone de dos directorios: css: contiene los archivos necesarios para la estilización de los elementos y una alternativa al tema original; js: contiene la parte posterior del archivo bootstrap.js (original y minificado), responsable de la ejecución de aplicaciones de estilo que requieren manipulación interactiva. Para asignarle una característica a un elemento, simplemente debemos informar la clase correspondiente en la propiedad “class” del elemento que será estilizado, como mostramos e el siguiente ejemplo: En este ejemplo, fue asignado el contenido «rounded-sm» para una propiedad de imagen. Es un estilo que agrega bordes redondeados y no un elemento. Por lo tanto, al cargar la imagen, se aplicarán al elemento las características que se refieren a esta clase.', 
          class: '',
          disabled: false,
          link: 'https://getbootstrap.com/docs/4.5/getting-started/introduction/',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: false,
          childList: []
        }
      ]
    },
    {
      title: 'Primeros pasos',
      dependency: '', 
      disabled: false, 
      link: '',
      contentHeader: '',
      children: [
        {
          title: 'NPM Instalación', 
          dependency: 'npm install bootstrap@4.5.0',
          description: 'Instalación de dependencias en tu proyecto', 
          class: '',
          disabled: false,
          link: 'https://www.npmjs.com/package/bootstrap',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: false,
          childList: []
        },
        {
          title: 'Añadir link de estilos', 
          dependency: "@import '~bootstrap/dist/css/bootstrap.min.css'",
          description: "Añadir la importación de las dependencias instaladas en el archivo styles.scss de nuestro proyecto.", 
          class: '',
          disabled: false,
          link: 'https://www.npmjs.com/package/bootstrap',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: false,
          childList: []
        }
      ]
    },
    {
      title: 'Layout',
      dependency: '', 
      disabled: false, 
      link: '',
      contentHeader: 'Para comenzar a usar Bootstrap en tus proyectos es necesario realizar los siguientes pasos:',
      children: [
        {
          title: 'Overview', 
          dependency: '',
          description: '', 
          class: '',
          disabled: false,
          link: 'https://getbootstrap.com/docs/4.5/layout/overview/',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'continaer', 
              description: 'Establece un ancho máximo en cada punto de interrupción de respuesta', 
              link: 'https://getbootstrap.com/docs/4.5/layout/overview/'
            },
            {
              name: 'continaer-fluid', 
              description: '100% en todos los puntos de interrupción', 
              link: 'https://getbootstrap.com/docs/4.5/layout/overview/'
            }
          ]
        },
        {
          title: 'Grid', 
          dependency: '',
          description: '', 
          class: '',
          disabled: false,
          link: 'https://getbootstrap.com/docs/4.5/layout/grid/',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'row', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'col-1', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'col-1', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'col-2', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'col-3', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'col-4', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'col-5', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'col-6', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'col-7', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'col-8', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'col-9', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'col-10', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'col-11', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'col-12', 
              description: 'Recomendamos el uso del grid para componer los espacios que contendrán nuestros elementos en las vistas.', 
              link: 'Refenrencia a sitio bootstrap'
            }
          ]
        },
        {
          title: 'Espacios', 
          dependency: '',
          description: '', 
          class: '',
          disabled: false,
          link: 'https://getbootstrap.com/docs/4.5/utilities/spacing/',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'm-{sides}-{size}', 
              description: 'Este apartado hace referencia a los margenes y padding positivos y negativos.', 
              link: 'https://getbootstrap.com/docs/4.5/utilities/spacing/'
            },
            {
              name: 'p-{sides}-{size}', 
              description: 'Este apartado hace referencia a los margenes y padding positivos y negativos.', 
              link: 'https://getbootstrap.com/docs/4.5/utilities/spacing/'
            }
          ]
        },
        {
          title: 'Display', 
          dependency: '',
          description: '', 
          class: '',
          disabled: false,
          link: 'https://getbootstrap.com/docs/4.5/utilities/display/',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'd-{value}', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            }
          ]
        },
        {
          title: 'Flex', 
          dependency: '',
          description: '', 
          class: '',
          disabled: false,
          link: 'https://getbootstrap.com/docs/4.5/utilities/flex/',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'd-{flexClass}', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            }
          ]
        }
      ]
    },
    {
      title: 'Utilidades',
      dependency: '', 
      disabled: false, 
      link: '',
      contentHeader: '',
      children: [
        {
          title: 'Posiciones', 
          dependency: '',
          description: 'Usaremos estas clases para determinar el tipo de posición', 
          class: '',
          disabled: false,
          link: 'https://getbootstrap.com/docs/4.5/utilities/position/',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'position-static', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'position-relative', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'position-absolute', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'position-fixed', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'position-sticky', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'fixed-top', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'sticky-top', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            }
          ]
        },
        {
          title: 'Float', 
          dependency: '',
          description: '', 
          class: '',
          disabled: false,
          link: 'https://getbootstrap.com/docs/4.5/utilities/float/',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'float-left', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'float-right', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'float-none', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            }
          ]
        },
        {
          title: 'Vertical align', 
          dependency: '',
          description: '', 
          class: '',
          disabled: false,
          link: 'https://getbootstrap.com/docs/4.5/utilities/float/',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'align-baseline', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'align-top', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'align-middle', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'align-bottom', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'align-text-top', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'align-text-bottom', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            }
          ]
        },
        {
          title: 'Textos', 
          dependency: '',
          description: '', 
          class: '',
          disabled: false,
          link: 'https://getbootstrap.com/docs/4.5/utilities/text/',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'text-left', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'text-right', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'text-center', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            }
          ]
        },
        {
          title: 'Overflow', 
          dependency: '',
          description: '', 
          class: '',
          disabled: false,
          link: 'https://getbootstrap.com/docs/4.5/utilities/overflow/',
          openItem: true,
          iconTextAccordion: 'keyboard_arrow_down',
          childListBoolean: true,
          childList: [
            {
              name: 'overflow-auto', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            },
            {
              name: 'overflow-hidden', 
              description: 'Descipción de la clase', 
              link: 'Refenrencia a sitio bootstrap'
            }
          ]
        }
      ]
    }
  ];

  toggleAccordion(child): void {
    child.openItem = !child.openItem;
    if (child.openItem) {
      child.iconTextAccordion = 'keyboard_arrow_up';
    } else {
      child.iconTextAccordion = 'keyboard_arrow_down';
    }
  }

  onChangeTab(e) {
    console.log(e);
    console.log(this.accordionsGroup);
  }

}