import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
	templateUrl: './session-handler.view.html',
	styleUrls: ['./session-handler.view.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class SessionHandlerView implements OnInit {
	constructor() {}
	moduleContent = `
  import { CaSessionHandlerService } from '@global-front-components/common';
`;

  modalExampleModule = `
  @NgModule({
    declarations: [ AppComponent, SessionExpiredComponent ],
    imports: [
      CommonModule,
      CaButtonModule,
      CaModalOverlayModule,
    ],
  `
  modalExampleAppComponent = `

  @Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
  })
  export class AppComponent implements OnInit, OnDestroy {
    constructor(
      private _sessionHandlerService: CaSessionHandlerService,
      private _modalOverlayService: CaModalOverlayService,
      private _router: Router
    ) {}
    private _destroy$: Subject<void> = new Subject();


    ngOnInit() {
      let modal: CaModalOverlayRef<SessionExpiredComponent>;
      this._sessionHandlerService.init();

      this._sessionHandlerService.showExpirationWarning$.subscribe((value) => {
        if(value){
          if (!modal) {
            modal = this._modalOverlayService.open(SessionExpiredComponent, {
              title: 'Tu sesión está por caducar'
            });
          }
          modal
            .afterClosed()
            .pipe(takeUntil(this._destroy$))
            .subscribe(() => {
                this._sessionHandlerService.close();
                this._router.navigate(['/']);
            });
          }
        });
    }

    ngOnDestroy() {
      this._destroy$.next();
      this._destroy$.complete();
    }
  }
  `
  modalExampleModalComponent= `
  @Component({
    selector: 'ad-session-expired',
    template: '
      <div class="container">
		    <p> Su sesión va ha expirar en <span>{{ countDown }}</span> segundo </p>
        <div class="actions">
          <button ca-button (click)="redirectLogin()">Cerra Sesión</button>
        </div>
	    </div>

    ',
    styleUrls: ['./session-expired.component.scss']
  })
  export class SessionExpiredComponent implements OnInit {
    constructor(private _modalRef: CaModalOverlayRef<SessionExpiredComponent>, private _sessionHandler: CaSessionHandlerService) {}
    countDown: number;


    redirectLogin() {
      this._modalRef.close(false);
    }


    ngOnInit() {
      this.countDown = this._sessionHandler.expirationCountdown$;
      this.countDown.subscribe((value) => this.countDown = value);
    }
  }

  `


	ngOnInit(): void {}
}
