import { Component } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { Application } from '@global-front-components/common';

@Component({
	templateUrl: './menu-header.view.html',
	styleUrls: ['./menu-header.view.scss']
})
export class MenuHeaderView {
  moduleContent = `import { CaMenuHeaderModule } from '@global-front-components/ui';`;
	srcLogo = './assets/images/logo.png';
	version = 'Test';

  selectedApp: Application;
  selectedAppWithOption: { app: Application, option: Application };
  menu: Application[];

  caseBasic: ComponentDoc = {
    title: 'Uso de Menu Header',
    description: `
    <p>Para incluir esta cabecera con menú integrado en nuestra aplicación tan sólo hemos de añadir la etiqueta <code class="tag">ca-menu-header</code> y  pasarle la ruta del logo a traves del input  <code class="attribute">srcLogo</code></p>
    <p>adiccionalmente podemos incicarle la versión de nuestra aplicación mediante el input <code class="tag">versionTag</code>, la cual se mostrará al lado del logo, tal y cómo vemos en el ejemplo </p>`,
    codeExample: {
      ts: ``,
      html: `<ca-header srcLogo="./assets/images/logo.png" versionTag="Test"></ca-header>`
    }
  };

  caseContent: ComponentDoc = {
    title: 'Transclusión de contenido',
    description: `
    <p>Para insertar un menu de navegación o botones de acciones a la cabecera, utilizaremos la transclusión de contenido de Angular.
    Para ello añadiremos los elementos dentro de la etiqueta <code class="tag">ca-menu-header</code> y le añadiremos la clase <code >ca-header__action</code> a acada uno de los botones de accion.</p>
    `,
    codeExample: {
      ts: `
      srcLogo = './assets/images/logo.png';
      version = 'Test';`,
      html: `	<ca-menu-header [srcLogo]="srcLogo" versionTag="Test">
      <div class="ca-header__action">
        <button class="button__icon" ca-button-icon>
          <span class="material-icons">star</span>
        </button>
      </div>
      <div class="ca-header__action">
        <button class="button__user">
          <span class="material-icons">account_circle</span>
          <span class="name">UserName</span>
        </button>
      </div>
    </ca-menu-header>`,
    css: `
    .ca-header__action {
      display: flex;
      align-items: center;
      height: 32px;
      &:first-child {
        margin-right: 18px;
      }
      .button__icon {
        min-width: 32px;
        height: 32px;
        &:hover,
        &:focus {
          background-color: rgba(0, 0, 0, 0.15);
        }
        .material-icons {
          color: #ffffff;
          cursor: pointer;
          font-size: 24px;
        }
      }
      .button__user {
        display: flex;
        height: 32px;
        background: inherit;
        border: none;
        color: #FFFFFF;
        align-items: center;
        span {
          margin-right: 8px;
          &:last-child {
            margin-right: 0px;
          }
          &.name {
            text-transform: uppercase;
            font-family: Lato;
            font-size: 18px;
          }
        }
        &:hover, &:focus {
          border-radius: 16px;
          background-color: #0c8c85;
        }
      }
    }`
    }
  };

  caseSelection: ComponentDoc = {
    title: 'Selección de las aplicaciones',
    description: `
    A través de los Outputs <em>selectedApp</em> y <em>selectedOption</em> se obtiene cual de las aplicaciones, u opciones dentro de una aplicación, han sido clickadas, para que la vista que lo implemente pueda gestionar la navegación a las rutas correspondientes.
    `,
    codeExample: {
      ts: `
      import { Application } from '@global-front-components/common';
      ...
      selectedApp: Application;
      selectedAppWithOption: { app: Application, option: Application };

      selectApp(app) {
        this.selectedApp = app;
      }

      selectOption(appWithOption) {
        const {app, option} = appWithOption;
        this.selectedAppWithOption = {app: app, option: option};
      }
      `,
      html: `<ca-menu-header
      [srcLogo]="srcLogo" [versionTag]="version"
      (selectedApp)="selectApp($event)"
      (selectedOption)="selectOption($event)"
    ></ca-menu-header>
    <pre class="mt-2" *ngIf="selectedApp">{{ selectedApp | json }}</pre>
    <pre class="mt-2" *ngIf="selectedAppWithOption">{{ selectedAppWithOption | json }}</pre>`
    }
  };

  caseMenu: ComponentDoc = {
    title: 'Menu con las aplicaciones obtenidas por el servicio',
    description: `
    A través del Ouput <em>menu</em> se puede obtener el estado actual del menu (lista de aplicaciones) conforme el servicio vaya enviando aplicaciones.
    `,
    codeExample: {
      ts: `
      import { Application } from '@global-front-components/common';
      ...
      menu: Application[];

      getMenu(menu) {
        this.menu = menu;
      }
      `,
      html: `<ca-menu-header
      [srcLogo]="srcLogo" [versionTag]="version"
      (menu)="getMenu($event)"
    ></ca-menu-header>
    <pre class="mt-2" *ngIf="menu">{{ menu | json }}</pre>`
    }
  };

  selectApp(app) {
    this.selectedApp = app;
  }

  selectOption(appWithOption) {
    const {app, option} = appWithOption;
    this.selectedAppWithOption = {app: app, option: option};
  }

  getMenu(menu) {
    this.menu = menu;
  }
}
