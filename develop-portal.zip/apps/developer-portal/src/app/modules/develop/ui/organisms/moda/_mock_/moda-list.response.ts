import { ModasResponse } from "@global-front-components/common";

export const MODAS_RESPONSE_MOCK: ModasResponse = {
  "serviceId": "ConsultaModasSrv",
  "outputMap": {
      "mapacoddescripcion": [
          {
              "codigo": "00",
              "descripcion": "AUTOMOVILES"
          },
          {
              "codigo": "01",
              "descripcion": "AUTOCASER"
          },
          {
              "codigo": "02",
              "descripcion": "AUTOMOVILES"
          },
          {
              "codigo": "03",
              "descripcion": "POLIZA-RACC"
          },
          {
              "codigo": "04",
              "descripcion": "POLIZA MARFIL ATESA"
          },
          {
              "codigo": "05",
              "descripcion": "CASER AUTO POLIZA MARFIL"
          },
          {
              "codigo": "06",
              "descripcion": "AUTOS"
          },
          {
              "codigo": "07",
              "descripcion": "RENTING CON DEPRE"
          },
          {
              "codigo": "08",
              "descripcion": "RENTING SIN DEPRE"
          },
          {
              "codigo": "09",
              "descripcion": "RENTING FRACCIONARIO"
          },
          {
              "codigo": "10",
              "descripcion": "POLIZA MARFIL GENERICO"
          },
          {
              "codigo": "11",
              "descripcion": "POLIZA AZUL SIN BONUS"
          },
          {
              "codigo": "12",
              "descripcion": "AUTOS"
          },
          {
              "codigo": "13",
              "descripcion": "AUTOS"
          },
          {
              "codigo": "14",
              "descripcion": "PLACAS PRUEBAS"
          },
          {
              "codigo": "15",
              "descripcion": "CASER AUTO BANCANALYTICS"
          },
          {
              "codigo": "16",
              "descripcion": "POLIZA RENAULT"
          },
          {
              "codigo": "17",
              "descripcion": "POLIZA OVERLEASE"
          },
          {
              "codigo": "18",
              "descripcion": "CASER AUTO POLIZA MARFIL"
          },
          {
              "codigo": "19",
              "descripcion": "POLIZA FIAT"
          },
          {
              "codigo": "20",
              "descripcion": "POLIZA CICLOMOTOR"
          },
          {
              "codigo": "21",
              "descripcion": "0"
          },
          {
              "codigo": "22",
              "descripcion": "POLIZA AZUL"
          },
          {
              "codigo": "23",
              "descripcion": "RACC-XXI"
          },
          {
              "codigo": "24",
              "descripcion": "POLIZA VERDE"
          },
          {
              "codigo": "26",
              "descripcion": "AUTOS"
          },
          {
              "codigo": "27",
              "descripcion": "NEOTECA RENTING BBVA"
          },
          {
              "codigo": "28",
              "descripcion": "CASER FAMILIA"
          },
          {
              "codigo": "34",
              "descripcion": "CASER REMOTO EUROLLOYD"
          },
          {
              "codigo": "41",
              "descripcion": "VEHICULO PRIMERA CATEGORIA"
          },
          {
              "codigo": "42",
              "descripcion": "VEHICULOS SEGUNDA CATEGORIA"
          },
          {
              "codigo": "43",
              "descripcion": "VEHICULOS MENOS 4 RUEDAS"
          },
          {
              "codigo": "44",
              "descripcion": "FLOTAS"
          },
          {
              "codigo": "60",
              "descripcion": "AUTOMOVILES"
          },
          {
              "codigo": "64",
              "descripcion": "CASER AUTO S.XX 64"
          },
          {
              "codigo": "65",
              "descripcion": "CASER AUTO S.XX 65"
          },
          {
              "codigo": "66",
              "descripcion": "CASER AUTO S.XX 66"
          },
          {
              "codigo": "67",
              "descripcion": "CASER AUTO POLIZA AZUL"
          },
          {
              "codigo": "68",
              "descripcion": "CASER AUTO POLIZA-RACC"
          },
          {
              "codigo": "69",
              "descripcion": "CASER AUTO POLIZA VERDE"
          },
          {
              "codigo": "70",
              "descripcion": "CASER AUTO POLIZA RENAULT"
          },
          {
              "codigo": "71",
              "descripcion": "CASER AUTO POLIZA AZUL"
          },
          {
              "codigo": "72",
              "descripcion": "CASER AUTO POLIZA CICLOMOTOR"
          },
          {
              "codigo": "73",
              "descripcion": "CASER AUTO POLIZA AZUL"
          },
          {
              "codigo": "74",
              "descripcion": "CASER AUTO POLIZA RACC"
          },
          {
              "codigo": "75",
              "descripcion": "CASER AUTO POLIZA VERDE"
          },
          {
              "codigo": "76",
              "descripcion": "CASER AUTO POLIZA ROJA"
          },
          {
              "codigo": "77",
              "descripcion": "CASER AUTO RENTING"
          },
          {
              "codigo": "79",
              "descripcion": "PLURIANUAL"
          },
          {
              "codigo": "80",
              "descripcion": "CASER AUTO TARIFA PLANA"
          },
          {
              "codigo": "88",
              "descripcion": "TALLERES CONCERTADOS"
          }
      ]
  }
}
