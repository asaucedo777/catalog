import { Component } from '@angular/core';

@Component({
  templateUrl: 'validators.view.html',
  styleUrls: ['validators.view.scss']
})
export class ValidatorsView {}
