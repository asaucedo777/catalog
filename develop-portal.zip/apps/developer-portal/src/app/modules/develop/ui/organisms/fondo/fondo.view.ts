import { Component, OnInit } from '@angular/core';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
import { FondosRequest, FondosResponse, CaFondosService, Fondo } from '@global-front-components/common';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { FONDOS_RESPONSE_MOCK } from './_mock_/fondos-list.response';

@Component({
	templateUrl: 'fondo.view.html',
	styleUrls: ['fondo.view.scss']
})
export class FondoView implements OnInit {
	constructor(private _CaFondosService: CaFondosService) {}
	fondos: Fondo[];
	fondo: Fondo;
	fondoFound: Fondo;
	selectedFondo: Fondo;

	caseFondosSelect: ComponentDoc = {
		title: 'Componente Seleccionable de Fondo de pensión',
		description: `
    `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-select
          placeholder="Seleccione su fondo de pensión"
          keyValue="descripcion"
          [options]="fondos"
          [(ngModel)]="selectedFondo"
        ></ca-select>
        <pre class="mt-2" *ngIf="selectedFondo">
          {{ selectedFondo | json }}
        </pre>
      </ca-form-field>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { Fondo, FondosRequest, FondosResponse, CaFondosService } from '@global-front-components/common';

      @Component({
        selector: 'fondo-select-example',
        templateUrl: 'fondo-select-example.component.html',
        styleUrls: ['fondo-select-example.component.scss']
      })

      export class FondoSelectExampleComponent implements OnInit {
        constructor( private _caFondosService: CaFondosService ) { }

        fondos: Fondo[];
        selectedFondo: Fondo;

        ngOnInit() {
          const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
          const request: FondosRequest = {
            serviceId: 'ConsultaFondosPenSrv',
            inputMap: {
              codFondo: -1
            }
          };
          this._caFondosService.getFondos(endpoint, request).subscribe((response: FondosResponse) => {
            this.fondos = response.outputMap.mapacoddescripcion;
          })
        }
      }`
		}
	};

	codeFondosTypeahead: ComponentDoc = {
		title: 'Componente Predictivo de fondos',
		description: `Hay dos formas de emplear este componente predictivo. Por un lado se puede hacer una única llamada al servicio de fondos que nos devuelva toda la lista y filtrar a través del componente,
    o bien, llamar al servicio cada vez que el usuario introduce un valor en el <code class="tag">input</code>.
    <br />
    Primeramente se describe como implementarlo con una única llamada incial.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Fondo</ca-label>
        <input
          type="text"
          placeholder="Busque un fondo pensión"
          [caTypeahead]="search"
          [inputFormatter]="fondoFormatter"
          [(ngModel)]="fondo"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="fondo">
        {{ fondo | json }}
      </pre>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
      import { Fondo, FondosRequest, FondosResponse, CaFondosService } from '@global-front-components/common';

      @Component({
        selector: 'fondo-typeahead-example',
        templateUrl: 'fondo-typeahead-example.component.html',
        styleUrls: ['fondo-typeahead-example.component.scss']
      })

      export class FondoTypeaheadExampleComponent implements OnInit {
        constructor( private _caFondosService: CaFondosService ) { }

        fondos: Fondo[];
        fondo: Fondo;

        fondoFormatter = (x:{descripcion: string}) => x.descripcion;

        search = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            map(term => term === '' ? []
              : this.fondos.filter(v => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1))
          )

        ngOnInit() {
          const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
          const request: FondosRequest = {
            serviceId: 'ConsultaFondosPenSrv',
            inputMap: {
              codFondo: -1
            }
          };
          this._caFondosService.getFondos(endpoint, request).subscribe((response: FondosResponse) => {
            this.fondos = response.outputMap.mapacoddescripcion;
          })
        }
      }`
		}
	};

	codeFondosTypeaheadService: ComponentDoc = {
		description: `A continuación se describe como implementarlo con llamadas al servicio cuando el usuario interactúe.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Fondo</ca-label>
        <input
          type="text"
          placeholder="Busque su fondo de pensión"
          [caTypeahead]="searchFondos"
          [inputFormatter]="fondoFormatter"
          [(ngModel)]="fondoFound"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="fondoFound">
        {{ fondoFound | json }}
      </pre>`,
			ts: `
      import { Component } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
      import { Fondo, FondosRequest, FondosResponse, CaFondosService } from '@global-front-components/common';

      @Component({
        selector: 'fondo-typeahead-example',
        templateUrl: 'fondo-typeahead-example.component.html',
        styleUrls: ['fondo-typeahead-example.component.scss']
      })

      export class FondoTypeaheadExampleComponent {
        constructor( private _caFondosService: CaFondosService ) { }

        fondoFound: Fondo;

        fondoFormatter = (x:{descripcion: string}) => x.descripcion;

        searchFondos = (text$: Observable<string>) =>
        text$.pipe(
          debounceTime(300),
          distinctUntilChanged(),
          switchMap(term => {
            const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
            const request: FondosRequest = {
              serviceId: 'ConsultaFondosPenSrv',
              inputMap: {
                codFondo: -1
              }
            };
            return combineLatest([this._caFondosService(endpoint, request), of(term)])
           })
          )
          .pipe(map(([response, term]) => term === '' ? []
              : this.fondos.filter(v => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1))
          );
      }`
		}
	};

	fondoFormatter = (x: { descripcion: string }) => x.descripcion;

	search = (text$: Observable<string>) =>
		text$.pipe(
			debounceTime(300),
			distinctUntilChanged(),
			map((term) =>
				term === '' ? [] : this.fondos.filter((v) => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1)
			)
		);

	searchFondos = (text$: Observable<string>) =>
		text$
			.pipe(
				debounceTime(300),
				distinctUntilChanged(),
				switchMap((term) => {
					const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
					const request: FondosRequest = {
						serviceId: 'ConsultaFondosPenSrv',
						inputMap: {
							codFondo: -1
						}
					};
					return combineLatest([this._getFondosMock(endpoint, request), of(term)]);
				})
			)
			.pipe(
				map(([response, term]) =>
					term === '' ? [] : this.fondos.filter((v) => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1)
				)
			);

	private _getFondosMock(endpoint: string, request: FondosRequest): Observable<FondosResponse> {
		return this._CaFondosService.getFondos(endpoint, request).pipe(
			catchError(() => {
				return of(<FondosResponse>FONDOS_RESPONSE_MOCK);
			})
		);
	}

	ngOnInit() {
		const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
		const request: FondosRequest = {
			serviceId: 'ConsultaFondosPenSrv',
			inputMap: {
				codFondo: -1
			}
		};
		this._getFondosMock(endpoint, request).subscribe((response: FondosResponse) => {
			this.fondos = response.outputMap.mapacoddescripcion;
		});
	}
}
