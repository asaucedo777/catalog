import { DragDropModule } from '@angular/cdk/drag-drop';
import { CdkTableModule } from '@angular/cdk/table';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CaDownloadModule, CaFilterModule, CaResizeColumnModule } from '@global-front-components/common';
import {
  CaBreadcrumbModule, CaButtonModule,
  CaCardModule,
  CaCheckboxModule, CaClientValueModule, CaDatepickerModule,
  CaFormFieldModule, CaHeaderModule, CaIbanModule, CaInputFileModule,
  CaInputModule,
  CaMenuModule, CaMinComponentsModule, CaModalOverlayModule,
  CaModalOverlayService,
  CaPaginationModule,
  CaRadioButtonModule,
  CaSelectModule,
  CaSidebarModule, CaSidenavMenuModule, CaSlideToggleModule,
  CaSnackbarModule,
  CaSpinnerModule,
  CaTabsModule,
  CaTextareaModule,
  CaTooltipModule, CaTreeModule, CaTypeaheadModule
} from '@global-front-components/ui';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ComponentDocModule } from '../../../../components/component-doc/component-doc.module';
import { AtomsRoutingModule } from './atoms-routing.module';
import { AtomsView } from './atoms.view';
import { BreadCrumbView } from './breadcrumb/breadcrumb.view';
import { ButtonView } from './button/button.view';
import { CardView } from './card/card.view';
import { CdkTableView } from './cdk-table/cdk-table.view';
import { ModalTableExampleComponent } from './cdk-table/modal-example/modal-example.component';
import { CheckboxView } from './checkbox/checkbox.view';
import { ClientValueView } from './client-value/client-value.view';
import { DatepickerView } from './datepicker/datepicker.view';
import { DownloadView } from './download/download.view';
import { FormFieldView } from './form-field/form-field.view';
import { HeaderView } from './header/header.view';
import { IbanView } from './iban/iban.view';
import { InputFileView } from './input-file/input-file.view';
import { InputView } from './input/input.view';
import { MenuView } from './menu/menu.view';
import { ExampleModalComponent, ModalView } from './modal/modal.view';
import { PaginationView } from './pagination/pagination.view';
import { RadioButtonView } from './radio-button/radio-button.view';
import { SelectView } from './select/select.view';
import { SidenavMenuView } from './sidenav-menu/sidenav-menu.view';
import { SlideToggleView } from './slide-toggle/slide-toggle.view';
import { SnackbarView } from './snackbar/snackbar.view';
import { SpinnerView } from './spinner/spinner.view';
import { TabsView } from './tabs/tabs.view';
import { TestTabComponent } from './tabs/test.component';
import { TextareaView } from './textarea/textare.view';
import { TooltipView } from './tooltip/tooltip.view';
import { TreeView } from './tree/tree.view';
import { TypeaheadView } from './typeahead/typeahead.view';

@NgModule({
	declarations: [
		AtomsView,
		ButtonView,
		BreadCrumbView,
		CardView,
		CdkTableView,
		CheckboxView,
		ClientValueView,
		DatepickerView,
		ExampleModalComponent,
		FormFieldView,
		InputView,
		InputFileView,
		MenuView,
		ModalView,
		ModalTableExampleComponent,
		PaginationView,
		RadioButtonView,
		SelectView,
		SlideToggleView,
		SnackbarView,
		SpinnerView,
		TabsView,
		TestTabComponent,
		TextareaView,
		TooltipView,
		TypeaheadView,
		IbanView,
		TreeView,
		SidenavMenuView,
		HeaderView,
		DownloadView
	],
	imports: [
		AtomsRoutingModule,
		CaButtonModule,
		CaCardModule,
		CaCheckboxModule,
		CaDatepickerModule,
		CaFormFieldModule,
		CaInputFileModule,
		CaInputModule,
		CaMenuModule,
		CaModalOverlayModule,
		CaPaginationModule,
		CaRadioButtonModule,
		CaSelectModule,
		CaSidebarModule,
		CaSlideToggleModule,
		CaSnackbarModule,
		CaSpinnerModule,
		CaTabsModule,
		CaTextareaModule,
		CaTooltipModule,
		CaMinComponentsModule,
		CaTypeaheadModule,
		CaClientValueModule,
		CaFilterModule,
		CaBreadcrumbModule,
		CdkTableModule,
		CaIbanModule,
		CaTreeModule,
		CaSidenavMenuModule,
		CaHeaderModule,
		CommonModule,
		ComponentDocModule,
		DragDropModule,
		FormsModule,
		NgbModule,
		NgxChartsModule,
		ReactiveFormsModule,
		RouterModule,
		CaDownloadModule,
    CaResizeColumnModule
	],
	providers: [CaModalOverlayService]
})
export class AtomsModule {}
