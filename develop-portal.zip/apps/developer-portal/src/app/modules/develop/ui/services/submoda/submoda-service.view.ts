import { Component } from '@angular/core';

@Component({
	templateUrl: 'submoda-service.view.html',
	styleUrls: ['submoda-service.view.scss']
})
export class SubmodaServiceView {
	moduleContent = `
  import { CaSubmodaService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaSubmodaService ],
    ...
  })`;
}