import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
  templateUrl: 'checkbox.view.html',
  styleUrls: ['checkbox.view.scss']
})
export class CheckboxView implements OnInit, OnDestroy {
  importModule = `import { CaCheckboxModule } from '@global-front-components/ui';`;

  caseSimple: ComponentDoc = {
    title: `Uso simple`,
    codeExample: {
      html: `<ca-checkbox>Checkbox</ca-checkbox>`
    }
  };

  caseTrue: ComponentDoc = {
    title: `Uso con valor predeterminado`,
    description: `A través del atributo <code class="attribute">checked</code> se puede prestablecer un valor. Por defecto es <em>false</em>.`,
    codeExample: {
      html: `<ca-checkbox [checked]="true">
  Checkbox con valor preestablecido
</ca-checkbox>`
    }
  };

  caseIndeterminate: ComponentDoc = {
    title: `Estado indeterminado`,
    description: `A través del atributo <code class="attribute>indeterminate</code> podemos cargar el componente con el estado <em>indeterminate</em>, que se emplea en agrupaciones de checkboxes.`,
    codeExample: {
      html: `<ca-checkbox [indeterminate]="true">
  Checkbox indeterminado
</ca-checkbox>`
    }
  };

  caseLabels: ComponentDoc = {
    title: `Uso con diferente posición de label`,
    description: `A través del atributo <code class="attribute">labelPosition</code> podemos situar el texto delante o detrás del slide. Por defecto es <em>after</em>.`,
    codeExample: {
      html: `<ca-checkbox labelPosition="before">Label a la izquierda</ca-checkbox>
<ca-checkbox>Label a la derecha</ca-checkbox>`
    }
  };

  caseNoLabel: ComponentDoc = {
    title: `Uso sin label`,
    description: `Si queremos añadir un componente <code class="tag">ca-slide-toggle</code> sin asociar un label al mismo,
    por cuestiones de accesibilidad el <code class="tag">label</code> siempre debe renderizarse a nivel de DOM así que lo que haremos
    será ocultar el mismo a través del atributo <code class="attribute">labelVisible</code>.`,
    codeExample: {
      html: `<ca-checkbox [labelVisible]="false">Label invisible</ca-checkbox>`
    }
  };

  caseDisabled: ComponentDoc = {
    title: `Estado disabled`,
    description: `Siempre que nuestro elemento este deshabilitado a través del atributo <code class="attribute>disabled</code> se marcara como tal a nivel visual.`,
    codeExample: {
      html: `<ca-checkbox [disabled]="true">
  Checkbox deshabilitado
</ca-checkbox>
<ca-checkbox [checked]="true" [disabled]="true">
  Checkbox checked deshabilitado
</ca-checkbox>
<ca-checkbox [indeterminate]="true" [disabled]="true">
  Checkbox indeterminado deshabilitado
</ca-checkbox>`
    }
  };

  caseTemplateForm: ComponentDoc = {
    title: `Uso en formularios de plantilla`,
    description: `El componente <code class="tag">ca-checkbox</code> puede emplearse en formularios de plantilla
    mediante la directiva <code class="attribute">ngModel</code>
    del módulo <code class="module">@angular/forms</code>.`,
    codeExample: {
      ts: `import { Component } from '@angular/core';
@Component({
  selector: 'ca-template-form-view',
  templateUrl: './template-form-view.component.html',
  styleUrls: ['./template-form-view.component.scss']
})
export class TemplateFormViewComponent {
  model = false;
}`,
      html: `<ca-checkbox [(ngModel)]="model">
  Checkbox en formulario de plantila
</ca-checkbox>
<p>Valor en el formulario: <i>{{model}}</i></p>`
    }
  };

  caseReactiveForm: ComponentDoc = {
    title: `Uso en formularios reactivos`,
    description: `El componente <code class="tag">ca-checkboxe</code> puede emplearse en formularios reactivos
    mediante la directiva <code class="attribute">formControlName</code>
    del módulo <code class="module">@angular/forms</code>.`,
    codeExample: {
      ts: `import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup} from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'ca-reactive-form-view',
  templateUrl: './reactive-form-view.component.html',
  styleUrls: ['./reactive-form-view.component.scss']
})
export class ReactiveFormViewComponent implements OnInit, OnDestroy {
  constructor(private formBuild: FormBuilder) {}
  private _destroy$: Subject<void> = new Subject<void>();
  public form: FormGroup;

  ngOnInit() {
    this.form = this.formBuild.group({
      controlOne: false,
      controlTwo: [{value: true, disabled: true}]
    });
    this.form.get('controlOne').valueChanges
      .pipe(takeUntil(this._destroy$))
      .subscribe((value)=>{
      if (value) {
        this.form.get('controlTwo').enable();
      } else {
        this.form.get('controlTwo').disable();
      }
    })
  }

  ngOnDestroy() {
   this._destroy$.next();
    this._destroy$.unsubscribe();
  }
}`,
      html: `<form [formGroup]="form">
  <ca-checkbox formControlName="controlOne">
    Primer control
  </ca-checkbox>
  <ca-checkbox formControlName="controlTwo">
    SegundoControl
  </ca-checkbox>
</form>`
    }
  }

  caseMinimumSize: ComponentDoc = {
    title: `Checkbox a tamaño mínimo`,
    description: `Para conseguir que los checkboxes adquieran el tamaño mínimo, se le añade el atributo <code class="attribute">ca-checkbox-min</code> junto al resto de atributos.`,
    codeExample: {
      html: `<ca-checkbox ca-checkbox-min>
  Checkbox mínimo
</ca-checkbox>
<ca-checkbox [checked]="true" ca-checkbox-min>
  Checkbox checked mínimo
</ca-checkbox>
<ca-checkbox [indeterminate]="true" ca-checkbox-min>
  Checkbox indeterminado mínimo
</ca-checkbox>`
    }
  };

  caseStringToBoolean: ComponentDoc = {
    title: `Conversión del valor del checkbox a un string`,
    description: `Supongamos que se desea convertir el valor devuelto por el checkbox a un string correspondiente al <em>true</em> y otro al <em>false</em>.
    Para ello definiremos en el <em>TypeScript</em> un método para convertirlos.`,
    codeExample: {
      html: `<form [formGroup]="valueForm">
  <ca-checkbox formControlName="conditions">
    Acepto las condiciones
  </ca-checkbox>
</form>
<p>Valor como string: {{convertBooleanToString(valueForm.get('conditions').value,'S','N')}}</p>
`,

      ts: `import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup} from '@angular/forms';
@Component({
  selector: 'ca-checkbox-string-value',
  templateUrl: './checkbox-string-value-component.component.html',
  styleUrls: ['./checkbox-string-value-component.component.scss']
})
export class CheckboxStringValueComponent implements OnInit{
  constructor(private _formBuild: FormBuilder) {}
  valueForm: FormGroup;

  convertBooleanToString(value: boolean, stringOk: string, stringKo: string): string {
    return value ? stringOk : stringKo;
  }

  ngOnInit() {
    this.valueForm = this._formBuild.group({
      conditions: false
    });
  }
}`
    }
  }

  caseBooleanToString: ComponentDoc = {
    title: `Conversión del valor recibido como string para setearlo en el checkbox`,
    description: `Supongamos que recibimos un valor del servidor como un string que se deba setear al checkbox, por ejemplo, 'S'.
    Para ello, en la inicialización del formulario, deberemos convertir ese valor <em>válido</em> a un booleano.`,
    codeExample: {
      html: `<form [formGroup]="valueForm">
  <ca-checkbox formControlName="conditions">
    Acepto las condiciones
  </ca-checkbox>
</form>`,

      ts: `import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup} from '@angular/forms';
@Component({
  selector: 'ca-checkbox-string-value',
  templateUrl: './checkbox-string-value-component.component.html',
  styleUrls: ['./checkbox-string-value-component.component.scss']
})
export class CheckboxStringValueComponent implements OnInit{
  constructor(private _formBuild: FormBuilder) {}
  valueForm: FormGroup;
  acceptedString = 'S';

  private _convertStringToBoolean(stringOk: string): boolean {
    return stringOk === this.acceptedString;
  }

  ngOnInit() {
    this.valueForm = this._formBuild.group({
      conditions: this._convertStringToBoolean('S')
    });
  }
}`
    }
  }

  constructor(private formBuild: FormBuilder) { }
  private _destroy$: Subject<void> = new Subject<void>();
  form: FormGroup;
  valueForm: FormGroup;
  model = false;
  acceptedString = 'S';

  convertBooleanToString(value: boolean, stringOk: string, stringKo: string): string {
    return value ? stringOk : stringKo;
  }

  private _convertStringToBoolean(stringOk: string): boolean {
    return stringOk === this.acceptedString;
  }

  ngOnInit() {
    this.valueForm = this.formBuild.group({
      conditions: false,
      conditions2: this._convertStringToBoolean('S')
    });
    this.form = this.formBuild.group({
      controlOne: false,
      controlTwo: [{ value: true, disabled: true }]
    });
    this.form.get('controlOne').valueChanges
      .pipe(takeUntil(this._destroy$))
      .subscribe((value) => {
        if (value) {
          this.form.get('controlTwo').enable();
        } else {
          this.form.get('controlTwo').disable();
        }
      })
  }

  ngOnDestroy() {
    this._destroy$.next();
    this._destroy$.unsubscribe();
  }
}
