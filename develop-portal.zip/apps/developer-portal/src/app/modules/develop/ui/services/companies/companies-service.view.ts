import { Component } from '@angular/core';

@Component({
  templateUrl: 'companies-service.view.html',
  styleUrls: ['companies-service.view.scss']
})
export class CompaniesServiceView {
  moduleContent = `
  import { CaCompaniesService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaCompaniesService ],
    ...
  })`;
}
