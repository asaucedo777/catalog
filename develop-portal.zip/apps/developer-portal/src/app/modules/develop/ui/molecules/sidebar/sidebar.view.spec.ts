import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SidebarView } from './sidebar.view';

describe('SidebarView', () => {
  let component: SidebarView;
  let fixture: ComponentFixture<SidebarView>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SidebarView ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SidebarView);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
