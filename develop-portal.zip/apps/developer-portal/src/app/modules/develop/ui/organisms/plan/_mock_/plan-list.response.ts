import { PlanPenResponse } from "@global-front-components/common/lib/models/plan.interface";

export const PLAN_LIST_RESPONSE_MOCK: PlanPenResponse = {
	serviceId: 'ConsultaPlanesPenSrv',
	outputMap: {
		mapacoddescripcion: [
			{
				codigo: '0',
				descripcion: 'AHORRO Y TITUL. PP'
			},
			{
				codigo: '3958',
				descripcion: 'PENEDES PENSIO MIXT PP'
			},
			{
				codigo: '3959',
				descripcion: 'PENEDES PENSIO VARIABLE MIXT PP'
			},
			{
				codigo: '3960',
				descripcion: 'PENEDES PENSIO BORSA PP'
			},
			{
				codigo: '3962',
				descripcion: 'PENEDES PENSIO EUROBORSA 100, PP'
			},
			{
				codigo: '3963',
				descripcion: 'CEP 1 PP'
			},
			{
				codigo: '4141',
				descripcion: 'PENEDES PENSIO PROTECCION 2017 PP'
			},
			{
				codigo: '4338',
				descripcion: 'PENEDES PENSIO CREIXENT PP'
			}
		]
	}
};
