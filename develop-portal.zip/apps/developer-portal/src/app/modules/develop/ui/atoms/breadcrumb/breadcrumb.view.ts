import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';
import { IBreadCrumb } from '@global-front-components/ui';

@Component({
    templateUrl: 'breadcrumb.view.html',
    styleUrls: ['breadcrumb.view.scss']
})
export class BreadCrumbView {
    dataBreadcrumb: IBreadCrumb[] = [
        {
            label: 'Card',
            url: '/develop/atoms/card'
        },
        {
          label: 'Cdk Table',
          url: '/develop/atoms/cdk-table'
        },
        {
          label: 'Breadcrumb',
          url: '/develop/atoms/breadcrumb/prueba1/prueba2/prueba3'
        }
    ];

    param1: string = '';
    param2: string = '';
    param3: string = '';

    constructor(private route: ActivatedRoute) {
        this.param1 = this.route.snapshot.paramMap.get('id');
        this.param2 = this.route.snapshot.paramMap.get('id2');
        this.param3 = this.route.snapshot.paramMap.get('id3');
    }

    moduleContent = `import { CaBreadcrumbModule } from '@global-front-components/ui';`;

    caseOne: ComponentDoc = {
        title: 'Uso de Breadcrumb',
        description: `<p>Ejemplo de uso de breadcrumb simple para aplicaciones</p>`,
        codeExample: {
            html: `
<ca-breadcrumb>
    <li
    ca-breadcrumb-item
    *ngFor="let item of dataBreadcrumb"
    >
        <a
        routerLink="{{item.url}}"
        routerLinkActive="ca-router-link-active"
        [routerLinkActiveOptions]="{exact:true}">
        {{item.label}}
        </a>
        <span class="material-icons">keyboard_arrow_right</span>
    </li>
</ca-breadcrumb>`,
            ts: `
import { IBreadCrumb } from '@global-front-components/ui';

dataBreadcrumb: IBreadCrumb[] = [
  {
    label: 'Card',
    url: '/develop/atoms/card'
  },
  {
    label: 'Cdk Table',
    url: '/develop/atoms/cdk-table'
  },
  {
    label: 'Breadcrumb',
    url: '/develop/atoms/breadcrumb/prueba1/prueba2/prueba3'
  }
];`
        }
    };

    caseTwo: ComponentDoc = {
        title: 'Uso de Breadcrumb de consulta',
        description: `<p>Ejemplo de uso de breadcrumb readonly para consulta de usuarios</p>
        <p>Añadimos el atributo <code>readonly</code></p>`,
        codeExample: {
            html: `
<ca-breadcrumb readonly>
    <li
    ca-breadcrumb-item
    *ngFor="let item of dataBreadcrumb"
    >
        <a
        routerLink="{{item.url}}"
        routerLinkActive="ca-router-link-active"
        [routerLinkActiveOptions]="{exact:true}">
        {{item.label}}
        </a>
        <span class="material-icons">keyboard_arrow_right</span>
    </li>
</ca-breadcrumb>`
        }
    };

    caseThree: ComponentDoc = {
        title: 'Ocultar breadcrumb',
        description: `<p>Ejemplo de uso de breadcrumb oculto para que los usuarios no puedan visualizarlo</p>
            <p>Añadimos el atributo <code>hidden</code></p>
        `,
        codeExample: {
            html: `
<ca-breadcrumb hidden>
    <li
    ca-breadcrumb-item
    *ngFor="let item of dataBreadcrumb"
    >
        <a
        routerLink="{{item.url}}"
        routerLinkActive="ca-router-link-active"
        [routerLinkActiveOptions]="{exact:true}">
        {{item.label}}
        </a>
        <span class="material-icons">keyboard_arrow_right</span>
    </li>
</ca-breadcrumb>`,
        }
    };

    caseFour: ComponentDoc = {
        title: 'Uso de Breadcrumb con parámetros',
        description: `<p>Ejemplo de uso de breadcrumb con parámetros</p>`,
        codeExample: {
            html: `
<ca-breadcrumb>
    <li
    ca-breadcrumb-item
    *ngFor="let item of dataBreadcrumb"
    >
        <a
        routerLink="{{item.url}}"
        routerLinkActive="ca-router-link-active"
        [routerLinkActiveOptions]="{exact:true}">
        {{item.label}}
        </a>
        <span class="material-icons">keyboard_arrow_right</span>
    </li>
    <li ca-breadcrumb-params-items>{{param1}}</li>
    <li ca-breadcrumb-params-items>{{param2}}</li>
    <li ca-breadcrumb-params-items>{{param3}}</li>
</ca-breadcrumb>`,
            ts: `
import { ActivatedRoute } from '@angular/router';
import { IBreadCrumb } from '@global-front-components/ui';

param1: string = '';
param2: string = '';
param3: string = '';

constructor(private route: ActivatedRoute) {
    this.param1 = this.route.snapshot.paramMap.get('id');
    this.param2 = this.route.snapshot.paramMap.get('id2');
    this.param3 = this.route.snapshot.paramMap.get('id3');
}`
        }
    };

}
