import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DevelopView } from './develop.view';

const routes: Routes = [
  {
    path: '',
    component: DevelopView,
    children: [
      {
        path: 'atoms',
        loadChildren: () => import('./ui/atoms/atoms.module').then((m) => m.AtomsModule)
      },
      {
        path: 'extensions',
        loadChildren: () => import('./ui/extensions/extensions.module').then((m) => m.ExtensionsModule)
      },
      {
        path: 'molecules',
        loadChildren: () => import('./ui/molecules/molecules.module').then((m) => m.MoleculesModule)
      },
      {
        path: 'organisms',
        loadChildren: () => import('./ui/organisms/organisms.module').then((m) => m.OrganismsModule)
      },
      {
        path: 'services',
        loadChildren: () => import('./ui/services/services.module').then((m) => m.ServicesModule)
      },
      {
        path: 'validators',
        loadChildren: () => import('./ui/validators/validators.module').then((m) => m.ValidatorsModule)
      },
      {
        path: 'utilities',
        loadChildren: () => import('./ui/utiliesStyle/utiliesStyle.module').then((m) => m.UtiliesStyleModule)
      },
      {
        path: 'salud',
        loadChildren: () => import('./ui/salud/salud.module').then((m) => m.SaludModule)
      }

    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DevelopRoutingModule { }
