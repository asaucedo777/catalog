import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'app-build.view.html',
	styleUrls: ['app-build.view.scss']
})
export class AppBuildView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/app-build/app-build.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
