# Creación de la vista de Login

El siguiente paso es la creación de la vista de Login. 

De nuevo, tenemos dos opciones:

* A través de la interfaz de la consola de ***Nx*** :

![NxLoginView](./assets/docs/images/nx-login-view.png)

![NxLoginView2](./assets/docs/images/nx-login-view-2.png)

* A través de la consola del _entorno de desarrollo_:

```
npm run ng generate component modules/login/views/login --module=login.module --style=scss --skipSelector --type=view
```

Como se puede observar, se ha optado por evitar la incorporación del *selector*, ya que por buena práctica, las vistas no van a poder estar contenidas en otro elemento de la aplicación (a diferencia de los componentes), si no que serán accesibles a través de la navegación. Además se ha usado la nomenclatura ***view*** (en vez de *component*).

El resultado es el siguiente:

![LoginModule2](./assets/docs/images/login-module-2.png)
