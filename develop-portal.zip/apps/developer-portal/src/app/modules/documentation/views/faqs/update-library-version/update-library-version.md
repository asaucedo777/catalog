# Actualizar versión de la librería de compoenetes globales.

## Actualizar @global-front-components.

Si actualmente tenemos instalada un versión de la librería global-front-components y queremos subir de versión. tan sólo debemos indicar la versión a la que quermos actualizar en el package.json.
Podemos consultar la ultima versión publicada en la cabecera de este mismo portal.

```
"@global-front-components/common": "1.1.2",
"@global-front-components/core": "1.1.2",
"@global-front-components/ui": "1.1.2",
```
Una vez actualizada la version en el package.json lanzaremos en la consola el comando de instalación de npm:

```
npm install
```
recordemos que tenemos que estar en la carperta del proyecto.

## Actualizar desde la antigua @caser-architecture:

Si aún tenemos instalada la antigua versión de la librería de componentes, nombrada com @caser-architecture.
Debemos renombrar esos paquetes en el package.json con la nueva nomenclatura. 

cambiaremos

```
"@caser-architecture/common": "0.1.19",
"@caser-architecture/core": "0.1.19",
"@caser-architecture/ui": "0.1.19",
```
por

```
"@global-front-components/common": "1.1.2",
"@global-front-components/core": "1.1.2",
"@global-front-components/ui": "1.1.2",
```

Ahora en el terminal, situados en la carpeta del proyecto, lanzaremos el comando

```
npm install
```

Una vez realizado el proceso de instalación. Revisen la documentacionmm del portal para ver posibles cambios en los modulos, compoenets, servicios etc.. que puedan generar fallos en la aplicación.


