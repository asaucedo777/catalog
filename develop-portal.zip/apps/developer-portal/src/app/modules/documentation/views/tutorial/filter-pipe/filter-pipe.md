# Implementación del filtrado en la tabla mediante un Pipe

En este apartado vamos a aplicar el filtrado sobre la tabla, de modo que cuando escribamos sobre el \<input\> la tabla filtre y muestre aquellas filas que contengan el texto escrito.

Para ello vamos a hacer uso de una herramienta que **Angular** nos proporciona, los ***Pipe***.

Para generar un *Pipe*, de nuevo tenemos dos formas:

* A través de la interfaz de la consola de ***Nx*** :

![NxFilterPipe](./assets/docs/images/nx-filter-pipe.png)

* A través de la consola del _entorno de desarrollo_:

```
npm run ng g pipe modules/information/pipes/filter --module=information.module
```

El resultado es el siguiente:

![InfoModule9](./assets/docs/images/info-module-9.png)

Vamos ahora a darle lógica a nuestro *Pipe*:

![FilterPipe](./assets/docs/images/filter-pipe.png)

Una vez hemos dotado de lógica al *pipe* nos disponemos a implementarlo sobre el ***table.component***.
Además, como se comento en el apartado anterior, vamos a añadir un nuevo input sobre este componente, que recibirá el texto escribo en el campo de búsqueda.

De este modo, vamos a refactorizar el componente de Tabla del siguiente modo:

![TableFilterFinalTs1](./assets/docs/images/table-filter-final-ts-1.png)

![TableFilterFinalTs2](./assets/docs/images/table-filter-final-ts-2.png)

Dónde:

* ***1)***  La declaración del *pipe* en el constructor
* ***2)***  Propiedad privada para el *Input* **search** 
* ***3)***  Propiedad privada para el *Input* **dataSource** 
* ***4)***  Propiedad pública que almacenará el resultado del *pipe* e informará al *.html*
* ***5)***  *Input* **dataSource** que recibe la información a mostrar en la tabla. También copia su contenido en la propiedad pública **dataSourceResult**, para muestre toda la información cuando no haya búsqueda.
* ***6)***  *Input* **search** que recibe texto por el que se debe filtrar. Contiene el punto ***7)***.
* ***7)***  Aplicación del *pipe* de filtrado y almacenamiento en la propiedad pública **dataSourceResult**

Por tanto debemos cambiar el *.html* de la tabla para que muestre la informacion filtrada *dataSourceResult*, y no toda la información:

![TableFilterFinalHtml](./assets/docs/images/table-filter-final-html.png)

Por último debemos añadir el nuevo *Input* *search* en *introduction.view.html* para que setee su propiedad *search* en la tabla (recordemos que es la que recoge el campo de texto a buscar, como se explicó en el apartado anterior).

![InfoViewFinalHtml](./assets/docs/images/info-view-final-html.png)

Ahora incializamos la aplicación y realizamos una búsqueda y obtenemos:

![TableFinalResult](./assets/docs/images/table-final-result.png)
