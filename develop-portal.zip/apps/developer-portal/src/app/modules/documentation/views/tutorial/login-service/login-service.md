# Creación del servicio de login

Una vez creado el servidor mock, vamos a generar el servicio de login que apunte al *endpoint*, y así poder consumirlo desde nuestra vista.

De nuevo, tenemos dos opciones:

* A través de la interfaz de la consola de ***Nx*** :

![NxLoginService](./assets/docs/images/nx-login-service.png)

* A través de la consola del *entorno de desarrollo*:
```
npm run ng g service modules/login/services/login
```

El resultado será:

![LoginService](./assets/docs/images/login-service.png)

Para poder usarlo, deberemos importarlo en el ***login.module.ts*** del siguiente modo:

![LoginModule6](./assets/docs/images/login-module-6.png)

Ahora vamos a darle lógica a nuestro servicio. Lo primero vamos a definir una *interfaz* para la petición y para la respuesta del servicio, del siguiente modo:

![LoginInterface](./assets/docs/images/login-interface.png)

A continuación, vamos a crear el método *sendData* del servicio, que apuntará a nuestro *endpoint* (***/api/login***):

![LoginService2](./assets/docs/images/login-service-2.png)

Una vez lista la lógica del servicio, vamos a poder consumirlo desde nuestro componente:

![LoginFormTsService](./assets/docs/images/login-form-ts-service.png)

![LoginFormHtmlService](./assets/docs/images/login-form-html-service.png)

Arrancamos la aplicación y el resultado que obtendremos al pulsar en el botón de Enviar será el siguiente:

![LoginServiceResult](./assets/docs/images/login-service-result.png)
