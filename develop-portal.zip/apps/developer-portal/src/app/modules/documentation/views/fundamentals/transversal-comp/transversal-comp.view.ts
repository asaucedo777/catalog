import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'transversal-comp.view.html',
	styleUrls: ['transversal-comp.view.scss']
})
export class TransversalCompView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/transversal-comp/transversal-comp.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
