import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'table-server.view.html',
	styleUrls: ['table-server.view.scss']
})
export class TableServerView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/table');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/table-service');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/table-server/table-server.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
