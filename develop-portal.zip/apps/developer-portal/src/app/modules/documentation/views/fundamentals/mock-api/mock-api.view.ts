import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'mock-api.view.html',
	styleUrls: ['mock-api.view.scss']
})
export class MockApiView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/mock-api/mock-api.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
