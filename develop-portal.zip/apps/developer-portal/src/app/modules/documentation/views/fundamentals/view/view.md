# Creación de una vista

Es una buena práctica diferenciar las *vistas* de los _componentes_. 

Un **componente** puede ser llamado en el *html* de otro componente o vista a través de su **selector**, por ejemplo el componente de CASER *form-field* lo llamaremos a través de *\<ca-form-field\>\</ca-form-field\>*.

En cambio, una **vista** sólo debe ser cargada a través de la navegación de la aplicación que la contenga (a través del _router_), por lo que no precisa de **selector**, además se diferencian en que acaban con la extension *.view.ts*, *.view.html* y *.view.scss*.

Por tanto, podemos decir que las *vistas* son un caso especial de *componentes*.

Para crear una vista tenemos dos opciones:

## A través de la interfaz de usuario de Nx:

Pasos: 
* **1**  Abrir la consola de Nx
* **2**  Seleccionar la acción _generate_
* **3**  Buscar _component_
* **4**  Seleccionar la opción _@schematics/angular - component_
* **5**  Escribir el nombre del componente
* **6**  Escribir el nombre del _módulo_ al que pertenece
* **7**  Seleccionar la extensión de los _estilos_
* **8**  Seleccionar la opción _skipSelector_
* **9**  Escribir la extensión _View_

![NxView](./assets/docs/images/nx-view.png)

![NxView2](./assets/docs/images/nx-view-2.png)

## A través de la consola del entorno de desarrollo:

Podríamos realizar el mismo proceso a través de consola lanzando el siguiente comando:

```
npm run ng generate component modules/example/views/example --module=example.module --style=scss --skipSelector --type=view
```

El resultado es el siguiente:

![ExampleModuleView](./assets/docs/images/example-module-view.png)
