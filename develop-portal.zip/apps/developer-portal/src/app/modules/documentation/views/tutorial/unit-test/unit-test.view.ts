import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'unit-test.view.html',
	styleUrls: ['unit-test.view.scss']
})
export class UnitTestView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/filter-pipe');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/e2e');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/unit-test/unit-test.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
