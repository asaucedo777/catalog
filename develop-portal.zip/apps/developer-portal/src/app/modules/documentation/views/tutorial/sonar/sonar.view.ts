import { Component, OnInit } from '@angular/core';

@Component({
	templateUrl: 'sonar.view.html'
})
export class SonarView {
    dataSonarConfig = [
        {
            title: '¿Qué es?', 
            description: 'Es una plataforma para evaluar la calidad del código fuente, realizando un análisis estático sobre dicho código, con el objetivo de advertirnos sobre diferentes puntos a mejorar y obtener métricas que nos ayudan a mejorar nuestro código.'
        },
        {
            title: 'SonarLint',
            description: 'Tan solo disponemos de esta extensión en el IDE (IntelliJ, Eclipse y Visual Studio). Su propósito es brindar retroalimentación instantánea a medida que escribe su código.',
            child: [
                {
                    title: 'Instalación',
                    description: {
                        text: 'La instalación de esta extensión se realiza a través del software Visual Studio Code.',
                        img: '',
                        params: [
                            {
                                text: 'Abre la pestaña de Extensiones sitada en la barra lateral derecha del programa.'
                            },
                            {
                                text: 'Introduce sonar en el buscador.',
                                img: ''
                            },
                            {
                                text: 'Selecciona SonarLint.',
                                img: '../../../../assets/docs/images/sonar_search.png'
                            },
                            {
                                text: 'Instala la extensión',
                                img: '../../../../assets/docs/images/sonarlint_install.png'
                            }
                        ]
                    } 
                },
                {
                    title: 'Configuración',
                    description: {
                        text: 'Un vez instalada la extensión, tenemos que configurar nuestras reglas.',
                        img: '',
                        params: [
                            {
                                text: 'Haz click sobre el icono de configuración.',
                                img: '../../../../assets/docs/images/sonarlint_config.png'
                            },
                            {
                                text: 'Es necesario editar la configuración de SonarQube.',
                                img: '../../../../assets/docs/images/sonarlint_config_conections.png'
                            },
                            {
                                text: 'Introduce la url de nuestro sonar coorporativo.',
                                link: 'https://sonar.caser.local/',
                                img: ''
                            },
                            {
                                text: 'Agrega el token generado en Sonar.',
                                img: '../../../../assets/docs/images/sonarlint_config_page.PNG'
                            },
                            {
                                text: 'Accede a SonarQube para generar tu token.',
                                link: 'https://sonar.caser.local/account/security/'
                            }
                        ]
                    },
                }
            ]
        },
        {
            title: 'SonarQube',
            description: 'Es una plataforma de software libre para evaluar la calidad de nuestro código fuente, realizando un análisis estático sobre dicho código, con el objetivo de advertirnos sobre diferentes puntos a mejorar. Se denomina análisis estático del código al proceso de evaluar el software sin ejecutarlo.',
            child: [
                {
                    title: 'Configuración SonarQube',
                    description: {
                        text: 'Para poder usar SonarQube en local:',
                        img: '',
                        params: [
                            {
                                text: 'Descargar Sonar CE.',
                                link: 'https://www.sonarqube.org/downloads',
                                img: '../../../../assets/docs/images/sonar_web_version.png'
                            },
                            {
                                text: 'Descomprime el archivo que has descargado y ejecuta StartSonar.bat desde la carpeta bin para levantar el entorno local de SonarQube',
                                link: 'C:/opt/sonarqube-7.1/bin/windows-x86-64',
                                img: '../../../../assets/docs/images/sonar_exe_bat.png'
                            },
                            {
                                text: 'Abre el navegador en',
                                link: 'https://localhost:9000/'
                            },
                            {
                                text: 'Accede a SonerQube con las siguientes credenciales:',
                            },
                            {
                                text: 'User: admin',
                                link: ''
                            },
                            {
                                text: 'Password: admin',
                                link: '',
                                img: '../../../../assets/docs/images/sonar_localhost.png'
                            }
                        ]
                    }
                },
                {
                    title: 'Configuración y ejecución del proyecto',
                    description: {
                        text: 'Si ya tienes SonarQube en ejecución puedes comenzar a configurar tu proyecto:',
                        img: '',
                        params: [
                            {
                                text: 'Es necesario instalar dos dependencias nuevas'
                            },
                            {
                                text: '"jest-sonar": "^0.2.12"',
                                link: 'npm i -D jest-sonar'
                            },
                            {
                                text: '"sonar-scanner": "^3.1.0"',
                                link: 'npm install -D sonarqube-scanner'
                            },
                            {
                                text: 'Una vez instaladas las dependencias asegurate de que el archivo jest.config.js contiene la siguiente configuración:',
                                img: '../../../../assets/docs/images/jest_sonar.png'
                            },
                            {
                                text: 'A continuación ejecuta las pruebas unitarias para generar los archivos necesarios para su posterior lectura en SonarQube.',
                                link: 'npm run test',
                                img: ''
                            },
                            {
                                text: 'Ahora ejetumos el comando necesario para conectar nuestro proyecto con sonar y conocer el resultado de nuestras métricas.',
                                link: 'npm run sonar',
                                img: ''
                            },
                            {
                                text: 'Por último abrimos nuestro navegador para visualizar el resultado de nuestros proyectos.',
                                link: 'https://localhost:9000/',
                                img: '../../../../assets/docs/images/sonar_local_apps.png'
                            }
                        ]
                    }
                }
            ]
        }
    ];
}
