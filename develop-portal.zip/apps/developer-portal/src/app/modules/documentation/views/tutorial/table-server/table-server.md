# Creación de un nuevo endpoint en el servidor mock para la tabla

Vamos a levantar en local otro *endpoint* en el servidor mock creado anteriormente, para alimentar la tabla.

Para ello, configuraremos nuestro *proxy.conf* del siguiente modo:

![TableProxyConf](./assets/docs/images/table-proxy-conf.png)

A continuación, configuraremos nuestros servidor mock para que cuando se haga un *GET* al nuevo endpoint nos devuelva un objeto con un listado de elementos de la tabla periódica, que vamos a resperesentar en nuestra tabla:

![TableServer](./assets/docs/images/table-server.png)

El objeto con el listado de elementos químicos se encuentra en el siguiente archivo, al que apunta nuestro servidor mock:

![ElementsApi](./assets/docs/images/elements-api.png)

Esta API de elementos periódicos se ha obtenido de este [enlace](https://github.com/Bowserinator/Periodic-Table-JSON/blob/master/PeriodicTableJSON.json).

