import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'new-component.view.html',
	styleUrls: ['new-component.view.scss']
})
export class NewComponentView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/new-component/new-component.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
