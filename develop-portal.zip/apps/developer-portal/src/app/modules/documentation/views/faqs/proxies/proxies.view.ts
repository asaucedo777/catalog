import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
  templateUrl: './proxies.view.html',
  styleUrls: ['./proxies.view.scss']
})
export class ProxiesView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  markdown: any;

  ngOnInit(): void {
    this._markdownService.getMarkdown('assets/docs/md/faqs/proxies/proxies.md').subscribe((response) => {
      this.markdown = response;
    })
  }

}
