import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'dependencies.view.html',
	styleUrls: ['dependencies.view.scss']
})
export class DependenciesView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/dependencies/dependencies.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
