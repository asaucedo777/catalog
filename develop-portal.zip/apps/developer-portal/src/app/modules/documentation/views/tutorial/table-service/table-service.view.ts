import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'table-service.view.html',
	styleUrls: ['table-service.view.scss']
})
export class TableServiceView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/table-server');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/cdk-table');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/table-service/table-service.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
