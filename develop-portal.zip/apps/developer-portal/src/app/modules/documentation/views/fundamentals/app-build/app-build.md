# Construcción de una aplicación

Una vez que tenemos una aplicación lista para liberar una versión en los diferentes entornos, debemos proceder a construir la misma, para ellos lanzaremos el siguiente comando:

```
npm run build:prod
```

![Build](./assets/docs/images/build.png)

Este proceso generar una serie de ficheros estáticos en la siguiente ruta:

![Dist](./assets/docs/images/dist.png)

Este proceso por si mismo no tiene mucho sentido aplicarlo en nuestro local, salvo para saber que nuestra aplicativo puede _construirse_.

Es muy importante aplicar este proceso dentro de los entornos de **integración continua** de CASER y hacer uso de estos mismos scripts ya que si lo hacemos de esta forma aseguraremos que nuestro desarrollo _local_ siempre cumple con las expectativas de nuestro desarrollo en los entornos de **integración continua**.
