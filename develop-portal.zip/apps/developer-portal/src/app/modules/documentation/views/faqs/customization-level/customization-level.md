# Nivel de personalización

Los componentes por defecto tienen asociado un estilo visual (_theme_) para dotar de homogeneidad a todas las aplicaciones que hagan uso de los mismos.
Pueden existir casos en los que no queramos hacer uso de este estilo visual y dotar de cierta personalización a los componentes, entre ellos encontramos los siguientes:

* Personalización global.
* Personalización específica.

## Personalización global

Puede darse el caso en el que estemos haciendo uso de un componente del catálogo de componentes, pero que nuestra aplicación requiere que ese componente siempre se visualice de una forma diferente a la predefinida.

En este caso lo que haremos será hacer uso del fichero _styles.scss_ que se encuentra en nuestra aplicación y ahí indicaremos que un componente X se visualizará de una forma X.

Para este ejemplo vamos a añadir a nuestra vista del apartado anterior unos cuantos componentes **button** del catálogo de componentes:

![CustomComponent](./assets/docs/images/custom-component.png)

Modificación del fichero _styles.scss_:

![CustomStylesCss](./assets/docs/images/custom-styles-css.png)

El resultado es el siguiente:

![CustomCardGlobal](./assets/docs/images/custom-card-global.png)

## Personalización específica

Puede darse el caso en el que estemos haciendo uso de un componente del catálogo de componentes, pero que nuestra aplicación requiere que en cierto punto de la aplicación un componente tenga una visualización diferente.

En este caso lo que haremos será hacer añadir un clase css _custom_ a nuestro componente:

![CustomComponent2](./assets/docs/images/custom-component-2.png)

Modificar el fichero _.scss_ asociado al componente.

![CustomComponentScss](./assets/docs/images/custom-component-scss.png)


El resultado es el siguiente:

![CustomCardSpecific](./assets/docs/images/custom-card-specific.png)
