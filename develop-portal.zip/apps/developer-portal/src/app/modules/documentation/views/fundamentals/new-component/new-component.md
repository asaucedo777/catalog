# Creación y estilado de componentes globales

Si se desea crear un nuevo componente visual global para alguna de las librerias de ***@global-front-components***, deberemos seguir los siguiente pasos:

* Situarnos en la librería de la cual el nuevo componente va a formar parte. (En este ejemplo vamos a crear un componente llamado _Example_, que será un componente atómico de @global-front-components/ui).

* Generar una carpeta con todos los archivos necesarios para el funcionamiento del componente.

![GlobalExampleComponent](./assets/docs/images/global-example-component.png)

* Desarrollar el componente, maquetarlo, hacer sus tests unitarios y configurar su módulo (con sus declaraciones, exportaciones, importación de dependencias, como puede ser _CDK_, módulos de _Formularios_, otros módulos de componentes en el caso de móleculas, organismos; providers si emplea servicios, etc.)

Cabe mencionar que el estilado de dicho componente no se realizará en un archivo de estilos en la misma carpeta que el resto de archivos del componente,por lo que no se aplicarán directamente en la propiedad _styleUrls_ del decorador _@Component_ en _example.component.ts_, sino que se generará en un archivo llamado _example.scss_ dentro de la libreria _themes_ en _styles/scss/base-theme/components_:

![GlobalExampleScss](./assets/docs/images/global-example-scss.png)

Como se puede observar en la imagen anterior, en este archivo de estilos es necesario importar las _variables.scss_ que definiremos en cada uno de los temas:

![GlobalExampleVariables](./assets/docs/images/global-example-variables.png)

Por último deberemos importar el archivo de estilos en el _main.scss_ del tema base:

![GlobalExampleMainScss](./assets/docs/images/global-example-main-scss.png)

* Generar las exportaciones en los _index.ts_ correspondientes para que el componente sea exportable por la librería elegida:

![GlobalExampleComponentIndex](./assets/docs/images/global-example-component-index.png)
