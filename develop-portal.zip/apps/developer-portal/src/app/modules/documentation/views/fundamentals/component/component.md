# Creación de un componente

Para crear un componente tenemos dos opciones:

## A través de la interfaz de usuario de Nx:

Pasos: 
* **1**  Abrir la consola de Nx
* **2**  Seleccionar la acción _generate_
* **3**  Buscar _component_
* **4**  Seleccionar la opción _@schematics/angular - component_
* **5**  Escribir el nombre del componente
* **6**  Escribir el nombre del _módulo_ al que pertenece
* **7**  Seleccionar la extensión de los _estilos_
* **8**  Ejecutar

![NxComponent](./assets/docs/images/nx-component.png)

## A través de la consola del entorno de desarrollo:

Podríamos realizar el mismo proceso a través de consola lanzando el siguiente comando:

```
npm run ng generate component modules/example/components/example --module=example.module --style=scss
```

El resultado es el siguiente:

![ExampleModuleComponent](./assets/docs/images/example-module-component.png)

Para ver todas las opciones disponibles a la hora de generar un componente, puedes consultar en la documentación oficial de [Angular](https://angular.io/cli/generate#component-command).



