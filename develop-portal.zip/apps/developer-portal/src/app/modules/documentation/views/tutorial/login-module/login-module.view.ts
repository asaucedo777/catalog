import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'login-module.view.html',
	styleUrls: ['login-module.view.scss']
})
export class LoginModuleView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/app-component');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/login-view');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/login-module/login-module.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
