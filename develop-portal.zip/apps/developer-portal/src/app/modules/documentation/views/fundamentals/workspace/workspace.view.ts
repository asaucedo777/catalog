import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';


@Component({
	templateUrl: 'workspace.view.html',
	styleUrls: ['workspace.view.scss']
})
export class WorkspaceView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/workspace/workspace.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
