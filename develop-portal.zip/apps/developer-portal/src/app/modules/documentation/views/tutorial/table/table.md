# Creación del componente Tabla

Nuestra vista de Información contendrá un componente *tabla* que utilizará el ***CDK Table*** para mostrar cierta información, por ejemplo de los elementos de la tabla periódica.

Para la creación del componente, lo haremos:

* A través de la interfaz de la consola de ***Nx*** :

![NxTable](./assets/docs/images/nx-table.png)

* A través de la consola del _entorno de desarrollo_:

```
npm run ng g component modules/information/components/table --module=information.module --style=scss
```

El resultado es el siguiente:

![InfoModule4](./assets/docs/images/info-module-4.png)

Antes de implementar el *CDK Table* en nuestro componente de tabla, vamos a necesitar conocer qué información vamos a mostrar en la tabla. Dicha información la recogeremos a través de un servicio, que para nuestra aplicación apuntará al mock server (todo esto se detallará en los siguientes apartados).

Para que el componente de tabla sea *agnóstico*, la petición al *servicio* que recoge la información la realizará la *vista (information.view)* y ésta informará al *componente (table.component)* a través de un *Input*. 

Por tanto, vamos a implementar un input de entrada en el componente:

![TableComponentTs](./assets/docs/images/table-component-ts.png)

Ahora vamos a consumir dicho componente desde la vista y alimentar su *Input*. Por tanto, la vista tendrá una porpiedad pública que contendrá la información a representar en la tabla (y ésta vendrá de un servicio, como se detalla en los próximos apartados):

![InfoViewTs](./assets/docs/images/info-view-ts.png)

![InfoViewHtml](./assets/docs/images/info-view-html.png)

Dónde: 

* ***1)***  Input del componente tabla
* ***2)***  Propiedad de la vista que contendrá la información para la tabla

Esta manera de informar a través de un input, se conoce como *property binding*.
