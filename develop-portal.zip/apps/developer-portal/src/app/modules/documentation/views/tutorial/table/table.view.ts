import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'table.view.html',
	styleUrls: ['table.view.scss']
})
export class TableView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/info-view');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/table-server');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/table/table.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
