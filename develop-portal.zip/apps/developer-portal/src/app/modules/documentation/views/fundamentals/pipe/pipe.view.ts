import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'pipe.view.html',
	styleUrls: ['pipe.view.scss']
})
export class PipeView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/pipe/pipe.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
