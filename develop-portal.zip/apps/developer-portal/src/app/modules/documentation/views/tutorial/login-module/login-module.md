# Creación del módulo de Login

La primera funcionalidad _de principio a fin_ que vamos a crear es la vista de ***login***, que nos permita identificarnos en nuestra aplicación.

Para ello, lo primero que se debe hacer es generar el módulo nuevo. De nuevo, tenemos dos opciones:

* A través de la interfaz de la consola de ***Nx*** :

![NxLoginModule](./assets/docs/images/nx-login-module.png)

* A través de la consola del _entorno de desarrollo_:

```
npm run ng generate module modules/login
```

El resultado es el siguiente:

![LoginModule](./assets/docs/images/login-module.png)
