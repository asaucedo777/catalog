import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'scafold.view.html',
	styleUrls: ['scafold.view.scss']
})
export class ScafoldView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/introduction');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/app-component');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/scafold/scafold.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
