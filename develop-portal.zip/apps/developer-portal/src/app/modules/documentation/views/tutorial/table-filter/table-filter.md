# Creación del componente Filtro para la Tabla

El siguiente paso será desarrollar un campo de texto para poder realizar una búsqueda sobre la tabla.

Para ello vamos a necesitar un nuevo ***componente*** que contenga el campo de texto dónde escribamos aquello por lo que queramos filtrar. Además necesitaremos un ***pipe*** sobre la tabla, que será el encargado de mostrar el resultado deseado (ésto se verá en el siguiente apartado).

Centrándonos en el componente, el primer paso será crearlo. Para ello, como siempre, tenemos dos opciones:

Para la creación del componente, lo haremos:

* A través de la interfaz de la consola de ***Nx*** :

![NxTableFilter](./assets/docs/images/nx-table-filter.png)

* A través de la consola del _entorno de desarrollo_:

```
npm run ng g component modules/information/components/table-filter --module=information.module --style=scss
```

El resultado es el siguiente:

![InfoModule7](./assets/docs/images/info-module-7.png)

Vamos ahora a desarrollar nuestro componente ***table-filter.component***. El campo de texto en el cual vamos a realizar la búsqueda sera un tipo *input* encapsulado en el componente de CASER *form-field*, por lo que vamos a necesitar importar su módulo, para que esté disponible para usarlo:

![InfoModule8](./assets/docs/images/info-module-8.png)

Ahora vamos darle lógica a nuestro componente. Necesitamos obtener el valor del campo de texto para informar a la vista (_information.view_) y que ésta informe a la tabla (vía un nuevo *Input*, como veremos en el siguiente apartado). Este proceso de extracción de información de un componente a otro (o vista) que lo contiene se hace mediante un *Output*

![TableFilterTs](./assets/docs/images/table-filter-ts.png)

Siendo:

* ***1)***  ViewEncapsulation.None: Necesario para poder editar los estilos del *form-field* para este componente.
* ***2)***  Output que *emitirá* el campo de texto introducido.
* ***3)***  Método *handler* que captará el valor escrito en el \<input\> y emitirá el *Output*.

Ahora vamos a maquetar el *template* del componente:

![TableFilterHtml](./assets/docs/images/table-filter-html.png)

Con:

* ***1)***  Evento *input* que captura el cambio en el \<input\> que dispará el *handler*.
* ***2)***  Llamada al *handler* definido en el *.ts* y que se le pasa el valor del campo de texto (_$event.target.value_).

Para finalizar con el componente, vamos a editar la *hoja de estilos* para que se adecue a la vista:

![TableFilterScss](./assets/docs/images/table-filter-scss.png)

Una vez tenemos listo el componente, vamos usarlo en la lista y a capturar el *Output* desde la vista (para posteriormente informar a la tabla).

Para ello, en el *information.view.ts*:

![InfoViewFilterTs](./assets/docs/images/info-view-filter-ts.png)

Con:

* ***1)***  Propiedad que va a almacenar el texto introducido en el \<input\> del filtro y que servirá para informar a la tabla, vía *Input*.
* ***2)***  Método *handler* que captará el valor del texto emitido desde el *table-filter.component*.

Y finalmente en el *information.view.html*:

![InfoViewFilterHtml](./assets/docs/images/info-view-filter-html.png)


Con:

* ***1)***  Evento *search* que se activa cuando *table-filter.component* haga una emisión de su *Output*, es decir, cuando se escriba sobre el \<input\> y disparará *handler*.
* ***2)***  Llamada al *handler* definido en el *.ts* y que se le pasa el valor (_$event_) del *EventEmitter* de *table-filter.component* .

Ahora volvemos a inicializar la aplicación y obtenemos el siguiente resultado:

![TableFilterResult](./assets/docs/images/table-filter-result.png)
