# Creación de un nuevo tema

Si se desea crear un nuevo tema aplicable a los componentes visuales de la librería *global-front-components/ui*, se deberá ir al proyecto de temas (librería *global-front-components/themes*), y crear una carpeta con el nombre del tema (en este caso *new-theme*) dentro de */styles/scss* y generar un archivo de variables, **_variables.scss**.

![NewThemeScafold](./assets/docs/images/new-theme-scafold.png)

A continuación copiamos en este nuevo archivo de variables *TODO* el contenido del archivo de variables del *tema base* (*/styles/scss/base-theme/_variables.scss*). Ahora ya podremos editar el valor de aquellas variables que se necesiten para el nuevo tema.

Pongamos como ejemplo cambios en el componente botón (directiva *ca-button* sobre un elemento *button*) de la librería *global-front-components/themes*.

Imaginemos que vamos a cambiar varios estilos del botón, como podria ser el *background-color*, *border-color*, *font-size*, *font-weight* y *color*. Para ello, comprobaremos la estructura del componente en su *html* dento de *global-front-components/ui*, así como su hoja de estilos y que variable corresponde a cada estilos en la *global-front-components/themes*, dentro de */styles/scss/base-theme/components/button.scss*.

Una vez identificadas las variables a cambiar, iremos al archivo de variables del nuevo tema */styles/scss/new-theme/_variables.scss*, las buscaremos y cambiaremos el valor por el deseado.

![NewThemeVariables](./assets/docs/images/new-theme-variables.png)

Para poder visualizar los estilos del nuevo tema en el catalogo, deberemos añadir los siguientes cambios:

![NewThemeTS](./assets/docs/images/new-theme-ts.png)

![NewThemeHTML](./assets/docs/images/new-theme-html.png)

Una vez realizados dichos cambios, podremos arrancar la aplicación en local (comando *npm start*).

Para visualizar los cambios y realizar los que deseemos, iremos a la documentación de dicho componente.

![BaseThemeButton](./assets/docs/images/base-theme-button.png)

Cambiamos al nuevo tema, y podremos visualizar los cambios.

![NewThemeButton](./assets/docs/images/new-theme-button.png)

**NOTA**: Una vez se haya creado un nuevo tema, y el equipo de Arquitectura lo haya validado y publicado en una nueva versión de la librería, este se podrá consumir en la aplicación deseada, siguiendo los pasos descritos en *Fundamentos* -> *Dependencias NPM*.
