import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'nodenv.view.html',
	styleUrls: ['nodenv.view.scss']
})
export class NodenvView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/nodenv/nodenv.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
