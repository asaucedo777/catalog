# Clonación de un repositorio ya existente

Si se desea trabajar sobre un repositorio ya existente, deberemos ir a la página principal del repositorio en *GitLab* y y seleccionar la opción *Clone* y copiar la ruta que aparece en la opción *Clone with HTTP*.

A modo de ejemplo: 

![RepoClone](./assets/docs/images/repo-clone.png)

Una vez copiada la ruta, en consola ejecutaremos el comando:

```
git clone url-repositirio-existente
```

Una vez clonado, nos situamos en la carpera correspondiente:

```
cd repositorio-clonado
```

A continuación, instalamos las dependecias con 
```
npm install
```

Ahora ya  podremos trabajar sobre el repositorio.
