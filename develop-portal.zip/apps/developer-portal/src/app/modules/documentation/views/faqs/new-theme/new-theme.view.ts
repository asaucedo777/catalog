import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'new-theme.view.html',
	styleUrls: ['new-theme.view.scss']
})
export class NewThemeView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/faqs/new-theme/new-theme.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
