# Creación del servicio de la tabla

Una vez creado el nuevo endpoint en el servidor mock, vamos a generar el servicio de login que apunte al endpoint, y así poder consumirlo desde nuestra vista de información.

De nuevo, tenemos dos opciones:

* A través de la interfaz de la consola de ***Nx*** :

![NxTableService](./assets/docs/images/nx-table-service.png)

* A través de la consola del *entorno de desarrollo*:
```
npm run ng g service modules/table/services/table
```

El resultado será:

![TableService](./assets/docs/images/table-service.png)

Para poder usarlo, deberemos importarlo en el ***information.module.ts*** del siguiente modo:

![InfoModule5](./assets/docs/images/info-module-5.png)

Ahora vamos a definir las *interfaces* necesarias para dar consistencia a la información recuperada por el servicio, según el API de elementos de la tabla periódica elegida:

![ElementsInterface](./assets/docs/images/elements-interface.png)

A continuación, vamos a crear el método *getData* del servicio, que apuntará a nuestro *endpoint* (***/api/table***):

![TableService2](./assets/docs/images/table-service-2.png)

Finalmente vamos a llamar a nuestro servicio desde la vista ***information.view.ts***, de modo que una vez se inicialice la vista se llamará al servicio (en el ciclo de vida _ngOnInit_) y así la propiedad *dataSource* de la vista (que hemos tipado como un *array* de _Element_) quedará alimentada, y automáticamente informará al componente ***table.component.ts*** mediante su *Input*.

![InfoViewTs2](./assets/docs/images/info-view-ts-2.png)



