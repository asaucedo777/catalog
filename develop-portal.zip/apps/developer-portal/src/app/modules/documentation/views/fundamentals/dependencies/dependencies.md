# Dependencias NPM

Todos los proyectos que hagan uso de la arquitectura CASER tendrán como eje central el fichero ***package.json***.

![PacakgeJson](./assets/docs/images/package-json.png)

El fichero _package.json_ está compuesto por diversas secciones que vamos a ver a continuación.

## Scripts

Los scripts de NPM nos permiten abstraer a los desarrolladores de la tecnología que hay por detrás eliminando complejidad usando **alias** para scripts más complejos.

![Scripts](./assets/docs/images/scripts.png)

### Original
```
ng build example-app --prod --build-optimizer
```

### Alias
```
npm run build:prd
```

## Dependencias

Son las dependencias que nuestro proyecto necesita para funcionar de manera productiva.

![Dependencies](./assets/docs/images/dependencies.png)

_Aquí irían las dependencias de la arquitectura y del catálogo de componentes._

## DevDependencies

Son las dependencias que necesitamos para construir nuestro proyecto.

![DevDependencies](./assets/docs/images/dev-dependencies.png)

Para instalar la arquitectura y el catálogo de componentes de CASER debemos lanzar los siguientes comandos:

### Paquete CORE
```
npm install --save @global-front-components/core
```

### Paquete COMMON
```
npm install --save @global-front-components/common
```

### Paquete UI
```
npm install --save @global-front-components/ui
```


### Paquete THEMES
```
npm install --save @global-front-components/themes
```

Para poder consumir uno de los temas en nuestra aplicación, se deberá incluir en el archivo *angular.json* de la aplicación, del siguiente modo:

![ThemesAngularJson](./assets/docs/images/themes-angular-json.png)

```
"styles": [
    "node_modules/@angular/cdk/overlay-prebuilt.css",
    "node_modules/bootstrap/dist/css/bootstrap.css",
    "node_modules/@global-front-components/themes/styles/css/base-theme.min.css",
    "apps/developer-portal/src/styles.scss"
]
```

## Dependencias externas

Una vez instaladas las dependencias de arquitectura es necesario instalar una serie de paquetes que usa la arquitectura:

### Paquete @angular/cdk
```
npm install --save @angular/cdk
```

### Paquete bootstrap
```
npm install --save bootstrap@4.5.0
```
El proceso de instalación hará las siguientes modificaciones en nuestro package.json.

```
"dependencies": {
    "@angular/animations": "^9.1.0",
    "@angular/cdk": "^9.2.4",
    "@angular/common": "^9.1.0",
    "@angular/compiler": "^9.1.0",
    "@angular/core": "^9.1.0",
    "@angular/forms": "^9.1.0",
    "@angular/localize": "^9.1.9",
    "@angular/platform-browser": "^9.1.0",
    "@angular/platform-browser-dynamic": "^9.1.0",
    "@angular/router": "^9.1.0",
    "@commitlint/cli": "^8.3.5",
    "@commitlint/config-angular": "^8.3.4",
    "@commitlint/config-conventional": "^8.3.4",
    "@global-front-components/common": "2.19.0",
    "@global-front-components/core": "2.19.0",
    "@global-front-components/salud": "2.19.0",
    "@global-front-components/themes": "2.19.0",
    "@global-front-components/ui": "2.19.0",
    "@ng-bootstrap/ng-bootstrap": "^6.1.0",
    "@nrwl/angular": "9.5.1",
    "@swimlane/ngx-charts": "^19.0.1",
    "bootstrap": "^4.5.0",
    "rxjs": "~6.5.4",
    "zone.js": "^0.10.2"
}
```

## Dependencias opcionales

En función de las necesidades de tu proyecto puedes instalar dependencias opcionales, para consumir componentes de otras áreas

### Paquete salud
```
npm install --save @global-front-components/salud
```

El proceso de instalación hará las siguientes modificaciones en nuestro package.json.

```
"dependencies": {
    "@angular/animations": "^9.1.0",
    "@angular/cdk": "^9.2.4",
    "@angular/common": "^9.1.0",
    "@angular/compiler": "^9.1.0",
    "@angular/core": "^9.1.0",
    "@angular/forms": "^9.1.0",
    "@angular/localize": "^9.1.9",
    "@angular/platform-browser": "^9.1.0",
    "@angular/platform-browser-dynamic": "^9.1.0",
    "@angular/router": "^9.1.0",
    "@commitlint/cli": "^8.3.5",
    "@commitlint/config-angular": "^8.3.4",
    "@commitlint/config-conventional": "^8.3.4",
    "@global-front-components/common": "2.19.0",
    "@global-front-components/core": "2.19.0",
    "@global-front-components/salud": "2.19.0",
    "@global-front-components/themes": "2.19.0",
    "@global-front-components/ui": "2.19.0",
    "@ng-bootstrap/ng-bootstrap": "^6.1.0",
    "@nrwl/angular": "9.5.1",
    "@swimlane/ngx-charts": "^19.0.1",
    "bootstrap": "^4.5.0",
    "rxjs": "~6.5.4",
    "zone.js": "^0.10.2"
}
```

