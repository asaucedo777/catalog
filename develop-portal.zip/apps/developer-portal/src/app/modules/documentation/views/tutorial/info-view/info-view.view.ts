import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'info-view.view.html',
	styleUrls: ['info-view.view.scss']
})
export class InfoViewView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/info-module');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/table');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/info-view/info-view.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
