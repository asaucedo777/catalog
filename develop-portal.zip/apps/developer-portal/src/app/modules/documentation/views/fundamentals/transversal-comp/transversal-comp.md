# Componente transversal

Para crear un componente tenemos dos opciones:

#### ¿Qué es?
 
Aquella pieza sin disinción por tipo de estructura que se reutilizará en todas las aplicaciones de Caser, por lo que debe estar en la librería de componente globales.


#### Tipo de estructura

* **1**  Átomo
* **2**  Molécula
* **3**  Organismo
* **4**  Sericios
* **5**  Validadores
* **6**  Utilidades CSS

![TipoEstructura](./assets/docs/images/tipo-comp.png)


#### Creación:

Para crear un componente transversal necesitarás:

Clonar el repositorio de:
```powershell
git clone http://gitlab.caser.local/arquitectura/front/caser-architecture.git
```

Genera una rama nueva en el repositorio con el nombre del componente a desarrollar.

Crea el tipo de componente que necesites siguiendo la documentación en los apartados relacionados con la creación de los diferentes elementos.

Debes tener en cuenta que para poder publicar tu componente tienes que añadir los archivos generados en el index.ts correspondiente y añadirlos también en indez.ts de general

![ExampleIndex](./assets/docs/images/index.png)

Para ver todas las opciones disponibles a la hora de generar un componente, puedes consultar en la documentación oficial de [Angular](https://angular.io/cli/generate#component-command).

#### Validación:

Ante de publicar el componente asegurate que:

* **1**  Compila correctamente
* **2**  Tiene un 80% de cobertura de test
* **3**  Sigue los requisitos de estilo
* **4**  Realiza el commit para subir tus cambios
* **5**  Genera pull-request para mergear tus cambios con la rama develop
* **5**  El equipo de arquitectura validará tus cambios para aceptar la creación del componente

#### Despliegue:

El despliegue de tu nuevo componente se realiza al final de cada Sprint del equipo de Gobierno Front perteneciente al área de arquitectura, consulta JIRA para más información:

[JIRA Arquitectura](https://jira.caser.local:8443/secure/RapidBoard.jspa?rapidView=282&projectKey=GOBFF1&view=planning&selectedIssue=GOBFF1-644&issueLimit=100)



