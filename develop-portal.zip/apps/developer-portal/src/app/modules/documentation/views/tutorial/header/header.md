# Creación de un componente de aplicación

Vamos a empezar creando un componente común para toda aplicación, que podrá ser consumido de dos formas:

* A nivel de toda la aplicación (en todas las vistas)
* En diferentes módulos (vistas) de la aplicación

En este tutorial vamos a realizar un **header**, de modo que aparezca en el encabezado de todas las vistas de nuestra aplicación.

Como ya se ha indicado en los fundamentos, para generar un componente podemos hacerlo:

* A través de la interfaz de la consola de ***Nx*** :

![NxHeader](./assets/docs/images/nx-header.png)

* A través de la consola del _entorno de desarrollo_:

```
npm run ng generate component components/header --style=scss 
```

Una vez ejecutado, observamos como se ha generado dentro de la carpeta ***components***, dónde irán los componentes de la aplicación. Para que este nuevo componente esté disponible para toda la aplicación, el comando anterior ha importado el nuevo componente en el _app.module.ts_:

![ScafoldHeader](./assets/docs/images/scafold-header.png)

A continuación vamos a modificar los archivos del componente:

## HTML

![HeaderHTML](./assets/docs/images/header-html.png)

## TypeScript

![HeaderTS](./assets/docs/images/header-ts.png)

## SCSS

![HeaderSCSS](./assets/docs/images/header-scss.png)


Para consumirlo a nivel de toda la aplicación, vamos a consumirlo desde _app.component.html_, haciendo uso de su _selector_ del siguiente modo:

![AppHeader](./assets/docs/images/app-header.png)

Ahora ya podemos lanzar el siguiente comando en la consola del entorno:

```
npm run start
```

Abrimos el navegador y navegamos a _localhost:4200_:

![ResultHeader](./assets/docs/images/result-header.png)
