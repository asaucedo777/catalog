import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'cdk-table.view.html',
	styleUrls: ['cdk-table.view.scss']
})
export class CdkTableView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/table-service');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/table-filter');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/cdk-table/cdk-table.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
