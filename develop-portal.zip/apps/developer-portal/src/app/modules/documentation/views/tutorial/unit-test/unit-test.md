# Test unitarios

Un test unitario es una forma de comprobar el correcto funcionamiento de una unidad de código. Esto sirve para asegurar que cada unidad funcione correctamente y eficientemente por separado.

Cuando hemos ido creando nuestros componentes, vistas, servicios y pipe, vemos cómo también se han generado archivos con la extensión ***.spec.ts***. Son en estos archvios dónde se van a realizar los tests unitarios.

Angular 9 emplea **Jest** como framework por defecto para los tests unitarios, por lo que ya lo tenemos instalado. 

## Configuración de los Test Unitarios

Para ejecutar los tests basta con lanzar en la consola del portal del desarrollador el siguiente comando:

```
npm run ng test
```

Sin haber realizado ningún test hasta ahora y lanzando el anterior comando, el resultado es el siguiente:

![InitialTest](./assets/docs/images/initial-test.png)

Cómo vemos, muchos de los tests generados automáticamente cuando se ha creado su correspondiente componente están *fallando*, tanto el *Test Suite* (configuración de archivos _.spec.ts_, definidos a través de _describe_) como _Test_ (test unitario, definidos a través de un *it*).

Veamos porqué, a través de un ejemplo, como puede ser *table-filter.component*

![TableFilterTest](./assets/docs/images/table-filter-test.png)

En este caso, fallan tanto el *Test Suite* como el único *Test* que viene por defecto. De hecho, si el *Test Suite* (_describe_) falla, fallarán todos los *Test* (_it_) contenidos en él.

Esto se debe a que el componente *table-filter.component* hace uso de *componentes* no importados en la configuración del *.spec.ts*, cómo por ejemplo el *form-field* de CASER. Importándolo:

![TableFilterTest2](./assets/docs/images/table-filter-test-2.png)

Si relanzamos ahora la ejecución de los tests (_npm run ng test_) vemos como ya *pasan* un Test Suite y un Test más que antes, correspondientes al test del componente que acabamos de corregir.

Vamos a poner otro ejemplo de como corregir el *Test Suite* de una vista que consume un servicio y hace uso de otros componentes, como puede ser el *information.view*:

![InformationViewTest](./assets/docs/images/info-view-test.png)

Otro ejemplo de configuración de test vamos a ver el caso de un servicio, como puede ser *table.service*:

![TableServiceTest](./assets/docs/images/table-service-test.png)

Cómo ultimo ejemplo, vamos a configurar el test unitario del *app.component*, y de paso eliminar dos tests (*it*) que venian por defecto y que ya no tienen sentido, quedando:

![AppTest](./assets/docs/images/app-test.png)

De manera análoga vamos a importar todo lo necesario en cada uno de los *.spec.ts* que tenemos en nuestra aplicación, para corregir todos los *Test Suites*, obteniendo el siguiente resultado:

![TestSuites](./assets/docs/images/test-suites.png)

## Realización de tests y cobertura

A la hora de realizar test unitarios es importarte conocer la cobertura, es decir, cuantas líneas de código están cubiertas por los tests.

Para ver la cobertura actual, debemos lanzar por consola:

```
npm run ng test --code-coverage
```

O bien, modificar nuestro script *test* del ***package.json*** de la siguiente forma:

![PackageJsonTest](./assets/docs/images/package-json-test.png)

Por lo que ahora, bastaría con lanzar:

```
npm run test
```

Una vez hayamos lanzado el comando, en el árbol del proyecto vemos cómo se ha generado una nueva carpeta **coverage**. 

![CoverageTree](./assets/docs/images/coverage-tree.png)

Abrimos en el explorador el archivo **index.html** y veremos lo siguiente:

![CodeCoverageAll](./assets/docs/images/coverage-all.png)

Aquí podemos seleccionar el archivo que deseemos y ver la cobertura línea a línea.

A continuación vamos a realizar varios ejemplos de test y ver su cobertura

### Componente

Vamos a darle una cobertura completa al componente de ejemplo que configuramos anteriormente, **table-filter.component**.

Inicialmente, sólo con el test inicial (el de creación de componente), tenemos ésta cobertura:

![TableFilterCoverageBefore](./assets/docs/images/table-filter-coverage-before.png)

Podemos observar como las líneas no cubiertas aparecen con un fondo rojizo.

Volvemos al archivo de test y realizamos el siguiente *it*:

![TableFilterTest3](./assets/docs/images/table-filter-test-3.png)

Lanzamos el comando *npm run test* y refrescamos el *index.html* abierto en el navegador, obteniendo:

![TableFilterCoverageAfter](./assets/docs/images/table-filter-coverage-after.png)

### Vista

Vamos a darle una cobertura completa a la vista de ejemplo que configuramos anteriormente, **information.view**.

Inicialmente, sólo con el test inicial (el de creación de la vista), tenemos ésta cobertura:

![InfoViewCoverageBefore](./assets/docs/images/info-view-coverage-before.png)

Volvemos al archivo de test y como ésta vista tiene una llamada al servicio *table.service* tenemos que *mockear* tanto la llamada como la respuesta al servicio, ya que el test unitario de ésta vista no va a testear la llamada HTTP del servicio (eso será parte del test del propio servicio). 

Para la respuesta mockeada:

![InfoViewTestMock](./assets/docs/images/info-view-test-mock.png)

En cuanto al serivico mockeado, deberemos hacerlo en el *providers* de la configuración del test:

![InfoViewTestService](./assets/docs/images/info-view-test-service.png)

Una vez listo, pasamos a realizar los siguientes tests (_it_):

![InfoViewTestIt](./assets/docs/images/info-view-test-it.png)

Lanzamos de nuevo el comando *npm run test* y refrescamos el *index.html* abierto en el navegador, obteniendo:

![InfoViewCoverageAfter](./assets/docs/images/info-view-coverage-after.png)

### Servicio

Ahora sí, vamos a testear la funcionalidad del servicio **table.service**. Sólo con la configuración que le dimos anteriormente, obtenemos la siguiente cobertura:

![TableServiceCoverageBefore](./assets/docs/images/table-service-coverage-before.png)

Vamos a realizar el test (_it_) del método del siguiente modo:

![TableServiceTest2](./assets/docs/images/table-service-test-2.png)

Ejecutamos el comando *npm run test* y refrescamos, obteniendo:

![TableServiceCoverageAfter](./assets/docs/images/table-service-coverage-after.png)

### Pipe

Como último ejemplo, vamos a ver el test del **filter.pipe**

Inicialmente, la cobertura es:

![FilterPipeCoverageBefore](./assets/docs/images/filter-pipe-coverage-before.png)

Realizamos los tests oportunos:

![FilterPipeTest](./assets/docs/images/filter-pipe-test.png)

Relanzamos los tests y vemos ahora su cobertura:

![FilterPipeCoverageAfter](./assets/docs/images/filter-pipe-coverage-after.png)

## Documentación oficial

Para más información sobre los test unitarios, visita la documentación oficial de [Jest](https://jestjs.io/).
