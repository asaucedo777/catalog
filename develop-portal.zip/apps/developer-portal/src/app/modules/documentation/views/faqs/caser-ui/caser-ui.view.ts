import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'caser-ui.view.html',
	styleUrls: ['caser-ui.view.scss']
})
export class CaserUIView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/faqs/caser-ui/caser-ui.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
