import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DocumentationView } from './documentation.view';
import { NodenvView } from './views/fundamentals/nodenv/nodenv.view';
import { WorkspaceView } from './views/fundamentals/workspace/workspace.view';
import { DependenciesView } from './views/fundamentals/dependencies/dependencies.view';
import { ModuleView } from './views/fundamentals/module/module.view';
import { ComponentView } from './views/fundamentals/component/component.view';
import { ViewView } from './views/fundamentals/view/view.view';
import { ServiceView } from './views/fundamentals/service/service.view';
import { PipeView } from './views/fundamentals/pipe/pipe.view';
import { MockApiView } from './views/fundamentals/mock-api/mock-api.view';
import { AppBuildView } from './views/fundamentals/app-build/app-build.view';
import { IntroductionView } from './views/tutorial/introduction/introduction.view';
import { ScafoldView } from './views/tutorial/scafold/scafold.view';
import { HeaderView } from './views/tutorial/header/header.view';
import { LoginModuleView } from './views/tutorial/login-module/login-module.view';
import { LoginViewView } from './views/tutorial/login-view/login-view.view';
import { LoginFormView } from './views/tutorial/login-form/login-form.view';
import { RouterView } from './views/tutorial/router/router.view';
import { LoginServerView } from './views/tutorial/login-server/login-server.view';
import { LoginServiceView } from './views/tutorial/login-service/login-service.view';
import { InfoModuleView } from './views/tutorial/info-module/info-module.view';
import { InfoViewView } from './views/tutorial/info-view/info-view.view';
import { TableView } from './views/tutorial/table/table.view';
import { TableServerView } from './views/tutorial/table-server/table-server.view';
import { TableServiceView } from './views/tutorial/table-service/table-service.view';
import { CdkTableView } from './views/tutorial/cdk-table/cdk-table.view';
import { TableFilterView } from './views/tutorial/table-filter/table-filter.view';
import { FilterPipeView } from './views/tutorial/filter-pipe/filter-pipe.view';
import { UnitTestView } from './views/tutorial/unit-test/unit-test.view';
import { E2ETestView } from './views/tutorial/e2e-test/e2e-test.view';
import { CustomizationLevelView } from './views/faqs/customization-level/customization-level.view';
import { CaserUIView } from './views/faqs/caser-ui/caser-ui.view';
import { UpdateLibaryVersionView } from './views/faqs/update-library-version/update-library-version.view';
import { LibraryView } from './views/fundamentals/library/library.view';
import { RepoCloneView } from './views/fundamentals/repo-clone/repo-clone.view';
import { ProxiesView } from './views/faqs/proxies/proxies.view';
import { NewComponentView } from './views/fundamentals/new-component/new-component.view';
import { DocumentationReposView } from './views/fundamentals/documentation-repos/documentation-repos.view';
import { E2ESSOView } from './views/faqs/e2e-sso/e2e-sso.view';
import { NewThemeView } from './views/faqs/new-theme/new-theme.view';
import { TransversalCompView } from './views/fundamentals/transversal-comp/transversal-comp.view';
import { SonarView } from './views/tutorial/sonar/sonar.view';

const routes: Routes = [
	{
		path: '',
		component: DocumentationView,
		children: [
      {
        path: 'fundamentals/nodenv',
        component: NodenvView
      },
      {
        path: 'fundamentals/workspace',
        component: WorkspaceView
      },
      {
        path: 'fundamentals/dependencies',
        component: DependenciesView
      },
      {
        path: 'fundamentals/module',
        component: ModuleView
      },
      {
        path: 'fundamentals/component',
        component: ComponentView
      },
      {
        path: 'fundamentals/view',
        component: ViewView
      },
      {
        path: 'fundamentals/library',
        component: LibraryView
      },
      {
        path: 'fundamentals/service',
        component: ServiceView
      },
      {
        path: 'fundamentals/pipe',
        component: PipeView
      },
      {
        path: 'fundamentals/mock',
        component: MockApiView
      },
      {
        path: 'fundamentals/app-build',
        component: AppBuildView
      },
      {
        path: 'fundamentals/new-component',
        component: NewComponentView
      },
      {
        path: 'fundamentals/documentation-repos',
        component: DocumentationReposView
      },
      {
        path: 'fundamentals/repo-clone',
        component: RepoCloneView
      },
      {
        path: 'fundamentals/tansversal-comp',
        component: TransversalCompView
      },
      {
        path: 'tutorial/introduction',
        component: IntroductionView
      },
      {
        path: 'tutorial/scafold',
        component: ScafoldView
      },
      {
        path: 'tutorial/app-component',
        component: HeaderView
      },
      {
        path: 'tutorial/login-module',
        component: LoginModuleView
      },
      {
        path: 'tutorial/login-view',
        component: LoginViewView
      },
      {
        path: 'tutorial/caser-components',
        component: LoginFormView
      },
      {
        path: 'tutorial/router',
        component: RouterView
      },
      {
        path: 'tutorial/login-server',
        component: LoginServerView
      },
      {
        path: 'tutorial/login-service',
        component: LoginServiceView
      },
      {
        path: 'tutorial/info-module',
        component: InfoModuleView
      },
      {
        path: 'tutorial/info-view',
        component: InfoViewView
      },
      {
        path: 'tutorial/table',
        component: TableView
      },
      {
        path: 'tutorial/table-server',
        component: TableServerView
      },
      {
        path: 'tutorial/table-service',
        component: TableServiceView
      },
      {
        path: 'tutorial/cdk-table',
        component: CdkTableView
      },
      {
        path: 'tutorial/table-filter',
        component: TableFilterView
      },
      {
        path: 'tutorial/filter-pipe',
        component: FilterPipeView
      },
      {
        path: 'tutorial/unit-test',
        component: UnitTestView
      },
      {
        path: 'tutorial/e2e',
        component: E2ETestView
      },
      {
        path: 'tutorial/sonar',
        component: SonarView
      },
      {
        path: 'faqs/caser-ui',
       component: CaserUIView
      },
      {
        path: 'faqs/customization-level',
        component: CustomizationLevelView
      },
      {
        path: 'faqs/update-library-version',
        component: UpdateLibaryVersionView
      },
      {
        path: 'faqs/proxies',
        component: ProxiesView
      },
      {
        path: 'faqs/e2e-sso',
        component: E2ESSOView
      },
      {
        path: 'faqs/new-theme',
        component: NewThemeView
      }
    ]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class DocumentationRoutingModule {}
