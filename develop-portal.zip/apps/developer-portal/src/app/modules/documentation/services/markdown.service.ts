import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class MarkdownService {
  constructor(private _httpClient: HttpClient) { }

  getMarkdown(markdownFile: string): Observable<any> {
    return this._httpClient.get(markdownFile, { responseType: 'text' });
  }
}
