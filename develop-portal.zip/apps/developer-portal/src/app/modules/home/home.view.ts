import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { version } from '../../../../../../package.json';

@Component({
	selector: 'ca-home',
	templateUrl: './home.view.html',
	styleUrls: ['./home.view.scss']
})
export class HomeView {
	constructor(private _router: Router) {}
  version = version;

	goTo(name: string) {
		switch (name) {
			case 'principles':
        this._router.navigateByUrl('/principles');
				break;
			case 'design':
        this._router.navigateByUrl('/design');
				break;
			case 'develop':
        this._router.navigateByUrl('/develop/atoms/button');
				break;
      case 'documentation':
        this._router.navigateByUrl('/documentation/fundamentals/nodenv');
				break;
			default:
				break;
		}
	}
}
