import { Component } from '@angular/core';
import { Sidebar } from '../../models/sidebar.interface';

@Component({
  selector: 'ca-design',
  templateUrl: './design.view.html',
  styleUrls: ['./design.view.scss']
})
export class DesignView {
	sidebarItems: Sidebar[] = [
		{ title: 'Guía de uso', link: '/design/use-guide'},
		{ title: 'Composición de ventanas', link: '/design/compose-view'},
		{ title: 'Componentes', link: '#', subItems: [
			{ title: 'Breadcrumbs', link: '/design/component/breadcrumbs' },
			{ title: 'Button', link: '/design/component/button' },
			{ title: 'Checkbox', link: '/design/component/checkbox' },
			// { title: 'Chips', link: '/design/component/chips' },
			{ title: 'Menu', link: '/design/component/context-menu' },
			{ title: 'Datepicker', link: '/design/component/datepicker' },
			{ title: 'Accordion', link: '/design/component/desplegables' },
			// { title: 'Dropdown', link: '/design/component/dropdown' },
			{ title: 'Links', link: '/design/component/links' },
			{ title: 'Spinner', link: '/design/component/loader' },
			{ title: 'Modal', link: '/design/component/modal' },
			{ title: 'Pagination', link: '/design/component/pagination' },
			{ title: 'Radio button', link: '/design/component/radio-button' },
			{ title: 'Snackbar', link: '/design/component/snackbar' },
			{ title: 'Slide Toggle', link: '/design/component/switch' },
			{ title: 'Table', link: '/design/component/table' },
			{ title: 'Tabs', link: '/design/component/tabs' },
			{ title: 'Form field', link: '/design/component/text-field' },
			{ title: 'Tooltip', link: '/design/component/tooltip' },
		] },
		// { title: 'Recursos', link: '/design/resources'}
	];
}
