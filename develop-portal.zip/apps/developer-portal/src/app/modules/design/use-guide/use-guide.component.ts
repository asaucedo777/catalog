import { Component } from '@angular/core';

@Component({
	selector: 'ca-use-guide',
	templateUrl: './use-guide.component.html',
	styleUrls: ['./use-guide.component.scss']
})
export class UseGuideComponent {
	constructor() {}
}
