import { NgModule, SecurityContext } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { DesignRoutingModule } from './design-routing.module';
import { UseGuideComponent } from './use-guide/use-guide.component';
import { Vieweromponent } from './viewer/viewer.component';
import { ComponentViewerComponent } from '../../components/component-viewer/component-viewer.component';
import { DownloadComponent } from '../../components/download/download.component';
import { ResourcesComponent } from './resources/resources.component';
import { DesignView } from './design.view';
import { CaAccordionModule, CaBreadcrumbModule, CaButtonModule, CaCardModule, CaCheckboxModule, CaDatepickerModule, CaFormFieldModule, CaIcon, CaInputModule, CaLabel, CaModalOverlayModule, CaModalOverlayService, CaPaginationModule, CaRadioButtonModule, CaSelectModule, CaSidebarModule, CaTabsModule, CaTextareaModule } from '@global-front-components/ui';
import { ComposeView } from './compose-view/compose.view';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CdkTableModule } from '@angular/cdk/table';
import { CaResizableTableModule, CaResizeColumnModule } from '@global-front-components/common';
import { ModalComponent } from './compose-view/modal-action/modal-action.view';
import { ComponentDocModule } from '../../components/component-doc/component-doc.module';
@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    DesignRoutingModule,
    CaSidebarModule,
    CaAccordionModule,
    ReactiveFormsModule,
    FormsModule,
    CaFormFieldModule,
    CaInputModule,
    CaButtonModule,
    CaBreadcrumbModule,
    CaSelectModule,
    CaDatepickerModule,
    CaRadioButtonModule,
    CaTextareaModule,
    CaCheckboxModule,
    CdkTableModule,
    CaPaginationModule,
    CaTabsModule,
    CaCardModule,
    CaResizeColumnModule,
    CaPaginationModule,
    CaModalOverlayModule,
    ComponentDocModule
  ],
  declarations: [
    UseGuideComponent,
    Vieweromponent,
    ComponentViewerComponent,
    DownloadComponent,
    ResourcesComponent,
    DesignView,
    ComposeView,
    ModalComponent
  ],
  providers: [CaModalOverlayService]
})
export class DesignModule {}
