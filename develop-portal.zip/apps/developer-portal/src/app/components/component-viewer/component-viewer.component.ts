import { Component, Input } from '@angular/core';
import { ComponentEstructure } from '../../models/component-structure.interface';

@Component({
	selector: 'ca-component-viewer',
	templateUrl: './component-viewer.component.html',
	styleUrls: ['./component-viewer.component.scss']
})
export class ComponentViewerComponent {
	@Input() data: ComponentEstructure;
	constructor() {
    }
    ngOnInit(){
    }
}
