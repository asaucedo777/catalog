import { Component, Input, ViewEncapsulation } from '@angular/core';
import { ComponentDoc } from './component-doc.interface';

@Component({
  selector: 'ca-component-doc',
  templateUrl: 'component-doc.component.html',
  styleUrls: ['component-doc.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class ComponentDocComponent {
  @Input() componentDoc: ComponentDoc;
}
