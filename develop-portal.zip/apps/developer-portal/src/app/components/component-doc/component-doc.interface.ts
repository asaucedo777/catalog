interface CodeExample {
  ts?: string;
  html?: string;
  css?: string,
}

export interface ComponentDoc {
  title?: string;
  description?: string;
  codeExample?: CodeExample;
}
