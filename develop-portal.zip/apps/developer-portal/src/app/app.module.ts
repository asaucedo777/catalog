import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CaButtonModule, CaMenuModule, CaTooltipModule } from '@global-front-components/ui';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing.module';
import { ComponentDocModule } from './components/component-doc/component-doc.module';
import { FooterComponent } from './components/footer/footer.component';
import { PageHeaderComponent } from './components/header/header.component';
import { NewsItemComponent } from './components/news-item/news-item.component';
import { HomeView } from './modules/home/home.view';
import { ReactiveFormsModule } from '@angular/forms';
import { IConfig, NgxMaskModule } from 'ngx-mask';

export const options: Partial<IConfig> | (() => Partial<IConfig>) = null;


@NgModule({
	declarations: [
    AppComponent,
    FooterComponent,
    HomeView,
    NewsItemComponent,
    PageHeaderComponent
  ],
	imports: [
    AppRoutingModule,
    BrowserAnimationsModule,
    BrowserModule,
    ComponentDocModule,
    HttpClientModule,
    ReactiveFormsModule,
    NgbModule,
    CaMenuModule,
    CaButtonModule,
    CaTooltipModule,
    NgxMaskModule.forRoot(),
  ],
	providers: [],
	bootstrap: [AppComponent]
})
export class AppModule {}

