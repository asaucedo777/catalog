export interface Sidebar {
	title: string;
	link?: string;
	subItems?: Sidebar[];
  open?: boolean;
}
