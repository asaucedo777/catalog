export interface ComponentEstructure {
	componentTitle: string;
	componentSubtitle: string;
	demo: {
		title: string;
		image: string;
	};
	use: {
		title: string;
		uses: Uses;
		type: UseType;
		recomendation: UseRecomendation;
	};
	anatomy: {
		title: string;
		composition: AnatomyComposition;
		status: {
			title: string;
			image: string;
		};
		specialItems: {
			title: string;
			items: [
				{
					title: string;
					text: string;
					image: string;
				}
			];
		};
	};
	behaviour: {
		title: string;
		subtitle?: string;
		content: BehaviourContent[];
	};
	specs: {
		title: string;
		items: [
			{
				title: string;
				text: string;
				image: string;
			}
		];
	};
}

export interface UseType {
	title: string;
	subtitle: string;
	types: string[];
	image: string;
}

export interface UseRecomendation {
	title: string;
	recomendation: [
		{
			text: string;
			correctImage: string;
			incorrectImage: string;
		}
	];
}

export interface AnatomyComposition {
	title: string;
	image: string;
	items: AnatomyCompositionContent[];
}

export interface BehaviourContent {
	text: string;
	subtext: string[];
	img: string;
}
export interface Uses {
	title: string;
	content: UsesContent[];
}

export interface UsesContent {
	title: string;
	content: string;
}

export interface AnatomyCompositionContent {
	title: string;
	content: string;
}
