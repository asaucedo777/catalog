export interface Color {
    code: string;
    text: string;
    subText?: string;
}