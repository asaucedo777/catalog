const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const chalk = require('chalk');
const port = 3007;
app.use(express.json());

const policiesResponse = require('./services/edocs-table/lookup/response_lookup_policies.json');
const documentsHmResponse = require('./services/edocs-table/documentos/documentos-response.json');
const supervisorResponse = require('./services/edocs-table/authentication/response_login_supervisor.json');
const userResponse = require('./services/edocs-table/authentication/response_login_user.json');
const userRights = require('./services/edocs-table/lookup/response_lookup_user_rights.json');
const companiesListResponse = require('./services/companies/response_companies.json');
const provincesResponse = require('./services/provinces/response_provinces.json');
const clientValueResponse = require('./services/client-value/client-value_response.json');
const globalPositionResponse = require('./services/global-position/response_global-position.json');
const protocols = require('./services/protocol/response_protocol.json');
const subprotocols = require('./services/protocol/response_subprotocol.json');
const versions = require('./services/protocol/response_version.json');
const applications = require('./services/applications/applications.json');

app.use(bodyParser.urlencoded({ extended: true }));

app.post('/caser.sdc.server.core/lookup-service/rest/GetLookup', (req, res) => {
	switch (req.body.LookupId) {
		case 13: //Columnas
			res.send(policiesResponse);
      break;
    case 19:
      res.send(userRights);
      break;
	}
});

app.post('/caser.sdc.server.core/search-service/rest/SearchDocument', (req, res) => {
	res.send(documentsHmResponse);
});

app.post('/caser.sdc.server.core/authentication-service/rest/Login', (req, response) => {
	if (req.body.UserName === 'EXMSAGOM01') {
		response.send(supervisorResponse);
	} else {
		response.send(userResponse);
	}
});

app.post('/apibdihttpchannel/bindJSONServlet', (req, res) => {
  if(req.body.serviceId ==='BuscarCompaniaPorCodCiaDgs') {
    res.send(companiesListResponse);
  }
  if(req.body.serviceId ==='BuscarProvinciaPorNombreSRV') {
    res.send(provincesResponse);
  }
  if(req.body.serviceId ==='BuscarValorClienteSRV') {
    res.send(clientValueResponse);
  }
  if(req.body.serviceId ==='PosicionGlobalSRV') {
    res.send(globalPositionResponse);
  }
})

app.get('/lib-core-salud-sb/api/salud/protocols', (req, res) => {
  res.send(protocols);
})

app.get('/lib-core-salud-sb/api/salud/protocols/:idProtocol/subprotocols', (req, res) => {
  res.send(subprotocols);
})

app.get('/lib-core-salud-sb/api/salud/protocols/:idProtocol/subprotocols/:idSubprotocol/versions', (req, res) => {
  res.send(versions);
})

app.get('/portuno/caser/api/menu', (req, res) => {
	res.setHeader('Cache-Control', 'no-cache');
	res.setHeader('Content-Type', 'text/event-stream');
	res.setHeader('Access-Control-Allow-Origin', '*');
	res.flushHeaders();

	let counter = 0;
	let interValID = setInterval(() => {
		if (counter >= applications.length) {
			clearInterval(interValID);
			res.end();
			return;
		}
		res.write(`data: ${JSON.stringify(applications[counter])}\n\n`);
		counter++;
	}, 1000);

	res.on('close', () => {
		clearInterval(interValID);
		res.end();
	});
});


app.listen(port, () => {
	console.log(chalk.green(`Escuchando por el puerto ${port}`));
});
