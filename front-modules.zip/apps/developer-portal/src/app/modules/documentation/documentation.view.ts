import { Component } from '@angular/core';
import { Sidebar } from '../../models/sidebar.interface';

@Component({
  selector: 'ca-documentation',
  templateUrl: './documentation.view.html',
  styleUrls: ['./documentation.view.scss']
})
export class DocumentationView {
  sidebarItems: Sidebar[] = [
    {
      title: 'Fundamentos', subItems: [
        {
          link: '/documentation/fundamentals/nodenv',
          title: 'Instalación entorno de desarrollo'
        },
        {
          link: '/documentation/fundamentals/workspace',
          title: 'Creación de un workspace'
        },
        {
          link: '/documentation/fundamentals/dependencies',
          title: 'Dependencias NPM'
        },
        {
          link: '/documentation/fundamentals/module',
          title: 'Creación de un módulo'
        },
        {
          link: '/documentation/fundamentals/component',
          title: 'Creación de un componente'
        },
        {
          link: '/documentation/fundamentals/view',
          title: 'Creación de una vista'
        },
        {
          link: '/documentation/fundamentals/library',
          title: 'Creación de una biblioteca'
        },
        {
          link: '/documentation/fundamentals/service',
          title: 'Creación de un servicio'
        },
        {
          link: '/documentation/fundamentals/pipe',
          title: 'Creación de un pipe'
        },
        {
          link: '/documentation/fundamentals/mock',
          title: 'Configuración de un mock server'
        },
        {
          link: '/documentation/fundamentals/app-build',
          title: 'Construcción de una aplicación'
        },
        {
          link: '/documentation/fundamentals/repo-clone',
          title: 'Clonación de un repositorio existente'
        },
        {
          link: '/documentation/fundamentals/new-component',
          title: 'Creación y estilado de componentes globales'
        },
        {
          link: '/documentation/fundamentals/documentation-repos',
          title: 'Repositorios para la documentación de componentes globales'
        }
      ]
    },
    {
      title: 'Tutorial', subItems: [
        {
          link: '/documentation/tutorial/introduction',
          title: 'Introducción'
        },
        {
          link: '/documentation/tutorial/scafold',
          title: 'Estructura del proyecto'
        },
        {
          link: '/documentation/tutorial/app-component',
          title: 'Creación de un componente de aplicación'
        },
        {
          link: '/documentation/tutorial/login-module',
          title: 'Creación del módulo de Login'
        },
        {
          link: '/documentation/tutorial/login-view',
          title: 'Creación de la vista de Login'
        },
        {
          link: '/documentation/tutorial/caser-components',
          title: 'Creación del formulario de Login y Consumo de componentes CASER'
        },
        {
          link: '/documentation/tutorial/router',
          title: 'Creación del rúter para la navegación'
        },
        {
          link: '/documentation/tutorial/login-server',
          title: 'Creación del servidor mock para el login'
        },
        {
          link: '/documentation/tutorial/login-service',
          title: 'Creación del servicio de login'
        },
        {
          link: '/documentation/tutorial/info-module',
          title: 'Creación del módulo de Información'
        },
        {
          link: '/documentation/tutorial/info-view',
          title: 'Creación de la vista de Información'
        },
        {
          link: '/documentation/tutorial/table',
          title: 'Creación del componente Tabla'
        },
        {
          link: '/documentation/tutorial/table-server',
          title: 'Creación de un nuevo endpoint en el servidor mock para la tabla'
        },
        {
          link: '/documentation/tutorial/table-service',
          title: 'Creación del servicio de la tabla'
        },
        {
          link: '/documentation/tutorial/cdk-table',
          title: 'Implementación de CdkTable en el componente Tabla'
        },
        {
          link: '/documentation/tutorial/table-filter',
          title: 'Creación del componente Filtro para la Tabla'
        },
        {
          link: '/documentation/tutorial/filter-pipe',
          title: 'Implementación del filtrado en la tabla mediante un Pipe'
        },
        {
          link: '/documentation/tutorial/unit-test',
          title: 'Test unitarios'
        },
        {
          link: '/documentation/tutorial/e2e',
          title: 'Test E2E'
        }
      ]
    },
    {
      title: 'FAQs', subItems: [
        {
          link: '/documentation/faqs/caser-ui',
          title: 'Uso de componentes CASER UI'
        },
        {
          link: '/documentation/faqs/customization-level',
          title: 'Nivel de personalización'
        },
        {
          link: '/documentation/faqs/update-library-version',
          title: 'Actualizar versión de librería'
        },
        {
          link: '/documentation/faqs/proxies',
          title: 'Entornos de desarrollo para local'
        },
        {
          link: '/documentation/faqs/e2e-sso',
          title: 'Configuración Tests E2E para aplicaciones con SSO'
        },
        {
          link: '/documentation/faqs/new-theme',
          title: 'Creación de un nuevo tema'
        }
      ]
    }
  ];
  constructor() { }
}
