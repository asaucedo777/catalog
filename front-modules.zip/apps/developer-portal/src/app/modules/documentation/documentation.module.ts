import { NgModule, SecurityContext } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { DocumentationRoutingModule } from './documentation.routing.module';
import { DocumentationView } from './documentation.view';
import { MarkdownService } from './services/markdown.service';
import { NodenvView } from './views/fundamentals/nodenv/nodenv.view';
import { WorkspaceView } from './views/fundamentals/workspace/workspace.view';
import { DependenciesView } from './views/fundamentals/dependencies/dependencies.view';
import { ModuleView } from './views/fundamentals/module/module.view';
import { ComponentView } from './views/fundamentals/component/component.view';
import { ViewView } from './views/fundamentals/view/view.view';
import { ServiceView } from './views/fundamentals/service/service.view';
import { PipeView } from './views/fundamentals/pipe/pipe.view';
import { MockApiView } from './views/fundamentals/mock-api/mock-api.view';
import { AppBuildView } from './views/fundamentals/app-build/app-build.view';
import { IntroductionView } from './views/tutorial/introduction/introduction.view';
import { ScafoldView } from './views/tutorial/scafold/scafold.view';
import { HeaderView } from './views/tutorial/header/header.view';
import { LoginModuleView } from './views/tutorial/login-module/login-module.view';
import { LoginViewView } from './views/tutorial/login-view/login-view.view';
import { LoginFormView } from './views/tutorial/login-form/login-form.view';
import { RouterView } from './views/tutorial/router/router.view';
import { LoginServerView } from './views/tutorial/login-server/login-server.view';
import { LoginServiceView } from './views/tutorial/login-service/login-service.view';
import { InfoModuleView } from './views/tutorial/info-module/info-module.view';
import { InfoViewView } from './views/tutorial/info-view/info-view.view';
import { TableView } from './views/tutorial/table/table.view';
import { TableServerView } from './views/tutorial/table-server/table-server.view';
import { TableServiceView } from './views/tutorial/table-service/table-service.view';
import { CdkTableView } from './views/tutorial/cdk-table/cdk-table.view';
import { TableFilterView } from './views/tutorial/table-filter/table-filter.view';
import { FilterPipeView } from './views/tutorial/filter-pipe/filter-pipe.view';
import { UnitTestView } from './views/tutorial/unit-test/unit-test.view';
import { E2ETestView } from './views/tutorial/e2e-test/e2e-test.view';
import { CaserUIView } from './views/faqs/caser-ui/caser-ui.view';
import { CustomizationLevelView } from './views/faqs/customization-level/customization-level.view';
import { UpdateLibaryVersionView } from './views/faqs/update-library-version/update-library-version.view';
import { MarkdownModule } from 'ngx-markdown';
import { CaButtonModule, CaSidebarModule } from '@global-front-components/ui';
import { LibraryView } from './views/fundamentals/library/library.view';
import { RepoCloneView } from './views/fundamentals/repo-clone/repo-clone.view';
import { ProxiesView } from './views/faqs/proxies/proxies.view';
import { NewComponentView } from './views/fundamentals/new-component/new-component.view';
import { DocumentationReposView } from './views/fundamentals/documentation-repos/documentation-repos.view';
import { E2ESSOView } from './views/faqs/e2e-sso/e2e-sso.view';
import { NewThemeView } from './views/faqs/new-theme/new-theme.view';

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    DocumentationRoutingModule,
    CaSidebarModule,
    MarkdownModule.forRoot({
      sanitize: SecurityContext.NONE
    }),
    CaButtonModule
  ],
  declarations: [
    DocumentationView,
    NodenvView,
    WorkspaceView,
    DependenciesView,
    ModuleView,
    ComponentView,
    ViewView,
    ServiceView,
    PipeView,
    MockApiView,
    AppBuildView,
    RepoCloneView,
    IntroductionView,
    ScafoldView,
    HeaderView,
    LoginModuleView,
    LoginViewView,
    LoginFormView,
    RouterView,
    LoginServerView,
    LoginServiceView,
    InfoModuleView,
    InfoViewView,
    TableView,
    TableServerView,
    TableServiceView,
    CdkTableView,
    TableFilterView,
    FilterPipeView,
    UnitTestView,
    E2ETestView,
    CaserUIView,
    CustomizationLevelView,
    UpdateLibaryVersionView,
    LibraryView,
    ProxiesView,
    NewComponentView,
    DocumentationReposView,
    E2ESSOView,
    NewThemeView
  ],
  providers: [ MarkdownService ]
})
export class DocumentationModule {}
