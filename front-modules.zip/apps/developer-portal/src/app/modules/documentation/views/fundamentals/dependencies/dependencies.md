# Dependencias NPM

Todos los proyectos que hagan uso de la arquitectura CASER tendrán como eje central el fichero ***package.json***.

![PacakgeJson](./assets/docs/images/package-json.png)

El fichero _package.json_ está compuesto por diversas secciones que vamos a ver a continuación.

## Scripts

Los scripts de NPM nos permiten abstraer a los desarrolladores de la tecnología que hay por detrás eliminando complejidad usando **alias** para scripts más complejos.

![Scripts](./assets/docs/images/scripts.png)

### Original
```
ng build example-app --prod --build-optimizer
```

### Alias
```
npm run build:prd
```

## Dependencias

Son las dependencias que nuestro proyecto necesita para funcionar de manera productiva.

![Dependencies](./assets/docs/images/dependencies.png)

_Aquí irían las dependencias de la arquitectura y del catálogo de componentes._

## DevDependencies

Son las dependencias que necesitamos para construir nuestro proyecto.

![DevDependencies](./assets/docs/images/dev-dependencies.png)

Para instalar la arquitectura y el catálogo de componentes de CASER debemos lanzar los siguientes comandos:

### Paquete CORE
```
npm install --save @global-front-components/core
```

### Paquete COMMON
```
npm install --save @global-front-components/common
```

### Paquete UI
```
npm install --save @global-front-components/ui
```


### Paquete THEMES
```
npm install --save @global-front-components/themes
```


Para poder consumir uno de los temas en nuestra aplicación, se deberá incluir en el archivo *angular.json* de la aplicación, del siguiente modo:

![ThemesAngularJson](./assets/docs/images/themes-angular-json.png)



Una vez instaladas las dependencias de arquitectura es necesario instalar una serie de paquetes que usa la arquitectura:

### Paquete @angular/cdk
```
npm install --save @angular/cdk
```

El proceso de instalación hará las siguientes modificaciones en nuestro package.json.

![DependenciesCaser](./assets/docs/images/dependencies-caser.png)

