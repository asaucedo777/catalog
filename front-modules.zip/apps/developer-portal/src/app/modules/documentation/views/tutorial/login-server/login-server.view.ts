import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'login-server.view.html',
	styleUrls: ['login-server.view.scss']
})
export class LoginServerView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/router');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/login-service');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/login-server/login-server.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
