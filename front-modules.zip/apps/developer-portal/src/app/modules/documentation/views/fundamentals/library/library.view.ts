import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'library.view.html',
	styleUrls: ['library.view.scss'],
    encapsulation: ViewEncapsulation.None
})
export class LibraryView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/library/library.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
