import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'customization-level.view.html',
	styleUrls: ['customization-level.view.scss']
})
export class CustomizationLevelView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/faqs/customization-level/customization-level.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
