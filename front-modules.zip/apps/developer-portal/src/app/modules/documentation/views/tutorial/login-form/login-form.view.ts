import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'login-form.view.html',
	styleUrls: ['login-form.view.scss']
})
export class LoginFormView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/login-view');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/router');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/login-form/login-form.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
