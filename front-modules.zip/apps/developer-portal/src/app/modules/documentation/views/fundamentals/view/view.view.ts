import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'view.view.html',
	styleUrls: ['view.view.scss']
})
export class ViewView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/view/view.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
