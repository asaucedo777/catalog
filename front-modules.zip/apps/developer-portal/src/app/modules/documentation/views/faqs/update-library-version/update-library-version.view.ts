import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';


@Component({
  templateUrl: './update-library-version.view.html',
  styleUrls: ['./update-library-version.view.scss']
})
export class UpdateLibaryVersionView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  markdown: any;

  ngOnInit(): void {
    this._markdownService.getMarkdown('assets/docs/md/faqs/update-library-version/update-library-version.md').subscribe((response) => {
      this.markdown = response;
    })
  }

}
