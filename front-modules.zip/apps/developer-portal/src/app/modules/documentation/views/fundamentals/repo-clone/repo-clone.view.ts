import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'repo-clone.view.html',
	styleUrls: ['repo-clone.view.scss']
})
export class RepoCloneView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/repo-clone/repo-clone.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
