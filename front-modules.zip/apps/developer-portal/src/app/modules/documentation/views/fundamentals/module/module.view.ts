import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'module.view.html',
	styleUrls: ['module.view.scss']
})
export class ModuleView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/module/module.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
