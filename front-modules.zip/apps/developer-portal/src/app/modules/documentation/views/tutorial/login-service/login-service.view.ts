import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'login-service.view.html',
	styleUrls: ['login-service.view.scss']
})
export class LoginServiceView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/login-server');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/info-module');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/login-service/login-service.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
