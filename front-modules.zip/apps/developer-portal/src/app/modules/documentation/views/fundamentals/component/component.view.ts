import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'component.view.html',
	styleUrls: ['component.view.scss']
})
export class ComponentView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/component/component.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
