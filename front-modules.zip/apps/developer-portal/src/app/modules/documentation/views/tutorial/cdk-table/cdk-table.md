# Implementación de CdkTable en el componente Tabla

Una vez hemos creado el servicio que obtiene la información relativa a los elementos de la tabla periódica que queremos representar en nuestra tabla, e informado vía *Input* a nuestro componente ***table.component***, vamos a ver cómo representar dicha tabla.

Para poder usar un *CdkTable* en nuestro componente, debemos importar su módulo en nuestro módulo:

![InfoModule6](./assets/docs/images/info-module-6.png)

Lo primero que vamos a hacer es tipar nuestro *Input* cómo *array* de *Elements*. Este input es el que contiene la información recuperada por la vista a través del servicio.

A continuación vamos a decidir qué campos del API queremos representar, es decir, qué *columnas* y cómo las vamos a nombrar. En este caso vamos a representar el *Número atómico*, el *símbolo*, el *nombre* y la *masa atómica*.

Para ello, en nuestro *table.component.ts* crearemos una propiedad pública *columns*, que servirá para elegir qué campos de *dataSource* son los que se van a mostrar, y otra propiedad, *displayedColumns*, que servirá para nombrar y ordenar dichas columnas.

![CdkTableComponentTs](./assets/docs/images/cdk-table-component-ts.png)

Ahora vamos a añadir el *html* correspondiente:

![CdkTableComponentHtml](./assets/docs/images/cdk-table-component-html.png)

Y por último la hoja de estilos (_scss_) del componente:

![CdkTableComponentScss](./assets/docs/images/cdk-table-component-scss.png)

Ahora, lanzamos la aplicación a través de la *consola del entorno del desarrollador* (mediante el comando _npm run start_), y en el navegador navegamos a  *localhost:4200/login* y nos logueamos (cualquier combinación es válida) y pulsamos *Entrar*, o accedemos directamente a *localhost:4200/information*.

![TableResult](./assets/docs/images/table-result.png)

**NOTA**: Se aconseja revisar la documentación de la *CDK Table* que se encuentra en este portal, *Componentes -> Átomos -> CDK Table*, y en la página oficial del [CDK Table](https://material.angular.io/cdk/table/overview).



