import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'login-view.view.html',
	styleUrls: ['login-view.view.scss']
})
export class LoginViewView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/login-module');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/caser-components');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/login-view/login-view.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
