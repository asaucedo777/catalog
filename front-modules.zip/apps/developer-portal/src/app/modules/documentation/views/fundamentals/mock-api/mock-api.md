# Mock Server

Para levantar este servidor local haremos uso de un servidor ***Express***. Este paquete nos permite replicar el comportamiento de nuestros servidores de desarrollo, test, integración e incluso producción, para instalar el paquete lanzamos el siguiente comando:

```
npm install --save-dev express
```

Gracias a nuestro fichero de configuración del workspace, ***angular.json***, vamos a configurar un _proxy_ que nos permitirá no tener que cambiar la programación de nuestros servicios en los diferentes despliegues entre entornos ya que este proxy se encargará de redirigir las peticiones a los correspondientes entornos.

![ProxyConf](./assets/docs/images/proxy-conf.png)

Una vez creado nuestro fichero de proxy debemos incluir dicho fichero dentro de la configuración del workspace de Angular, para ello añadiremos la siguiente propiedad a nuestro fichero ***angular.json***.

![AngularJson](./assets/docs/images/angular-json.png)

Para levantar nuestro servidor local vamos a incluir un nuevo script en nuestro ***package.json***

![PackageJsonMocks](./assets/docs/images/package-json-mocks.png)

Para lanzar nuestro servidor a la vez que lanzamos nuestra aplicación vamos a apoyarnos en un paquete npm llamado ***concurrently***, instalamos dicho paquete a través del siguiente comando:


```
npm install--save-dev concurrently
```

Ahora modificamos nuestro script de la siguiente forma:

![PackageJsonMocks2](./assets/docs/images/package-json-mocks-2.png)

![NpmStart](./assets/docs/images/npm-start.png)
