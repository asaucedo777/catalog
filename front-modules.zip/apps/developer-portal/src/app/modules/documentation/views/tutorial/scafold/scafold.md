# Estructura del proyecto

Una vez configurado el workspace, debemos definir como va a ser nuestra estructura de proyecto.

Nuestras aplicaciones se van a dividir en módulos funcionales. Un módulo funcional debe agrupa una lógica que permita realizar una operación _de principio a fin_, ejemplos de estos serían:

* Login
* Administración de usuarios
* Administraciónde roles
* ...

Estos módulos deben comportarse como **cajas negras**, deben contener **todo** lo necesario para funcionar por si solas en una aplicación Angular cualquiera.
Agrupar esta _lógica_ en módulos nos permitirá en un futuro poder reutilizar dicha lógica si fuese necesario.

Estos módulos estarán compuestos por vistas alimentadas por servicios y construidas con: 

* Componentes de módulo
* Componentes de aplicación
* Componentes de CASER UI

Para ello, abrimos el _VSCode_ desde la raíz del proyecto, o bien en la linea de comandos, ejecutamos:

```
code .
```

![InitialScafold](./assets/docs/images/initial-scafold.png)

Para más información de cómo estructurar de proyecto, seguir la [guía de codificación de estilos de Angular](https://angular.io/guide/styleguide)

## Estilos globales para nuestra aplicación

Podemos crear clases en nuestra hoja de estilos global (_styles.scss_), para que estén disponibles para toda la aplicación. Por ejemplo, para aquellas vistas o componentes que usen la clase *container*:

![StylesScss](./assets/docs/images/styles-scss.png)

### NOTA
Ahora que vamos a comenzar a trabajar sobre nuestra aplicación, es conveniente eliminar el contenido de los archivos ***app.component.html*** y ***app.component.scss***.
