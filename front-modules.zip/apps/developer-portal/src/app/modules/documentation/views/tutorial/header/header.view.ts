import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'header.view.html',
	styleUrls: ['header.view.scss']
})
export class HeaderView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/scafold');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/login-module');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/header/header.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
