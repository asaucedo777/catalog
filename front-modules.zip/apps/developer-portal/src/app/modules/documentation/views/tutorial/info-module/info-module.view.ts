import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'info-module.view.html',
	styleUrls: ['info-module.view.scss']
})
export class InfoModuleView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/login-service');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/info-view');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/info-module/info-module.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
