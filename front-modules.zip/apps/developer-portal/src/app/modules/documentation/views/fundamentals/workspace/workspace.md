# Creación de un Workspace

Para crear un espacio de trabajo haremos uso de **_Angular CLI_** y de **_nrwl_** , para ello en la consola del entorno de desarrollo ejecutaremos el siguiente comando:

```
npm init nx-workspace@9.5.1
```

El resultado por consola es el siguiente:

![InitWorkspace](./assets/docs/images/init-workspace.png)

Abrimos el workspace generado en el **_VSCode_**:

![Scafold](./assets/docs/images/scafold.png)

A continuación se describen los elementos del workspace generado:

- **apps:** Carpeta que contiene todas las aplicaciones asociadas a nuestro workspace.
- **libs:** Carpeta que contiene todas las librerías asociadas a nuestro workspace.
- **node_modules:** Carpeta que contiene todas las dependencias de nuestro workspace.
- **tools:** Carpeta que contiene scripts de ayuda para el desarrollo, build, deploy…
- **.editorconfig:** Fichero de configuración que ayuda a mantener estilos de codificación consistentes para múltiples desarrolladores trabajando en el mismo workspace.
- **.gitignore:** Lista de ficheros que serán ignorados por GIT.
- **.prettierrc:** Fichero de configuración, sirve para dar formato al código.
- **.prettierignore:** Listado de ficheros y directorios que serán excluidos por **_prettier_**.
- **angular.json:** Fichero de configuración de Angular Workspace. (<https://angular.io/guide/workspace-config>)
- **jest.config.js:** : Fichero de configuración para test unitarios.
- **nx.json:** Fichero de configuración para los workspace de NX.
- **package-lock.json:** Fichero que representa el árbol de dependencias del proyecto.
- **package.json:** Fichero de configuración con las dependencias del proyecto.
- **tsconfig.json:** Fichero de configuración de Typescript.
- **tslint.json:** **_(Deprecado)_** Fichero de configuración para las reglas de TSLint. (<https://palantir.github.io/tslint/>)

#### Reglas Ts-lint recomendadas

Estas son las reglas básicas que, al menos, debería contener el projecto:

```
    "arrow-return-shorthand": true,
    "callable-types": true,
    "class-name": true,
    "deprecation": {
      "severity": "warn"
    },
    "forin": true,
    "import-blacklist": [true, "rxjs/Rx"],
    "interface-over-type-literal": true,
    "member-access": false,
    "member-ordering": [
      true,
      {
        "order": [
          "static-field",
          "instance-field",
          "static-method",
          "instance-method"
        ]
      }
    ],
    "no-arg": true,
    "no-bitwise": true,
    "no-console": [true, "debug", "info", "time", "timeEnd", "trace"],
    "no-construct": true,
    "no-debugger": true,
    "no-duplicate-super": true,
    "no-empty": false,
    "no-empty-interface": true,
    "no-eval": true,
    "no-for-in": true,
    "no-inferrable-types": [true, "ignore-params"],
    "no-misused-new": true,
    "no-non-null-assertion": true,
    "no-shadowed-variable": true,
    "no-string-literal": false,
    "no-string-throw": true,
    "no-switch-case-fall-through": true,
    "no-this-assignment": [true, {"allow-destructuring": true}],
    "no-unnecessary-initializer": true,
    "no-unused-expression": true,
    "no-var-keyword": true,
    "object-literal-sort-keys": false,
    "prefer-const": true,
    "prefer-for-of": true,
    "radix": true,
    "triple-equals": [true, "allow-null-check"],
    "unified-signatures": true,
    "use-isnan": true,
    "variable-name": false,
    "nx-enforce-module-boundaries": [
      true,
      {
        "enforceBuildableLibDependency": true,
        "allow": [],
        "depConstraints": [
          {
            "sourceTag": "*",
            "onlyDependOnLibsWithTags": ["*"]
          }
        ]
      }
    ],
    "directive-selector": [true, "attribute", "ca", "camelCase"], // remplazar "ca" por las siglas de su aplicación
    "component-selector": [true, "element", "ca", "kebab-case"], // remplazar "ca" por las siglas de su aplicación
    "no-conflicting-lifecycle": true,
    "no-host-metadata-property": false,
    "no-input-rename": true,
    "no-inputs-metadata-property": true,
    "no-output-native": true,
    "no-output-on-prefix": true,
    "no-output-rename": true,
    "no-outputs-metadata-property": true,
    "template-banana-in-box": true,
    "template-no-negated-async": true,
    "use-lifecycle-interface": true,
    "use-pipe-transform-interface": true
```
