# Uso de componentes CASER UI

***NOTA:*** *Para este apartado y el siguiente se ha generado un nuevo espacio de trabajo y una nueva aplicación, siguiendo los pasos de **Fundamentos**, pero obviamente se puede realizar en cualquier módulo de una aplicación ya existente.*

Para ejemplificar cómo hacer uso de un componente del catálogo de componentes vamos a usar el componente **card**.

![DevPortal](./assets/docs/images/dev-portal.png)

Lo primero que debemos hacer es importar el módulo del componente en el módulo principal de nuestra aplicación.

![CaserUiModule](./assets/docs/images/caser-ui-module.png)

Para hacer uso del componente, visitaremos su sección del _Portal de desarrollador_ y copiaremos el ejemplo que más nos convenga, en caso de que ningún ejemplo se adecuará a nuestros requisitos veríamos la sección API y haríamos uso del componente en base a nuestros requisitos.

![DevPortal2](./assets/docs/images/dev-portal-2.png)

Para este ejemplo vamos a hacer uso de la vista principal y copiar dicho código en el fichero _app.component.html_.

![CaserUiComponent](./assets/docs/images/caser-ui-component.png)

El resultado es el siguiente:

![CardResult](./assets/docs/images/card-result.png)
