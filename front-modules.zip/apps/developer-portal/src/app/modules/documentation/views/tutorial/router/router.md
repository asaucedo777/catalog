# Creación del rúter para la navegación

Para poder ver nuestra vista debemos especificar sobre que ruta queremos que esta se renderice, así que debemos añadir un nuevo fichero:

![AppRoutingModule](./assets/docs/images/app-routing-module.png)

Ahora debemos incluirlo en nuestro módulo principal y modificar nuestro **_app.component.html_** para que sirva de base para cargar componentes en rutas.

![AppModule](./assets/docs/images/app-module.png)

![AppComponent](./assets/docs/images/app-component.png)

Nuestros módulos de aplicación, al poder gestionar más de una vista, también deben tener su propio routing, así que vamos a crearlo e importarlo en su módulo.

![LoginRoutingModule](./assets/docs/images/login-routing-module.png)

![LoginModule5](./assets/docs/images/login-module-5.png)

El resultado que obtendremos en nuestro navegador será el siguiente:

![LoginResult](./assets/docs/images/login-result.png)
