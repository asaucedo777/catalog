
# Creación de un módulo

Para crear un módulo tenemos dos opciones:

## A través de la interfaz de usuario de Nx:

Pasos: 
* **1**  Abrir la consola de Nx
* **2**  Seleccionar la acción _generate_
* **3**  Buscar _module_
* **4**  Seleccionar la opción _@schematics/angular - module_
* **5**  Escribir el nombre del módulo
* **6**  Ejecutar

![NxModule](./assets/docs/images/nx-module.png)

## A través de la consola del entorno de desarrollo:

Podríamos realizar el mismo proceso a través de consola lanzando el siguiente comando:

```
npm run ng generate module modules/example
```

El resultado es el siguiente:

![ExampleModule](./assets/docs/images/example-module.png)

Para ver todas las opciones disponibles a la hora de generar un módulo, puedes consultar en la documentación oficial de [Angular](https://angular.io/cli/generate#module-command).
