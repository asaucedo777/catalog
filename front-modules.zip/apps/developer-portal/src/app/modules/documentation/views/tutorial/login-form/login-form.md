# Creación del formulario de Login y Consumo de componentes CASER

Nuestra vista va a hacer uso de un componente que consistirá en un formulario (basado en componentes CASER) que validará nuestro usuario y contraseña.

De nuevo, tenemos dos opciones:

- A través de la interfaz de la consola de **_Nx_** :

![NxLoginForm](./assets/docs/images/nx-login-form.png)

- A través de la consola del _entorno de desarrollo_:

```
npm run ng generate component modules/login/components/login-form --module=login.module --style=scss
```

El resultado es el siguiente:

![LoginModule3](./assets/docs/images/login-module-3.png)

## Consumo de componentes de CASER para la implementación del formulario

Vamos a crear el formulario haciendo uso de componentes CASER UI:

- CaFormFieldModule
- CaButtonModule

La potencia de un formulario Angular esta desarrollada en un módulo específico:

- ReactiveFormsModule

Para poder usarlos, debemos importarlos en nuestro módulo de login:

![LoginModule4](./assets/docs/images/login-module-4.png)

## Desarrollo del componente de formulario

Los formularios reactivos de Angular nos permiten construir la lógica de nuestros formularios a través de TypeScript la cual quedará plasmada en nuestro HTML, para ellos debemos hacer lo siguiente.

## TypeScript

![LoginFormTs](./assets/docs/images/login-form-ts.png)

## HTML

![LoginFormHTML](./assets/docs/images/login-form-html.png)

Ahora nuestro componente de vista debe consumir este componente que hemos creado, por medio de su _selector_:

![LoginView](./assets/docs/images/login-view.png)
