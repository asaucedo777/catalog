# Introducción

En este tutorial vamos a crear una aplicación consistente en un login, una navegación y una tabla, con funcionalidad _de principio a fin_.

Para ello, lo primero que debemos hacer es crear nuestro workspace. Desde la consola del entorno de desarrollador, lanzamos el siguiente comando:

```
npm init nx-workspace
```

Debemos elegir el nombre del workspace, el framework (**Angular**), el nombre de la aplicación y la hoja de estilos (**SASS**).

El resultado por consola es el siguiente:

![TutorialWorkspace](./assets/docs/images/tutorial-workspace.png)

Una vez se haya instalado, nos movemos a la carpeta del workspace generado, realizando:

```
cd tutorial-workspace
```

Ahora necesitamos instalar las dependencias necesarias para usar la arquitectura de CASER, por lo que lanzaremos los siguientes comandos:

```
npm install --save @global-front-components/common
npm install --save @global-front-components/core
npm install --save @global-front-components/ui
npm install --save @angular/cdk
```

