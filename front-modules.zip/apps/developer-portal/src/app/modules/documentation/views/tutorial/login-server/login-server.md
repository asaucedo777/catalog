# Creación del servidor mock para el login

Para el ejemplo práctico de la vista que hemos construido vamos a comprobar que un usuario está _dado de alta_ en nuestra aplicación haciendo una llamada a un servidor que levantaremos en local.

Vamos a seguir los pasos ya detallados en el apartado de Fundamentos, _Configuración de un mock server_.

A modo de resumen, comenzaremos configurando el _proxy_:

![LoginProxyConf](./assets/docs/images/login-proxy-conf.png)

![AngularJsonProxy](./assets/docs/images/angular-json-proxy.png)

A continuación vamos a instalar las dependencias necesarias, a través de la consola del entorno de desarrollo:

```
npm install --save-dev express
npm install --save-dev concurrently
```

Una vez instalado, vamos a crear nuestro servidor mock:

![LoginServer](./assets/docs/images/login-server.png)

Ahora vamos a crear los scripts necesarios para levantar nuestro servidor:

![LoginScripts](./assets/docs/images/login-scripts.png)

