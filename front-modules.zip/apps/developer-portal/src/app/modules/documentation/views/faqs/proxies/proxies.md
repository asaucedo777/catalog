# Entornos de desarrollo para local

Para desarrollar las aplicaciones podremos apuntar a diferentes entornos para probar las llamadas a los servicios de Back-End.

* **Servidor de estáticos**: Los servicios estarán mockeados en nuestra aplicación. 

* **Servidor en local**: Los servicios a los que apunte nuestra aplicación estarán desplegados de manera _local_ en otro puerto de nuestra máquina.

* **Servidor en integración**: Los servicios estarán desplegados en el entorno de _integración_.

* **Servidor en test**: Los servicios estarán desplegados en el entorno de _test_.


A continuación se va a ejemplificar como se configurarán estos entornos a través de archivos _proxy.conf_ en una aplicación fictícia (_app-ejemplo_) que se levantaría en el puerto _localhost: 4206_, y que el endpoint al que ataca nuestra aplicación es _/apiejemplo_. 


## Servidor de estáticos o mock

Los servicios mockeados estarán disponibles en nuestra aplicación. Para más información de cómo crear un servidor de estáticos, consultad el ejemplo del apartado _Tutorial_ -> _Creación del servidor mock para el login_ y siguientes.

Una vez hayamos creado nuestro servidor de estáticos (en _apps/app-ejemplo/api_), deberemos configurar nuestro _proxy.conf.json_ del siguiente modo:

![ProxyConfMock](./assets/docs/images/proxy-conf-mock.png)

Y en el _angular.json_ aplicamos esta configuración por defecto en el _serve_ (comando que compila nuestra app en local), de este modo: 

![AngularJsonMock](./assets/docs/images/angular-json-mock.png)

Por último en los _scripts_ del _package.json_:

![NpmStartMock](./assets/docs/images/npm-start-mock.png)

Se puede observar que este script, lanza dos acciones en dos puertos diferentes, gracias a la dependecia _concurrently_. Por una parte compila nuestra aplicación angular, en el puerto 4206, y por otro lanza el comando que arranca nuestro servidor de estáticos (situado en _./apps/app-ejemplo/api/server.js_) en el puerto 3006.

A continuación sólo habría que lanzar en consola el comando:

```
npm start
```


## Servidor en local

Supongamos que tenemos nuestro Back-End en local desplegado en el puerto _localhost:8080_.

Configuraremos un _proxy_ específico para este caso, al que llamaremos _proxy-local.conf.json_, del siguiente modo:

![ProxyConfLocal](./assets/docs/images/proxy-conf-local.png)

En la propiedad _target_ es dónde se informará del puerto en el que el Back-End está desplegado.

A continuación, añadimos el _script_ necesario en el _package.json_:

![NpmStartLocal](./assets/docs/images/npm-start-local.png)

En este script hemos sobreescrito la configuración del proxy, para que apunte al archivo que acabamos de crear, a través del flag __--proxy-config__

Y por último lanzamos la aplicación, a través del comando:

```
npm run start:local
```


## Servidor en Integración

Supongamos que nuestro Back-End está desplegado en un entorno de integración en _rutaapiejemplointe.caser.local_

Configuraremos un _proxy_ específico para este caso, al que llamaremos _proxy-int.conf.json_, del siguiente modo:

![ProxyConfInt](./assets/docs/images/proxy-conf-int.png)

En la propiedad _target_ es dónde se informará de la url en la que están nuestro servicios en integración.

A continuación, añadimos el _script_ necesario en el _package.json_:

![NpmStartInt](./assets/docs/images/npm-start-int.png)

En este script hemos sobreescrito la configuración del proxy, para que apunte al archivo que acabamos de crear, a través del flag __--proxy-config__

Y por último lanzamos la aplicación, a través del comando:

```
npm run start:int
```


## Servidor en Test

Supongamos que nuestro Back-End está desplegado en un entorno de test en _rutaapiejemplotest.caser.local_

Configuraremos un _proxy_ específico para este caso, al que llamaremos _proxy-test.conf.json_, del siguiente modo:

![ProxyConfTest](./assets/docs/images/proxy-conf-test.png)

En la propiedad _target_ es dónde se informará de la url en la que están nuestro servicios en test.

A continuación, añadimos el _script_ necesario en el _package.json_:

![NpmStartTest](./assets/docs/images/npm-start-test.png)

En este script hemos sobreescrito la configuración del proxy, para que apunte al archivo que acabamos de crear, a través del flag __--proxy-config__

Y por último lanzamos la aplicación, a través del comando:

```
npm run start:test
```
