# NODENV

El uso de un entorno de desarrollo personalizado nos brinda la posibilidad de disponer de las herramientas necesarias para empezar a desarrollar de forma ágil y rápida sin procesos de instalación complejos.

## Instalación

Nodenv es un proyecto _NodeJS_ y _NPM_ subido al respositorio coorporativo GitLab de CASER.

![Entorno](./assets/docs/images/gitlab-repo.png)

Para descargar el proyecto es necesario que tengamos GIT instalado en nuestra maquina.

Abriremos la consola de GIT (Git for Windows) y copiamos el siguiente comando:

```powershell
git clone http://gitlab.caser.local/arquitectura-interno/global-front-components/nodenv.git
```

Una vez clonado el proyecto tendremos una estructura de carpetas como esta:

![Entorno](./assets/docs/images/nodenv-folder.png)

Abrimos la carpeta que pone cmder y ejecutamos Cmder.exe:

![Entorno](./assets/docs/images/exec-nodenv.png)

Una vez ejecutado, obtendremos una terminal de sistema con las siguientes caracteristicas:

 * NodeJS: v12.17.0
 * NPM: v6.14.4
 * Git: 2.24.1.windows.2

Añadido a esto se creara un acceso directo en el escritorio para hacer mas accesible la apertura del entorno.

![Entorno](./assets/docs/images/nodenv-sortcut.png)

