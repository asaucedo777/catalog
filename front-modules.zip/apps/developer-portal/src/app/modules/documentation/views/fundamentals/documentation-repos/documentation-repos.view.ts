import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'documentation-repos.view.html',
	styleUrls: ['documentation-repos.view.scss']
})
export class DocumentationReposView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/documentation-repos/documentation-repos.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
