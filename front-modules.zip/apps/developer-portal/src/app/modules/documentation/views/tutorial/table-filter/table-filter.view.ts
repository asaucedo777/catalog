import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'table-filter.view.html',
	styleUrls: ['table-filter.view.scss']
})
export class TableFilterView implements OnInit {
  constructor(
    private _markdownService: MarkdownService,
    private _router: Router
  ) { }

  public markdown: string;

  previous(): void {
    this._router.navigateByUrl('/documentation/tutorial/cdk-table');
  }

  next(): void {
    this._router.navigateByUrl('/documentation/tutorial/filter-pipe');
  }

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/tutorial/table-filter/table-filter.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
