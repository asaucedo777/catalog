# Creación de un pipe

Para crear un pipe tenemos dos opciones:

## A través de la interfaz de usuario de Nx:

Pasos: 
* **1**  Abrir la consola de Nx
* **2**  Seleccionar la acción _generate_
* **3**  Buscar _pipe_
* **4**  Seleccionar la opción _@schematics/angular - pipe_
* **5**  Escribir el nombre del pipe
* **6**  Escribir el nombre del _módulo_ al que pertenece
* **7**  Ejecutar

![NxPipe](./assets/docs/images/nx-pipe.png)

## A través de la consola del entorno de desarrollo:

Podríamos realizar el mismo proceso a través de consola lanzando el siguiente comando:

```
npm run ng generate pipe modules/example/pipes/example --module=example.module
```

El resultado es el siguiente:

![ExampleModulePipe](./assets/docs/images/example-module-pipe.png)

Para ver todas las opciones disponibles a la hora de generar un pipe, puedes consultar en la documentación oficial de [Angular](https://angular.io/cli/generate#pipe).

Además puedes consultar información sobre la utilidad y uso de los pipe en la [guía de Angular](https://angular.io/guide/pipes).
