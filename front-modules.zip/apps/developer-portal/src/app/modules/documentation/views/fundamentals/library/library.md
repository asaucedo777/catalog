# Creación de una librería

Para crear una biblioteca detallamos los pasos a seguir:

## Clona el proyecto Caser-architecture:

git clone http://gitlab.caser.local/arquitectura/front/caser-architecture.git

## Añade la biblioteca:
Genera la nueva bilbioteca para componentes de tu grupo de aplicaciones.
Aquí tienes un ejemplo de la estructura:
![LibrarySchema](./assets/docs/images/library-schema.PNG)
\
Es importante revisar los siguientes archivos dentro de la nueva biblioteca generada:
\
<em>README.md</em>
\
<em>jest.config.js</em>
\
<em>ng-package.json</em>
\
<em>package.json</em>
\
<em>src/index.ts</em>
\
<em>src/lib/nameLib.module.ts</em>
\
<em>src/test-setup.ts</em>
\
<em>/tsconfig.json</em>
\
<em>/tsconfig.lib.json</em>
\
<em>/tslint.json</em>

## Añade script de construcción:
Modifica el archivo angular.json para construir la nueva biblioteca, a continuación puedes ver un ejemplo:
\
![AngularJsonInserLib](./assets/docs/images/angular-json-inser-lib.PNG)

## Iguala la versión de la nueva biblioteca a las extistentes:
Para evitar errores la nueva biblioteca nace con un número de version que determinan las bibliotecas ya existentes.

## Criterios de aceptación antes de publicación:
Para publicar la nueva biblioteca debes pedir un merge request al equipo de arquitectura para que valide los cambios.
Los criterios a evaluar serán los siguientes:
\
<strong>Diseño</strong>
\
<strong>Maquetación</strong>
\
<strong>Documentación</strong>
\
<strong>80% UnitTest</strong>

## Publica la nueva bilbioteca:
Modifica los archivos
#### NX.json
\
![NxAdd](./assets/docs/images/nx-add.PNG)
\
#### Package.json
\
Añade la nueva biblioteca al archivo
\
![AddBuild](./assets/docs/images/add-build.PNG)
\
Añade la nueva biblioteca a script de publicación
\
![PublishLib](./assets/docs/images/publish-lib.PNG)
\
#### tsConfig.json
\
Exporta la nueva biblioteca
\
![AddExportTsconfig](./assets/docs/images/add-export-tsconfig.PNG)
