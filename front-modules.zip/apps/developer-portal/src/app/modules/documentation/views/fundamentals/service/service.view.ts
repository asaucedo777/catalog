import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'service.view.html',
	styleUrls: ['service.view.scss']
})
export class ServiceView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/fundamentals/service/service.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
