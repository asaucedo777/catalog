import { Component, OnInit } from '@angular/core';
import { MarkdownService } from '../../../services/markdown.service';

@Component({
	templateUrl: 'e2e-sso.view.html',
	styleUrls: ['e2e-sso.view.scss']
})
export class E2ESSOView implements OnInit {
  constructor(private _markdownService: MarkdownService) { }

  public markdown: string;

  ngOnInit() {
    this._markdownService.getMarkdown('assets/docs/md/faqs/e2e-sso/e2e-sso.md').subscribe((response) => {
      this.markdown = response;
    })
  }
}
