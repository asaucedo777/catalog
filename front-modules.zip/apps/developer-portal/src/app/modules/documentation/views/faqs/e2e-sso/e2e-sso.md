# Configuración Tests E2E para aplicaciones con SSO

Para poder realizar tests E2E en aplicaciones que vayan por el SSO, deberemos instlar una dependencia y realizar unas configuraciones previas para _mockear_ la autenticación contra el SSO.

Para ello deberemos instalar _cypress-keycloak-commands_ en la versión 1.2.0, mediante:

```
npm i cypress-keycloak-commands@1.2.0 --save-dev
```

Una vez se haya instalador esta _devDependency_ en el package.json del aplicactivo, iremos al proyecto E2E, y en el archivo _commands.po.ts_ importaremos dicha dependencia:

![SSOE2ECommands](./assets/docs/images/sso-e2e-commands.png)

A contnuación en la carpeta _fixtures_ crearemos una carpeta denominada _users_ y en esta, crearemos un archivo _fakeUser.json_ con el siguiente contenido:

![SSOE2EFakeUser](./assets/docs/images/sso-e2e-fakeuser.png)

Para obtener los valores de los campos *access_token*, *refresh_token* y *client_id* deberemos copiarlos de una respuesta válida del SSO. Por ejemplo podemos ir a https://marcopolointe.caser.local/ y obtenerlos de ahí.

![SSOE2ETokens](./assets/docs/images/sso-e2e-tokens.png)


Una vez hayamos configurado todo esto, en **cada** archivo de test deberemos incluir lo siguiente:

![SSOE2ETestExample](./assets/docs/images/sso-e2e-test-example.png)

