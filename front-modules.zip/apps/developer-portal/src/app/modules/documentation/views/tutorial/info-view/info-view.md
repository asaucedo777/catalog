# Creación de la vista de Información

Vamos a crear ahora la vista de Información. Para ello:

* A través de la interfaz de la consola de ***Nx*** :

![NxInfoView](./assets/docs/images/nx-info-view.png)

![NxInfoView2](./assets/docs/images/nx-info-view-2.png)


* A través de la consola del _entorno de desarrollo_:

```
npm run ng generate component modules/information/views/information --module=information.module --style=scss --skipSelector --type=view
```

Se obtiene:

![InfoModule2](./assets/docs/images/info-module-2.png)

## Inclusión de la nueva vista al rúter

Una vez creada la vista, vamos a incluirla en el rúter, y que cuando un usuario se loguee, la aplicación navegue a esta nueva vista. 

Primero debemos crear el *routing* del módulo de Información:

![InfoRoutingModule](./assets/docs/images/info-routing-module.png)

Una vez creado, debemos importarlo en el módulo:

![InfoModule3](./assets/docs/images/info-module-3.png)

Ahora debemos incluirlo en el *routing* de la aplicación:

![AppRoutingModule2](./assets/docs/images/app-routing-module-2.png)

## Navegación a la nueva vista

Ahora ya podemos acceder a la nueva vista, arrancando la aplicación y navegando a *localhost:4200/information*, pero para darle cierta lógica funcional a nuestra aplicación, vamos a hacer que, una vez el usuario haya hecho *login*, se redirija a la nueva vista.

Para ello, debemos implememtar en el *login* lo siguiente:

![LoginFormTsRouter](./assets/docs/images/login-form-ts-router.png)
