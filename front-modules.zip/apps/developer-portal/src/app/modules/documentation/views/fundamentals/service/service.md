# Creación de un servicio

Para crear un servicio tenemos dos opciones:

## A través de la interfaz de usuario de Nx:

Pasos: 
* **1**  Abrir la consola de Nx
* **2**  Seleccionar la acción _generate_
* **3**  Buscar _service_
* **4**  Seleccionar la opción _@schematics/angular - service_
* **5**  Escribir el nombre del servicio
* **6**  Ejecutar


![NxService](./assets/docs/images/nx-service.png)

## A través de la consola del entorno de desarrollo:

Podríamos realizar el mismo proceso a través de consola lanzando el siguiente comando:

```
npm run ng generate service modules/example/services/example
```

El resultado es el siguiente:

![ExampleService](./assets/docs/images/example-service.png)

Para que el servicio esté disponible para las vistas y componentes de un módulo, debemos incluirlo en el *providers* del módulo:

![ExampleMouleService](./assets/docs/images/example-module-service.png)

Para ver todas las opciones disponibles a la hora de generar un servicio, puedes consultar en la documentación oficial de [Angular](https://angular.io/cli/generate#service-command).
