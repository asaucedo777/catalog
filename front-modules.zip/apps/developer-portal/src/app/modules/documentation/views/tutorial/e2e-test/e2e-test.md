# Test E2E

Los test E2E nos permiten probar nuestra aplicación de manera funcional.

* ¿Cómo debe responder el aplicativo a las acciones del usuario?
* ¿Lógica de validaciones de campos?
* ¿Lógica de navegación?

Para lanzar el script que nos permite evaluar los test E2E de nuestra aplicación debemos lanzar el siguiente comando:

```
npm run e2e --watch
```

Para que _Cypress_ sepa como debe interactuar con nuestra interfaz de usuario tiene que saber donde están cada uno de los elementos que lo componen, para ello vamos a modificar nuestro componente de formulario de la siguiente forma:

![LoginFormE2E](./assets/docs/images/login-form-e2e.png)

Una vez _identificados_ nuestros elementos ahora debemos capturarlos a través de _Cypress_ y los mecanismos que nos da para ellos:

![AppPo](./assets/docs/images/app-po.png)

Ahora ya podemos construir nuestro test para nuestra interfaz:

![AppSpec](./assets/docs/images/app-spec.png)

Y obtendremos el siguiente resultado:

![E2EResult](./assets/docs/images/e2e-result.png)
