# Creación del módulo de Información

La segunda funcionalidad que vamos a desarrollar en este tutorial va a ser una vista que contenga una *tabla* para mostrar información, cuyo contenido se obtendrá de un *servicio* y tendrá un input para realizar una búsqueda, mediante un *pipe*.

Lo primero que haremos será generar el módulo de información. Para ello:

* A través de la interfaz de la consola de ***Nx*** :

![NxInfoModule](./assets/docs/images/nx-info-module.png)

* A través de la consola del _entorno de desarrollo_:

```
npm run ng generate module modules/information
```

![InfoModule](./assets/docs/images/info-module.png)
