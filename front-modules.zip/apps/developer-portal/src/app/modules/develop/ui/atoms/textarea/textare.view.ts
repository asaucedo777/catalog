import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: 'textarea.view.html',
	styleUrls: ['textarea.view.scss']
})
export class TextareaView implements OnInit {
	constructor(private formBuilder: FormBuilder) {}

	public form: FormGroup;
  public importModule = `import { CaFormFieldModule, CaTextareaModule } from '@global-front-components/ui';`;

  caseSimple: ComponentDoc = {
    title: `Uso texarea simple`,
    codeExample: {
      html: `<ca-form-field>
  <ca-label>Descripción</ca-label>
  <textarea
    caTextarea
    placeholder="Inserte aquí una descripción"
  ></textarea>
</ca-form-field>`
    }
  }

  caseRequired: ComponentDoc = {
    title: `Estado requerido`,
    description: `Siempre que nuestro elemento sea requerido a través del atributo <code class="attribute">required</code> se marcara
    como tal a nivel visual.`,
    codeExample: {
      html: `<ca-form-field>
  <ca-label>Descripción</ca-label>
  <textarea
    caTextarea
    required
    placeholder="Inserte aquí una descripción"
  ></textarea>
</ca-form-field>`
    }
  }

  caseDisabled: ComponentDoc = {
    title: `Estado disabled`,
    description: `Siempre que nuestro elemento este deshabilitado a través del atributo <code class="attribute">disabled</code>
    se marcara como tal a nivel visual.`,
    codeExample: {
      html: `<ca-form-field>
  <ca-label>Descripción</ca-label>
  <textarea
    caTextarea
    disabled
    placeholder="Inserte aquí una descripción"
    value="Descripción deshabilitada"
  ></textarea>
</ca-form-field>`
    }
  }

  caseReadOnly: ComponentDoc = {
    title: `Estado readonly`,
    description: `Siempre que nuestro elemento este en modo solo lectura a través del atributo
    <code class="attribute">readonly</code> se marcara como tal a nivel visual.`,
    codeExample: {
      html: `<ca-form-field>
  <ca-label>Descripción</ca-label>
  <textarea
    caTextarea
    readonly
    placeholder="Inserte aquí una descripción"
    value="Descripción de sólo lectura">
  </textarea>
</ca-form-field>`
    }
  }

  caseReactiveForm: ComponentDoc = {
    title: `Uso en formularios reactivos`,
    description: `<p>El componente <code class="tag">ca-textarea</code> se puede utilizar dentro de formularios reactivos haciendo uso de la directiva
    <code class="attribute">formControlName</code> perteneciente al modulo <code class="module">@angular/forms</code></p>`,
    codeExample: {
      html: `<form [formGroup]="form">
  <ca-form-field>
    <ca-label>Descripción</ca-label>
    <textarea
      caTextarea
      formControlName="control"
      placeholder="Inserte aquí una descripción"
    ></textarea>
    <ca-hint>Introduce una descripción de cómo mínimo 20 carácteres</ca-hint>
    <ca-error *ngIf="form.controls['control'].errors?.required">El campo es requerido</ca-error>
    <ca-error *ngIf="form.controls['control'].errors?.minlength">El campo debe tener 20 caracteres como mínimo</ca-error>
  </ca-form-field>
</form>`,
      ts: `import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'ca-example-view',
  templateUrl: './example-view.component.html',
  styleUrls: ['./example-view.component.scss']
})
export class FormFieldPageComponent implements OnInit {
  constructor(private formBuilder: FormBuilder) {}

  public form: FormGroup;

  private _formBuilder(): void {
    this.form = this.formBuilder.group({
      control: ['', [Validators.required, Validators.minLength(20)]]
    });
  }

  ngOnInit(): void {
    this._formBuilder();
  }
}`
    }
  }

  caseSimpleMin: ComponentDoc = {
    title: `Uso texarea simple a tamaño mínimo`,
    description: `<p>El componente <code class="tag">ca-textarea</code> se puede utilizar con tamaño mínimo si al componente <code class="tag">ca-form-field</code> que lo contiene se le aplica el atributo <code class="attribute">ca-form-field-min</code>`,
    codeExample: {
      html: `<ca-form-field ca-form-field-min>
  <ca-label>Descripción</ca-label>
  <textarea
    caTextarea
    placeholder="Inserte aquí una descripción"
  ></textarea>
</ca-form-field>`
    }
  }

	ngOnInit(): void {
		this.form = this.formBuilder.group({
			control: ['', [Validators.required, Validators.minLength(20)]]
		});
	}
}
