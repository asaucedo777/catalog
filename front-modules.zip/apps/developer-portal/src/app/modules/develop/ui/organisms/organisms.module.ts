import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {
	CaCheckDataService,
	CaClientValueService,
	CaCodPostalesService,
	CaCompaniesService,
	CaDocumentService,
	CaDocumentTypeService,
	CaFondosService,
	CaGlobalPositionService,
	CaModasService,
	CaPlanService,
	CaPopulationService,
	CaProvincesService,
	CaRamosService,
	CaRoadTypeService,
	CaSubmodaService
} from '@global-front-components/common';
import {
	CaButtonModule,
	CaClientValueModule,
	CaEdocsTableModule,
	CaFormFieldModule,
	CaInputModule,
	CaModalOverlayModule,
	CaModalOverlayService,
	CaSelectModule,
	CaSidebarModule,
	CaTypeaheadModule
} from '@global-front-components/ui';
import { ComponentDocModule } from '../../../../components/component-doc/component-doc.module';
import { CheckDataView } from './check-data/check-data.view';
import { CaClientValueModalExampleComponent } from './client-value/client-value-modal-example/client-value-modal-example.component';
import { ClientValueView } from './client-value/client-value.view';
import { CompanyView } from './company/company.view';
import { DocumentTypeView } from './document-type/document-type.view';
import { DocumentView } from './document/document.view';
import { EdocsTableView } from './edocs-table/edocs-table.view';
import { FondoView } from './fondo/fondo.view';
import { GlobalPositionView } from './global-position/global-position.view';
import { ModaView } from './moda/moda.view';
import { OrganismsRoutingModule } from './organisms-routing.module';
import { OrganismsView } from './organisms.view';
import { PlanPenView } from './plan/plan.view';
import { ProvincesView } from './provinces/provinces.view';
import { RamoView } from './ramo/ramo.view';
import { RoadTypeView } from './road-type/road-type.view';
import { SexoView } from './sexo/sexo.view';
import { SubPlanView } from './sub-plan/sub-plan.view';
import { SubmodaView } from './submoda/submoda.view';
import { CodPostalView } from './cod-postal/cod-postal.view';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PopulationView } from './population/population.view';

@NgModule({
	declarations: [
		CaClientValueModalExampleComponent,
		ClientValueView,
		CompanyView,
		EdocsTableView,
		GlobalPositionView,
		OrganismsView,
		ProvincesView,
		DocumentView,
		DocumentTypeView,
		PlanPenView,
		RamoView,
		CheckDataView,
		ModaView,
		FondoView,
		RoadTypeView,
		SubmodaView,
		SubPlanView,
		SexoView,
		CodPostalView,
		PopulationView
	],
	imports: [
		CaButtonModule,
		CaClientValueModule,
		CaEdocsTableModule,
		CaFormFieldModule,
		CaInputModule,
		CaModalOverlayModule,
		CaSelectModule,
		CaSidebarModule,
		CaTypeaheadModule,
		CommonModule,
		ComponentDocModule,
		FormsModule,
		HttpClientModule,
		NgbModule,
		OrganismsRoutingModule,
		ReactiveFormsModule,
		RouterModule
	],
	providers: [
		CaModalOverlayService,
		CaCompaniesService,
		CaProvincesService,
		CaClientValueService,
		CaGlobalPositionService,
		CaDocumentService,
		CaDocumentTypeService,
		CaPlanService,
		CaRamosService,
		CaModasService,
		CaFondosService,
		CaRoadTypeService,
		CaSubmodaService,
		CaCodPostalesService,
		CaCheckDataService,
		CaPopulationService
	]
})
export class OrganismsModule {}
