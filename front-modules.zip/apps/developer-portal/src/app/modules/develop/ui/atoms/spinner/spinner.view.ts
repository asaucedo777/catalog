import { Component } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
  templateUrl: 'spinner.view.html',
  styleUrls: ['spinner.view.scss']
})
export class SpinnerView {

  loader: boolean = false;

  importModule = `import { CaSpinnerModule } from '@global-front-components/ui';`;
  caseLinearDeterminate: ComponentDoc = {
    title: `Spinner lineal`,
    description: `Por defecto el spinner es de tipo lineal y determinado. Se debe informar al componente del valor porcentual del progreso (de 0 a 100) a través del <code class="tag">value</code>.`,
    codeExample: {
      html: `<ca-spinner
  [value]="linearProgress"
  title="Cargando..."
  subtitle="Pulsa el botón para incrementar un 10%">
</ca-spinner>
<button
  ca-button-secondary
  (click)="progressIncrement()">
  Incrementa
</button>`,
    ts: `import { Component } from '@angular/core';
@Component({
  selector: 'ca-linear-spinner',
  templateUrl: './linear-spinner.component.html',
  styleUrls: ['./linear-spinner.component.scss']
})
export class LinearSpinnerComponent {
  linearProgress = 0;
  progressIncrement(): void {
    if(this.linearProgress <100) {
      this.linearProgress += 10;
    } else {
      this.linearProgress = 0;
    }
  }
}`
    }
  };

  caseLinearIndeterminate: ComponentDoc = {
    title: `Spinner lineal indeterminado`,
    codeExample: {
      html: `<ca-spinner
  mode="indeterminate"
  title="Inicializando...">
</ca-spinner>`
    }
  };

  caseCircularDeterminate: ComponentDoc = {
    title: `Spinner circular`,
    codeExample: {
      html: `<ca-spinner
  type="circular"
  [value]="circularProgress"
  title="Cargando..."
  subtitle="Pulsa el botón para incrementar un 10%">
</ca-spinner>
<button
  ca-button-secondary
  (click)="progressIncrement()">
  Incrementa
</button>`,
    ts: `import { Component } from '@angular/core';
@Component({
  selector: 'ca-circular-spinner',
  templateUrl: './circular-spinner.component.html',
  styleUrls: ['./circular-spinner.component.scss']
})
export class CircularSpinnerComponent {
  circularProgress = 0;
  progressIncrement(): void {
    if(this.circularProgress <100) {
      this.circularProgress += 10;
    } else {
      this.circularProgress = 0;
    }
  }
}`
    }
  };

  caseCircularIndeterminate: ComponentDoc = {
    title: `Spinner circular indeterminado`,
    codeExample: {
      html: `<ca-spinner
  type="circular"
  mode="indeterminate"
  title="Inicializando...">
</ca-spinner>`
    }
  };

  caseLoader: ComponentDoc = {
    title: `Loader, esperando la respuesta`,
    codeExample: {
      html: `<div class="ca-loader__backdrop">
  <div class="ca-loader__wrapper d-flex align-items-center">
    <ca-spinner
      class="ca-loader__loader"
      type="circular"
      mode="indeterminate"
      title="Cargando..."
    >
    </ca-spinner>
  </div>
</div>`
    }
  };

  linearProgress = 0;
  circularProgress = 0;

  progressIncrement(): void {
    if(this.linearProgress <100) {
      this.linearProgress += 10;
    } else {
      this.linearProgress = 0;
    }
  }

  progressUp(): void {
    if(this.circularProgress <100) {
      this.circularProgress += 10;
    } else {
      this.circularProgress = 0;
    }
  }

  openLoader() {
    console.log('Open');
    this.loader = true;
    setTimeout(() => {
      this.loader = false;
    }, 5000);
  }
}
