import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckDataServiceView } from './check-data/check-data-service.view';
import { ClientValueServiceView } from './client-value/client-value-service.view';
import { CompaniesServiceView } from './companies/companies-service.view';
import { DocumentTypeServiceView } from './document-type/document-type-service.view';
import { DocumentServiceView } from './document/document-service.view';
import { GlobalPositionServiceView } from './global-position/global-position-service.view';
import { ProvincesServiceView } from './provinces/provinces-service.view';
import { ServicesView } from './services.view';
import { SessionHandlerView } from './session-handler/session-handler.view';
import { SubPlanServiceView } from './sub-plan/sub-plan-service.view';
import { SubmodaServiceView } from './submoda/submoda-service.view';
import { CodPostalServiceView } from './cod-postal/cod-postal-service.view';
import { RamoServiceView } from './ramo/ramo-service.view';
import { MenuApplicationsServiceView } from './menu-applications/menu-applications-service.view';
import { ModaServiceView } from './moda/moda-service.view';
import { PlanServiceView } from './plan/plan-service.view';
import { FondosServiceView } from './fondo/fondo-service.view';
import { SexoServiceView } from './sexo/sexo-service.view';
import { RoadTypeServiceView } from './road-type/road-type-service.view';
import { PopulationServiceView } from './population/population-service.view';

const routes: Routes = [
	{
		path: '',
		component: ServicesView,
		children: [
			{
				path: 'client-value',
				component: ClientValueServiceView
			},
			{
				path: 'companies',
				component: CompaniesServiceView
			},
			{
				path: 'global-position',
				component: GlobalPositionServiceView
			},
			{
				path: 'menu-applications',
				component: MenuApplicationsServiceView
			},
			{
				path: 'provinces',
				component: ProvincesServiceView
			},
			{
				path: 'session-handler',
				component: SessionHandlerView
			},
			{
				path: 'document',
				component: DocumentServiceView
			},
			{
				path: 'document-type',
				component: DocumentTypeServiceView
			},
			{
				path: 'plan',
				component: PlanServiceView
			},
			{
				path: 'ramo',
				component: RamoServiceView
			},
			{
				path: 'moda',
				component: ModaServiceView
			},
			{
				path: 'check-data',
				component: CheckDataServiceView
			},
			{
				path: 'fondo',
				component: FondosServiceView
			},
			{
				path: 'road-type',
				component: RoadTypeServiceView
			},
			{
				path: 'submoda',
				component: SubmodaServiceView
			},
			{
				path: 'sub-plan',
				component: SubPlanServiceView
			},
			{
				path: 'sexo',
				component: SexoServiceView
			},
			{
				path: 'population',
				component: PopulationServiceView
			},
			{
				path: 'cod-postal',
				component: CodPostalServiceView
			}
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class ServicesRoutingModule {}
