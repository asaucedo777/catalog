import { Component, OnInit } from '@angular/core';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
import {
	Province,
	CaSubPlansService,
	SubPlan,
	SubPlansRequest,
	SubPlansResponse
} from '@global-front-components/common';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { SUB_PLANS_RESPONSE_MOCK } from './_mock_/sub-plan-list.response';

@Component({
	templateUrl: 'sub-plan.view.html',
	styleUrls: ['sub-plan.view.scss']
})
export class SubPlanView implements OnInit {
	constructor(private _subPlansService: CaSubPlansService) {}
	subPlans: SubPlan[];
	subPlan: Province;
	subPlanFound: SubPlan;
	selectedSubPlan: SubPlan;
	caseSubPlanSelect: ComponentDoc = {
		title: 'Componente Seleccionable de Sub-Plan de pensión',
		description: `
    `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-select
          placeholder="Seleccione su sub-plan"
          keyValue="descripcion"
          [options]="subPlan"
          [(ngModel)]="selectedSubPlan"
        ></ca-select>
        <pre class="mt-2" *ngIf="selectedSubPlan">
          {{ selectedSubPlan | json }}
        </pre>
      </ca-form-field>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { SubPlan, SubPlansRequest, SubPlansResponse, CaSubPlansService } from '@global-front-components/common';

      @Component({
        selector: 'sub-plan-select-example',
        templateUrl: 'sub-plan-select-example.component.html',
        styleUrls: ['sub-plan-select-example.component.scss']
      })

      export class SubPlanSelectExampleComponent implements OnInit {
        constructor( private _caSubPlansService: CaSubPlansService ) { }

        subPlans: SubPlan[];
        selectedSubPlan: SubPlan;

        ngOnInit() {
          const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
          const request: SubPlansRequest = {
            serviceId: 'ConsultaSubplanesPenSrv',
            inputMap: {
              codPlan: 0,
              codFondo: 0,
            }
          };
          this._caSubPlansService.getSubPlans(endpoint, request).subscribe((response: SubPlansResponse) => {
            this.subPlans = response.outputMap.mapacoddescripcion;
          })
        }
      }`
		}
	};

	codeSubPlanTypeahead: ComponentDoc = {
		title: 'Componente Predictivo de Sub-planes de pensión',
		description: `Hay dos formas de emplear este componente predictivo. Por un lado se puede hacer una única llamada al servicio de sub-planes que nos devuelva toda la lista y filtrar a través del componente,
    o bien, llamar al servicio cada vez que el usuario introduce un valor en el <code class="tag">input</code>.
    <br />
    Primeramente se describe como implementarlo con una única llamada incial.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Sub-Planes de pensión</ca-label>
        <input
          type="text"
          placeholder="Busque un sub-plan"
          [caTypeahead]="search"
          [inputFormatter]="subPlanFormatter"
          [(ngModel)]="subPlan"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="subPlan">
        {{ subPlan | json }}
      </pre>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
      import { SubPlan, SubPlansRequest, SubPlansResponse, CaSubPlansService } from '@global-front-components/common';

      @Component({
        selector: 'sub-plan-typeahead-example',
        templateUrl: 'sub-plan-typeahead-example.component.html',
        styleUrls: ['sub-plan-typeahead-example.component.scss']
      })

      export class SubPlanTypeaheadExampleComponent implements OnInit {
        constructor( private _caSubPlansService: CaSubPlansService ) { }

        subPlans: SubPlan[];
        subPlan: SubPlan;

        subPlanFormatter = (x:{descripcion: string}) => x.descripcion;

        search = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            map(term => term === '' ? []
              : this.subPlans.filter(v => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1))
          )

        ngOnInit() {
          const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
          const request: SubPlansRequest = {
            serviceId: 'ConsultaSubplanesPenSrv',
            inputMap: {
              codPlan: 0,
              codFondo: 0,
            }
          };
          this._caSubPlansService.getSubPlans(endpoint, request).subscribe((response: SubPlansResponse) => {
            this.subPlans = response.outputMap.mapacoddescripcion;
          })
        }
      }`
		}
	};

	codeSubPlanTypeaheadService: ComponentDoc = {
		description: `A continuación se describe como implementarlo con llamadas al servicio cuando el usuario interactúe.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Sub-planes de pensión</ca-label>
        <input
          type="text"
          placeholder="Busque un sub-plan"
          [caTypeahead]="searchSubPlans"
          [inputFormatter]="subPlanFormatter"
          [(ngModel)]="subPlanFound"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="subPlanFound">
        {{ subPlanFound | json }}
      </pre>`,
			ts: `
      import { Component } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
      import { SubPlan, SubPlansRequest, SubPlansResponse, CaSubPlansService } from '@global-front-components/common';

      @Component({
        selector: 'sub-plan-typeahead-example',
        templateUrl: 'sub-plan-typeahead-example.component.html',
        styleUrls: ['sub-plan-typeahead-example.component.scss']
      })

      export class SubPlanTypeaheadExampleComponent {
        constructor( private _caSubPlansService: CaSubPlansService ) { }

        subPlanFound: SubPlan;

        subPlanFormatter = (x:{descripcion: string}) => x.descripcion;

        searchProvinces = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            switchMap(term => {
              const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
              const request: SubPlansRequest = {
                serviceId: 'ConsultaSubplanesPenSrv',
                inputMap: {
                  codPlan: 0,
                  codFondo: 0,
                }
              };
              return this._caSubPlansService.getSubPlans(endpoint, request)
            })
            ).pipe(map((response: SubPlansResponse) => response.outputMap.mapacoddescripcion)
          );
      }`
		}
	};

	subPlanFormatter = (x: { descripcion: string }) => x.descripcion;
	search = (text$: Observable<string>) =>
		text$.pipe(
			debounceTime(300),
			distinctUntilChanged(),
			map((term) =>
				term === '' ? [] : this.subPlans.filter((v) => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1)
			)
		);

	searchSubPlans = (text$: Observable<string>) =>
		text$
			.pipe(
				debounceTime(300),
				distinctUntilChanged(),
				switchMap((term) => {
					const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
					const request: SubPlansRequest = {
						serviceId: 'ConsultaSubplanesPenSrv',
						inputMap: {
							codPlan: 0,
							codFondo: 0
						}
					};
					return combineLatest([this._getSubPlansMock(endpoint, request), of(term)]);
				})
			)
			.pipe(
				map(([response, term]) =>
					term === '' ? [] : this.subPlans.filter((v) => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1)
				)
			);

	private _getSubPlansMock(endpoint: string, request: SubPlansRequest): Observable<SubPlansResponse> {
		return this._subPlansService.getSubPlans(endpoint, request).pipe(
			catchError(() => {
				return of(<SubPlansResponse>SUB_PLANS_RESPONSE_MOCK);
			})
		);
	}

	ngOnInit() {
		const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
		const request: SubPlansRequest = {
			serviceId: 'ConsultaSubplanesPenSrv',
			inputMap: {
				codPlan: 0,
				codFondo: 0
			}
		};
		this._getSubPlansMock(endpoint, request).subscribe((response: SubPlansResponse) => {
			this.subPlans = response.outputMap.mapacoddescripcion;
		});
	}
}
