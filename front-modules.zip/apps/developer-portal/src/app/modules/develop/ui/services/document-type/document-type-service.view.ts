import { Component } from "@angular/core";

@Component({
    templateUrl: 'document-type-service.view.html',
    styleUrls: ['document-type-service.view.scss']
  })
  export class DocumentTypeServiceView {

    moduleContent = `
    import { CaDocumentTypeService } from '@global-front-components/common';
    import { HttpClientModule } from '@angular/common/http';
  
    @NgModule({
        ...
      imports: [
        ...
        HttpClientModule,
        ...
      ],
      providers: [ CaDocumentTypeService ],
      ...
    })`;
  }