import { Component } from '@angular/core';

@Component({
	templateUrl: 'moda-service.view.html',
	styleUrls: ['moda-service.view.scss']
})
export class ModaServiceView {
	moduleContent = `
  import { CaModasService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaModasService ],
    ...
  })`;
}
