import { Component, Input } from '@angular/core';
import { CaModalOverlayRef } from '@global-front-components/ui';

@Component({
  selector: 'modal-example',
  templateUrl: 'modal-example.component.html',
  styleUrls: ['modal-example.component.scss']
})
export class ModalTableExampleComponent {
  constructor(private _modalRef: CaModalOverlayRef<ModalTableExampleComponent>) {}

  @Input() data: any;
}
