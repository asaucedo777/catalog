import { Component, ChangeDetectorRef } from '@angular/core';
import { CaModalOverlayRef } from '@global-front-components/ui';
import { CaFilterPipe } from '@global-front-components/common';
import { BehaviorSubject, Subject } from 'rxjs';
import { debounceTime, takeUntil } from 'rxjs/operators';

interface TableColumn {
  id: number;
  field: string;
  value: string;
}

@Component({
	templateUrl: './salud-modal.component.html',
	styleUrls: ['./salud-modal.component.scss'],
  providers: [ CaFilterPipe ]
})
export class SaludModalComponent {
	constructor(
    private _caModalOverlayRef: CaModalOverlayRef<SaludModalComponent>,
    private _caFilterPipe: CaFilterPipe,
    private _changeDetectorRef: ChangeDetectorRef
  ) {}

  private _destroy$: Subject<void> = new Subject();
  private _filterChange$: BehaviorSubject<string> = new BehaviorSubject(undefined);
  displayedColumns: string[] = [];
  displayedTableData: any[] = [];
  queryFilter = '';
  selectedRow: any;
  columns: TableColumn[] = [
    {
      id: 0,
      field: 'selectable',
      value: ''
    },
    {
      id: 0,
      field: 'policyNumber',
      value: 'Número de Póliza'
    },
    {
      id: 1,
      field: 'name',
      value: 'Nombre'
    }
  ];

  tableData = [
    {
      policyNumber: 33300100,
      name: 'M.P.C.G.A. DE VALENCIA'
    },
    {
      policyNumber: 44400100,
      name: 'M.P.C.G.A. DE MINGLANILLA'
    },
    {
      policyNumber: 55500100,
      name: 'M.P.C.G.A. DE BILBAO'
    },
    {
      policyNumber: 66600100,
      name: 'M.P.C.G.A. DE AILEO'
    }
  ];

  private _setDisplayedColumns(): void {
    this.displayedColumns = this.columns.map((column) => column.field);
  }

  isSelectedRow(row): boolean {
    return this.selectedRow && Object.keys(this.selectedRow).every((key) => this.selectedRow[key] === row[key]);
  }

  onSelectedRow(row: any): void {
    if (!this.isSelectedRow(row)) {
      this.selectedRow = row;
    }
  }

  onFilter(query: string): void {
    this._filterChange$.next(query);
  }

	closeDialog(): void {
		this._caModalOverlayRef.close(this.selectedRow);
	}

  ngOnInit() {
    this._setDisplayedColumns();
    this.displayedTableData= this.tableData;
    this._filterChange$.pipe(takeUntil(this._destroy$),debounceTime(200)).subscribe((value) => {
      this.displayedTableData = this._caFilterPipe.transform(this.tableData, value);
      this._changeDetectorRef.markForCheck();
    })
  }

  ngOnDestroy() {
    this._destroy$.next();
    this._destroy$.complete();
  }
}
