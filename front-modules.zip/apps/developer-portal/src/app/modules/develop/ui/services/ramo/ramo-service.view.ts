import { Component } from '@angular/core';

@Component({
	templateUrl: 'ramo-service.view.html',
	styleUrls: ['ramo-service.view.scss']
})
export class RamoServiceView {
	moduleContent = `
  import { CaRamosService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaRamosService ],
    ...
  })`;
}
