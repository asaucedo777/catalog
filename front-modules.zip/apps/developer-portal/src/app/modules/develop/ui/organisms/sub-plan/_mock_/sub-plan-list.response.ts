import { SubPlansResponse } from "@global-front-components/common";

export const SUB_PLANS_RESPONSE_MOCK: SubPlansResponse = {
  "serviceId": "ConsultaSubplanesPenSrv",
  "outputMap": {
      "mapacoddescripcion": [
          {
              "codigo": "0",
              "descripcion": "prueba1"
          },
          {
              "codigo": "0",
              "descripcion": "prueba2"
          },
          {
              "codigo": "0",
              "descripcion": "prueba3"
          }
      ]
  }
}
