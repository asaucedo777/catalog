import { Component, OnInit } from '@angular/core';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, map, switchMap, tap } from 'rxjs/operators';
import {
	CodPostalesRequest,
	CodPostalesResponse,
	CaCodPostalesService,
	CodPostalData
} from '@global-front-components/common';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { COD_POSTALES_RESPONSE_MOCK } from './_mock_/cos-postales-list.response';

@Component({
	templateUrl: 'cod-postal.view.html',
	styleUrls: ['cod-postal.view.scss']
})
export class CodPostalView implements OnInit {
	constructor(private _CaCodPostalesService: CaCodPostalesService) {}
	codPostales: CodPostalData[];
	codPostalFound: CodPostalData;


	codeCodPostalesTypeaheadService: ComponentDoc = {
		description: `A continuación se describe como implementarlo con llamadas al servicio cuando el usuario interactúe.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Codigo Postal</ca-label>
        <input
          type="text"
          placeholder="Busque un codigo postal"
          [caTypeahead]="searchCodPostales"
          [inputFormatter]="codPostalFormatter"
          [(ngModel)]="codPostalFound"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="codPostalFound">
        {{ codPostalFound | json }}
      </pre>`,
			ts: `
      import { Component } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
      import { CodPostal, CodPostalesRequest, CodPostalesResponse, CaCodPostalesService } from '@global-front-components/common';

      @Component({
        selector: 'cod-postal-typeahead-example',
        templateUrl: 'cod-postal-typeahead-example.component.html',
        styleUrls: ['cod-postal-typeahead-example.component.scss']
      })

      export class CodPostalTypeaheadExampleComponent {
        constructor( private _caCodPostalesService: CaCodPostalesService ) { }

        codPostalFound: CodPostalData;

        codPostalFormatter = (x:{cpostal: string}) => x.cpostal;

        searchCodPostales = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            switchMap(term => {
              const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
              const request: CodPostalesRequest = {
                serviceId: 'BuscarLocalidadPorCodigoPostalSRV',
                inputMap: {
                  codigoPostal: term,
                  usuario: 'BDI',
                  aplicacion: 'BDI'
                }
              };
              return this._caCodPostalesService.getCodPostales(endpoint, request)
            })
            ).pipe(map((response: CodPostalesResponse) => response.outputMap.Lista)
          );
      }`
		}
	};

	codPostalFormatter = (x: { cpostal: string }) => x.cpostal;

	searchCodPostales = (text$: Observable<string>) =>
		text$
			.pipe(
				debounceTime(300),
				distinctUntilChanged(),
				switchMap((term) => {
					const endpoint: string = '/apibdihttpchannel/bindJSONServlet-';
					const request: CodPostalesRequest = {
						serviceId: 'BuscarLocalidadPorCodigoPostalSRV',
						inputMap: {
							codigoPostal: term,
							usuario: 'BDI',
							aplicacion: 'BDI'
						}
					};
					return combineLatest([this._getCodPostalesMock(endpoint, request), of(term)]);
				})
			)
			.pipe(
				map(([response, term]) =>
					term === '' ? [] : this.codPostales.filter((v) => v.cpostal.toLowerCase().indexOf(term.toLowerCase()) > -1)
				)
			);

	private _getCodPostalesMock(endpoint: string, request: CodPostalesRequest): Observable<CodPostalesResponse> {
		return this._CaCodPostalesService.getCodPostales(endpoint, request).pipe(
			tap((resp) => console.log('---')),
			catchError(() => {
				return of(<CodPostalesResponse>COD_POSTALES_RESPONSE_MOCK);
			})
		);
	}

	ngOnInit() {
		const endpoint: string = '/apibdihttpchannel/bindJSONServlet-';
		const request: CodPostalesRequest = {
			serviceId: 'BuscarLocalidadPorCodigoPostalSRV',
			inputMap: {
				codigoPostal: '%',
				usuario: 'BDI',
				aplicacion: 'BDI'
			}
		};
		this._getCodPostalesMock(endpoint, request).subscribe((response: CodPostalesResponse) => {
			this.codPostales = response.outputMap.Lista;
		});
	}
}
