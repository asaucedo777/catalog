import { Component } from "@angular/core";

@Component({
  templateUrl: "population-service.view.html",
  styleUrls: ["population-service.view.scss"],
})
export class PopulationServiceView {
  moduleContent = `
  import { CaPopulationService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaPopulationService ],
    ...
  })`;
}
