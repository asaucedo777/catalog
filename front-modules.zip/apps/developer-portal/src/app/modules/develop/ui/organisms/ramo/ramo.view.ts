import { Component, OnInit } from '@angular/core';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
import {
	CaProvincesService,
	Province,
	CaRamosService,
  Ramo,
  RamosRequest,
  RamosResponse,
} from '@global-front-components/common';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { RAMOS_RESPONSE_MOCK } from './_mock_/ramo-list.response';

@Component({
	templateUrl: 'ramo.view.html',
	styleUrls: ['ramo.view.scss']
})
export class RamoView implements OnInit {
	constructor(private _ramosService: CaRamosService, private _CaProvincesService: CaProvincesService) {}
	ramos: Ramo[];
	ramo: Province;
	ramoFound: Ramo;
	selectedRamo: Ramo;
	caseRamoSelect: ComponentDoc = {
		title: 'Componente Seleccionable de Ramo',
		description: `
    `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-select
          placeholder="Seleccione su ramo"
          keyValue="descripcion"
          [options]="ramos"
          [(ngModel)]="selectedRamo"
        ></ca-select>
        <pre class="mt-2" *ngIf="selectedRamo">
          {{ selectedRamo | json }}
        </pre>
      </ca-form-field>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { Ramo, RamosRequest, RamosResponse, CaRamosService } from '@global-front-components/common';

      @Component({
        selector: 'ramo-select-example',
        templateUrl: 'ramo-select-example.component.html',
        styleUrls: ['ramo-select-example.component.scss']
      })

      export class RamoSelectExampleComponent implements OnInit {
        constructor( private _caRamosService: CaRamosService ) { }

        companies: Ramo[];
        selectedRamo: Ramo;

        ngOnInit() {
          const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
          const request: RamosRequest = {
            serviceId: 'ConsultaRamosSrv',
            inputMap: {
              codCia: '0001', // procedente de CaCompaniesService
            }
          }
          this._caRamosService.getRamos(endpoint, request).subscribe((response: RamosResponse) => {
            this.ramos = response.outputMap.mapacoddescripcion;
          })
        }
      }`
		}
	};

	codeRamoTypeahead: ComponentDoc = {
		title: 'Componente Predictivo de Ramos',
		description: `Hay dos formas de emplear este componente predictivo. Por un lado se puede hacer una única llamada al servicio de ramos que nos devuelva toda la lista y filtrar a través del componente,
    o bien, llamar al servicio cada vez que el usuario introduce un valor en el <code class="tag">input</code>.
    <br />
    Primeramente se describe como implementarlo con una única llamada incial.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Ramos</ca-label>
        <input
          type="text"
          placeholder="Busque un ramo"
          [caTypeahead]="search"
          [inputFormatter]="ramoFormatter"
          [(ngModel)]="ramo"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="ramo">
        {{ ramo | json }}
      </pre>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
      import { Ramo, RamosRequest, RamosResponse, CaRamosService } from '@global-front-components/common';

      @Component({
        selector: 'ramo-typeahead-example',
        templateUrl: 'ramo-typeahead-example.component.html',
        styleUrls: ['ramo-typeahead-example.component.scss']
      })

      export class RamoTypeaheadExampleComponent implements OnInit {
        constructor( private _caRamosService: CaRamosService ) { }

        ramos: Ramo[];
        ramo: Ramo;

        ramoFormatter = (x:{descripcion: string}) => x.descripcion;

        search = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            map(term => term === '' ? []
              : this.ramos.filter(v => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1))
          )

        ngOnInit() {
          const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
          const request: RamosRequest = {
            serviceId: 'ConsultaRamosSrv',
            inputMap: {
              codCia: '0001', // procedente de CaCompaniesService
            }
          }
          this._caRamosService.getRamos(endpoint, request).subscribe((response: RamosResponse) => {
            this.ramos = response.outputMap.mapacoddescripcion;
          })
        }
      }`
		}
	};

	codeRamoTypeaheadService: ComponentDoc = {
		description: `A continuación se describe como implementarlo con llamadas al servicio cuando el usuario interactúe.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Ramo</ca-label>
        <input
          type="text"
          placeholder="Busque un ramo"
          [caTypeahead]="searchRamos"
          [inputFormatter]="ramoFormatter"
          [(ngModel)]="ramoFound"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="ramoFound">
        {{ ramoFound | json }}
      </pre>`,
			ts: `
      import { Component } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
      import { Ramo, RamosRequest, RamosResponse, CaRamosService } from '@global-front-components/common';

      @Component({
        selector: 'ramo-typeahead-example',
        templateUrl: 'ramo-typeahead-example.component.html',
        styleUrls: ['ramo-typeahead-example.component.scss']
      })

      export class RamoTypeaheadExampleComponent {
        constructor( private _caRamosService: CaRamosService ) { }

        ramoFound: Ramo;

        ramoFormatter = (x:{descripcion: string}) => x.descripcion;

        searchProvinces = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            switchMap(term => {
              const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
              const request: RamosRequest = {
                serviceId: 'ConsultaRamosSrv',
                inputMap: {
                  codCia: '0001', // procedente de CaCompaniesService
                }
              };
              return this._caRamosService.getRamos(endpoint, request)
            })
            ).pipe(map((response: RamosResponse) => response.outputMap.mapacoddescripcion)
          );
      }`
		}
	};

	ramoFormatter = (x: { descripcion: string }) => x.descripcion;
	search = (text$: Observable<string>) =>
		text$.pipe(
			debounceTime(300),
			distinctUntilChanged(),
			map((term) =>
				term === '' ? [] : this.ramos.filter((v) => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1)
			)
		);

	searchRamos = (text$: Observable<string>) =>
		text$
			.pipe(
				debounceTime(300),
				distinctUntilChanged(),
				switchMap((term) => {
					const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
					const request: RamosRequest = {
						serviceId: 'ConsultaRamosSrv',
						inputMap: {
							codCia: '0001'
						}
					};
					return combineLatest([this._getRamosMock(endpoint, request), of(term)]);
				})
			)
			.pipe(
				map(([response, term]) =>
					term === '' ? [] : this.ramos.filter((v) => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1)
				)
			);

	private _getRamosMock(endpoint: string, request: RamosRequest): Observable<RamosResponse> {
		return this._ramosService.getRamos(endpoint, request).pipe(
			catchError(() => {
				return of(<RamosResponse>RAMOS_RESPONSE_MOCK);
			})
		);
	}

	ngOnInit() {
		const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
		const request: RamosRequest = {
			serviceId: 'ConsultaRamosSrv',
			inputMap: {
				codCia: '0001'
			}
		};
		this._getRamosMock(endpoint, request).subscribe((response: RamosResponse) => {
			this.ramos = response.outputMap.mapacoddescripcion;
		});
	}
}
