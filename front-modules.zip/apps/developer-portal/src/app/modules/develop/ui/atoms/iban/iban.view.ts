import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
	templateUrl: 'iban.view.html',
	styleUrls: ['iban.view.scss']
})
export class IbanView implements OnInit {
	constructor(private formBuilder: FormBuilder) {}

	public form: FormGroup;

	ngOnInit(): void {

		this.form = this.formBuilder.group({
			iban: ''
		});

    this.form.get('iban').valueChanges.subscribe(value => console.log('formulario: ', value))
	}
}
