import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormsModule,
  ReactiveFormsModule
} from '@angular/forms';
import { CdkTableModule } from '@angular/cdk/table';
import {
  CaButtonModule,
  CaFormFieldModule,
  CaInputModule,
  CaRadioButtonModule,
  CaSelectModule,
  CaTypeaheadModule
} from '@global-front-components/ui';
import { CaInputModalFilterModule, CaSelectModalFilterModule, CaProtocoloModule } from '@global-front-components/salud';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SaludRoutingModule } from './salud-routing.module';
import { SaludView } from './salud.view';
import { ProtocoloViewComponent } from './protocolo/protocolo.view';
import { COMPONENTS } from './components';
import { ComponentDocModule } from '../../../../components/component-doc/component-doc.module';


@NgModule({
  declarations: [
    ...COMPONENTS,
    ProtocoloViewComponent,
    SaludView
  ],
  imports: [
    CaButtonModule,
    CaFormFieldModule,
    CaInputModalFilterModule,
    CaInputModule,
    CaProtocoloModule,
    CaRadioButtonModule,
    CdkTableModule,
    CommonModule,
    ComponentDocModule,
    FormsModule,
    NgbModule,
    ReactiveFormsModule,
    SaludRoutingModule,
    CaSelectModalFilterModule,
    CaSelectModule,
    CaTypeaheadModule
  ]
})
export class SaludModule { }
