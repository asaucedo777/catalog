import { Component } from '@angular/core';

@Component({
	templateUrl: 'sexo-service.view.html',
	styleUrls: ['sexo-service.view.scss']
})
export class SexoServiceView {
	moduleContent = `
  import { CaSexoService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaSexoService ],
    ...
  })`;
}
