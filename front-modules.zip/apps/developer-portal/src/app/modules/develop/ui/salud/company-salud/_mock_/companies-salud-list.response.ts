import { CompaniesSaludResponse } from '@global-front-components/salud';

export const COMPANIES_SALUD_RESPONSE_MOCK: CompaniesSaludResponse  = {
  "links": [],
  "_embedded":{
      "companies": [
        {
          "cod": "0001",
          "descCorta": "CASER S.A."
        },
        {
          "cod": "0033",
          "descCorta": "CAJASOL SEGUROS"
        },
        {
          "cod": "0027",
          "descCorta": "MEDITERRANEO SEGUROS DIV."
        }
      ]
  },
  "_response": {
      "status": 200,
      "timestamp": {
          "init": "2021-09-30T12:12:00.364+02:00",
          "end": "2021-09-30T12:12:00.364+02:00"
      },
      "duration": 1,
      "path": "/OpcionesEscritorioSrv",
      "api": "http://examplemock.com",
      "version": "1.0-SNAPSHOT",
      "server": "lint-springboot01.caser.local:32040",
      "environment": "local",
      "trace_id": "52dc13ff65",
      "span_id": "52dc13ff65"
  }
}
