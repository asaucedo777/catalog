import { Component } from '@angular/core';

@Component({
  templateUrl: 'molecules.view.html',
  styleUrls: ['molecules.view.scss']
})
export class MoleculesView {}
