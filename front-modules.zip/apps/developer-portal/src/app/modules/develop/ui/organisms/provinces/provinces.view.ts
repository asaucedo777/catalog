import { Component, OnInit } from '@angular/core';
import {
  combineLatest,
  Observable,
  of
} from 'rxjs';
import {
  catchError,
  debounceTime,
  distinctUntilChanged,
  map,
  switchMap
} from 'rxjs/operators';
import {
  ProvincesRequest,
  ProvincesResponse,
  CaProvincesService,
  Province
} from '@global-front-components/common';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { PROVINCES_RESPONSE_MOCK } from './_mock_/provinces-list.response';

@Component({
  templateUrl: 'provinces.view.html',
  styleUrls: ['provinces.view.scss']
})

export class ProvincesView implements OnInit {
  constructor(
    private _CaProvincesService: CaProvincesService
  ) { }
  provinces: Province[];
  province: Province;
  provinceFound: Province;
  selectedProvince: Province;

  caseProvincesSelect: ComponentDoc = {
    title: 'Componente Seleccionable de Provincias',
    description: `
    `,
    codeExample: {
      html: `
      <ca-form-field>
        <ca-select
          placeholder="Seleccione su provincia"
          keyValue="tdescripcion"
          [options]="provinces"
          [(ngModel)]="selectedProvince"
        ></ca-select>
        <pre class="mt-2" *ngIf="selectedProvince">
          {{ selectedProvince | json }}
        </pre>
      </ca-form-field>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { Province, ProvincesRequest, ProvincesResponse, CaProvincesService } from '@global-front-components/common';

      @Component({
        selector: 'province-select-example',
        templateUrl: 'province-select-example.component.html',
        styleUrls: ['province-select-example.component.scss']
      })

      export class ProvinceSelectExampleComponent implements OnInit {
        constructor( private _caProvincesService: CaProvincesService ) { }

        companies: Province[];
        selectedProvince: Province;

        ngOnInit() {
          const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
          const request: ProvincesRequest = {
            serviceId: 'BuscarProvinciaPorNombreSRV',
            inputMap: {
              descripcionProvincia: '%%',
              aplicacion: 'AquiIraSuAplicacion',
              usuario: 'UsuarioLogado'
            }
          }
          this._caProvincesService.getProvinces(endpoint, request).subscribe((response: ProvincesResponse) => {
            this.provinces = response.outputMap.provincias;
          })
        }
      }`
    }
  }

  codeProvincesTypeahead: ComponentDoc = {
    title: 'Componente Predictivo de provincias',
    description: `Hay dos formas de emplear este componente predictivo. Por un lado se puede hacer una única llamada al servicio de provincias que nos devuelva toda la lista y filtrar a través del componente,
    o bien, llamar al servicio cada vez que el usuario introduce un valor en el <code class="tag">input</code>.
    <br />
    Primeramente se describe como implementarlo con una única llamada incial.`,
    codeExample: {
      html: `
      <ca-form-field>
        <ca-label>Provincia</ca-label>
        <input
          type="text"
          placeholder="Busque una provincia"
          [caTypeahead]="search"
          [inputFormatter]="provinceFormatter"
          [(ngModel)]="province"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="province">
        {{ province | json }}
      </pre>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
      import { Province, ProvincesRequest, ProvincesResponse, CaProvincesService } from '@global-front-components/common';

      @Component({
        selector: 'province-typeahead-example',
        templateUrl: 'province-typeahead-example.component.html',
        styleUrls: ['province-typeahead-example.component.scss']
      })

      export class ProvinceTypeaheadExampleComponent implements OnInit {
        constructor( private _caProvincesService: CaProvincesService ) { }

        provinces: Province[];
        province: Province;

        provinceFormatter = (x:{tdescripcion: string}) => x.tdescripcion;

        search = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            map(term => term === '' ? []
              : this.provinces.filter(v => v.tdescripcion.toLowerCase().indexOf(term.toLowerCase()) > -1))
          )

        ngOnInit() {
          const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
          const request: ProvincesRequest = {
            serviceId: 'BuscarProvinciaPorNombreSRV',
            inputMap: {
              descripcionProvincia: '%%',
              aplicacion: 'AquiIraSuAplicacion',
              usuario: 'UsuarioLogado'
            }
          }
          this._caProvincesService.getProvinces(endpoint, request).subscribe((response: ProvincesResponse) => {
            this.provinces = response.outputMap.provincias;
          })
        }
      }`

    }
  }

  codeProvincesTypeaheadService: ComponentDoc = {
    description: `A continuación se describe como implementarlo con llamadas al servicio cuando el usuario interactúe.`,
    codeExample: {
      html: `
      <ca-form-field>
        <ca-label>Provincia</ca-label>
        <input
          type="text"
          placeholder="Busque una provincia"
          [caTypeahead]="searchProvinces"
          [inputFormatter]="provinceFormatter"
          [(ngModel)]="provinceFound"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="provinceFound">
        {{ provinceFound | json }}
      </pre>`,
      ts: `
      import { Component } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
      import { Province, ProvincesRequest, ProvincesResponse, CaProvincesService } from '@global-front-components/common';

      @Component({
        selector: 'province-typeahead-example',
        templateUrl: 'province-typeahead-example.component.html',
        styleUrls: ['province-typeahead-example.component.scss']
      })

      export class ProvinceTypeaheadExampleComponent {
        constructor( private _caProvincesService: CaProvincesService ) { }

        provinceFound: Province;

        provinceFormatter = (x:{denCia: string}) => x.denCia;

        searchProvinces = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            switchMap(term => {
              const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
              const request: ProvincesRequest = {
                serviceId: 'BuscarProvinciaPorNombreSRV',
                inputMap: {
                  descripcionProvincia: '%'+term.toUpperCase()+'%',
                  aplicacion: 'AquiIraSuAplicacion',
                  usuario: 'UsuarioLogado'
                }
              }
              return this._caProvincesService.getProvinces(endpoint, request)
            })
            ).pipe(map((response: ProvincesResponse) => response.outputMap.provincias)
          );
      }`
    }
  }

  provinceFormatter = (x:{tdescripcion: string}) => x.tdescripcion;

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      map(term => term === '' ? []
        : this.provinces.filter(v => v.tdescripcion.toLowerCase().indexOf(term.toLowerCase()) > -1))
    )

  searchProvinces = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      switchMap(term => {
        const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
        const request: ProvincesRequest = {
          serviceId: 'BuscarProvinciaPorNombreSRV',
          inputMap: {
            descripcionProvincia: `%${term.toUpperCase()}%`,
            aplicacion: 'AquiIraSuAplicacion',
            usuario: 'UsuarioLogado'
          }
        }
        return combineLatest([this._getProvincesMock(endpoint, request), of(term)])
       })
      )
      .pipe(map(([response, term]) => term === '' ? []
          : this.provinces.filter(v => v.tdescripcion.toLowerCase().indexOf(term.toLowerCase()) > -1))
      );

  private _getProvincesMock(endpoint: string, request: ProvincesRequest): Observable<ProvincesResponse> {
    return this._CaProvincesService.getProvinces(endpoint, request).pipe(catchError(() => {
      return of (<ProvincesResponse>PROVINCES_RESPONSE_MOCK);
    }))
  }

  ngOnInit() {
    const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
    const request: ProvincesRequest = {
      serviceId: 'BuscarProvinciaPorNombreSRV',
      inputMap: {
        descripcionProvincia: '%%',
        aplicacion: 'AquiIraSuAplicacion',
        usuario: 'UsuarioLogado'
      }
    }
    this._getProvincesMock(endpoint, request).subscribe((response: ProvincesResponse) => {
      this.provinces = response.outputMap.provincias;
    })
  }
}
