import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CaDocumentService } from '@global-front-components/common';
import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';
import { DocumentOuputMap, DocumentRequest, DocumentResponse } from 'libs/common/src/lib/models/document.interface';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { DOCUMENT_RESPONSE_MOCK, INVALID_DOCUMENT_RESPONSE_MOCK } from './_mock/document.response';

@Component({
	templateUrl: 'document.view.html',
	styleUrls: ['document.view.scss']
})
export class DocumentView implements OnInit {
	constructor(private _CaDocumentService: CaDocumentService, private _formBuilder: FormBuilder) {}
	form: FormGroup;
	formInvalid: FormGroup;
	document: DocumentOuputMap;
	documentType = '';
	text: any = [];
	number: any = [];
	desError: string;

	caseSimple: ComponentDoc = {
		title: 'Organismo Documento',
		description: `
        `,
		codeExample: {
			html: `
                <form [formGroup]="form">
                <div class="d-flex align-items-end">
                    <div class="d-flex form__container mr-5">
                        <div class="form__input">
                            <ca-form-field>
                                <ca-label>Documento</ca-label>
                                <input type="text" caInput required formControlName="documento" />
                                <ca-error *ngIf="form.get('documento').errors?.required">Campo obligatorio </ca-error>
                            </ca-form-field>
                        </div>
                        
                    </div>
                    <button
                            class="form__button"
                            ca-button
                            [disabled]="form.invalid"
                            (click)="getNormalizedDocument(form.get('documento').value)"
                        >
                            <span>Normalizar</span>
                        </button>
                </div>
            </form>`,
			ts: `
            import { Component, OnInit } from '@angular/core';
            import { FormBuilder, FormGroup, Validators } from '@angular/forms';
            import { CaDocumentService } from '@global-front-components/common';
            import { DocumentOuputMap, DocumentRequest, DocumentResponse } from 'libs/common/src/lib/models/document.interface';
      
            @Component({
              templateUrl: 'document.view.html',
              styleUrls: ['document.view.scss']
            })
            export class DocumentView implements OnInit {

                constructor(
                    private _CaDocumentService: CaDocumentService,
                    private _formBuilder: FormBuilder
                ) { }

                form: FormGroup;
                document: DocumentOuputMap;
                documentType = '';
                text : any = [];
                number : any = [];

                                
                getNormalizedDocument(document: string): void {
                    this.checkInputField(document);
                    this.getDocument(this.documentType, this.text[0], this.number[0]);
                }
            
              
                checkInputField(document: string) {
                    this.documentType = '4';
                    if (this.documentType == '1' || this.documentType == '3' || this.documentType == '5' || this.documentType == '6') {
                        this.parseInputData(document);
                    } else {
                        this.text[0] = document;
                        this.number[0] = '';
                    }
                }

                getDocument(type: string, char: string, number: string) {
                    const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
                    const request: DocumentRequest = {
                        serviceId: 'NormalizarDocumento',
                        inputMap: {
                            tipoDocumento: type,
                            letra: char,
                            numero: number
                        }
                    };
                    this._getNormalizedDocument(endpoint, request).subscribe((response: DocumentResponse) => {
                        this.document = response.outputMap;
                        if (response.outputMap.codigoError == -19) {
                            this.form.get('documento').setValue(this.document.numeroNormalizado + this.document.letraNormalizado);
                            this.form.updateValueAndValidity();
                        }
                    });
                }
            
                parseInputData(document: string){
                    this.text = document.match(/[a-zA-Z]+/g);
                    this.number = document.match(/\d+/g);
                }
        
                ngOnInit() {
                    this.form = this._formBuilder.group({
                        documento: ['', [Validators.required]]
                    });
                 
                }
            }
                  
          }`
		}
	};

	caseError: ComponentDoc = {
		title: 'Organismo Documento No Válido',
		description: `En el caso de que el usuario introduzca un documento no válido (por tipo o por contenido), se gestiona el error a través de un mensaje de error obtenido en el campo <code class="attribute">desError</code>
        de la llamada al servicio CaDocumentService.
        <br />
        `,
		codeExample: {
			html: `
            <form [formGroup]="formInvalid">
            <div class="d-flex align-items-end">
                <div class="d-flex form__container mr-5">
                    <div class="form__input">
                        <ca-form-field>
                            <ca-label>Documento</ca-label>
                            <input type="text" caInput required formControlName="documento" />
                            <ca-error *ngIf="formInvalid.get('documento').errors?.required">Campo obligatorio </ca-error>
                        </ca-form-field>
                    </div>
                </div>
                <button
                    class="form__button"
                    ca-button
                    [disabled]="formInvalid.invalid"
                    (click)="getNormalizedDocumentWithValidation(formInvalid.get('documento').value)"
                >
                    <span>Normalizar</span>
                </button>
            </div>
            <p class="error-input" *ngIf="desError.length">{{desError}}</p>
        </form>`,
			ts: `
            import { Component, OnInit } from '@angular/core';
            import { FormBuilder, FormGroup, Validators } from '@angular/forms';
            import { CaDocumentService } from '@global-front-components/common';
            import { DocumentOuputMap, DocumentRequest, DocumentResponse } from 'libs/common/src/lib/models/document.interface';
      
            @Component({
              templateUrl: 'document.view.html',
              styleUrls: ['document.view.scss']
            })
            export class DocumentView implements OnInit {

                constructor(
                    private _CaDocumentService: CaDocumentService,
                    private _formBuilder: FormBuilder
                ) { }

                Invalidform: FormGroup;
                document: DocumentOuputMap;
                documentType = '';
                text : any = [];
                number : any = [];
                desError : string;

                getNormalizedDocumentWithValidation(document: string): void {
                    this.checkInputField(document);
                    this.getDocumentWithValidation(this.documentType, this.text[0], this.number[0]);
                }
            
                checkInputField(document: string) {
                    this.documentType = '4';
                    if (this.documentType == '1' || this.documentType == '3' || this.documentType == '5' || this.documentType == '6') {
                        this.parseInputData(document);
                    } else {
                        this.text[0] = document;
                        this.number[0] = '';
                    }
                }

                getDocumentWithValidation(type: string, char: string, number: string) {
                    const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
                    const request: DocumentRequest = {
                        serviceId: 'NormalizarDocumento',
                        inputMap: {
                            tipoDocumento: type,
                            letra: char,
                            numero: number
                        }
                    };
                    this._getNormalizedDocumentWithValidation(endpoint, request).subscribe((response: DocumentResponse) => {
                        this.document = response.outputMap;
                        if (response.outputMap.codigoError != -19) {
                            this.desError = response.outputMap.desError;
                        } else {
                            this.form.get('documento').setValue(this.document.numeroNormalizado + this.document.letraNormalizado);
                            this.form.updateValueAndValidity();
                        }
                    });
                }
                                
               
                parseInputData(document: string){
                    this.text = document.match(/[a-zA-Z]+/g);
                    this.number = document.match(/\d+/g);
                }
        
                ngOnInit() {
                    this.formInvalid = this._formBuilder.group({
                        documento: ['', [Validators.required]]
                    });
                    this.desError = '';
                }
            }
                  
          }`,
			css: `
          form{
            .error-input {
                margin-top: .3125rem;
                color: red;
            }
        }`
		}
	};

	getNormalizedDocument(document: string): void {
		this.checkInputField(document);
		this.getDocument(this.documentType, this.text[0], this.number[0]);
	}

	getNormalizedDocumentWithValidation(document: string): void {
		this.checkInputField(document);
		this.getDocumentWithValidation(this.documentType, this.text[0], this.number[0]);
	}

	checkInputField(document: string) {
		this.documentType = '4';
		if (this.documentType == '1' || this.documentType == '3' || this.documentType == '5' || this.documentType == '6') {
			this.parseInputData(document);
		} else {
			this.text[0] = document;
			this.number[0] = '';
		}
	}

	getDocument(type: string, char: string, number: string) {
		const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
		const request: DocumentRequest = {
			serviceId: 'NormalizarDocumento',
			inputMap: {
				tipoDocumento: type,
				letra: char,
				numero: number
			}
		};
		this._getNormalizedDocument(endpoint, request).subscribe((response: DocumentResponse) => {
			this.document = response.outputMap;
			if (response.outputMap.codigoError == -19) {
				this.form.get('documento').setValue(this.document.numeroNormalizado + this.document.letraNormalizado);
				this.form.updateValueAndValidity();
			}
		});
	}

	getDocumentWithValidation(type: string, char: string, number: string) {
		const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
		const request: DocumentRequest = {
			serviceId: 'NormalizarDocumento',
			inputMap: {
				tipoDocumento: type,
				letra: char,
				numero: number
			}
		};
		this._getNormalizedDocumentWithValidation(endpoint, request).subscribe((response: DocumentResponse) => {
			this.document = response.outputMap;
			if (response.outputMap.codigoError != -19) {
				this.desError = response.outputMap.desError;
			} else {
				this.form.get('documento').setValue(this.document.numeroNormalizado + this.document.letraNormalizado);
				this.form.updateValueAndValidity();
			}
		});
	}

	parseInputData(document: string) {
		this.text = document.match(/[a-zA-Z]+/g);
		this.number = document.match(/\d+/g);
	}

	private _getNormalizedDocument(endpoint: string, request: DocumentRequest): Observable<DocumentResponse> {
		return this._CaDocumentService.getDocument(endpoint, request).pipe(
			catchError(() => {
				return of(<DocumentResponse>DOCUMENT_RESPONSE_MOCK);
			})
		);
	}

	private _getNormalizedDocumentWithValidation(
		endpoint: string,
		request: DocumentRequest
	): Observable<DocumentResponse> {
		return this._CaDocumentService.getDocument(endpoint, request).pipe(
			catchError(() => {
				return of(<DocumentResponse>INVALID_DOCUMENT_RESPONSE_MOCK);
			})
		);
	}

	ngOnInit() {
		this.form = this._formBuilder.group({
			documento: ['', [Validators.required]]
		});
		this.formInvalid = this._formBuilder.group({
			documento: ['', [Validators.required]]
		});
		this.desError = '';
	}
}
