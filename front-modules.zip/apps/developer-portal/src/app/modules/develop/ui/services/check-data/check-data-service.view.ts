import { Component } from '@angular/core';

@Component({
  templateUrl: 'check-data-service.view.html',
  styleUrls: ['check-data-service.view.scss']
})
export class CheckDataServiceView {
  moduleContent = `
  import { CaCheckDataService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaCheckDataService ],
    ...
  })`;
}
