import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SaludView } from './salud.view';
import { ProtocoloViewComponent } from './protocolo/protocolo.view';

import { InputModalFilterView } from './input-modal-filter/input-modal-filter.view';
import { SelectModalFilterView } from './select-modal-filter/select-modal-filter.view';
import { CompanySaludViewComponent } from './company-salud/company-salud.view';
import { CompaniesSaludServiceView } from './companies-salud/companies-salud-service.view';

const routes: Routes = [{
  path: '',
  component: SaludView,
  children: [{
    path: 'input-modal-filter',
    component: InputModalFilterView
  }, {
    path: 'protocolo',
    component: ProtocoloViewComponent
  },
  {
    path: 'select-modal-filter',
    component: SelectModalFilterView
  },{
    path: 'salud-companies',
    component: CompanySaludViewComponent
  },{
    path: 'salud-companies-service',
    component: CompaniesSaludServiceView
  }
]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SaludRoutingModule { }
