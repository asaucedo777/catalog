import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ProtocolValue } from '@global-front-components/salud';
import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';

@Component({
	templateUrl: 'protocolo.view.html',
	styleUrls: ['protocolo.view.scss']
})
export class ProtocoloViewComponent implements OnInit {
	constructor(private _formBuilder: FormBuilder) {}
	importModule = `import { CaProtocolModule } from '@global-front-components/salud';`;
	protocolValue: ProtocolValue = {
		protocol: {
			id: '1',
			value: 'CLIENTES'
		},
		subProtocol: {
			id: '0',
			value: 'MUFACE'
		},
		version: {
			id: '0',
			value: '0'
		}
	};
	protocolForm: FormGroup;
	caseSimple: ComponentDoc = {
		title: `Uso simple`,
		codeExample: {
			html: `<ca-protocolo></ca-protocolo>`
		}
	};

	casePredetermined: ComponentDoc = {
		title: `Uso con valor predeterminado`,
		codeExample: {
			html: `<ca-protocolo [value]="protocolValue" (changeProtocolValue)="changeProtocol($event)"></ca-protocolo>`,
      ts: `import { Component, OnInit } from '@angular/core';
import { ProtocolValue } from '@global-front-components/salud';

@Component({
  templateUrl: 'protocolo.view.html',
  styleUrls: [ 'protocolo.view.scss' ]
})

export class ProtocoloViewExampleComponent implements OnInit {
  constructor() {}
  protocolValue: ProtocolValue = {
    protocol: {
      id: '1',
      value: 'CLIENTES'
    },
    subProtocol: {
      id: '0',
      value: 'MUFACE'
    },
    version: {
      id: '0',
      value: '0'
    }
  }
  changeProtocol(data: ProtocolValue) {
    console.log(data);
  }
}`
		}
	};

	caseNgModel: ComponentDoc = {
		title: `Uso con ngModel`,
		codeExample: {
			html: `<ca-protocolo [(ngModel)]="protocolValue"></ca-protocolo>`,
      ts: `import { Component, OnInit } from '@angular/core';
import { ProtocolValue } from '@global-front-components/salud';

@Component({
  templateUrl: 'protocolo.view.html',
  styleUrls: [ 'protocolo.view.scss' ]
})

export class ProtocoloViewExampleComponent implements OnInit {
  constructor() {}
  protocolValue: ProtocolValue = {
    protocol: {
      id: '1',
      value: 'CLIENTES'
    },
    subProtocol: {
      id: '0',
      value: 'MUFACE'
    },
    version: {
      id: '0',
      value: '0'
    }
  }
}`
		}
	};

	caseReactive: ComponentDoc = {
		title: `Uso con formulario reactivo`,
		codeExample: {
			html: `<form [formGroup]="protocolForm">
  <ca-protocolo formControlName="caProtocol"></ca-protocolo>
</form>`,
      ts: `import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ProtocolValue } from '@global-front-components/salud';

@Component({
  templateUrl: 'protocolo.view.html',
  styleUrls: [ 'protocolo.view.scss' ]
})

export class ProtocoloViewExampleComponent implements OnInit {
  constructor(private _formBuilder: FormBuilder) {}
  protocolValue: ProtocolValue = {
    protocol: {
      id: '1',
      value: 'CLIENTES'
    },
    subProtocol: {
      id: '0',
      value: 'MUFACE'
    },
    version: {
      id: '0',
      value: '0'
    }
  }
  protocolForm: FormGroup;

  private protocolFormBuild() {
    this.protocolForm = this._formBuilder.group({
      caProtocol: [this.protocolValue]
    });
  }

  ngOnInit() {
    this.protocolFormBuild();
  }
}`
		}
	};

	private protocolFormBuild() {
		this.protocolForm = this._formBuilder.group({
			caProtocol: [this.protocolValue]
		});
	}

	changeProtocol(data: ProtocolValue) {
		console.log(data);
	}
	ngOnInit() {
		this.protocolFormBuild();
	}
}
