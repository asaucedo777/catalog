import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
	CaCheckDataService,
	CheckDataOutputMap,
	CheckDataRequest,
	CheckDataResponse
} from '@global-front-components/common';
import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import {
	CHECK_DATA_IBAN_INVALID_RESPONSE_MOCK,
	CHECK_DATA_INVALID_RESPONSE_MOCK,
	CHECK_DATA_RESPONSE_MOCK
} from './_mock_/check-data.response';

@Component({
	templateUrl: 'check-data.view.html',
	styleUrls: ['check-data.view.scss']
})
export class CheckDataView implements OnInit {
	constructor(private _caCheckDataService: CaCheckDataService, private _formBuilder: FormBuilder) {}

	form: FormGroup;
	formIBAN: FormGroup;
	formInvalid: FormGroup;
	formIBANInvalid: FormGroup;
	dataAccount: CheckDataOutputMap;
	dataAccountIBAN: CheckDataOutputMap;
	dataAccountInvalid: CheckDataOutputMap;
	dataAccountIBANInvalid: CheckDataOutputMap;

	caseSimple: ComponentDoc = {
		title: 'Organismo Comprobar Datos Cuenta',
		description: `

        `,
		codeExample: {
			html: `
            <form [formGroup]="form">
            <div class="d-flex align-items-end">
                <div class="d-flex form__container mr-5">
                    <div class="form__input">
                        <ca-form-field>
                            <ca-label>Entidad</ca-label>
                            <input type="text" caInput required formControlName="entId" />
                            <ca-error *ngIf="form.get('entId').errors?.required">Campo obligatorio </ca-error>
                        </ca-form-field>
                        <ca-form-field>
                            <ca-label>Oficina</ca-label>
                            <input type="text" caInput required formControlName="ofiId" />
                            <ca-error *ngIf="form.get('ofiId').errors?.required">Campo obligatorio </ca-error>
                        </ca-form-field>
                        <ca-form-field>
                            <ca-label>Digito de control</ca-label>
                            <input type="text" caInput required formControlName="dig" />
                            <ca-error *ngIf="form.get('dig').errors?.required">Campo obligatorio </ca-error>
                        </ca-form-field>
                        <ca-form-field>
                            <ca-label>Número de cuenta</ca-label>
                            <input type="text" caInput required formControlName="numCta" />
                            <ca-error *ngIf="form.get('numCta').errors?.required">Campo obligatorio </ca-error>
                        </ca-form-field>
                    </div>
                </div>
                <button
                    class="form__button"
                    ca-button
                    [disabled]="form.invalid"
                    (click)="getDataAccount()"
                >
                    <span>Comprobar</span>
                </button>
                 </div>
             </form>
            `,
			ts: `

            import { Component, OnInit } from '@angular/core';
            import { FormBuilder, FormGroup, Validators } from '@angular/forms';
            import {
                CaCheckDataService, CheckDataOutputMap,
                CheckDataRequest,
                CheckDataResponse
            } from '@global-front-components/common';

            @Component({
                templateUrl: 'check-data.view.html',
                styleUrls: ['check-data.view.scss']
            })
            export class CheckDataView implements OnInit {
                constructor(private _caCheckDataService: CaCheckDataService, private _formBuilder: FormBuilder) {}
            
                form: FormGroup;
                dataAccount: CheckDataOutputMap;

                getDataAccount() {
                    const endpoint: string = '/normalizacionbdihttpchannel/bindJSONServlet';
                    const request: CheckDataRequest = {
                        serviceId: 'ChequarDatosCuentaSRV',
                        inputMap: {
                            entId: this.form.get('entId').value,
                            ofiId: this.form.get('ofiId').value,
                            dig: this.form.get('dig').value,
                            numCta: this.form.get('numCta').value
                        }
                    };
            
                    this._checkDataAccount(endpoint, request).subscribe((response: CheckDataResponse) => {
                        this.dataAccount = response.outputMap;
                    });
                }
            

                ngOnInit(): void {
                    this.form = this._formBuilder.group({
                        entId: ['', Validators.required],
                        ofiId: ['', Validators.required],
                        dig: ['', Validators.required],
                        numCta: ['', Validators.required]
                    });
                }
            }
          `,
			css: `
                .form__input{
                    display: flex;
                    align-content: space-between;
                    flex-direction: row;
                    .ca-form-field{
                        margin-left: .625rem;
                    }
                
                }
          `
		}
	};

	caseSimpleNoValid: ComponentDoc = {
		title: 'Organismo Comprobar Datos Cuenta (Datos erróneos)',
		description: ` En el caso de que los datos introducidos no sean correctos se hará uso del servicio CaCheckDataService para obtener
        los datos válidos correspondientes a la cuenta introducida. 
        `,
		codeExample: {
			html: `
            <form [formGroup]="form">
            <div class="d-flex align-items-end">
                <div class="d-flex form__container mr-5">
                    <div class="form__input">
                        <ca-form-field>
                            <ca-label>Entidad</ca-label>
                            <input type="text" caInput required formControlName="entId" />
                            <ca-error *ngIf="form.get('entId').errors?.required">Campo obligatorio </ca-error>
                        </ca-form-field>
                        <ca-form-field>
                            <ca-label>Oficina</ca-label>
                            <input type="text" caInput required formControlName="ofiId" />
                            <ca-error *ngIf="form.get('ofiId').errors?.required">Campo obligatorio </ca-error>
                        </ca-form-field>
                        <ca-form-field>
                            <ca-label>Digito de control</ca-label>
                            <input type="text" caInput required formControlName="dig" />
                            <ca-error *ngIf="form.get('dig').errors?.required">Campo obligatorio </ca-error>
                        </ca-form-field>
                        <ca-form-field>
                            <ca-label>Número de cuenta</ca-label>
                            <input type="text" caInput required formControlName="numCta" />
                            <ca-error *ngIf="form.get('numCta').errors?.required">Campo obligatorio </ca-error>
                        </ca-form-field>
                    </div>
                </div>
                <button
                    class="form__button"
                    ca-button
                    [disabled]="form.invalid"
                    (click)="getDataAccount()"
                >
                    <span>Comprobar</span>
                </button>
                 </div>
             </form>
            `,
			ts: `

            import { Component, OnInit } from '@angular/core';
            import { FormBuilder, FormGroup, Validators } from '@angular/forms';
            import {
                CaCheckDataService, CheckDataOutputMap,
                CheckDataRequest,
                CheckDataResponse
            } from '@global-front-components/common';

            @Component({
                templateUrl: 'check-data.view.html',
                styleUrls: ['check-data.view.scss']
            })
            export class CheckDataView implements OnInit {
                constructor(private _caCheckDataService: CaCheckDataService, private _formBuilder: FormBuilder) {}
            
                form: FormGroup;
                dataAccount: CheckDataOutputMap;

                getDataAccount() {
                    const endpoint: string = '/normalizacionbdihttpchannel/bindJSONServlet';
                    const request: CheckDataRequest = {
                        serviceId: 'ChequarDatosCuentaSRV',
                        inputMap: {
                            entId: this.form.get('entId').value,
                            ofiId: this.form.get('ofiId').value,
                            dig: this.form.get('dig').value,
                            numCta: this.form.get('numCta').value
                        }
                    };
            
                    this._checkDataAccount(endpoint, request).subscribe((response: CheckDataResponse) => {
                        this.dataAccount = response.outputMap;
                    });
                }
            

                ngOnInit(): void {
                    this.form = this._formBuilder.group({
                        entId: ['', Validators.required],
                        ofiId: ['', Validators.required],
                        dig: ['', Validators.required],
                        numCta: ['', Validators.required]
                    });
                }
            }
          `,
			css: `
                .form__input{
                    display: flex;
                    align-content: space-between;
                    flex-direction: row;
                    .ca-form-field{
                        margin-left: .625rem;
                    }
                
                }
          `
		}
	};

	caseIBAN: ComponentDoc = {
		title: 'Organismo Comprobar Datos Cuenta (IBAN Y BIC)',
		description: ` 
        `,
		codeExample: {
			html: `
            <form [formGroup]="form">
            <div class="d-flex align-items-end">
                <div class="d-flex form__container mr-5">
                    <div class="form__input">
                        <ca-form-field>
                            <ca-label>IBAN</ca-label>
                            <input type="text" caInput required formControlName="iban" />
                            <ca-error *ngIf="form.get('iban').errors?.required">Campo obligatorio </ca-error>
                        </ca-form-field>
                        <ca-form-field>
                            <ca-label>BIC</ca-label>
                            <input type="text" caInput required formControlName="bic" />
                            <ca-error *ngIf="form.get('bic').errors?.required">Campo obligatorio </ca-error>
                        </ca-form-field>
                    </div>
                </div>
                <button
                    class="form__button"
                    ca-button
                    [disabled]="form.invalid"
                    (click)="getDataAccount()"
                >
                    <span>Comprobar</span>
                </button>
                 </div>
             </form>
            `,
			ts: `

            import { Component, OnInit } from '@angular/core';
            import { FormBuilder, FormGroup, Validators } from '@angular/forms';
            import {
                CaCheckDataService, CheckDataOutputMap,
                CheckDataRequest,
                CheckDataResponse
            } from '@global-front-components/common';

            @Component({
                templateUrl: 'check-data.view.html',
                styleUrls: ['check-data.view.scss']
            })
            export class CheckDataView implements OnInit {
                constructor(private _caCheckDataService: CaCheckDataService, private _formBuilder: FormBuilder) {}
            
                form: FormGroup;
                dataAccount: CheckDataOutputMap;

                getDataAccount() {
                    const endpoint: string = '/normalizacionbdihttpchannel/bindJSONServlet';
                    const request: CheckDataRequest = {
                        serviceId: 'ChequarDatosCuentaSRV',
                        inputMap: {
                            iban: this.form.get('iban').value,
                            bic: this.form.get('bic').value,
                        }
                    };
            
                    this._checkDataAccount(endpoint, request).subscribe((response: CheckDataResponse) => {
                        this.dataAccount = response.outputMap;
                    });
                }
            

                ngOnInit(): void {
                    this.form = this._formBuilder.group({
                        iban: ['', Validators.required],
                        bic: ['', Validators.required],
                    });
                }
            }
          `,
			css: `
                .form__input{
                    display: flex;
                    align-content: space-between;
                    flex-direction: row;
                    .ca-form-field{
                        margin-left: .625rem;
                    }
                
                }
          `
		}
	};

	caseIBANNovalid: ComponentDoc = {
		title: 'Organismo Comprobar Datos Cuenta (IBAN o BIC Erróneos)',
		description: ` En el caso de que los datos introducidos no sean correctos se hará uso del servicio CaCheckDataService para obtener
        los datos válidos correspondientes a la cuenta introducida. 
        `,
		codeExample: {
			html: `
            <form [formGroup]="form">
            <div class="d-flex align-items-end">
                <div class="d-flex form__container mr-5">
                    <div class="form__input">
                        <ca-form-field>
                            <ca-label>IBAN</ca-label>
                            <input type="text" caInput required formControlName="iban" />
                            <ca-error *ngIf="form.get('iban').errors?.required">Campo obligatorio </ca-error>
                        </ca-form-field>
                        <ca-form-field>
                            <ca-label>BIC</ca-label>
                            <input type="text" caInput required formControlName="bic" />
                            <ca-error *ngIf="form.get('bic').errors?.required">Campo obligatorio </ca-error>
                        </ca-form-field>
                    </div>
                </div>
                <button
                    class="form__button"
                    ca-button
                    [disabled]="form.invalid"
                    (click)="getDataAccount()"
                >
                    <span>Comprobar</span>
                </button>
                 </div>
             </form>
            `,
			ts: `

            import { Component, OnInit } from '@angular/core';
            import { FormBuilder, FormGroup, Validators } from '@angular/forms';
            import {
                CaCheckDataService, CheckDataOutputMap,
                CheckDataRequest,
                CheckDataResponse
            } from '@global-front-components/common';

            @Component({
                templateUrl: 'check-data.view.html',
                styleUrls: ['check-data.view.scss']
            })
            export class CheckDataView implements OnInit {
                constructor(private _caCheckDataService: CaCheckDataService, private _formBuilder: FormBuilder) {}
            
                form: FormGroup;
                dataAccount: CheckDataOutputMap;

                getDataAccount() {
                    const endpoint: string = '/normalizacionbdihttpchannel/bindJSONServlet';
                    const request: CheckDataRequest = {
                        serviceId: 'ChequarDatosCuentaSRV',
                        inputMap: {
                            iban: this.form.get('iban').value,
                            bic: this.form.get('bic').value,
                        }
                    };
            
                    this._checkDataAccount(endpoint, request).subscribe((response: CheckDataResponse) => {
                        this.dataAccount = response.outputMap;
                    });
                }
            

                ngOnInit(): void {
                    this.form = this._formBuilder.group({
                        iban: ['', Validators.required],
                        bic: ['', Validators.required],
                    });
                }
            }
          `,
			css: `
          .form__input{
              display: flex;
              align-content: space-between;
              flex-direction: row;
              .ca-form-field{
                  margin-left: .625rem;
              }
          
          }
    `
		}
	};

	getDataAccount() {
		const endpoint: string = '/normalizacionbdihttpchannel/bindJSONServlet';
		const request: CheckDataRequest = {
			serviceId: 'ChequarDatosCuentaSRV',
			inputMap: {
				entId: this.form.get('entId').value,
				ofiId: this.form.get('ofiId').value,
				dig: this.form.get('dig').value,
				numCta: this.form.get('numCta').value
			}
		};

		this._checkDataAccount(endpoint, request).subscribe((response: CheckDataResponse) => {
			this.dataAccount = response.outputMap;
		});
	}

	getDataAccountInvalid() {
		const endpoint: string = '/normalizacionbdihttpchannel/bindJSONServlet';
		const request: CheckDataRequest = {
			serviceId: 'ChequarDatosCuentaSRV',
			inputMap: {
				entId: this.formInvalid.get('entId')?.value,
				ofiId: this.formInvalid.get('ofiId')?.value,
				dig: this.formInvalid.get('dig')?.value,
				numCta: this.formInvalid.get('numCta')?.value
			}
		};

		this._checkDataAccountInvalid(endpoint, request).subscribe((response: CheckDataResponse) => {
			this.dataAccountInvalid = response.outputMap;
		});
	}

	getDataAccountIBANInvalid() {
		const endpoint: string = '/normalizacionbdihttpchannel/bindJSONServlet';
		const request: CheckDataRequest = {
			serviceId: 'ChequarDatosCuentaSRV',
			inputMap: {
				iban: this.formIBAN.get('iban').value,
				bic: this.formIBAN.get('bic').value
			}
		};

		this._checkDataAccountIBANInvalid(endpoint, request).subscribe((response: CheckDataResponse) => {
			this.dataAccountIBANInvalid = response.outputMap;
		});
	}

	getIBANDataAccount() {
		const endpoint: string = '/normalizacionbdihttpchannel/bindJSONServlet';
		const request: CheckDataRequest = {
			serviceId: 'ChequarDatosCuentaSRV',
			inputMap: {
				iban: this.formIBAN.get('iban').value,
				bic: this.formIBAN.get('bic').value
			}
		};

		this._checkDataAccount(endpoint, request).subscribe((response: CheckDataResponse) => {
			this.dataAccountIBAN = response.outputMap;
		});
	}

	private _checkDataAccount(endpoint: string, request: CheckDataRequest): Observable<CheckDataResponse> {
		return this._caCheckDataService.getAccountData(endpoint, request).pipe(
			catchError(() => {
				return of(<CheckDataResponse>CHECK_DATA_RESPONSE_MOCK);
			})
		);
	}

	private _checkDataAccountInvalid(endpoint: string, request: CheckDataRequest): Observable<CheckDataResponse> {
		return this._caCheckDataService.getAccountData(endpoint, request).pipe(
			catchError(() => {
				return of(<CheckDataResponse>CHECK_DATA_INVALID_RESPONSE_MOCK);
			})
		);
	}

	private _checkDataAccountIBANInvalid(endpoint: string, request: CheckDataRequest): Observable<CheckDataResponse> {
		return this._caCheckDataService.getAccountData(endpoint, request).pipe(
			catchError(() => {
				return of(<CheckDataResponse>CHECK_DATA_IBAN_INVALID_RESPONSE_MOCK);
			})
		);
	}

	ngOnInit(): void {
		this.form = this._formBuilder.group({
			entId: ['', Validators.required],
			ofiId: ['', Validators.required],
			dig: ['', Validators.required],
			numCta: ['', Validators.required]
		});

		this.formIBAN = this._formBuilder.group({
			iban: ['', Validators.required],
			bic: ['', Validators.required]
		});

		this.formInvalid = this._formBuilder.group({
			entId: ['', Validators.required],
			ofiId: ['', Validators.required],
			dig: ['', Validators.required],
			numCta: ['', Validators.required]
		});
		this.formIBANInvalid = this._formBuilder.group({
			iban: ['', Validators.required],
			bic: ['', Validators.required]
		});
	}
}
