import { Component } from '@angular/core';

@Component({
  templateUrl: 'menu-applications-service.view.html',
  styleUrls: ['menu-applications-service.view.scss']
})
export class MenuApplicationsServiceView {
  moduleContent = `
  import { CaMenuApplicationsService } from '@global-front-components/common';

  @NgModule({
    ...
    providers: [ CaMenuApplicationsService ],
    ...
  })`;

  packageSSE = `npm install event-source-polyfill`;

  angularJson = `
  ...
  "architect": {
    "build": {
      ...
      "options": {
        ...
        "scripts": [
          "node_modules/event-source-polyfill/src/eventsource.min.js"
        ]
      },
      ...
    }
  }
  ...`;

  customModuleContent = `
  import { CaMenuApplicationsService, MENU_ENDPOINT } from '@global-front-components/common';

  const NEW_URL: string = '/prueba/api/menu';

  @NgModule({
    ...
    providers: [
      CaMenuApplicationsService,
      {
        provide: MENU_ENDPOINT,
        useValue: NEW_URL
      }
     ],
    ...
  })`
}
