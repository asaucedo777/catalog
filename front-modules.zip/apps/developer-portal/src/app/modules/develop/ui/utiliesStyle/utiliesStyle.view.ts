import { Component } from '@angular/core';

@Component({
  templateUrl: 'utiliesStyle.view.html',
  styleUrls: ['utiliesStyle.view.scss']
})
export class UtilieStyleView {

}
