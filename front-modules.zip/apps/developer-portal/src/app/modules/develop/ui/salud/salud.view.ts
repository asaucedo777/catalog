import { Component } from '@angular/core';

@Component({
  templateUrl: './salud.view.html',
  styleUrls: ['./salud.view.scss']
})
export class SaludView { }
