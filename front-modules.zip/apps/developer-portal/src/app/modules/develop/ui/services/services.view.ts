import { Component } from '@angular/core';

@Component({
  templateUrl: 'services.view.html',
  styleUrls: ['services.view.scss']
})
export class ServicesView {}
