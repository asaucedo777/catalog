import { ClientValueResponse } from '@global-front-components/common';

export const CLIENT_VALUE_RESPONSE_MOCK: ClientValueResponse = {
  serviceId: 'BuscarValorClienteSRV',
  outputMap: {
    intervId: 123456756789,
    antiguedad: 8,
    denTpoClie: 'Oro',
    documento: '12345678Z',
    idTpoClie: 4,
    numPolVig: 1,
    ratioSP: 0,
    segValor: 'M',
    vinculacion: 'BAJA',
    nombre: 'JOHN',
    apellido1: 'DOE',
    apellido2: 'GARCIA',
    razonSocial: '',
    sexo: '2',
    fechaNacimiento: '01/01/2021',
    nombreCausa: '',
    causaModifSeg: ''
  }
}
