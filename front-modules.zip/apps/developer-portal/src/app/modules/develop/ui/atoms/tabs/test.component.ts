import { Component } from '@angular/core';

@Component({
	selector: 'ca-test-tab',
	template: `
		<div>
			<h1>Hello</h1>
			<p>Componente de prueba <ca-icon>thumb_up_alt</ca-icon></p>
		</div>
	`
})
export class TestTabComponent {}
