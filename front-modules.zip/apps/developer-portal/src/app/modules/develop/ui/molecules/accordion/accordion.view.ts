import { Component } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
    templateUrl: 'accordion.view.html',
    styleUrls: ['accordion.view.scss']
})
export class AccordionView {
    toggAcComponent: boolean = false;
    iconTextAccordion: string = 'keyboard_arrow_down';
    toggAcComponentDisabled: boolean = false;
    toggAcComponentMultiple: boolean = false;

    // Modificadores CSS
    iconTextAccordionModify: string = 'add';

    toggleAccordion(): void {
        this.toggAcComponent = !this.toggAcComponent;
        console.log(this.toggAcComponent);
        if (this.toggAcComponent) {
            this.iconTextAccordion = 'keyboard_arrow_up';
            this.iconTextAccordionModify = 'remove';
        } else {
            this.iconTextAccordion = 'keyboard_arrow_down';
            this.iconTextAccordionModify = 'add';
        }
    }
    toggleAccordionDisabled(): void {
        this.toggAcComponent = !this.toggAcComponent;
        console.log(this.toggAcComponent);
    }
    accordionsGroup = [
        {title: 'Accordion multi 1', openItem: false, iconTextAccordion: 'keyboard_arrow_down',disabled: false, content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos sequi placeat distinctio dolor, amet magnam voluptatibus eos ex vero, sunt veritatis esse. Nostrum voluptatum et repudiandae vel sed, explicabo in'},
        {title: 'Accordion multi 2', openItem: false, iconTextAccordion: 'keyboard_arrow_down',disabled: false, content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos sequi placeat distinctio dolor, amet magnam voluptatibus eos ex vero, sunt veritatis esse. Nostrum voluptatum et repudiandae vel sed, explicabo in'},
        {title: 'Accordion multi 3', openItem: false, iconTextAccordion: 'keyboard_arrow_down',disabled: false, content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos sequi placeat distinctio dolor, amet magnam voluptatibus eos ex vero, sunt veritatis esse. Nostrum voluptatum et repudiandae vel sed, explicabo in'},
        {title: 'Accordion multi 4', openItem: false, iconTextAccordion: 'keyboard_arrow_down',disabled: false, content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos sequi placeat distinctio dolor, amet magnam voluptatibus eos ex vero, sunt veritatis esse. Nostrum voluptatum et repudiandae vel sed, explicabo in'}
    ];
    toggleAccordionMultiple(item): void {
        item.openItem = !item.openItem;
        if(item.openItem) {
            item.iconTextAccordion = 'keyboard_arrow_up';
        } else {
            item.iconTextAccordion = 'keyboard_arrow_down';
        }
    }
    moduleContent = `import { CaAccordionModule } from '@global-front-components/ui';`;
    caseOne: ComponentDoc = {
        title: 'Uso de accordion',
        description: `<p>Ejemplo de uso de accordion simple para aplicaciones</p>`,
        codeExample: {
            html: `
        <ca-accordion class="ca-accordion-content">
            <ca-accordion-item
            [openItem]="toggAcComponent"
            (toggle)="toggAcComponent =! toggAcComponent">
                <div ca-accordion-header>
                <h3 class="ca-accordion-title">Prueba 1</h3>
              </div>
              <div ca-accordion-body class="ca-accordion__body">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Dignissimos sequi placeat distinctio dolor, amet magnam voluptatibus eos ex vero,
                  sunt veritatis esse. Nostrum voluptatum et repudiandae vel sed, explicabo in?</p>
              </div>
              <div ca-accordion-footer class="ca-accordion__footer">
                <p>Prueba footer 2</p>
              </div>
            </ca-accordion-item>
        </ca-accordion>  `,
            ts: `
            import { Component } from '@angular/core';

            @Component({
                selector: 'ca-accordion-view',
                templateUrl: 'accordion-view.component.html'
            })
            export class AccordionPageComponent {
                toggAcComponent: boolean = false;
                iconTextAccordion: string = 'keyboard_arrow_down';
                toggleAccordion(): void {
                    this.toggAcComponent =! this.toggAcComponent;
                    console.log(this.toggAcComponent);
                    if (this.toggAcComponent) {
                        this.iconTextAccordion = 'keyboard_arrow_up';
                    } else {
                        this.iconTextAccordion = 'keyboard_arrow_down';
                    }
                }
            }`
        }
    };

    caseTwo: ComponentDoc = {
        title: 'Uso de accordion disabled',
        description: `<p>Ejemplo de uso de accordion simple deshabilitado para aplicaciones. Es necesario aplicar el atributo <code class="tag">disabled</code> en el componentes <code class="tag">ca-accordion-item</code></p>`,
        codeExample: {
            html: `
        <ca-accordion class="ca-accordion-content">
            <ca-accordion-item
            [openItem]="toggAcComponentDisabled"
            (toggle)="toggAcComponentDisabled =! toggAcComponentDisabled"
            disabled>
                <div ca-accordion-header>
                <h3 class="ca-accordion-title">Prueba 1</h3>
              </div>
              <div ca-accordion-body class="ca-accordion__body">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Dignissimos sequi placeat distinctio dolor, amet magnam voluptatibus eos ex vero,
                  sunt veritatis esse. Nostrum voluptatum et repudiandae vel sed, explicabo in?</p>
              </div>
              <div ca-accordion-footer class="ca-accordion__footer">
                <p>Prueba footer 2</p>
              </div>
            </ca-accordion-item>
        </ca-accordion>  `,
            ts: `
            import { Component } from '@angular/core';

            @Component({
                selector: 'ca-accordion-view',
                templateUrl: 'accordion-view.component.html'
            })

            export class AccordionPageComponent {
                toggAcComponentDisabled: boolean = false;

                toggleAccordionDisabled(): void {
                    this.toggAcComponent =! this.toggAcComponent;
                    console.log(this.toggAcComponent);
                }
            }`
        }
    };

    caseThree: ComponentDoc = {
        title: 'Uso de accordion multiple',
        description: `<p>Ejemplo de uso de accordion multiple con array, deshabilitado algunos de los item. Es necesario aplicar el atributo <code class="tag">disabled</code> en el componentes <code class="tag">ca-accordion-item</code> que necesitemos deshabilitar.</p>`,
        codeExample: {
            html: `
        <ca-accordion class="ca-accordion-content">
            <ca-accordion-item *ngFor="let item of accordionsGroup"
            [openItem]="item.openItem"
            (toggle)="item.openItem =! item.openItem">
                <div ca-accordion-header>
                <h3 class="ca-accordion-title">{{item.title}}</h3>
              </div>
              <div ca-accordion-body class="ca-accordion__body">
                <p>{{item.content}}</p>
              </div>
              <div ca-accordion-footer class="ca-accordion__footer">
                <p>Prueba footer 2</p>
              </div>
            </ca-accordion-item>
        </ca-accordion>  `,
            ts: `
            import { Component } from '@angular/core';

            @Component({
                selector: 'ca-accordion-view',
                templateUrl: 'accordion-view.component.html'
            })

            export class AccordionPageComponent {
                accordionsGroup = [
                    {title: 'Accordion multi 1', openItem: false, iconTextAccordion: 'keyboard_arrow_down',disabled: false, content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos sequi placeat distinctio dolor, amet magnam voluptatibus eos ex vero, sunt veritatis esse. Nostrum voluptatum et repudiandae vel sed, explicabo in'},
                    {title: 'Accordion multi 2', openItem: false, iconTextAccordion: 'keyboard_arrow_down',disabled: false, content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos sequi placeat distinctio dolor, amet magnam voluptatibus eos ex vero, sunt veritatis esse. Nostrum voluptatum et repudiandae vel sed, explicabo in'},
                    {title: 'Accordion multi 3', openItem: false, iconTextAccordion: 'keyboard_arrow_down',disabled: false, content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos sequi placeat distinctio dolor, amet magnam voluptatibus eos ex vero, sunt veritatis esse. Nostrum voluptatum et repudiandae vel sed, explicabo in'},
                    {title: 'Accordion multi 4', openItem: false, iconTextAccordion: 'keyboard_arrow_down',disabled: false, content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos sequi placeat distinctio dolor, amet magnam voluptatibus eos ex vero, sunt veritatis esse. Nostrum voluptatum et repudiandae vel sed, explicabo in'}
                ];
            }`
        }
    };

    caseFour: ComponentDoc = {
        codeExample: {
            html: `
            <ca-accordion class="ca-accordion-content">
            <ca-accordion-item
            class="ca-accordion--filter"
            [openItem]="toggAcComponent"
            (toggle)="toggleAccordion()">
                <div ca-accordion-header>
                  <h3 class="ca-accordion-title">Accordion para formulario</h3>
                  <span class="ca-accordion-icon material-icons">{{iconTextAccordion}}</span>
                </div>
              <div ca-accordion-body class="ca-accordion__body">
                <p>Este tipo de accordion se usa para recoger los formuraios</p>
              </div>
              <div ca-accordion-footer class="ca-accordion__footer">
                <p>Zona reservada para los botones</p>
              </div>
            </ca-accordion-item>
            <ca-accordion-item
            class="ca-accordion--result"
            [openItem]="toggAcComponent"
            (toggle)="toggleAccordion()">
                <div ca-accordion-header>
                  <h3 class="ca-accordion-title">Accordion resultado de datos</h3>
                  <span class="ca-accordion-icon material-icons">{{iconTextAccordion}}</span>
                </div>
              <div ca-accordion-body class="ca-accordion__body">
                <p>Este tipo de accordion se usa para recoger las diferentes formas de resultados</p>
              </div>
              <div ca-accordion-footer class="ca-accordion__footer">
                <p>Zona reservada para los botones</p>
              </div>
            </ca-accordion-item>
        </ca-accordion>  `,
            ts: `
            import { Component } from '@angular/core';

            @Component({
                selector: 'ca-accordion-view',
                templateUrl: 'accordion-view.component.html'
            })
            export class AccordionPageComponent {
                toggAcComponent: boolean = false;
                iconTextAccordion: string = 'keyboard_arrow_down';
                toggleAccordion(): void {
                    this.toggAcComponent =! this.toggAcComponent;
                    console.log(this.toggAcComponent);
                    if (this.toggAcComponent) {
                        this.iconTextAccordion = 'keyboard_arrow_up';
                    } else {
                        this.iconTextAccordion = 'keyboard_arrow_down';
                    }
                }
            }`
        }
    };
}
