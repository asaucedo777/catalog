import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { CaSnackbarService } from '@global-front-components/ui';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: 'select.view.html',
	styleUrls: ['select.view.scss']
})
export class SelectView implements OnInit {
	constructor(private formBuilder: FormBuilder) {}
	form: FormGroup;
	disabled = true;
	moduleContent = `import { CaFormFieldModule, CaSelectModule } from '@global-front-components/ui';`;

	caseStyleScss = `@import '~@angular/cdk/overlay-prebuilt.css';

cdk-virtual-scroll-viewport {
  .cdk-virtual-scroll-content-wrapper {
    position: relative;
    overflow-x: scroll;
  }
}

.cdk-overlay-container {
  z-index: 9999;
}`;

	caseArrayOptions: ComponentDoc = {
		title: `Select con opciones en formato array`,
		description: `
    <p>Podemos indicarle al componente select que opciones tiene que mostar, pasandole un array de tipo string.</p>
    <p> Cada vez que el select cambie su valor, emitira un evento con el nuevo valor</p>
    `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-select [options]="arrayOptions" (changeValue)="onChangeValue($event)"></ca-select>
      </ca-form-field>`,
			ts: `
      arrayOptions = ['Opción 1','Opción 2','Opción 3','Opción 4','Opción 5'];

      onChangeValue(value){
        console.log(value);
      }

      `
		}
	};

	caseArrayObjOptions: ComponentDoc = {
		title: `Select con opciones en formato array de objetos`,
		description: `
    <p> El componente admite como opciones un array de objetos.
    En este caso, debemos indicarle mediante el input <code class="attribute">keyValue</code>, que atributo de dicho objeto, se ha de mostrar.</p>
   `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-select keyValue="textValue" [options]="options"></ca-select>
      </ca-form-field>`,
			ts: `
      public options = [
        {
          value: 0,
          textValue: 'Primera opción'
        },
        {
          value: 1,
          textValue: 'Segunda opción'
        },
        {
          value: 2,
          textValue: 'Tercera opción'
        }
      ];`
		}
	};

	caseValueField: ComponentDoc = {
		title: `Retornar un attributo concreto del objeto`,
		description: `
    <p> Si necesitamos que,  al seleccionar una de las opciones del select, este nos devuelva un attributo concreto del obejto. Añadiremos a la etiqueta ca-select el atributo <code class="attribute">valueField</code> y como vale el nombre del attributo que necesitemos </p>
   `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-select
          [(ngModel)]="valueFieldModel"
          keyValue="textValue"
          [options]="options"
          valueField="value"
        ></ca-select>
      </ca-form-field>`,
			ts: `
      const valueFieldModel = 1
      public options = [
        {
          value: 0,
          textValue: 'Primera opción'
        },
        {
          value: 1,
          textValue: 'Segunda opción'
        },
        {
          value: 2,
          textValue: 'Tercera opción'
        }
      ];`
		}
	};

	caseDefaultValue: ComponentDoc = {
		title: `Select con valor por defecto`,
		description: `Mediante el input <code class="attribute">value</code> podemos indicarle al select cual es su valor por defecto, este valor debe coincidir con una de las opciones`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-select keyValue="textValue" [options]="options" [value]="selectedOption"></ca-select>
      </ca-form-field>`,
			ts: `public options = [
  {
    value: 0,
    textValue: 'Primera opción'
  },
  {
    value: 1,
    textValue: 'Segunda opción'
  },
  {
    value: 2,
    textValue: 'Tercera opción'
  }
];

public selectedOption = this.options[0];`
		}
	};

	caseCustomPlaceholder: ComponentDoc = {
		title: `Placeholder personalizado`,
		description: `Para personalizar el mensaje que se muestra en el placeholder. Haremos uso del input <code class="attribute">placeholder</code>.`,
		codeExample: {
			html: `<ca-form-field>
  <ca-select keyValue="textValue" [options]="options" placeholder="Placeholder personalizable"></ca-select>
</ca-form-field>`
		}
	};

	caseMultiple: ComponentDoc = {
		title: `Selección Multiple`,
		description: `Para habilitar la multiple selección tan sólo debemos añadir al atributo <code class="attribute">multiple</code>`,
		codeExample: {
			html: `<ca-form-field>
  <ca-select
    placeholder="Selección múltiple"
    [options]="arrayOptions"
    multiple
  ></ca-select>
</ca-form-field>`
		}
	};

	caseVirtualScroll: ComponentDoc = {
		title: `Virtual Scroll`,
		description: `Para  mejorar el rendimiento, en el caso de tener muchas opciones. Podemos indicarle al select que utilice el virtualscroll, para renderizar las opciones a medida que hacemos scroll y no sobrecargar el DOM.
      Para ello bastara con añadir el atributo <code class="attribute">virtualScroll</code>.
      <p>Si el numero de opciones es menor de 6, el select no usará el virtualscroll aunque se haya añadido el atributo</p>`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-select [options]="arrayOptions"  virtualScroll> </ca-select>
      </ca-form-field>`
		}
	};
	caseFilter: ComponentDoc = {
		title: `Panel de opciones con filtro`,
		description: `
    <p>Podemos añadir un filtro para las opciones del select, para ello añadiremos el atributo <code class="attribute">filter</code> tal cómo se muestra en el ejemplo</p>
    <p>Si el array que alimenta las opciones está compuesto por objetos, el filtro se asplicará sobre todos los atributos del objeto</p>
    `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-select [options]="options"  keyValue="textValue" filter> </ca-select>
      </ca-form-field>`
		}
	};

	caseReactiveForm: ComponentDoc = {
		title: `Select con formulario reactivo`,
		description: `Componente <code class="tag">ca-select</code> en un formulario reactivo, encapsulado en un <code class="tag">ca-form-field</code>.`,
		codeExample: {
			html: `<form [formGroup]="form" class="form">
  <ca-form-field>
    <ca-label>Elija su género</ca-label>
      <ca-select
        placeholder="Género"
        keyValue="textValue"
        formControlName="genderControl"
        [options]="formOptions"
      ></ca-select>
  </ca-form-field>
</form>`,
			ts: `constructor(private formBuilder: FormBuilder) {}
public form: FormGroup;

public formOptions = [
  {
    value: 'M',
    textValue: 'Masculino'
  },
  {
    value: 'F',
    textValue: 'Femenino'
  }
];

ngOnInit() {
  this.form = this.formBuilder.group({
    genderControl: ''
  })
}`,
			css: `.form {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;

  ca-form-field{
    width: 40%;
  }
}`
		}
	};

	prueba: any = [];

	public options: any = [
		{
			value: 0,
			textValue: 'Wanda maximoff'
		},
		{
			value: 1,
			textValue: 'Vision'
		},
		{
			value: 2,
			textValue: 'Black widow'
		},
		{
			value: 3,
			textValue: 'Thor'
		},
		{
			value: 4,
			textValue: 'Ant Man'
		},
		{
			value: 5,
			textValue: 'Spiderman'
		}
	];
	public valueFieldModel = 1;

	public options2 = [];

	public selectedOption: any | any[] = {
		value: 0,
		textValue: 'Primera opción'
	};

	public arrayOptions = ['Opción 1', 'Opción 2', 'Opción 3', 'Opción 4', 'Opción 5'];
	public arrayOptionsVC = Array.from({ length: 100000 }).map((_, i) => `Item #${i}`);

	public formOptions: any = [
		{
			value: 'M',
			textValue: 'Masculino'
		},
		{
			value: 'F',
			textValue: 'Femenino'
		}
	];

	onChangeValue(option: any) {
		console.log('option selected: ', option);
	}

	ngOnInit() {
		this.form = this.formBuilder.group({
			genderControl: ['M', [Validators.required]],
			multiple: [
				{
					value: 0,
					textValue: 'Primera opción'
				}
			]
		});
	}
}
