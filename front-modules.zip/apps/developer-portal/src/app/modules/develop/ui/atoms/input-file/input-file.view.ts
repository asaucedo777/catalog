import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: 'input-file.view.html',
	styleUrls: ['input-file.view.scss']
})
export class InputFileView implements OnInit {
	public importModule = `import { CaFormFieldModule, CaInputFileModule } from '@global-front-components/ui';`;
	constructor(private _fb: FormBuilder) {}

	file: File;
	fileMultiple: File;
	fileRequired: File;
	fileAccept: File;
	fileMin: File;

	disabled = true;
	form: FormGroup;

	caseNgModel: ComponentDoc = {
		title: 'Uso con NgModel',
		codeExample: {
			html: `<ca-form-field>
  <ca-label>Archivo</ca-label>
  <ca-input-file [(ngModel)]="file" id="id"></ca-input-file>
</ca-form-field>`
		}
	};
	caseReactive: ComponentDoc = {
		title: 'Uso con formularios reactivos',
		description: `<p> Podemos usar el componente como parte de un formulario reactivo.</p>`,
		codeExample: {
			html: `<form [formGroup]="form">
      <ca-form-field>
      <ca-label>Archivo</ca-label>
      <ca-input-file formControlName="file" ></ca-input-file>
      </ca-form-field>
      </form>`,
			ts: `
      export class InputFilePageComponent  {
        constructor(private _fb: FormBuilder) {}
        form =  this._fb.group({
          file: ['']
        });
      }`
		}
	};
	caseMultiple: ComponentDoc = {
    title: 'Seleccionando múltiples archivos',
    description: `<p>Podemos permitir la selección de múltiples archivos añadiendo el atributo <code class="attribute">multiple</code>. </p>`,
		codeExample: {
			html: `<ca-form-field>
  <ca-label>Archivo</ca-label>
  <ca-input-file [(ngModel)]="file" id="id" multiple></ca-input-file>
</ca-form-field>`
		}
  };

	caseRequired: ComponentDoc = {
    title: 'Campo requerido',
    description: `<p>Para que el input sea un campo requerido basta con agregar el atributo <code class="attribute">required</code>. /p>`,
		codeExample: {
			html: `<ca-orm-field>
  <ca-label>Archivo</ca-label>
  <ca-input-file [(ngModel)]="file" id="id" required></ca-input-file>
</ca-form-field>`
		}
  };

	caseDisabled: ComponentDoc = {
    title: 'Campo deshabilitado',
    description: `<p> Añadiremos el atributo <code class="attribute">disabled</code> para mostrar el input en estado deshabilitado.</p>`,
		codeExample: {
			html: `<ca-orm-field>
  <ca-label>Archivo</ca-label>
  <ca-input-file [(ngModel)]="file" id="id" disable></ca-input-file>
</ca-form-field>`
		}
	};
	caseAccept: ComponentDoc = {
    title: 'archivos aceptados',
    description: `
    <p>Con el atributo <code class="attribute">accept</code> le indicaremos al input que tipo de archivos son los que deb aceptar.</p>
    <p>Para ello de pasaremos como valor un string con los tipos permitidos. Para saber mas acerca de estos tipos, viste el siguiente <a href="https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input/file#Unique_file_type_specifiers" target="_blank">enlace</a>.</p>
    `,

		codeExample: {
			html: `<ca-orm-field>
  <ca-label>Archivo</ca-label>
  <ca-input-file [(ngModel)]="file" id="id" accept="image/*"></ca-input-file>
</ca-form-field>`
		}
  };
  caseNgModelMin: ComponentDoc = {
		title: 'Uso con NgModel a tamaño mínimo',
		codeExample: {
			html: `<ca-form-field>
  <ca-label>Archivo</ca-label>
  <ca-input-file [(ngModel)]="file" id="id" ca-min-component></ca-input-file>
</ca-form-field>`
		}
	};

	ngOnInit(): void {
		this.form = this._fb.group({
			file: ['']
		});

	}
}
