import { Component } from "@angular/core";

@Component({
    templateUrl: 'document-service.view.html',
    styleUrls: ['document-service.view.scss']
  })
  export class DocumentServiceView {

    moduleContent = `
    import { CaDocumentService } from '@global-front-components/common';
    import { HttpClientModule } from '@angular/common/http';
  
    @NgModule({
        ...
      imports: [
        ...
        HttpClientModule,
        ...
      ],
      providers: [ CaDocumentService ],
      ...
    })`;
  }