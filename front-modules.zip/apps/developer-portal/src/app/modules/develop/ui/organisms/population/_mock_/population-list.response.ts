import { PopulationResponse } from "@global-front-components/common";
export const POPULATION_RESPONSE_MOCK: PopulationResponse = {
  "serviceId": "BuscarLocalidadPorCodigoPostalSRV",
  "outputMap": {
      "Lista": [
          {
              "lpobla": "CERCA DE CASCARRILLA",
              "lmunic": "COLLADO VILLALBA",
              "cpobla": "28047001000",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "MADRID",
              "cpostal": "28400"
          },
          {
              "lpobla": "COLLADO VILLALBA",
              "lmunic": "COLLADO VILLALBA",
              "cpobla": "28047000000",
              "codPais": "ES",
              "nHabitantes": 10473,
              "lprovi": "MADRID",
              "cpostal": "28400"
          },
          {
              "lpobla": "DEHESA MUNICIPAL (COLLADO VILLALBA)",
              "lmunic": "COLLADO VILLALBA",
              "cpobla": "28047000200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "MADRID",
              "cpostal": "28400"
          },
          {
              "lpobla": "DEHESA NUEVA (COLLADO VILLALBA)",
              "lmunic": "COLLADO VILLALBA",
              "cpobla": "28047DD0400",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "MADRID",
              "cpostal": "28400"
          },
          {
              "lpobla": "DOMINIO DE FONTENEBRO (COLLADO VILLALBA)",
              "lmunic": "COLLADO VILLALBA",
              "cpobla": "28047001100",
              "codPais": "ES",
              "nHabitantes": 2117,
              "lprovi": "MADRID",
              "cpostal": "28400"
          },
          {
              "lpobla": "EL HORMIGAL (COLLADO VILLALBA)",
              "lmunic": "COLLADO VILLALBA",
              "cpobla": "28047000700",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "MADRID",
              "cpostal": "28400"
          },
          {
              "lpobla": "FUENTEPIZARRO (COLLADO VILLALBA)",
              "lmunic": "COLLADO VILLALBA",
              "cpobla": "28047000600",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "MADRID",
              "cpostal": "28400"
          },
          {
              "lpobla": "LA ESTACION (COLLADO VILLALBA)",
              "lmunic": "COLLADO VILLALBA",
              "cpobla": "28047000500",
              "codPais": "ES",
              "nHabitantes": 38041,
              "lprovi": "MADRID",
              "cpostal": "28400"
          },
          {
              "lpobla": "LAS ERAS (COLLADO VILLALBA)",
              "lmunic": "COLLADO VILLALBA",
              "cpobla": "28047000900",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "MADRID",
              "cpostal": "28400"
          },
          {
              "lpobla": "MIRADOR DE LA SIERRA (COLLADO VILLALBA)",
              "lmunic": "COLLADO VILLALBA",
              "cpobla": "28047000800",
              "codPais": "ES",
              "nHabitantes": 219,
              "lprovi": "MADRID",
              "cpostal": "28400"
          },
          {
              "lpobla": "MONTE EL ANDALUZ (COLLADO VILLALBA)",
              "lmunic": "COLLADO VILLALBA",
              "cpobla": "28047DD0300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "MADRID",
              "cpostal": "28400"
          },
          {
              "lpobla": "URB. LAS SUERTES (COLLADO VILLALBA)",
              "lmunic": "COLLADO VILLALBA",
              "cpobla": "28047DD0100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "MADRID",
              "cpostal": "28400"
          },
          {
              "lpobla": "URBANIZACION PARQUE CORUÑA",
              "lmunic": "COLLADO VILLALBA",
              "cpobla": "28047DD0200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "MADRID",
              "cpostal": "28400"
          }
      ]
  }
}
