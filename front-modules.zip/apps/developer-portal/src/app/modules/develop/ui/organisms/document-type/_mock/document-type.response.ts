import { DocumentTypeResponse } from '@global-front-components/common';

export const DOCUMENT_TYPE_RESPONSE_MOCK: DocumentTypeResponse = {
	serviceId: 'CtaTiposDocumentoBDI',
	outputMap: {
		lista: [
			{
				clave: '1',
				valor: 'NIF'
			},
			{
				clave: '3',
				valor: 'NIE'
			},
			{
				clave: '4',
				valor: 'PASAPORTE'
			},
			{
				clave: '6',
				valor: 'NIF TUTOR'
			},
			{
				clave: '7',
				valor: 'NIF EXTRANJERO'
			},
			{
				clave: '11',
				valor: 'NRT'
			},
			{
				clave: '9999',
				valor: 'DESCONOCIDO'
			}
		]
	}
};
