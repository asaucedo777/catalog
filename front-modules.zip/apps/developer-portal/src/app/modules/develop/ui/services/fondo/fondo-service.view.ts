import { Component } from '@angular/core';

@Component({
	templateUrl: 'fondo-service.view.html',
	styleUrls: ['fondo-service.view.scss']
})
export class FondosServiceView {
	moduleContent = `
  import { CaFondosService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaFondosService ],
    ...
  })`;
}
