import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ValidatorsView } from './validators.view';
import { NifValidatorView } from './nif/nif-validator.view';
import { EmailValidatorView } from './email/email-validator.view';
import { IbanValidatorView } from './iban/iban-validator.view';

const routes: Routes = [
  {
    path: '',
    component: ValidatorsView,
    children: [
      {
        path: 'email',
        component: EmailValidatorView,
      },
      {
        path: 'iban',
        component: IbanValidatorView,
      },
      {
        path: 'nif',
        component: NifValidatorView,
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ValidatorsRoutingModule {}
