import { Component, OnInit } from '@angular/core';
import { CaPlanService } from '@global-front-components/common';
import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';
import { PlanPen, PlanPenRequest, PlanPenResponse } from 'libs/common/src/lib/models/plan.interface';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { PLAN_LIST_RESPONSE_MOCK } from './_mock_/plan-list.response';
@Component({
	templateUrl: 'plan.view.html',
	styleUrls: ['plan.view.scss']
})
export class PlanPenView implements OnInit {
	constructor(private _caPlanPenService: CaPlanService) {}

	planList: PlanPen[];
	selectedPlan: PlanPen;
  codFondo : number;

	casePlanSelect: ComponentDoc = {
		title: 'Componente Seleccionable de Planes de Pensión',
		description: `
        `,
		codeExample: {
			html: `
          <ca-form-field>
            <ca-select
              placeholder="Seleccione Plan de Pensiones"
              keyValue="descripcion"
              [options]="planList"
              [(ngModel)]="selectedPlan"
            ></ca-select>
          </ca-form-field>
          <pre class="mt-2" *ngIf="selectedPlan">
          {{ selectedPlan | json }}
         </pre>`,
			ts: `
          import { Component, OnInit } from '@angular/core';
          import { PlanPen, PlanPenRequest, PlanPenResponse } from 'libs/common/src/lib/models/plan.interface';
          import { CaPlanService } from '@global-front-components/common';

    
          @Component({
            selector: 'plan-example',
            templateUrl: 'plan.view.html',
            styleUrls: ['plan.view.scss']
           
          })
    
          export class PlanPenSelectExampleComponent implements OnInit {
            constructor(private _caPlanPenService: CaPlanService) {}

            planList: PlanPen[];
            selectedPlan: PlanPen;
            codFondo : number;


            ngOnInit(): void {
                this.codFondo = 0;
                const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
                const request: PlanPenRequest = {
                    serviceId: 'ConsultaPlanesPenSrv',
                    inputMap : {
                        codFondo: this.codFondo
                    }
                };
                this._getPlanesPen(endpoint, request).subscribe((response: PlanPenResponse) => {
                    this.planList = response.outputMap.mapacoddescripcion;
                });
            }
          }`
		}
	};
	private _getPlanesPen(endpoint: string, request: PlanPenRequest): Observable<PlanPenResponse> {
		return this._caPlanPenService.getPlanPen(endpoint, request).pipe(
			catchError(() => {
				return of(<PlanPenResponse>PLAN_LIST_RESPONSE_MOCK);
			})
		);
	}

	ngOnInit(): void {
    this.codFondo = 0;
		const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
		const request: PlanPenRequest = {
			serviceId: 'ConsultaPlanesPenSrv',
			inputMap: {
				codFondo: this.codFondo
			}
		};
		this._getPlanesPen(endpoint, request).subscribe((response: PlanPenResponse) => {
			this.planList = response.outputMap.mapacoddescripcion;
		});
	}
}
