import { Component } from '@angular/core';

@Component({
  templateUrl: 'companies-salud-service.view.html',
  styleUrls: ['companies-salud-service.view.scss']
})
export class CompaniesSaludServiceView {
  moduleContent = `
  import { CaCompaniesSaludService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaCompaniesSaludService ],
    ...
  })`;
}
