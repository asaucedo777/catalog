import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CaIbanValidator } from '@global-front-components/common';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
  templateUrl: 'iban-validator.view.html',
  styleUrls: ['iban-validator.view.scss']
})
export class IbanValidatorView implements OnInit {
  constructor(private _formBuilder: FormBuilder) {}
  form: FormGroup;

  caseIban: ComponentDoc = {
    codeExample: {
      html: `
    <form [formGroup]="form">
      <ca-form-field>
        <ca-label>IBAN</ca-label>
        <input type="text" caInput formControlName="iban">
        <ca-error *ngIf="form.get('email').errors?.invalidIban">IBAN inválido</ca-error>
      </ca-form-field>
    </form>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { FormBuilder, FormGroup } from '@angular/forms';
      import { CaIbanValidator } from '@global-front-components/common';
      import { ComponentDoc } from '../../../../../../components/component-doc/component-doc.interface';

      @Component({
        templateUrl: 'iban-validator-example.view.html',
        styleUrls: ['iban-validator-example.view.scss']
      })
      export class IbanValidatorExample implements OnInit {
        constructor(private _formBuilder: FormBuilder) {}
        form: FormGroup;

        ngOnInit() {
          this.form = this._formBuilder.group({
            iban: ['', CaIbanValidator('invalidIban')]
          });
        }
      }`
    }
  }

  ngOnInit() {
    this.form = this._formBuilder.group({
      iban: ['', CaIbanValidator('invalidIban')]
    });
  }
}
