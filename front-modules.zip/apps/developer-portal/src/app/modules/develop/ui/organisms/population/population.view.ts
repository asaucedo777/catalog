import { Component, OnInit } from '@angular/core';
import {
	CaPopulationService,
	Population,
	PopulationRequest,
	PopulationResponse
} from '@global-front-components/common';
import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';
import { catchError, debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
import { combineLatest, Observable, of } from 'rxjs';
import { POPULATION_RESPONSE_MOCK } from './_mock_/population-list.response';
@Component({
	templateUrl: 'population.view.html',
	styleUrls: ['population.view.scss']
})
export class PopulationView implements OnInit {
	constructor(private _CaPopulationService: CaPopulationService) {}
	populations: Population[];
	population: Population;
	populationFound: Population;
	selectedPopulation: Population;
	casePopulationSelect: ComponentDoc = {
		title: 'Componente Seleccionable de Poblacion',
		description: `
    `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-select
          placeholder="Seleccione su poblacion"
          keyValue="lpobla"
          [options]="populations"
          [(ngModel)]="selectedPopulation"
        ></ca-select>
        <pre class="mt-2" *ngIf="selectedPopulation">
          {{ selectedPopulation | json }}
        </pre>
      </ca-form-field>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { Population, PopulationRequest, PopulationResponse, CaPopulationService } from '@global-front-components/common';

      @Component({
        selector: 'population-select-example',
        templateUrl: 'population-select-example.component.html',
        styleUrls: ['population-select-example.component.scss']
      })

      export class PopulationSelectExampleComponent implements OnInit {
        constructor( private _caPopulationsService: CaPopulationsService ) { }

        populations: Population[];
        selectedPopulation: Population;

        ngOnInit() {
          const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
          const request: PopulationRequest = {
            serviceId: 'BuscarLocalidadPorCodigoPostalSRV',
            inputMap: {
              codigoPostal: "28400",
              usuario: "BDI",
              aplicacion: "BDI",
            },
          }
          this._caPopulationService.getPopulation(endpoint, request).subscribe((response: PopulationResponse) => {
            this.populations = response.outputMap.lista;
          })
        }
      }`
		}
	};

	codePopulationTypeahead: ComponentDoc = {
		title: 'Componente Predictivo de poblacion',
		description: `Hay dos formas de emplear este componente predictivo. Por un lado se puede hacer una única llamada al servicio de provincias que nos devuelva toda la lista y filtrar a través del componente,
    o bien, llamar al servicio cada vez que el usuario introduce un valor en el <code class="tag">input</code>.
    <br />
    Primeramente se describe como implementarlo con una única llamada incial.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Poblacion</ca-label>
        <input
          type="text"
          placeholder="Busque una poblacion"
          [caTypeahead]="search"
          [inputFormatter]="populationFormatter"
          [(ngModel)]="population"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="population">
        {{ population | json }}
      </pre>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
      import { Population, PopulationRequest, PopulationResponse, CaPopulationService } from '@global-front-components/common';

      @Component({
        selector: 'population-typeahead-example',
        templateUrl: 'population-typeahead-example.component.html',
        styleUrls: ['population-typeahead-example.component.scss']
      })

      export class PopulationTypeaheadExampleComponent implements OnInit {
        constructor( private _caPopulationService: CaPopulationService ) { }

        populations: Population[];
        population: Population;

        populationFormatter = (x:{lpobla: string}) => x.lpobla;

        search = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            map(term => term === '' ? []
              : this.populations.filter(v => v.lpobla.toLowerCase().indexOf(term.toLowerCase()) > -1))
          )

        ngOnInit() {
          const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
          const request: PopulationRequest = {
            serviceId: 'BuscarLocalidadPorCodigoPostalSRV',
            inputMap: {
              codigoPostal: "28400",
              usuario: "BDI",
              aplicacion: "BDI",
            },
          }
          this._caPopulationService.getPopulation(endpoint, request).subscribe((response: PopulationResponse) => {
            this.populations = response.outputMap.lista;
          })
        }
      }`
		}
	};

	codePopulationTypeaheadService: ComponentDoc = {
		description: `A continuación se describe como implementarlo con llamadas al servicio cuando el usuario interactúe.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Poblacion</ca-label>
        <input
          type="text"
          placeholder="Busque una poblacion"
          [caTypeahead]="searchPopulations"
          [inputFormatter]="populationFormatter"
          [(ngModel)]="populationFound"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="populationFound">
        {{ populationFound | json }}
      </pre>`,
			ts: `
      import { Component } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
      import { Population, PopulationRequest, PopulationResponse, CaPopulationService } from '@global-front-components/common';

      @Component({
        selector: 'population-typeahead-example',
        templateUrl: 'population-typeahead-example.component.html',
        styleUrls: ['population-typeahead-example.component.scss']
      })

      export class PopulationTypeaheadExampleComponent {
        constructor( private _caPopulationService: CaPopulationService ) { }

        populationFound: Population;

        populationFormatter = (x: { lpobla: string }) => x.lpobla;

        searchPopulations = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            switchMap(term => {
              const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
              const request: PopulationRequest = {
                serviceId: 'BuscarLocalidadPorCodigoPostalSRV',
                inputMap: {
                  codigoPostal: "28400",
                  usuario: "BDI",
                  aplicacion: "BDI",
                },
              }
              return this._caPopulationService.getPopulation(endpoint, request)
            })
            ).pipe(map((response: PopulationResponse) => response.outputMap.lista)
          );
      }`
		}
	};
	populationFormatter = (x: { lpobla: string }) => x.lpobla;

	search = (text$: Observable<string>) =>
		text$.pipe(
			debounceTime(300),
			distinctUntilChanged(),
			map((term) =>
				term === '' ? [] : this.populations.filter((v) => v.lpobla.toLowerCase().indexOf(term.toLowerCase()) > -1)
			)
		);

	searchPopulation = (text$: Observable<string>) =>
		text$
			.pipe(
				debounceTime(300),
				distinctUntilChanged(),
				switchMap((term) => {
					const endpoint: string = '/apibdihttpchannel/bindJSONServlet-';
					const request: PopulationRequest = {
						serviceId: 'BuscarLocalidadPorCodigoPostalSRV',
						inputMap: {
							codigoPostal: '28400',
							usuario: 'BDI',
							aplicacion: 'BDI'
						}
					};
					return combineLatest([this._getPopulationsMock(endpoint, request), of(term)]);
				})
			)
			.pipe(
				map(([response, term]) =>
					term === '' ? [] : this.populations.filter((v) => v.lpobla.toLowerCase().indexOf(term.toLowerCase()) > -1)
				)
			);

	private _getPopulationsMock(endpoint: string, request: PopulationRequest): Observable<PopulationResponse> {
		return this._CaPopulationService.getPopulation(endpoint, request).pipe(
			catchError(() => {
				return of(<PopulationResponse>POPULATION_RESPONSE_MOCK);
			})
		);
	}

	ngOnInit() {
		const endpoint: string = '/apibdihttpchannel/bindJSONServlet-';
		const request: PopulationRequest = {
			serviceId: 'BuscarLocalidadPorCodigoPostalSRV',
			inputMap: {
				codigoPostal: '28400',
				usuario: 'BDI',
				aplicacion: 'BDI'
			}
		};
		this._getPopulationsMock(endpoint, request).subscribe((response: PopulationResponse) => {
			this.populations = response.outputMap.Lista;
		});
	}
}
