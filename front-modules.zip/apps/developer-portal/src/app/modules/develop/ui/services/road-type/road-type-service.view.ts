import { Component } from "@angular/core";

@Component({
  templateUrl: "road-type-service.view.html",
  styleUrls: ["road-type-service.view.scss"],
})
export class RoadTypeServiceView {
  moduleContent = `
  import { CaRoadTypeService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaRoadTypeService ],
    ...
  })`;
}
