import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: 'input.view.html',
	styleUrls: ['input.view.scss']
})
export class InputView implements OnInit {
	constructor(private formBuilder: FormBuilder) {}

	public formBlur: FormGroup;
	public formFocus: FormGroup;
  public importModule = `import { CaFormFieldModule, CaInputModule } from '@global-front-components/ui';`;

  caseSimple: ComponentDoc = {
    title: 'Uso simple',
    codeExample: {
      html: `<ca-form-field class="ca-form-field-1">
  <ca-label>Nombre</ca-label>
  <input caInput placeholder="Nombre" type="text"/>
</ca-form-field>`
    }
  }

  caseRequired: ComponentDoc = {
    title: `Estado requerido`,
    description: `Siempre que nuestro elemento sea requerido a través del atributo <code class="attribute">required</code> se marcara
    como tal a nivel visual.`,
    codeExample: {
      html: `<ca-form-field>
  <ca-label>Nombre</ca-label>
  <input
    caInput
    type="text"
    placeholder="Introduce tu nombre"
    required />
</ca-form-field>`
    }
  }

  caseDisabled: ComponentDoc = {
    title: `Estado disabled`,
    description: `Siempre que nuestro elemento este deshabilitado a través del atributo <code class="attribute">disabled</code>
    se marcara como tal a nivel visual.`,
    codeExample: {
      html: `<ca-form-field>
  <ca-label>Nombre de tu mascota</ca-label>
  <input
    caInput
    type="text"
    placeholder="Introduce el nombre de tu mascota"
    disabled
    value="Orejas"/>
</ca-form-field>`
    }
  }

  caseReadOnly: ComponentDoc = {
    title: `Estado readonly`,
    description: `Siempre que nuestro elemento este en modo solo lectura a través del atributo
    <code class="attribute">readonly</code> se marcara como tal a nivel visual.`,
    codeExample: {
      html: `<ca-form-field>
  <ca-label>Pet Name</ca-label>
  <input
    caInput
    type="text"
    placeholder="Enter your pet's name"
    readonly
    value="Frida" />
</ca-form-field>`
    }
  }

  caseReactiveForm: ComponentDoc = {
    title: `Uso en formularios reactivos`,
    description: `<p>El componente <code class="tag">ca-input</code> se puede utilizar dentro de formularios reactivos haciendo uso de la directiva
    <code class="attribute">formControlName</code> perteneciente al modulo <code class="module">@angular/forms</code></p>`,
    codeExample: {
      html: `<form [formGroup]="formBlur" class="form">
  <ca-form-field>
    <ca-label>Correo electrónico</ca-label>
    <input
      caInput
      formControlName="email"
      placeholder="Email"
      type="text"/>
    <ca-hint>Introduce tu dirección de correo</ca-hint>
    <ca-error *ngIf="formBlur.controls['email'].errors?.required">El campo es requerido</ca-error>
    <ca-error *ngIf="formBlur.controls['email'].errors?.minlength">El campo debe tener 6 carácteres como mínimo</ca-error>
    <ca-error *ngIf="formBlur.controls['email'].errors?.email">Introduce una dirección de correo valida</ca-error>
  </ca-form-field>
</form>`,
      ts: `import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'ca-example-view',
  templateUrl: './example-view.component.html',
  styleUrls: ['./example-view.component.scss']
})
export class FormFieldPageComponent implements OnInit {
  constructor(private formBuilder: FormBuilder) {}

  public formBlur: FormGroup;

  private _formBlurBuilder(): void {
    this.formBlur = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email, Validators.minLength(6)]]
    });
  }

  ngOnInit(): void {
    this._formBlurBuilder();
  }
}`
    }
  }

	ngOnInit(): void {
		this.formBlur = this.formBuilder.group({
			email: ['', [Validators.required, Validators.email, Validators.minLength(6)]]
		});
		this.formFocus = this.formBuilder.group({
			email: ['', [Validators.required, Validators.email, Validators.minLength(6)]]
		});
	}
}
