import { Component } from '@angular/core';

@Component({
  templateUrl: 'margin.view.html'
})
export class MarginView {

  columnClassList = [
    {type: 'Column', title: 'Columnas', listItem: [
      {className: 'ca-container', description: 'Contenedor con un ancho predefinido de 1250px'},
      {className: 'ca-container-fluid', description: 'Contenedor con un ancho del 100%'},
      {className: 'ca-row', description: 'Clase predefinida para ser utilizadas con columnas'},
      {className: 'ca-no-gutters', description: 'Clase predefinida para eliminar los margenes y paddings'}
    ]}
  ];

}