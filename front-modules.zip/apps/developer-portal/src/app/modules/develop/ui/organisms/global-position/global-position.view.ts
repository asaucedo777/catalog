import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import {
  GlobalPositionRequest,
  GlobalPositionResponse,
  CaGlobalPositionService,
  CaNifValidator,
  GeneralInsurance
} from '@global-front-components/common';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { GLOBAL_POSITION_RESPONSE_MOCK } from './_mock_/global-position.response';

@Component({
  templateUrl: 'global-position.view.html',
  styleUrls: ['global-position.view.scss']
})
export class GlobalPositionView implements OnInit {
  constructor(
    private _formBuilder: FormBuilder,
    private _globalPositionService: CaGlobalPositionService
  ) {}

  form: FormGroup;
  generalInsurances: Array<GeneralInsurance>;

  caseExample: ComponentDoc = {
    title: 'Posición global',
    codeExample: {
      html:`
    <form [formGroup]="form">
      <div class="d-flex form__container mr-5">
        <div class="form__input">
          <ca-form-field>
            <ca-label>Documento(NIF)</ca-label>
            <input type="text" caInput required formControlName="documento">
            <ca-error *ngIf="form.get('documento').errors?.invalidNif">NIF inválido</ca-error>
            <ca-error *ngIf="form.get('documento').errors?.required">Campo obligatorio</ca-error>
          </ca-form-field>
        </div>
        <button class ="form__button ml-2" ca-button [disabled]="form.invalid" (click)="searchGlobalPoisition(form.get('documento').value)">
          <span>Buscar</span>
        </button>
      </div>
    </form>
    <pre class="mt-2 general-insurances" *ngIf="generalInsurance">{{ generalInsurance | json }}</pre>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { FormBuilder, FormGroup, Validators } from '@angular/forms';
      import {
        GlobalPositionRequest,
        GlobalPositionResponse,
        CaGlobalPositionService,
        CaNifValidator,
        GeneralInsurance
      } from '@global-front-components/common';

      @Component({
        templateUrl: 'global-position.view.html',
        styleUrls: ['global-position.view.scss']
      })
      export class GlobalPositionView implements OnInit {
        constructor(
          private _formBuilder: FormBuilder,
          private _globalPositionService: CaGlobalPositionService
        ) {}

        form: FormGroup;
        generalInsurances: Array<GeneralInsurance>;

        searchGlobalPoisition(documento: string): void {
          const endpoint = '/apibdihttpchannel/bindJSONServlet';
          const request: GlobalPositionRequest = {
            serviceId: 'PosicionGlobalSRV',
            inputMap: {
              documento: documento
            }
          }
          this._globalPositionService.getGlobalPosition(endpoint, request).subscribe((response: GlobalPositionResponse) => {
            this.generalInsurances = response.outputMap.segurosGenerales;
          });
        }

        ngOnInit() {
          this.form = this._formBuilder.group({
            documento: ['',[CaNifValidator('invalidNif'),Validators.required]]
          });
        }
      }`,
      css: `
      .form {
        &__input {
          width: 200px;
        }

        &__button {
          height: 32px;
          margin-top: 31px;
        }
      }

      .general-insurances {
        background-color: #ffffff;
        color: #000000;
      }`
    }
  }

  private _getGlobalPositionMock(url: string, request: GlobalPositionRequest): Observable<GlobalPositionResponse> {
    return this._globalPositionService.getGlobalPosition(url, request).pipe(catchError(() => {
      return of(<GlobalPositionResponse>GLOBAL_POSITION_RESPONSE_MOCK);
    }))
  }

  searchGlobalPoisition(documento: string): void {
    const endpoint = '/apibdihttpchannel/bindJSONServlet';
    const request: GlobalPositionRequest = {
      serviceId: 'PosicionGlobalSRV',
      inputMap: {
        documento: documento
      }
    }
    this._getGlobalPositionMock(endpoint, request).subscribe((response: GlobalPositionResponse) => {
      this.generalInsurances = response.outputMap.segurosGenerales;
    });
  }

  ngOnInit() {
    this.form = this._formBuilder.group({
      documento: ['',[CaNifValidator('invalidNif'),Validators.required]]
    });
  }
}
