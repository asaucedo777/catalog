import { OnInit, ViewChild } from '@angular/core';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CaInputModalFilterValue, CaInputModalFilterConfig} from '@global-front-components/salud';
import { SaludModalComponent } from './exmple-modal-policy/salud-modal.component';
import { InputModalFilterExampleService } from './input-modal-filter.service';
import { Observable } from 'rxjs';
import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';
import { CaInputModalFilterComponent } from 'libs/salud/src/lib/input-modal-filter/input-modal-filter.component';

@Component({
	templateUrl: 'input-modal-filter.view.html',
	styleUrls: ['input-modal-filter.view.scss']
})
export class InputModalFilterView implements OnInit {
	constructor(
    private _formBuilder: FormBuilder,
    private _inputModalFilterExampleService: InputModalFilterExampleService
  ) {}
  @ViewChild(CaInputModalFilterComponent, { static: false }) caInputModalFilter: CaInputModalFilterComponent;
  importModule = `import { CaInputModalService } from '@global-front-components/salud';`;
	form: FormGroup;
	formOnlySearch: FormGroup;
  policyDefaultValue: CaInputModalFilterValue = {
		inputSearch: null,
		inputResult: null
	};
  policyDefaultSingleValue: CaInputModalFilterValue = {
		inputSearch: null
	};
	labelName = 'Póliza';
  modalConfig: CaInputModalFilterConfig = {
		component: SaludModalComponent,
		modalConfig: {
			title: 'Buscador de pólizas',
			windowDrag: false,
			backdropClick: false,
      panelClass: 'input-modal-filter-example'
		}
	};
  searchReference = 'policyNumber';
  resultReference = 'name';
  $policyResult: Observable<any>
  caseSimple: ComponentDoc = {
    title: `Uso simple`,
    codeExample: {
      html: `<ca-input-modal-filter
  [value]="policyDefaultValue"
  [labelName]="labelName"
  [inputModalFilterConfig]="modalConfig"
  [searchReference]="searchReference"
  [resultReference]="resultReference"
  [observableResult]="policyResult$">
</ca-input-modal-filter>`,
      ts: `import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CaInputModalFilterValue, CaInputModalFilterConfig} from '@global-front-components/salud';
import { SaludModalComponent } from './salud-modal/salud-modal.component';
import { InputModalFilterExampleService } from './input-search.service';
import { Observable } from 'rxjs';

@Component({
  templateUrl: 'input-search.view.html',
  styleUrls: ['input-search.view.scss']
})
export class InputModalFilterExampleView implements OnInit {
  constructor(private _inputModalFilterExampleService: InputModalFilterExampleService) {}

  policyDefaultValue: CaInputModalFilterValue = {
    inputSearch: '',
		inputResult: ''
  };
  labelName = 'Póliza';
  modalConfig: CaInputModalFilterConfig = {
    component: SaludModalComponent,
    modalConfig: {
      title: 'Buscador de pólizas',
      windowDrag: false,
      backdropClick: false,
      panelClass: 'input-modal-filter-example'
    }
  };
  searchReference = 'policyNumber';
  resultReference = 'name';
  $policyResult: Observable<any>

  ngOnInit() {
    this.policyResult$ = this._inputModalFilterExampleService.getPolicy()
  }
}
`
    }
  }

    caseReactive: ComponentDoc = {
  title: `Formulario reactivo`,
    codeExample: {
      html: `<form [formGroup]="form">
  <ca-input-modal-filter
    formControlName="policy"
    [labelName]="labelName"
    [inputModalFilterConfig]="modalConfig"
    [searchReference]="searchReference"
    [resultReference]="resultReference"
    [observableResult]="policyResult$">
  </ca-input-modal-filter>
</form>`,
      ts: `import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CaInputModalFilterValue, CaInputModalFilterConfig} from '@global-front-components/salud';
import { SaludModalComponent } from './salud-modal/salud-modal.component';
import { InputModalFilterExampleService } from './input-search.service';
import { Observable } from 'rxjs';

@Component({
  templateUrl: 'input-search.view.html',
  styleUrls: ['input-search.view.scss']
})
export class InputModalFilterExampleView implements OnInit {
  constructor(
    private _formBuilder: FormBuilder,
    private _inputModalFilterExampleService: InputModalFilterExampleService
  ) {}

  form: FormGroup;
  policyDefaultValue: CaInputModalFilterValue = {
    inputSearch: '',
    inputResult: ''
  };
  labelName = 'Póliza';
  modalConfig: CaInputModalFilterConfig = {
    component: SaludModalComponent,
    modalConfig: {
      title: 'Buscador de pólizas',
      windowDrag: false,
      backdropClick: false,
      panelClass: 'input-modal-filter-example'
    }
  };
  searchReference = 'policyNumber';
  resultReference = 'name';
  $policyResult: Observable<any>

  createForm() {
    this.form = this._formBuilder.group({
      policy: [this.policyDefaultValue]
    });
  }

  ngOnInit() {
    this.createForm();
    this.policyResult$ = this._inputModalFilterExampleService.getPolicy()
  }
}
`
    }
  }

  caseOnlySearch: ComponentDoc = {
    title: `Input de búsqueda`,
      codeExample: {
        html: `<form [formGroup]="form">
    <ca-input-modal-filter
      formControlName="policy"
      [labelName]="labelName"
      [inputModalFilterConfig]="modalConfig"
      [searchReference]="searchReference"
      [resultReference]="resultReference"
      [observableResult]="policyResult$"
      searchOnly="true">
    </ca-input-modal-filter>
  </form>`,
        ts: `import { OnInit } from '@angular/core';
  import { Component } from '@angular/core';
  import { FormBuilder, FormGroup } from '@angular/forms';
  import { CaInputModalFilterValue, CaInputModalFilterConfig} from '@global-front-components/salud';
  import { SaludModalComponent } from './salud-modal/salud-modal.component';
  import { InputModalFilterExampleService } from './input-search.service';
  import { Observable } from 'rxjs';
  
  @Component({
    templateUrl: 'input-search.view.html',
    styleUrls: ['input-search.view.scss']
  })
  export class InputModalFilterExampleView implements OnInit {
    constructor(
      private _formBuilder: FormBuilder,
      private _inputModalFilterExampleService: InputModalFilterExampleService
    ) {}
  
    form: FormGroup;
    policyDefaultValue: CaInputModalFilterValue = {
      inputSearch: ''
    };
    labelName = 'Póliza';
    modalConfig: CaInputModalFilterConfig = {
      component: SaludModalComponent,
      modalConfig: {
        title: 'Buscador de pólizas',
        windowDrag: false,
        backdropClick: false,
        panelClass: 'input-modal-filter-example'
      }
    };
    searchReference = 'policyNumber';
    resultReference = 'name';
    $policyResult: Observable<any>
  
    createForm() {
      this.form = this._formBuilder.group({
        policy: [this.policyDefaultValue]
      });
    }
  
    ngOnInit() {
      this.createForm();
      this.policyResult$ = this._inputModalFilterExampleService.getPolicy()
    }
  }
  `
      }
    }
  

  exampleModal: ComponentDoc = {
    title: `Ejemplo modal`,
    codeExample: {
      html: `<div class="container p-0">
  <div class="ca-table__container">
    <div class="ca-table__actions d-flex justify-content-end">
      <ca-form-field class="filter">
        <ca-label [visible]="false">Filtro</ca-label>
        <ca-icon>search</ca-icon>
        <input caInput type="text" placeholder="" [(ngModel)]="queryFilter" (ngModelChange)="onFilter($event)" />
      </ca-form-field>
    </div>
    <ng-container *ngIf="displayedTableData.length > 0; else noresult">
      <table cdk-table [dataSource]="displayedTableData" class="ca-table">
        <ng-container *ngFor="let column of columns; let i = index" [cdkColumnDef]="column.field">
          <th cdk-header-cell *cdkHeaderCellDef class="ca-table__header">
            <div class="ca-table__header-container justify-content-start">
              <span class="ca-table__header-wrapper">
                <span class="ca-table__header-text">{{ column.value }}</span>
              </span>
            </div>
          </th>
          <td cdk-cell *cdkCellDef="let row; let i = index" class="ca-table__cell">
            <ng-container *ngIf="column.field !== 'selectable'; else selectableCell">
              <div class="ca-table__cell-container">
                <span class="ca-table__cell-text">
                  {{ row[column.field] }}
                </span>
              </div>
            </ng-container>
            <ng-template #selectableCell>
              <ca-radio-button
                [value]="i"
                [checked]="isSelectedRow(row)">
              </ca-radio-button>
            </ng-template>
          </td>
        </ng-container>
        <thead class="ca-table__thead">
          <tr
            cdk-header-row
            *cdkHeaderRowDef="displayedColumns"
            class="ca-table__row ca-table__row--bordered ca-table__row--clean"
          ></tr>
        </thead>
        <tbody class="ca-table__tbody">
          <tr
            cdk-row *cdkRowDef="let row; columns: displayedColumns; let i = index"
            class="ca-table__row"
            [class.ca-table__row--selected]="isSelectedRow(row)"
            (click)="onSelectedRow(row, i)">
          </tr>
        </tbody>
      </table>
    </ng-container>
  </div>
  <ng-template #noresult>
    <p>No se han encontrado resultados</p>
  </ng-template>
  <div class="d-flex justify-content-between mt-3">
    <button ca-button-secondary (click)="closeDialog()">Cancelar</button>
    <button ca-button (click)="closeDialog()" [disabled]="!selectedRow">Seleccionar</button>
  </div>
</div>
`,
      ts: `import { Component, ChangeDetectorRef } from '@angular/core';
import { CaModalOverlayRef } from '@global-front-components/ui';
import { CaFilterPipe } from '@global-front-components/common';
import { BehaviorSubject, Subject } from 'rxjs';
import { debounceTime, takeUntil } from 'rxjs/operators';

interface TableColumn {
  id: number;
  field: string;
  value: string;
}

@Component({
  templateUrl: './salud-modal.component.html',
  styleUrls: ['./salud-modal.component.scss'],
  providers: [ CaFilterPipe ]
})
export class SaludModalComponent {
  constructor(
    private _caModalOverlayRef: CaModalOverlayRef<SaludModalComponent>,
    private _caFilterPipe: CaFilterPipe,
    private _changeDetectorRef: ChangeDetectorRef
  ) {}

  private _destroy$: Subject<void> = new Subject();
  private _filterChange$: BehaviorSubject<string> = new BehaviorSubject(undefined);
  displayedColumns: string[] = [];
  displayedTableData: any[] = [];
  queryFilter = '';
  selectedRow: any;
  columns: TableColumn[] = [
    {
      id: 0,
      field: 'selectable',
      value: ''
    },
    {
      id: 0,
      field: 'policyNumber',
      value: 'Número de Póliza'
    },
    {
      id: 1,
      field: 'name',
      value: 'Nombre'
    }
  ];

  tableData = [
    {
      policyNumber: 33300100,
      name: 'M.P.C.G.A. DE VALENCIA'
    },
    {
      policyNumber: 44400100,
      name: 'M.P.C.G.A. DE MINGLANILLA'
    },
    {
      policyNumber: 55500100,
      name: 'M.P.C.G.A. DE BILBAO'
    },
    {
      policyNumber: 66600100,
      name: 'M.P.C.G.A. DE AILEO'
    }
  ];

  private _setDisplayedColumns(): void {
    this.displayedColumns = this.columns.map((column) => column.field);
  }

  isSelectedRow(row): boolean {
    return this.selectedRow && Object.keys(this.selectedRow).every((key) => this.selectedRow[key] === row[key]);
  }

  onSelectedRow(row: any): void {
    if (!this.isSelectedRow(row)) {
      this.selectedRow = row;
    }
  }

  onFilter(query: string): void {
    this._filterChange$.next(query);
  }

  closeDialog(): void {
    this._caModalOverlayRef.close(this.selectedRow);
  }

  ngOnInit() {
    this._setDisplayedColumns();
    this.displayedTableData= this.tableData;
    this._filterChange$.pipe(takeUntil(this._destroy$),debounceTime(200)).subscribe((value) => {
      this.displayedTableData = this._caFilterPipe.transform(this.tableData, value);
      this._changeDetectorRef.markForCheck();
    })
  }

  ngOnDestroy() {
    this._destroy$.next();
    this._destroy$.complete();
  }
}
`,
    css: `.ca-table {
  &__container {
    display: flex;
    flex-direction: column;
    height: 100%;
  }

  &__actions {
    padding-bottom: 4px;
    margin-bottom: 8px;

    .filter {
      width: 206px;
    }
  }

  width: 100%;
  font-size: 14px;
  border-collapse: collapse;
  border: 1px solid #d0d2d3;
  &__row {
    &:nth-child(odd) {
      background-color: #eef2f5;
    }
    &:nth-child(even) {
      background-color: #ffffff;
    }
    &:hover {
      background-color: #dcf1f0;
    }
    &--bordered {
      border-bottom: 1px solid #d0d2d3;
    }
    &--clean {
      &:nth-child(odd) {
        background-color: #ffffff;
      }
      &:hover {
        background-color: inherit;
      }
    }
    &--selected:nth-child(odd),
    &--selected:nth-child(even) {
      background-color: #ccede9;
    }
  }
  &__header {
    padding: 6px 16px;
    text-align: left;
    background-color: #ffffff;

    &-container {
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    &-text {
      white-space: nowrap;
    }
  }
  &__cell {
    cursor: pointer;
    height: 32px;
    position: relative;
    padding: 0 16px;
    vertical-align: middle;
    max-width: 90px;
    &-container {
      overflow: hidden;
      text-overflow: ellipsis;
    }
    &-text {
      white-space: nowrap;
    }
  }
}
`
    }
  }

  exampleService: ComponentDoc = {
    title: `Ejemplo servicio`,
    codeExample: {
      ts: `import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({providedIn: 'root'})
export class InputModalFilterExampleService {
  constructor() { }

  getPolicy(): Observable<any> {
    return of({
      policyNumber: 33300100,
      name: 'M.P.C.G.A. DE VALENCIA'
    })
  }
}
`
    }
  }

	createForm() {
		this.form = this._formBuilder.group({
			policy: [this.policyDefaultValue]
		});
		this.formOnlySearch = this._formBuilder.group({
			policy: [this.policyDefaultSingleValue]
		});
	}

  reset() {
    this.caInputModalFilter.formInputSearch.get('inputSearch').setValue('');
  }


	ngOnInit() {
		this.createForm();
    this.$policyResult = this._inputModalFilterExampleService.getPolicy()
	}
}
