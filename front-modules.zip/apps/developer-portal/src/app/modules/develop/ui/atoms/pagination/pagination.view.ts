import { Component } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

const COUNTRIES = [
  {
    name: 'Russia',
    flag: 'RU',
    area: 17098242
  },
  {
    name: 'France',
    flag: 'FR',
    area: 640679
  },
  {
    name: 'Germany',
    flag: 'DE',
    area: 357114
  },
  {
    name: 'Portugal',
    flag: 'PT',
    area: 92090
  },
  {
    name: 'Spain',
    flag: 'ES',
    area: 505990
  },
  {
    name: 'Japan',
    flag: 'JP',
    area: 377973
  },
  {
    name: 'Brazil',
    flag: 'BR',
    area: 8515767
  },
  {
    name: 'Mexico',
    flag: 'MX',
    area: 1964375
  },
  {
    name: 'United States',
    flag: 'US',
    area: 9629091
  },
  {
    name: 'Italia',
    flag: 'IT',
    area: 301338
  },
  {
    name: 'Reino Unido',
    flag: 'GB',
    area: 242495
  },
  {
    name: 'Irlanda',
    flag: 'IE',
    area: 70274
  }
];

@Component({

  templateUrl: 'pagination.view.html',
  styleUrls: ['pagination.view.scss']
})
export class PaginationView {
  constructor() { }
  importModule = `import { CaPaginationModule } from '@global-front-components/ui';`;

  casePagination: ComponentDoc = {
    title: `Paginación`,
    description: `Ejemplo de paginación de un componente tabla.`,
    codeExample: {
      html: `<table>
  <thead>
    <tr>
      <th scope="col">Country</th>
      <th scope="col">Area</th>
    </tr>
  </thead>
  <tbody>
    <tr *ngFor="let country of countries">
      <td>
        <img
          [src]="
            'https://upload.wikimedia.org/wikipedia/commons/' +
            country.flag
          "
          class="mr-2"
          style="width: 20px"
        />
        {{ country.name }}
      </td>
      <td>{{ country.area | number }}</td>
    </tr>
  </tbody>
</table>
<ca-pagination
  [dataSize]="collectionSize"
  [(page)]="page"
  [pageSize]="pageSize"
></ca-pagination>`,
      ts: `import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

const COUNTRIES = [
  {
    name: 'Russia',
    flag: 'RU',
    area: 17098242
  },
  {
    name: 'France',
    flag: 'FR',
    area: 640679
  },
  {
    name: 'Germany',
    flag: 'DE',
    area: 357114
  },
  {
    name: 'Portugal',
    flag: 'PT',
    area: 92090
  },
  {
    name: 'Spain',
    flag: 'ES',
    area: 505990
  },
  {
    name: 'Japan',
    flag: 'JP',
    area: 377973
  },
  {
    name: 'Brazil',
    flag: 'BR',
    area: 8515767
  },
  {
    name: 'Mexico',
    flag: 'MX',
    area: 1964375
  },
  {
    name: 'United States',
    flag: 'US',
    area: 9629091
  },
  {
    name: 'Italia',
    flag: 'IT',
    area: 301338
  },
  {
    name: 'Reino Unido',
    flag: 'GB',
    area: 242495
  },
  {
    name: 'Irlanda',
    flag: 'IE',
    area: 70274
  },
  {
    name: 'China',
    flag: 'CN',
    area: 9596960
  }
];

@Component({
  selector: 'ca-example-view',
  templateUrl: './example-view.component.html',
  styleUrls: ['./example-view.component.scss']
})
export class ExampleViewComponent implements OnInit {
  constructor() {}

  page = 1;
  pageSize = 1;
  collectionSize = COUNTRIES.length;
  get countries() {
    return COUNTRIES.map((country, i) => ({ id: i + 1, ...country })).slice(
      (this.page - 1) * this.pageSize,
      (this.page - 1) * this.pageSize + this.pageSize
    );
  }
}`
    }
  }
  casePaginationMinimum: ComponentDoc = {
    title: `Paginación`,
    description: `Ejemplo de paginación de un componente tabla con tamaño mínimo.`,
    codeExample: {
      html: `<table>
  <thead>
    <tr>
      <th scope="col">Country</th>
      <th scope="col">Area</th>
    </tr>
  </thead>
  <tbody>
    <tr *ngFor="let country of countries">
      <td>
        <img
          [src]="
            'https://upload.wikimedia.org/wikipedia/commons/' +
            country.flag
          "
          class="mr-2"
          style="width: 20px"
        />
        {{ country.name }}
      </td>
      <td>{{ country.area | number }}</td>
    </tr>
  </tbody>
</table>
<ca-pagination
  ca-min-component
  [dataSize]="collectionSize"
  [(page)]="page"
  [pageSize]="pageSize"
></ca-pagination>`,
      ts: `import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

const COUNTRIES = [
  {
    name: 'Russia',
    flag: 'RU',
    area: 17098242
  },
  {
    name: 'France',
    flag: 'FR',
    area: 640679
  },
  {
    name: 'Germany',
    flag: 'DE',
    area: 357114
  },
  {
    name: 'Portugal',
    flag: 'PT',
    area: 92090
  },
  {
    name: 'Spain',
    flag: 'ES',
    area: 505990
  },
  {
    name: 'Japan',
    flag: 'JP',
    area: 377973
  },
  {
    name: 'Brazil',
    flag: 'BR',
    area: 8515767
  },
  {
    name: 'Mexico',
    flag: 'MX',
    area: 1964375
  },
  {
    name: 'United States',
    flag: 'US',
    area: 9629091
  },
  {
    name: 'Italia',
    flag: 'IT',
    area: 301338
  },
  {
    name: 'Reino Unido',
    flag: 'GB',
    area: 242495
  },
  {
    name: 'Irlanda',
    flag: 'IE',
    area: 70274
  },
  {
    name: 'China',
    flag: 'CN',
    area: 9596960
  }
];

@Component({
  selector: 'ca-example-view',
  templateUrl: './example-view.component.html',
  styleUrls: ['./example-view.component.scss']
})
export class ExampleViewComponent implements OnInit {
  constructor() {}

  page = 1;
  pageSize = 1;
  collectionSize = COUNTRIES.length;
  get countries() {
    return COUNTRIES.map((country, i) => ({ id: i + 1, ...country })).slice(
      (this.page - 1) * this.pageSize,
      (this.page - 1) * this.pageSize + this.pageSize
    );
  }
}`
    }
  }
  page = 1;
  pageSize = 1;
  collectionSize = COUNTRIES.length;
  get countries() {
    return COUNTRIES.map((country, i) => ({ id: i + 1, ...country })).slice(
      (this.page - 1) * this.pageSize,
      (this.page - 1) * this.pageSize + this.pageSize
    );
  }
}
