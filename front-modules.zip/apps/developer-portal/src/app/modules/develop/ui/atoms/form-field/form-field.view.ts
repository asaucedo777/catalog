import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: 'form-field.view.html',
	styleUrls: ['form-field.view.scss']
})
export class FormFieldView implements OnInit {
	constructor(private formBuilder: FormBuilder) {}

	formBlur: FormGroup;
	formFocus: FormGroup;
	formCustom: FormGroup;
	importModule = `import { CaFormFieldModule } from '@global-front-components/ui';`;

  caseSimple: ComponentDoc = {
    title: `Uso simple`,
    codeExample: {
      html: `<ca-form-field class="ca-form-field-1">
  <ca-label>Nombre</ca-label>
  <input caInput placeholder="Nombre" type="text"/>
</ca-form-field>`
    }
  }

  caseNoLabel: ComponentDoc = {
    title: `Uso sin label`,
    description: `Si queremos añadir un componente <code class="tag">ca-form-field</code> pero no queremos asociar un label al mismo,
    por cuestiones de accesibilidad el <code class="tag">label</code> siempre debe renderizarse a nivel de DOM así que lo que haremos
    será ocultar el mismo a través del atributo <code class="attribute">visible</code> de la directiva <code class="tag">ca-label</code>`,
    codeExample: {
      html: `<ca-form-field class="ca-form-field-1">
  <ca-label [visible]="false">Nombre</ca-label>
  <input caInput type="text" placeholder="Introduce tu nombre"/>
</ca-form-field>`
    }
  }

  caseHelpMessage: ComponentDoc = {
    title: `Uso del mensaje de ayuda`,
    description: `Podemos mostrar un mensaje de ayuda en la parte inferior del componente para ello usaremos la directiva
    <code class="tag">ca-hint</code> como si de un elemento HTML se tratase.`,
    codeExample: {
      html: `<ca-form-field>
  <ca-label>Email</ca-label>
  <input
    caInput
    type="text"
    value="miguel.martinez@gft.com"/>
  <ca-hint>usuario@dominio.ext</ca-hint>
</ca-form-field>`
    }
  }

  caseIcon: ComponentDoc = {
    title: `Uso de iconos`,
    description: `Podemos mostrar un icono tanto a la izquierda como a la derecha del componente para ello usaremos la directiva
    <code class="tag">ca-icon</code> como si de un elemento HTML se tratase.`,
    codeExample: {
      html: `<ca-form-field class="ca-form-field-1">
  <ca-label>Busqueda</ca-label>
  <ca-icon>search</ca-icon>
  <input caInput placeholder="Busqueda por nombre" type="text"/>
  <ca-icon>close</ca-icon>
</ca-form-field>`
    }
  }

  caseErrorMessageOnBlur: ComponentDoc = {
    title: `Uso en formulario reactivo con validacion al perder el foco del componente`,
    description: `<p>El componente <code class="tag">ca-form-field</code> permite controlar cuando se debe activar la validación
    del componente interno y mostrar mensajes de error en función del existo o fallo de la validación.</p>
    <p>Por defecto la validación se mostrará al perder el foco del componente.</p>
    <p>Si queremos mostrar un mensaje de error para ello usaremos la directiva <code class="tag">ca-error</code> como si
    de un elemento HTML se tratase.</p>`,
    codeExample: {
      html: `<form [formGroup]="formBlur" class="form">
  <ca-form-field>
    <ca-label>Correo electrónico</ca-label>
    <input
      caInput
      formControlName="email"
      placeholder="Email"
      type="text"/>
    <ca-hint>Introduce tu dirección de correo</ca-hint>
    <ca-error *ngIf="formBlur.controls['email'].errors?.required">El campo es requerido</ca-error>
    <ca-error *ngIf="formBlur.controls['email'].errors?.minlength">El campo debe tener 6 caracteres</ca-error>
    <ca-error *ngIf="formBlur.controls['email'].errors?.email">Introduce una dirección de correo valida</ca-error>
  </ca-form-field>
</form>`,
      ts: `import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'ca-example-view',
  templateUrl: './example-view.component.html',
  styleUrls: ['./example-view.component.scss']
})
export class FormFieldPageComponent implements OnInit {
  constructor(private formBuilder: FormBuilder) {}

  public formBlur: FormGroup;

  private _formBlurBuilder(): void {
    this.formBlur = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email, Validators.minLength(6)]]
    });
  }

  ngOnInit(): void {
    this._formBlurBuilder();
  }
}`
    }
  }

  caseErrorMessageOnFocus: ComponentDoc = {
    title: `Uso en formulario reactivo con validacion al hacer el foco del componente`,
    description: `<p>El componente <code class="tag">ca-form-field</code> permite controlar cuando se debe activar la validación
    del componente interno y mostrar mensajes de error en función del existo o fallo de la validación.</p>
    <p>Si queremos validar el componente al hacer foco sobre el mismo usaremos el atributo <code class="attribute">validate</code> y
    le pasaremos el valor onFocus.</p>
    <p>Si queremos mostrar un mensaje de error para ello usaremos la directiva <code class="tag">ca-error</code> como si
    de un elemento HTML se tratase.</p>`,
    codeExample: {
      html: `<form [formGroup]="formFocus" class="form">
  <ca-form-field validate="onFocus">
    <ca-label>Correo electrónico</ca-label>
    <input
      caInput
      formControlName="email"
      placeholder="Email"
      type="text"/>
    <ca-hint>Introduce tu dirección de correo</ca-hint>
    <ca-error *ngIf="formFocus.controls['email'].errors?.required">El campo es requerido</ca-error>
    <ca-error *ngIf="formFocus.controls['email'].errors?.minlength">El campo debe tener 6 caracteres</ca-error>
    <ca-error *ngIf="formFocus.controls['email'].errors?.email">Introduce una dirección de correo valida</ca-error>
  </ca-form-field>
</form>`,
      ts: `import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'ca-example-view',
  templateUrl: './example-view.component.html',
  styleUrls: ['./example-view.component.scss']
})
export class ExampleViewComponent implements OnInit {
  constructor(private formBuilder: FormBuilder) {}

  public formFocus: FormGroup;

  private _formFocusBuilder(): void {
    this.formFocus = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email, Validators.minLength(6)]]
    });
  }

  ngOnInit(): void {
    this._formFocusBuilder();
  }
}`
    }
  }
  caseErrorProgramatic: ComponentDoc = {
    title: `Setar errores de manera programática`,
    description: `<p>Podemos setara Errores de manera programática haciendo uso de los formularios reactivos, esta acción mostrará el control como invalido aunque no haya habiado una interación con el control</p>`,
    codeExample: {
      html: `<form [formGroup]="formFocus" class="form">
  <ca-form-field validate="onFocus">
    <ca-label>Correo electrónico</ca-label>
    <input
      caInput
      formControlName="email"
      placeholder="Email"
      type="text"/>
    <ca-hint>Introduce tu dirección de correo</ca-hint>
    <ca-error *ngIf="formFocus.controls['email'].errors?.custom">error personalizado</ca-error>
  </ca-form-field>
</form>`,
      ts: `import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'ca-example-view',
  templateUrl: './example-view.component.html',
  styleUrls: ['./example-view.component.scss']
})
export class ExampleViewComponent implements OnInit {
  constructor(private formBuilder: FormBuilder) {}

  public form: FormGroup;

  private _formBuilder(): void {
    this.form = this.formBuilder.group({
      email: ['',]
    });
  }

  ngOnInit(): void {
    this._formBuilder();
  }

  private SetCustomError(){
    this.from.controls['email'].setErrors({custom: true})
  }
}`
    }
  }

  caseIconMin: ComponentDoc = {
    title: `Uso con tamaños mínimos`,
    description: `Para conseguir que el componente adquiera tamaños mínimos, debemos hacer uso de la directiva <code class="attribute">ca-min-component</code> como usaríamos cualquier otro atributo HTML.`,
    codeExample: {
      html: `<ca-form-field ca-min-component class="ca-form-field-1">
  <ca-label>Busqueda</ca-label>
  <ca-icon>search</ca-icon>
  <input caInput placeholder="Busqueda por nombre" type="text"/>
  <ca-icon>close</ca-icon>
</ca-form-field>
<ca-form-field ca-min-component>
  <ca-label>Email</ca-label>
  <input caInput type="text" placeholder="Insert your email" value="miguel.martinez@gft.com" />
  <ca-hint>user@domain.ext</ca-hint>
</ca-form-field>`
    }
  }

  caseLabelLeft: ComponentDoc = {
    title: `Uso con etiqueta a la izquierda`,
    description: `Para conseguir que el componente tenga la etiqueta a la izquierda en vez de arriba, debemos hacer uso del atributo <code class="attribute">ca-form-field-left-label</code> y la etiqueta pasará a posicionarse al lado izquierdo del campo de inserción de datos.`,
    codeExample: {
      html: `<ca-form-field ca-form-field-left-label class="ca-form-field-1">
  <ca-label>Busqueda</ca-label>
  <ca-icon>search</ca-icon>
  <input caInput placeholder="Busqueda por nombre" type="text"/>
  <ca-icon>close</ca-icon>
</ca-form-field>
<ca-form-field ca-form-field-left-label ca-form-field-min class="ca-form-field-1">
  <ca-label>Busqueda</ca-label>
  <ca-icon>search</ca-icon>
  <input caInput placeholder="Busqueda por nombre" type="text"/>
  <ca-icon>close</ca-icon>
</ca-form-field>`
    }
  }

  setError(form: FormGroup){
    this.formCustom.controls['email'].setErrors({custom: true});
  }

	ngOnInit(): void {
		this.formBlur = this.formBuilder.group({
			email: ['', {updateOn: 'blur', validators:[Validators.required, Validators.email, Validators.minLength(6)]}]
		});
		this.formFocus = this.formBuilder.group({
			email: ['', [Validators.required, Validators.email, Validators.minLength(6)]]
		});
		this.formCustom = this.formBuilder.group({
			email: ''
		});
	}
}
