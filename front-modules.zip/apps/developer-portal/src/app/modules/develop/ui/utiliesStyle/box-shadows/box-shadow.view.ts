import { Component } from '@angular/core';

@Component({
  templateUrl: 'box-shadow.view.html'
})
export class BoxShadowView {

  boxShadowClassList = [
    {type: 'boxShadow', title: 'Tipo de sombra', listItem: [
      {className: 'ca-box-shadow-small', description: 'Añade una sombra de ligera a un elemento.'},
      {className: 'ca-box-shadow-medium', description: 'Añade una sombra de media a un elemento.'},
      {className: 'ca-box-shadow-large', description: 'Añade una sombra de alta a un elemento.'},
      {className: 'ca-box-shadow-none', description: 'Añade esta clase para quitar la sombra a un elemento. Por ejemplo a una card.'}
    ]}
  ];

}