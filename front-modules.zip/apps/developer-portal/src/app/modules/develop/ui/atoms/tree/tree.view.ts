import { Component, OnInit } from '@angular/core';
import { CaSnackbarService, CaTreeEvent, CaTreeNode, CaTreeUtilsService } from '@global-front-components/ui';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
@Component({
	templateUrl: './tree.view.html',
	styleUrls: ['./tree.view.scss']
})
export class TreeView implements OnInit {
	constructor(private _treeUtils: CaTreeUtilsService, private _snackbarService: CaSnackbarService) {}

	moduleContent = `import { CaSnackbarService, CaTreeEvent, CaTreeNode, CaTreeUtilsService } from '@global-front-components/ui';`;

	nodeSelected: CaTreeNode;
	multipleSelection = false;
	caseBasic: ComponentDoc = {
		title: 'Uso del Componenete Tree',
		description: ``,
		codeExample: {
			html: ` <ca-tree [data]="treeData" (selectItem)="selectedItem($event)"> </ca-tree>`,
			ts: `
      treeData: CaTreeNode[] = [
        {
          label: 'Prueba 1',
          expanded: false,
          selected: false,
          children: [
            {
              label: 'Prueba hijo 1',
              expanded: false,
              selected: false,
              children: [
                {
                  label: 'Prueba hijo 1 hijo 1',
                  expanded: false,
                  selected: false
                }
              ]
            },
            {
              label: 'Prueba hijo 2',
              expanded: false,
              selected: false
            },
            {
              label: 'Prueba hijo 3',
              expanded: false,
              selected: false
            },
            {
              label: 'Prueba hijo 4',
              expanded: false,
              selected: false,
            }
          ]
        },
        {
          label: 'Prueba 2',
          expanded: false,
          selected: false
        },
        {
          label: 'Prueba 3',
          expanded: false,
          selected: false,
          children: [
            {
              label: 'Prueba 3 hijo 1',
              expanded: false,
              selected: false,
              children: [
                {
                  label: 'Prueba 3  hijo 1 hijo 2',
                  expanded: false,
                  selected: false,
                  children: [
                    {
                      label: 'Prueba 3 hijo 2 hijo 3',
                      expanded: false,
                      selected: false,
                      children: [
                        {
                          label: 'Prueba 3 hijo 3 hijo 4',
                          expanded: false,
                          selected: false
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          ]
        }
      ];


      selectedItem(event: CaTreeEvent){
        this.nodeSelected = event.node;
      }`
		}
	};

	caseDescription: ComponentDoc = {
		title: 'Componenete Tree con Descripcion',
		description: `
    <p>
     Si necesitamos añadir uan descipción items del Arbol. posemos pasar dicha informacion al attributo<code class="attribute">description</code>.
    </p>
    `,
		codeExample: {
			html: ` <ca-tree [data]="treeData" (selectItem)="selectedItem($event)"> </ca-tree>`,
			ts: `		treeData: CaTreeNode[] = [
        {
          label: 'Prueba 1',
          description: 'texto de ejemplo
          expanded: false,
          selected: false,
          children: [
            {
              label: 'Prueba hijo 1',
              description: 'texto de ejemplo
              expanded: false,
              selected: false,
            },
            {
              label: 'Prueba hijo 2',
              description: 'texto de ejemplo
              expanded: false,
              selected: false
            }
          ]
        },
        {
          label: 'Prueba 2',
          description: 'texto de ejemplo
          expanded: false,
          selected: false
        }
      ];


      selectedItem(event: CaTreeEvent){
        this.nodeSelected = event.node;
      }`
		}
	};

	caseCustoIcons: ComponentDoc = {
		title: 'Iconos de expandir/colapsar personalizados',
		description: `
    <p>
     Tenemos la posibilidad de personalizar los iconos de expndir y collapsar utilizando los atributos y <code class="attribute">collapsedIcon</code>. PAra ello y como en el caso de los icono de los elentos haremos uso de Material icons
    </p>
    `,
		codeExample: {
			html: ` <ca-tree [data]="treeData" (selectItem)="selectedItem($event)"> </ca-tree>`,
			ts: `		treeData: CaTreeNode[] = [
        {
          label: 'Prueba 1',
          collapsedIcon: 'keyboard_arrow_down',
		      expandedIcon: 'keyboard_arrow_up'
          expanded: false,
          selected: false,
          children: [
            {
              label: 'Prueba hijo 1',
              collapsedIcon: 'keyboard_arrow_down',
		          expandedIcon: 'keyboard_arrow_up'
              expanded: false,
              selected: false,
            },
            {
              label: 'Prueba hijo 2',
              collapsedIcon: 'keyboard_arrow_down',
		          expandedIcon: 'keyboard_arrow_up'
              expanded: false,
              selected: false
            }
          ]
        },
        {
          label: 'Prueba 2',
          collapsedIcon: 'keyboard_arrow_down',
		      expandedIcon: 'keyboard_arrow_up'
          expanded: false,
          selected: false
        }
      ];


      selectedItem(event: CaTreeEvent){
        this.nodeSelected = event.node;
      }`
		}
	};

	caseIcons: ComponentDoc = {
		title: 'Componenete Tree con iconos',
		description: `
    <p>
      Adicionalmente podemos añadir iconos a los items del Arbol. Para ello disponemos del attributo<code class="attribute">addIcon</code>. Actualmente estos se limitan a los ofrecidos por Material Icons.
    </p>
    `,
		codeExample: {
			html: ` <ca-tree [data]="treeData" (selectItem)="selectedItem($event)"> </ca-tree>`,
			ts: `		treeData: CaTreeNode[] = [
        {
          label: 'Prueba 1',
          addIcon: 'folder',
          expanded: false,
          selected: false,
          children: [
            {
              label: 'Prueba hijo 1',
              addIcon: 'people',
              expanded: false,
              selected: false,
            },
            {
              label: 'Prueba hijo 2',
              addIcon: 'people',
              expanded: false,
              selected: false
            }
          ]
        },
        {
          label: 'Prueba 2',
          addIcon: 'folder',
          expanded: false,
          selected: false
        },
        {
          label: 'Prueba 3',
          addIcon: 'folder',
          expanded: false,
          selected: false
        }
      ];


      selectedItem(event: CaTreeEvent){
        this.nodeSelected = event.node;
      }`
		}
	};

	caseUtilService: ComponentDoc = {
		title: 'Uso del Arbol con CaTreeUtilsService',
		description: `
    <p>
      Como hemos comentado anteriormente, la lógica de que indicar al compoenente que elementos serán marcados como seleccionados, recae sobre quien implementa el arbol. Pero para facilitar la tarea en los casos mas básicos como son selección individual y selección multiple. se ha desarrollado un servicio de utilidades.
    </p>
    <p>
      Para hacer uso de este servico importaremos <code class="tag">CaTreeUtilsService</code> de <b>"@global-front-components/ui"</b>.
      E invocaremos a la función <code class="tag">toggleSelection()</code> o <code class="tag">toggleExpand()</code>.
      Estas funciónes nos devolvera el copia del array modificada.
    </p>
    `,
		codeExample: {
			html: '<ca-tree [data]="treeData" (selectItem)="selectedItemBasic($event)" (expandNode)="toggleExpandPanel($event)" (dbClickItem)="onDbclick($event)"> </ca-tree>',
			ts: `
      multipleSelection = true;
      treeData: CaTreeNode[] = [
        {
          label: 'Prueba 1',
          expanded: false,
          selected: false,
          children: [
            {
              label: 'Prueba hijo 1',
              expanded: false,
              selected: false,
              children: [
                {
                  label: 'Prueba hijo 1 hijo 1',
                  expanded: false,
                  selected: false
                }
              ]
            },
            {
              label: 'Prueba hijo 2',
              expanded: false,
              selected: false
            },
            {
              label: 'Prueba hijo 3',
              expanded: false,
              selected: false
            },
            {
              label: 'Prueba hijo 4',
              expanded: false,
              selected: false,
            }
          ]
        },
        {
          label: 'Prueba 2',
          expanded: false,
          selected: false
        },
        {
          label: 'Prueba 3',
          expanded: false,
          selected: false,
          children: [
            {
              label: 'Prueba 3 hijo 1',
              expanded: false,
              selected: false,
              children: [
                {
                  label: 'Prueba 3  hijo 1 hijo 2',
                  expanded: false,
                  selected: false,
                  children: [
                    {
                      label: 'Prueba 3 hijo 2 hijo 3',
                      expanded: false,
                      selected: false,
                      children: [
                        {
                          label: 'Prueba 3 hijo 3 hijo 4',
                          expanded: false,
                          selected: false
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          ]
        }
      ];


      selectedItem(event: CaTreeEvent) {
        this.treeData = this._treeUtils.toggleSelection(this.treeData, event.node, this.multipleSelection);
      }

      toggleExpandPanel(event: CaTreeEvent) {
        this.treeData = this._treeUtils.toggleExpand(this.treeDatA, event.node);
      }

      onDbclick(event: CaTreeEvent){
        ...
      }
      `
		}
	};

	caseCheckbox: ComponentDoc = {
		title: 'Uso del Arbol con CheckBox',
		description: `
    <p>
      Podemos renderizar el componente arbol con checkbox. Para ello basta añadir el atributo <code class="attribute">checkbox</code> a la etiqueta <code class="tag">ca-tree</code>
    </p>

    `,
		codeExample: {
			html: '<ca-tree checkbox [data]="treeData" (selectItem)="selectedItemBasic($event)" (expandNode)="toggleExpandPanel($event)"> </ca-tree>',
			ts: `
      multipleSelection = true;
      treeData: CaTreeNode[] = [
        {
          label: 'Prueba 1',
          expanded: false,
          selected: false,
          children: [
            {
              label: 'Prueba hijo 1',
              expanded: false,
              selected: false,
              children: [
                {
                  label: 'Prueba hijo 1 hijo 1',
                  expanded: false,
                  selected: false
                }
              ]
            },
            {
              label: 'Prueba hijo 2',
              expanded: false,
              selected: false
            },
            {
              label: 'Prueba hijo 3',
              expanded: false,
              selected: false
            },
            {
              label: 'Prueba hijo 4',
              expanded: false,
              selected: false,
            }
          ]
        },
        {
          label: 'Prueba 2',
          expanded: false,
          selected: false
        },
        {
          label: 'Prueba 3',
          expanded: false,
          selected: false,
          children: [
            {
              label: 'Prueba 3 hijo 1',
              expanded: false,
              selected: false,
              children: [
                {
                  label: 'Prueba 3  hijo 1 hijo 2',
                  expanded: false,
                  selected: false,
                  children: [
                    {
                      label: 'Prueba 3 hijo 2 hijo 3',
                      expanded: false,
                      selected: false,
                      children: [
                        {
                          label: 'Prueba 3 hijo 3 hijo 4',
                          expanded: false,
                          selected: false
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          ]
        }
      ];


      selectedItem(event: CaTreeEvent) {
        this.treeData = this._treeUtils.toggleSelection(this.treeData, event.node, this.multipleSelection);
      }

      toggleExpandPanel(event: CaTreeEvent) {
        this.treeData = this._treeUtils.toggleExpand(this.treeDatA, event.node);
      }
      `
		}
	};

  caseAdditionalData: ComponentDoc = {
		title: 'Pasar Datos adicionales a los elementos',
		description: `
    <p>Si necesitamos pasarle a los elemtos del arbol, cuarquier tipo de dato adicional, haremos uso del attributo<code class="attribute">additionalData</code> del que dispone la interfaz.</p>
    `,
		codeExample: {
			html: ` <ca-tree [data]="treeData" (selectItem)="selectedItem($event)"> </ca-tree>`,
			ts: `
      treeData: CaTreeNode[] = [
        {
          label: 'Prueba 1',
          expanded: false,
          selected: false,
          additionalData: 'ejemplo de dato adicional para el item Prueba 1',
          children: [
            {
              label: 'Prueba hijo 1',
              expanded: false,
              selected: false,
              additionalData: 'ejemplo de dato adicional para el item Prueba hijo 1'
            }
          ]
        },
        {
          label: 'Prueba 2',
          expanded: false,
          selected: false,
          additionalData: 'ejemplo de dato adicional para el item Prueba 2'
        }
      ];


      selectedItem(event: CaTreeEvent){
        this.nodeSelected = event.node;
        this.additionalData = event.node.additionalData;
      }`
		}
	};

	treeDataBasic: CaTreeNode[] = [
		{
			label: 'Prueba 1',
			expanded: false,
			selected: false,
			children: [
				{
					label: 'Prueba hijo 1',
					expanded: false,
					selected: false,
					children: [
						{
							label: 'Prueba hijo 1 hijo 1',
							expanded: false,
							selected: false
						}
					]
				},
				{
					label: 'Prueba hijo 2',
					expanded: false,
					selected: false
				},
				{
					label: 'Prueba hijo 3',
					expanded: false,
					selected: false
				},
				{
					label: 'Prueba hijo 4',
					expanded: false,
					selected: false
				}
			]
		},
		{
			label: 'Prueba 2',
			expanded: false,
			selected: false
		},
		{
			label: 'Prueba 3',
			expanded: false,
			selected: false,
			children: [
				{
					label: 'Prueba 3 hijo 1',
					expanded: false,
					selected: false,
					children: [
						{
							label: 'Prueba 3  hijo 1 hijo 2',
							expanded: false,
							selected: false,
							children: [
								{
									label: 'Prueba 3 hijo 2 hijo 3',
									expanded: false,
									selected: false,
									children: [
										{
											label: 'Prueba 3 hijo 3 hijo 4',
											expanded: false,
											selected: false
										}
									]
								}
							]
						}
					]
				}
			]
		}
	];

	treeDataIcons: CaTreeNode[] = [
		{
			label: 'Prueba 1',
			addIcon: 'folder',
			expanded: false,
			selected: false,
			children: [
				{
					label: 'Prueba hijo 1',
					addIcon: 'people',
					expanded: false,
					selected: false
				},
				{
					label: 'Prueba hijo 2',
					addIcon: 'people',
					expanded: false,
					selected: false
				}
			]
		},
		{
			label: 'Prueba 2',
			addIcon: 'folder',
			expanded: false,
			selected: false
		},
		{
			label: 'Prueba 3',
			addIcon: 'folder',
			expanded: false,
			selected: false
		}
	];

	treeDataDescription: CaTreeNode[] = this.treeDataBasic.map((item) => ({ ...item, description: 'texto de ejemplo' }));
	treeDataCustomIcons: CaTreeNode[] = this.treeDataBasic.map((item) => ({
		...item,
		collapsedIcon: 'keyboard_arrow_down',
		expandedIcon: 'keyboard_arrow_up'
	}));

	treeDataUtilService: CaTreeNode[] = [
		{
			label: 'Prueba 1',
			expanded: false,
			selected: false,
			children: [
				{
					label: 'Prueba hijo 1',
					expanded: false,
					selected: false,
					children: [
						{
							label: 'Prueba hijo 1 hijo 1',
							expanded: false,
							selected: false
						}
					]
				},
				{
					label: 'Prueba hijo 2',
					expanded: false,
					selected: false
				},
				{
					label: 'Prueba hijo 3',
					expanded: false,
					selected: false
				},
				{
					label: 'Prueba hijo 4',
					expanded: false,
					selected: false
				}
			]
		},
		{
			label: 'Prueba 2',
			expanded: false,
			selected: false
		},
		{
			label: 'Prueba 3',
			expanded: false,
			selected: false,
			children: [
				{
					label: 'Prueba 3 hijo 1',
					expanded: false,
					selected: false,
					children: [
						{
							label: 'Prueba 3  hijo 1 hijo 2',
							expanded: false,
							selected: false

						}
					]
				}
			]
		}
	];;
  treeDataAdditional: CaTreeNode[] = [
    {
      label: 'Prueba 1',
      expanded: false,
      selected: false,
      additionalData: '  Datos adicionales del item: Prueba 1',
      children: [
        {
          label: 'Prueba hijo 1',
          expanded: false,
          selected: false,
          additionalData: '  Datos adicionales del item: Prueba hijo 1'
        }
      ]
    },
    {
      label: 'Prueba 2',
      expanded: false,
      selected: false,
      additionalData: '  Datos adicionales del item: Prueba 2'
    }
  ];

	selectedItemBasic(event: CaTreeEvent) {
		const sanckbarConfig = {
			message: `node seleccionado: ${event.node.label} ${event.node.additionalData || '' }`,
			actions: [],
			sticky: false,
			timer: 2000
		};
		this._snackbarService.open(sanckbarConfig);
	}

	selectedItem(event: CaTreeEvent) {
		this.treeDataUtilService = this._treeUtils.toggleSelection(this.treeDataUtilService, event.node, this.multipleSelection);
	}
  toggleExpandPanel(event: CaTreeEvent, type: string){
    switch(type){
      case 'utils':
        this.treeDataUtilService = this._treeUtils.toggleExpand(this.treeDataUtilService, event.node, this.multipleSelection)
        break;
      case 'icons':
        this.treeDataIcons = this._treeUtils.toggleExpand(this.treeDataIcons, event.node, this.multipleSelection)
        break;
      case 'description':
        this.treeDataDescription = this._treeUtils.toggleExpand(this.treeDataDescription, event.node, this.multipleSelection)
        break;
      case 'customIcons':
        this.treeDataCustomIcons = this._treeUtils.toggleExpand(this.treeDataCustomIcons, event.node, this.multipleSelection)
        break;
      case 'additional':
        this.treeDataAdditional = this._treeUtils.toggleExpand(this.treeDataAdditional, event.node, this.multipleSelection)
        break;

    }

  }

  onDbclick(event: CaTreeEvent){
    console.log('dobclick', event.node.label)
  }

	ngOnInit(): void {}
}
