import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {
  CaFormFieldModule,
  CaButtonModule,
  CaSidebarModule,
  CaTransferModule,
  CaAccordionModule,
  CaMenuHeaderModule
} from '@global-front-components/ui';
import { CaSSOUtilService } from '@global-front-components/common';
import { ComponentDocModule } from '../../../../components/component-doc/component-doc.module';
import { MoleculesView } from './molecules.view';
import { MoleculesRoutingModule } from './molecules-routing.module';
import { AccordionView } from './accordion/accordion.view';
import { TransferView } from './transfer/transfer.view';
import { SidebarView } from './sidebar/sidebar.view';
import { MenuHeaderView } from './menu-header/menu-header.view';

const SSOUtilServiceMock = {
  getToken() {
    return 'mockToKeN'
  }
}

@NgModule({
  declarations: [
    AccordionView,
    MoleculesView,
    TransferView,
    SidebarView,
    MenuHeaderView
  ],
  imports: [
    CaFormFieldModule,
    CaButtonModule,
    CaSidebarModule,
    CaTransferModule,
    CaAccordionModule,
    CaSidebarModule,
    CaMenuHeaderModule,
    CommonModule,
    ComponentDocModule,
    HttpClientModule,
    MoleculesRoutingModule,
    NgbModule,
    RouterModule
  ],
  providers: [
    {
      provide: CaSSOUtilService,
      useValue: SSOUtilServiceMock
    }
  ]
})
export class MoleculesModule {}
