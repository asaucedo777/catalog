import { Component, OnInit } from '@angular/core';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
import { ModasRequest, ModasResponse, CaModasService, Moda } from '@global-front-components/common';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { MODAS_RESPONSE_MOCK } from './_mock_/moda-list.response';


@Component({
	templateUrl: 'moda.view.html',
	styleUrls: ['moda.view.scss']
})
export class ModaView implements OnInit {
	constructor(private _CaModasService: CaModasService) {}
	modas: Moda[];
	moda: Moda;
	modaFound: Moda;
	selectedModa: Moda;

	caseModasSelect: ComponentDoc = {
		title: 'Componente Seleccionable de Modas',
		description: `
    `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-select
          placeholder="Seleccione su Moda"
          keyValue="descripcion"
          [options]="modas"
          [(ngModel)]="selectedModa"
        ></ca-select>
        <pre class="mt-2" *ngIf="selectedModa">
          {{ selectedModa | json }}
        </pre>
      </ca-form-field>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { Moda, ModasRequest, ModasResponse, CaModasService } from '@global-front-components/common';

      @Component({
        selector: 'moda-select-example',
        templateUrl: 'moda-select-example.component.html',
        styleUrls: ['moda-select-example.component.scss']
      })

      export class ModaSelectExampleComponent implements OnInit {
        constructor( private _caModasService: CaModasService ) { }

        modas: Moda[];
        selectedModa: Moda;

        ngOnInit() {
          const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
          const request: ModasRequest = {
            serviceId: 'ConsultaModasSrv',
            inputMap: {
              codCia: '0001',
              codRamo: '14',
            }
          };
          this._caModasService.getModas(endpoint, request).subscribe((response: ModasResponse) => {
            this.modas = response.outputMap.mapacoddescripcion;
          })
        }
      }`
		}
	};

	codeModasTypeahead: ComponentDoc = {
		title: 'Componente Predictivo de modas',
		description: `Hay dos formas de emplear este componente predictivo. Por un lado se puede hacer una única llamada al servicio de modas que nos devuelva toda la lista y filtrar a través del componente,
    o bien, llamar al servicio cada vez que el usuario introduce un valor en el <code class="tag">input</code>.
    <br />
    Primeramente se describe como implementarlo con una única llamada incial.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Moda</ca-label>
        <input
          type="text"
          placeholder="Busque una moda"
          [caTypeahead]="search"
          [inputFormatter]="modaFormatter"
          [(ngModel)]="moda"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="moda">
        {{ moda | json }}
      </pre>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
      import { Moda, ModasRequest, ModasResponse, CaModasService } from '@global-front-components/common';

      @Component({
        selector: 'moda-typeahead-example',
        templateUrl: 'moda-typeahead-example.component.html',
        styleUrls: ['moda-typeahead-example.component.scss']
      })

      export class ModaTypeaheadExampleComponent implements OnInit {
        constructor( private _caModasService: CaModasService ) { }

        modas: Moda[];
        moda: Moda;

        modaFormatter = (x:{descripcion: string}) => x.descripcion;

        search = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            map(term => term === '' ? []
              : this.modas.filter(v => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1))
          )

        ngOnInit() {
          const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
          const request: ModasRequest = {
            serviceId: 'ConsultaModasSrv',
            inputMap: {
              codCia: '0001',
              codRamo: '14',
            }
          };
          this._caModasService.getModas(endpoint, request).subscribe((response: ModasResponse) => {
            this.modas = response.outputMap.mapacoddescripcion;
          })
        }
      }`
		}
	};

	codeModasTypeaheadService: ComponentDoc = {
		description: `A continuación se describe como implementarlo con llamadas al servicio cuando el usuario interactúe.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Moda</ca-label>
        <input
          type="text"
          placeholder="Busque una moda"
          [caTypeahead]="searchModas"
          [inputFormatter]="modaFormatter"
          [(ngModel)]="modaFound"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="modaFound">
        {{ modaFound | json }}
      </pre>`,
			ts: `
      import { Component } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
      import { Moda, ModasRequest, ModasResponse, CaModasService } from '@global-front-components/common';

      @Component({
        selector: 'moda-typeahead-example',
        templateUrl: 'moda-typeahead-example.component.html',
        styleUrls: ['moda-typeahead-example.component.scss']
      })

      export class ModaTypeaheadExampleComponent {
        constructor( private _caModasService: CaModasService ) { }

        modaFound: Moda;

        modaFormatter = (x:{descripcion: string}) => x.descripcion;

        searchModas = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            switchMap(term => {
              const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
              const request: ModasRequest = {
                serviceId: 'ConsultaModasSrv',
                inputMap: {
                  codCia: '0001',
                  codRamo: '14',
                }
              };
              return this._caModasService.getModas(endpoint, request)
            })
            ).pipe(map((response: ModasResponse) => response.outputMap.mapacoddescripcion)
          );
      }`
		}
	};

	modaFormatter = (x: { descripcion: string }) => x.descripcion;

	search = (text$: Observable<string>) =>
		text$.pipe(
			debounceTime(300),
			distinctUntilChanged(),
			map((term) =>
				term === '' ? [] : this.modas.filter((v) => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1)
			)
		);

	searchModas = (text$: Observable<string>) =>
		text$
			.pipe(
				debounceTime(300),
				distinctUntilChanged(),
				switchMap((term) => {
					const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
					const request: ModasRequest = {
						serviceId: 'ConsultaModasSrv',
						inputMap: {
							codCia: '0001',
							codRamo: '14',
						}
					};
					return combineLatest([this._getModasMock(endpoint, request), of(term)]);
				})
			)
			.pipe(
				map(([response, term]) =>
					term === '' ? [] : this.modas.filter((v) => v.descripcion.toLowerCase().indexOf(term.toLowerCase()) > -1)
				)
			);

	private _getModasMock(endpoint: string, request: ModasRequest): Observable<ModasResponse> {
		return this._CaModasService.getModas(endpoint, request).pipe(
			catchError(() => {
				return of(<ModasResponse>MODAS_RESPONSE_MOCK);
			})
		);
	}

	ngOnInit() {
    const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
    const request: ModasRequest = {
      serviceId: 'ConsultaModasSrv',
      inputMap: {
        codCia: '0001',
        codRamo: '14',
      }
    };
		this._getModasMock(endpoint, request).subscribe((response: ModasResponse) => {
			this.modas = response.outputMap.mapacoddescripcion;
		});
	}
}
