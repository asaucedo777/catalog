import { Component } from '@angular/core';

@Component({
  templateUrl: 'cod-postal-service.view.html',
  styleUrls: ['cod-postal-service.view.scss']
})
export class CodPostalServiceView {
  moduleContent = `
  import { CaCodPostalesService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaCodPostalesService ],
    ...
  })`;
}
