import { Component } from '@angular/core';

@Component({
	templateUrl: 'sub-plan-service.view.html',
	styleUrls: ['sub-plan-service.view.scss']
})
export class SubPlanServiceView {
	moduleContent = `
  import { CaSubPlansService } from '@global-front-components/common';
  import { HttpClientModule } from '@angular/common/http';

  @NgModule({
      ...
    imports: [
      ...
      HttpClientModule,
      ...
    ],
    providers: [ CaSubPlansService ],
    ...
  })`;
}
