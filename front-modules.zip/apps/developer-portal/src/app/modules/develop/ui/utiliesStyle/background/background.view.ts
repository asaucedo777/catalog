import { Component } from '@angular/core';

@Component({
  templateUrl: 'background.view.html'
})
export class BackgroundView {
  backgroundClassList = [
    {type: 'colors', title: 'Colors', listItem: [
      {className: 'ca-background-primary', description: 'Agrega un color de fondo primario a un bloque.'},
      {className: 'ca-background-primary-light', description: 'Agrega un color de fondo primario light a un bloque.'},
      {className: 'ca-background-primary-dark', description: 'Agrega un color de fondo primario dark a un bloque.'},
      {className: 'ca-background-secondary', description: 'Agrega un color de fondo secundario a un bloque.'},
      {className: 'ca-background-secondary-light', description: 'Agrega un color de fondo secundario light a un bloque.'},
      {className: 'ca-background-secondary-dark', description: 'Agrega un color de fondo secundario dark a un bloque.'},
      {className: 'ca-background-muted', description: 'Agrega un color de fondo de apoyo a un bloque.'},
      {className: 'ca-background-white', description: 'Agrega un color de fondo blanco a un bloque.'},
      {className: 'ca-background-ui-1', description: 'Agrega un color de apoyo UI-01 a un bloque.'},
      {className: 'ca-background-ui-2', description: 'Agrega un color de apoyo UI-02 a un bloque.'},
      {className: 'ca-background-ui-3', description: 'Agrega un color de apoyo UI-03 a un bloque.'}
    ]},
    {type: 'imagePosition', title: 'Image position', listItem: [
      {className: 'ca-background-cover', description: 'Añade esta clase para que la imagen de fondo escale hasta que su ancho y alto esten dentro del área que lo contiene.', image: '../../../../assets/images/example-bg.png'},
      {className: 'ca-background-contain', description: 'Añade esta clase para que la imagen de fondo escale hasta que su ancho y alto esten dentro del área que lo contiene.', image: '../../../../assets/images/example-bg.png'},
      {className: 'ca-background-fixed', description: 'Añade esta clase para que la imagen de fondo escale hasta que su ancho y alto esten dentro del área que lo contiene.', image: '../../../../assets/images/example-bg.png'},
      {className: 'ca-background-repeat', description: 'Añade esta clase para que la imagen de fondo escale hasta que su ancho y alto esten dentro del área que lo contiene.', image: '../../../../assets/images/example-bg.png'},
      {className: 'ca-background-top-left', description: 'Añade esta clase para que la imagen de fondo escale hasta que su ancho y alto esten dentro del área que lo contiene.', image: '../../../../assets/images/example-bg.png'},
      {className: 'ca-background-top-center', description: 'Añade esta clase para que la imagen de fondo escale hasta que su ancho y alto esten dentro del área que lo contiene.', image: '../../../../assets/images/example-bg.png'},
      {className: 'ca-background-top-right', description: 'Añade esta clase para que la imagen de fondo escale hasta que su ancho y alto esten dentro del área que lo contiene.', image: '../../../../assets/images/example-bg.png'},
      {className: 'ca-background-center-left', description: 'Añade esta clase para que la imagen de fondo escale hasta que su ancho y alto esten dentro del área que lo contiene.', image: '../../../../assets/images/example-bg.png'},
      {className: 'ca-background-bottom-left', description: 'Añade esta clase para que la imagen de fondo escale hasta que su ancho y alto esten dentro del área que lo contiene.', image: '../../../../assets/images/example-bg.png'},
      {className: 'ca-background-bottom-center', description: 'Añade esta clase para que la imagen de fondo escale hasta que su ancho y alto esten dentro del área que lo contiene.', image: '../../../../assets/images/example-bg.png'},
      {className: 'ca-background-bottom-right', description: 'Añade esta clase para que la imagen de fondo escale hasta que su ancho y alto esten dentro del área que lo contiene.', image: '../../../../assets/images/example-bg.png'},
    ]}
  ];
}