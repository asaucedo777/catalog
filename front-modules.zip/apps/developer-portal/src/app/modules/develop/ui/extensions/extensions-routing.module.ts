import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExtensionsView } from './extensions.view';
import { MaskView } from './mask/mask.view';
import { NgxChartsView } from './ngx-charts/ngx-charts.view';


const routes: Routes = [{
  path: '',
  component: ExtensionsView,
  children: [
    {
      path: 'mask',
      component: MaskView
    },
    {
      path: 'ngx-charts',
      component: NgxChartsView
    },
  ]

}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ExtensionsRoutingModule { }
