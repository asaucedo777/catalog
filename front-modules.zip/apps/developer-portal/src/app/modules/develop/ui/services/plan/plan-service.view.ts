import { Component } from "@angular/core";

@Component({
    templateUrl: 'plan-service.view.html',
    styleUrls: ['plan-service.view.scss']
  })
  export class PlanServiceView {

    moduleContent = `
    import {CaPlanService } from '@global-front-components/common';
    import { HttpClientModule } from '@angular/common/http';
  
    @NgModule({
        ...
      imports: [
        ...
        HttpClientModule,
        ...
      ],
      providers: [CaPlanService],
      ...
    })`;
  }