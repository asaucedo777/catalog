import { Component, OnInit } from '@angular/core';
import {
  CaDocumentTypeService
} from '@global-front-components/common';
import { ComponentDoc } from 'apps/developer-portal/src/app/components/component-doc/component-doc.interface';
import { DocumentType, DocumentTypeRequest, DocumentTypeResponse } from 'libs/common/src/lib/models/document-type.interface';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { DOCUMENT_TYPE_RESPONSE_MOCK } from './_mock/document-type.response';
@Component({
	templateUrl: 'document-type.view.html',
	styleUrls: ['document-type.view.scss']
})
export class DocumentTypeView implements OnInit {
	constructor(private _caDocumentTypeService: CaDocumentTypeService) {}

	typeDocumentList: DocumentType[];
	selectedDocumentType: DocumentType;

	caseDocumentTypeSelect: ComponentDoc = {
		title: 'Componente Seleccionable de Tipos de Documento',
		description: `
        `,
		codeExample: {
			html: `
          <ca-form-field>
            <ca-select
              placeholder="Seleccione tipo de Documento"
              keyValue="valor"
              [options]="typeDocumentList"
              [(ngModel)]="selectedDocumentType"
            ></ca-select>
            <pre class="mt-2" *ngIf="selectedDocumentType">
             {{ selectedDocumentType | json }}
            </pre>
          </ca-form-field>`,
			ts: `
          import { Component, OnInit } from '@angular/core';
          import { DocumentType, DocumentTypeRequest, DocumentTypeResponse, CaDocumentTypeService } from '@global-front-components/common';
    
          @Component({
            selector: 'document-type-select-example',
            templateUrl: 'document-type-select-example.component.html',
            styleUrls: ['document-type-select-example.component.scss']
          })
    
          export class DocumentTypeSelectExampleComponent implements OnInit {
            constructor( private _caDocumentTypeService: CaDocumentTypeService ) { }
    
            documentTypeList: DocumentType[];
            selectedDocumentType: DocumentType;

            ngOnInit(): void {
                const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
                const request: DocumentTypeRequest = {
                  serviceId: 'CtaTiposDocumentoBDI',
                }
                this._getDocumentTypeList(endpoint, request).subscribe((response: DocumentTypeResponse) => {
                  this.typeDocumentList = response.outputMap.lista;
                })
              }
          }`
		}
	};
	private _getDocumentTypeList(endpoint: string, request: DocumentTypeRequest): Observable<DocumentTypeResponse> {
		return this._caDocumentTypeService.getDocumentType(endpoint, request).pipe(
			catchError(() => {
				return of(<DocumentTypeResponse>DOCUMENT_TYPE_RESPONSE_MOCK);
			})
		);
	}

	ngOnInit(): void {
		const endpoint: string = '/utilidadesbdihttpchannel/bindJSONServlet';
		const request: DocumentTypeRequest = {
			serviceId: 'CtaTiposDocumentoBDI'
		};
		this._getDocumentTypeList(endpoint, request).subscribe((response: DocumentTypeResponse) => {
			this.typeDocumentList = response.outputMap.lista;
		});
	}
}
