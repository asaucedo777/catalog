import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ComponentDocModule } from 'apps/developer-portal/src/app/components/component-doc/component-doc.module';
import { BackgroundView } from './background/background.view';
import { BorderView } from './border/border.view';
import { BoxShadowView } from './box-shadows/box-shadow.view';
import { ColorsView } from './colors/colors.view';
import { ColumnView } from './column/column.view';
import { ContainerView } from './container/container.view';
import { DisplayView } from './display/display.view';
import { FlexView } from './flex/flex.view';
import { GridView } from './grid/grid.view';
import { HeaderView } from './header/header.view';
import { MarginView } from './margin/margin.view';
import { PaddingView } from './padding/padding.view';
import { PositionView } from './position/position.view';
import { TextView } from './text/text.view';
import { UtiliesStyleRoutingModule } from './utiliesStyle-routing.module';
import { UtilieStyleView } from './utiliesStyle.view';
import { UtilitiesView } from './utilities/utilities.view';
import { VisibilityView } from './visibility/visibility.view';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CaAccordionModule, CaTabsModule } from '@global-front-components/ui';

@NgModule({
  declarations: [
      UtilieStyleView,
      BorderView,
      BackgroundView,
      BoxShadowView,
      ColorsView,
      ColumnView,
      FlexView,
      GridView,
      HeaderView,
      MarginView,
      PaddingView,
      PositionView,
      TextView,
      ContainerView,
      DisplayView,
      UtilitiesView,
      VisibilityView,
  ],
  imports: [
    CommonModule,
    UtiliesStyleRoutingModule,
    ComponentDocModule,
    NgbModule,
    CaAccordionModule,
    CaTabsModule
  ]
})
export class UtiliesStyleModule {}
