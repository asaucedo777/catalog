import { Component } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: 'menu.view.html',
	styleUrls: ['menu.view.scss']
})
export class MenuView {
	languages = ['html'];
	moduleContent = `import { CaMenuModule } from '@global-front-components/ui';`;

	caseMenuBasic: ComponentDoc = {
		title: 'Uso básico del menu.',
		description: `<p>Utilizaremos la directiva <code class="tag">caMenuTriggerFor</code>  en el elemento que queremos que haga de lanzador. a esta directiva le pasaremos la referencia del panel que sera lanzado</p>
    <P>Para generar el menu, añadiremos las etiquetas <code class="tag">ca-menu</code> y dentro de esta tantas etiquetas <code class="tag">ca-menu-item</code> como necesitemos</P>
    <p>utilizaremos el ouput <code class="tag">selected</code>en cada unbo de los itemspara capturar el evento de seleción de dicho item</p>`,
		codeExample: {
			html: `
      <button ca-button-icon [caMenuTriggerFor]="menu">
        <span class="material-icons">more_vert </span>
      </button>
      <ca-menu #menu="caMenu">
        <ca-menu-item (selected)="">
          Visualizar
        </ca-menu-item>
        <ca-menu-item (selected)="">
          Descargar
        </ca-menu-item>
      </ca-menu>`
		}
	};

	caseMenuIcons: ComponentDoc = {
		title: 'Menu con iconos.',
		description: `<p>para mostrar un menu com iconos insertaremos los compoenentes <code class="tag">ca-icon</code>dentro de cada item. Este icono siempre se mostrará al lado izquierdo del texto</p>`,
		codeExample: {
			html: `
      <button ca-button-icon [caMenuTriggerFor]="menu">
        <span class="material-icons">more_vert </span>
      </button>
      <ca-menu #menu="caMenu">
        <ca-menu-item (selected)=">
        <ca-icon>remove_red_eye</ca-icon>
          Visualizar
        </ca-menu-item>
        <ca-menu-item (selected)=">
        <ca-icon>remove_red_eye</ca-icon>
          Descargar
      </ca-menu-item>
    </ca-menu>`
		}
	};

	caseMenuItemsDisabled: ComponentDoc = {
		title: 'Menu con elementos desabilitidados.',
		description: `<p>Para deshabilitar opciones del menu basta poner el attributo disable en cada item</p>
    <p>podemos asignarle una variable para activarlo o desactivarlo de manera programática</p>`,
		codeExample: {
			html: `
      <button ca-button-icon [caMenuTriggerFor]="menu">
        <span class="material-icons">more_vert </span>
      </button>
      <ca-menu #menu="caMenu">
        <ca-menu-item (selected)="" disabled>
        <ca-icon>remove_red_eye</ca-icon>
          Visualizar
        </ca-menu-item>
        <ca-menu-item (selected)="" disabled>
        <ca-icon>remove_red_eye</ca-icon>
          Descargar
      </ca-menu-item>
    </ca-menu>`
		}
	};

	caseMenudivider: ComponentDoc = {
		title: 'Menu con divisiones',
		description: `<p>PAra crear divisiones dentro  del menu añadiremos el attributo <code class="attribute">divider</code> en el ultimo item donde queramos realizar la división </p>`,
		codeExample: {
			html: `
    <button ca-button-icon [caMenuTriggerFor]="menu">
      <span class="material-icons">more_vert </span>
    </button>
    <ca-menu #menu="caMenu">
      <ca-menu-item (selected)="clickHandler(1)" >
        Visualizar
      </ca-menu-item>
      <ca-menu-item (selected)="clickHandler(2)" divider>
        Descargar
      </ca-menu-item>
      <ca-menu-item (selected)="clickHandler(3)" >
        Borrar
      </ca-menu-item>
      <ca-menu-item (selected)="clickHandler(4)">
        Editar
      </ca-menu-item>
    </ca-menu>`
		}
	};

	caseMenuTwoLevel: ComponentDoc = {
		title: 'Menu con dos niveles.',
		description: `<p>Pare crear un menu con dos niveles tan solo tenemos que crear otro menu tal y como mostramos en los otros ejemplos y anadir la directiva <code class="tag">caMenuTriggerFor</code> a unos de los items del primer menu, pasandole como valor la referencia del segundo menu, tal y como se muestra en el ejemplo</p>`,
		codeExample: {
			html: `
      <button ca-button-icon [caMenuTriggerFor]="menu">
        <span class="material-icons">more_vert </span>
      </button>
      <ca-menu #menu="caMenu">
        <ca-menu-item [caMenuTriggerFor]="submenu">
          open submenu
        </ca-menu-item>
        <ca-menu-item (selected)="">
          Descargar
        </ca-menu-item>
      </ca-menu>
      <ca-menu #submenu="caMenu">
        <ca-menu-item (selected)="">
          submenu item 1
        </ca-menu-item>
        <ca-menu-item (selected)="">
          submenu item  2
        </ca-menu-item>
      </ca-menu>`
		}
  };

  caseMenuTwoLevelMin: ComponentDoc = {
		title: 'Menu con dos niveles a tamaño mínimo.',
		description: `<p>Pare crear un menu con dos niveles a tamaño mínimo además de seguir los pasos descritos en el ejemplo de menú a dos niveles, debemos añadir al botón disparador la directiva <code class="attribute">ca-min-component</code> y a cada uno de los componentes <code class="tag">ca-menu</code> le agregamos la directiva <code class="attribute">ca-min-component</code>`,
		codeExample: {
			html: `
      <button ca-button-icon ca-min-component [caMenuTriggerFor]="menumin">
        <span class="material-icons">more_vert </span>
      </button>
      <ca-menu #menumin="caMenu" ca-min-component>
        <ca-menu-item [caMenuTriggerFor]="submenumin">
          open submenu
        </ca-menu-item>
        <ca-menu-item (selected)="">
          Descargar
        </ca-menu-item>
      </ca-menu>
      <ca-menu #submenumin="caMenu" ca-min-component>
        <ca-menu-item (selected)="">
          submenu item 1
        </ca-menu-item>
        <ca-menu-item (selected)="">
          submenu item  2
        </ca-menu-item>
      </ca-menu>`
		}
	};

	clickHandler(index: number) {
		console.log('Click on intem menu index:', index);
	}
}
