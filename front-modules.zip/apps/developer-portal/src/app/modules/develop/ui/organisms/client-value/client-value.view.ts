import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { CaModalOverlayService } from '@global-front-components/ui';
import { CaClientValueModalExampleComponent } from './client-value-modal-example/client-value-modal-example.component';
import { CaClientValueService, ClientValueRequest, ClientValueResponse, ClientValueOutputMap, CaNifValidator } from '@global-front-components/common';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { CLIENT_VALUE_RESPONSE_MOCK } from './_mock_/client-value.response';

@Component({
  templateUrl: 'client-value.view.html',
  styleUrls: ['client-value.view.scss']
})
export class ClientValueView implements OnInit {
  constructor(
    private _caClientValueService: CaClientValueService,
    private _formBuilder: FormBuilder,
    private _modalService: CaModalOverlayService
  ) {}
  form: FormGroup;
  formInfo: FormGroup;
  clientValue: ClientValueOutputMap;
  clientValueInfo: ClientValueOutputMap;

  caseSimple: ComponentDoc = {
    title: 'Valor Cliente (uso simple)',
    codeExample: {
      html: `
      <form [formGroup]="form">
        <div class="d-flex align-items-end">
          <div class="d-flex form__container mr-5">
            <div class="form__input">
              <ca-form-field>
                <ca-label>Documento (NIF)</ca-label>
                <input type="text" caInput required formControlName="documento">
                <ca-error *ngIf="form.get('documento').errors?.invalidNif">Nif inválido</ca-error>
                <ca-error *ngIf="form.get('documento').errors?.required">Campo obligatorio</ca-error>
              </ca-form-field>
            </div>
            <button
              class="form__button ml-2"
              ca-button
              [disabled]="form.invalid"
              (click)="searchClientValue(form.get('documento').value)">
              <span>Buscar</span>
            </button>
          </div>
          <ca-client-value *ngIf="clientValue"
            [type]="clientValue.denTpoClie"
            [link]="clientValue.vinculacion"
            [policiesNumber]="clientValue.numPolVig"
          ></ca-client-value>
        </div>
      </form>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import {
        FormBuilder,
        FormGroup,
        Validators
      } from '@angular/forms';
      import {
        CaClientValueService,
        ClientValueRequest,
        ClientValueResponse,
        ClientValueOutputMap,
        CaNifValidator
      } from '@global-front-components/common';

      @Component({
        templateUrl: 'client-value.view.html',
        styleUrls: ['client-value.view.scss']
      })
      export class ClientValueView implements OnInit {
        constructor(
          private _caClientValueService: CaClientValueService,
          private _formBuilder: FormBuilder
        ) {}
        form: FormGroup;
        clientValue: ClientValueOutputMap;

        searchClientValue(nif: string): void {
          const endpoint = '/apibdihttpchannel/bindJSONServlet';
          const request: ClientValueRequest = {
            serviceId:'BuscarValorClienteSRV',
            inputMap: {
              documento: nif,
              aplicacion: 'AplicacionQueInvocaAlServicio',
              usuario: 'UsuarioLogadoAplicacion'
            }
          }
          this._caClientValueService.getClientValue(endpoint, request)
            .subscribe((response: ClientValueResponse) => {
              this.clientValue =  response.outputMap;
            }
          );
        }

        ngOnInit() {
          this.form = this._formBuilder.group({
            documento: ['',[CaNifValidator('invalidNif'),Validators.required]]
          });
        }
      }
      `,
      css: `
      .form {
        &__container {
          align-items: baseline;
        }

        &__input {
          width: 200px;
        }
      }`
    }
  }


  caseMoreInfo: ComponentDoc = {
    title: 'Valor Cliente con información adicional',
    description: `Se puede visualizar infomarción adicional del valor de un cliente, clickando sobre el componente de Valor Cliente.
    Para ello se debe generar un componente que muestre los campos deseados a través de una modal. En este ejemplo se van a visualizar el <em>nombre</em>, <em>apellido1</em> y <em>apellido2</em> del cliente.`,
    codeExample: {
      html: `
    <form [formGroup]="form">
      <div class="d-flex align-items-end">
        <div class="d-flex form__container mr-5">
          <div class="form__input">
            <ca-form-field>
              <ca-label>Documento (NIF)</ca-label>
              <input type="text" caInput required formControlName="documento">
              <ca-error *ngIf="form.get('documento').errors?.invalidNif">Nif inválido</ca-error>
              <ca-error *ngIf="form.get('documento').errors?.required">Campo obligatorio</ca-error>
            </ca-form-field>
          </div>
          <button
            class="form__button ml-2"
            ca-button
            [disabled]="form.invalid"
            (click)="searchClientValue(form.get('documento').value)">
            <span>Buscar</span>
          </button>
        </div>
        <ca-client-value *ngIf="clientValue"
          [type]="clientValue.denTpoClie"
          [link]="clientValue.vinculacion"
          [policiesNumber]="clientValue.numPolVig"
          (click)="showClientValueInfo()"
        ></ca-client-value>
      </div>
    </form>`,
    ts: `
      import { Component, Input, OnInit } from '@angular/core';
      import {
        FormBuilder,
        FormGroup,
        Validators
      } from '@angular/forms';
      import {
        CaClientValueService,
        ClientValueRequest,
        ClientValueResponse,
        ClientValueOutputMap,
        CaNifValidator
      } from '@global-front-components/common';
      import { CaModalOverlayRef, CaModalOverlayService } from '@global-front-components/ui';

      @Component({
        selector: 'ca-client-value-modal-example',
        template: \`
          <div class="ca-client-value-modal-example__container d-flex flex-column justify-content-center">
            <div class="ca-client-value-modal-example__control mb-3">
              <ca-form-field ca-form-field-left-label>
                <ca-label>Nombre</ca-label>
                <input type="text" caInput readonly [value]="data.nombre">
              </ca-form-field>
            </div>
            <div class="ca-client-value-modal-example__control mb-3">
              <ca-form-field ca-form-field-left-label>
                <ca-label>Primer apellido</ca-label>
                <input type="text" caInput readonly [value]="data.apellido1">
              </ca-form-field>
            </div>
            <div class="ca-client-value-modal-example__control mb-3">
              <ca-form-field ca-form-field-left-label>
                <ca-label>Segundo apellido</ca-label>
                <input type="text" caInput readonly [value]="data.apellido2">
              </ca-form-field>
            </div>
          </div>\`
      })
      export class CaClientValueModalExampleComponent {
        constructor(private _modalRef: CaModalOverlayRef<CaClientValueModalExampleComponent>) {}

        @Input() data: any;

        close(): void {
          this._modalRef.close();
        }
      }

      @Component({
        templateUrl: 'client-value.view.html',
        styleUrls: ['client-value.view.scss']
      })
      export class ClientValueView implements OnInit {
        constructor(
          private _caClientValueService: CaClientValueService,
          private _formBuilder: FormBuilder,
          private _modalService: CaModalOverlayService
        ) {}
        form: FormGroup;
        clientValue: ClientValueOutputMap;

        searchClientValue(nif: string): void {
          const endpoint = '/apibdihttpchannel/bindJSONServlet';
          const request: ClientValueRequest = {
            serviceId:'BuscarValorClienteSRV',
            inputMap: {
              documento: nif,
              aplicacion: 'AplicacionQueInvocaAlServicio',
              usuario: 'UsuarioLogadoAplicacion'
            }
          }
          this._caClientValueService.getClientValue(endpoint, request)
            .subscribe((response: ClientValueResponse) => {
              this.clientValue =  response.outputMap;
            }
          );
        }

        showClientValueInfo(): void {
          this._modalService.open(CaClientValueModalExampleComponent, {
            title: 'Tipo de cliente',
            data: this.clientValue
          })
        }

        ngOnInit() {
          this.form = this._formBuilder.group({
            documento: ['',[CaNifValidator('invalidNif'),Validators.required]]
          });
        }
      }`,
      css: `
      .form {
        &__container {
          align-items: baseline;
        }

        &__input {
          width: 200px;
        }
      }
      ca-client-value {
        cursor: pointer;
      }`
    }
  }

  private _getClientValueMock(url: string, request: ClientValueRequest): Observable<ClientValueResponse> {
    return this._caClientValueService.getClientValue(url, request).pipe(catchError(() => {
      return of(<ClientValueResponse>CLIENT_VALUE_RESPONSE_MOCK);
    }))
  }

  searchClientValue(nif: string): void {
    const endpoint = '/apibdihttpchannel/bindJSONServlet';
    const request: ClientValueRequest = {
      serviceId:'BuscarValorClienteSRV',
      inputMap: {
        documento: nif,
        aplicacion: 'AplicacionQueInvocaAlServicio',
        usuario: 'UsuarioLogadoAplicacion'
      }
    }
    this._getClientValueMock(endpoint, request).subscribe((response: ClientValueResponse) => {
      this.clientValue =  response.outputMap;
    });
  }

  searchClientValueInfo(nif: string): void {
    const endpoint = '/apibdihttpchannel/bindJSONServlet';
    const request: ClientValueRequest = {
      serviceId:'BuscarValorClienteSRV',
      inputMap: {
        documento: nif,
        aplicacion: 'AplicacionQueInvocaAlServicio',
        usuario: 'UsuarioLogadoAplicacion'
      }
    }
    this._getClientValueMock(endpoint, request).subscribe((response: ClientValueResponse) => {
      this.clientValueInfo =  response.outputMap;
    });
  }

  showClientValueInfo(): void {
    this._modalService.open(CaClientValueModalExampleComponent, {
      title: 'Tipo de cliente',
      data: this.clientValueInfo
    })
  }

  ngOnInit() {
    this.form = this._formBuilder.group({
      documento: ['',[CaNifValidator('invalidNif'),Validators.required]]
    });
    this.formInfo = this._formBuilder.group({
      documento: ['',[CaNifValidator('invalidNif'),Validators.required]]
    });
  }
}
