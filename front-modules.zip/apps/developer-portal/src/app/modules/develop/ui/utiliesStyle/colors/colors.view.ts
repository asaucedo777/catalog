import { Component } from '@angular/core';

@Component({
  templateUrl: 'colors.view.html'
})
export class  ColorsView {

  colorsClassList = [
    {type: 'boxShadow', title: 'Tipo de sombra', listItem: [
      {className: 'ca-background-primary', description: '#007363'},
      {className: 'ca-box-shadow-medium', description: 'Añade una sombra de media a un elemento.'},
      {className: 'ca-box-shadow-large', description: 'Añade una sombra de alta a un elemento.'},
      {className: 'ca-box-shadow-none', description: 'Añade esta clase para quitar la sombra a un elemento. Por ejemplo a una card.'}
    ]}
  ];

}