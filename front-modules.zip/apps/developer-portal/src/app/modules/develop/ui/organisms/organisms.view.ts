import { Component } from '@angular/core';

@Component({
  templateUrl: 'organisms.view.html',
  styleUrls: ['organisms.view.scss']
})
export class OrganismsView {}
