import { Component } from '@angular/core';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: 'button.view.html',
	styleUrls: ['button.view.scss']
})
export class ButtonView {
  moduleContent = `import { CaButtonModule } from '@global-front-components/ui';`;

  caseBtnMin: ComponentDoc = {
		title: 'Botones mínimos',
		description: `<p>
    Para hacer uso de lo botones a tamaño mínimo solo debemos combinar la directiva <code class="tag">ca-min-component</code> con
    cualquiera de las anteriores
  </p>`,
		codeExample: {
			html: `
      <button ca-button ca-min-component>Botón de Ejemplo</button>
      <button ca-button-secondary ca-min-component>Botón de Ejemplo</button>
      <button ca-button-tertiary ca-min-component>Botón de Ejemplo</button>
      <button ca-button-icon ca-min-component><span class="material-icons">delete</span></button>
      <button ca-button-icon-primary ca-min-component><span class="material-icons">add</span></button>
      `
		}
	};

	caseBtnPrimary: ComponentDoc = {
		title: 'Botton primario',
		description: `<p>La directiva <code class="tag">ca-button</code> añade estilos predeterminados para el botón primario.</p>`,
		codeExample: {
			html: `<button ca-button class="ca-btn-icon__container">
	<ca-icon>
		search
	</ca-icon>
	Botón de Ejemplo
</button>`
		}
	};

	caseBtnSecondary: ComponentDoc = {
		title: 'Botton Secundario',
		description: `<p>la Directiva <code class="tag">ca-button-secondary</code> añade estilos para los botones secundarios .</p>`,
		codeExample: {
			html: `<button ca-button-secondary>
<span class="material-icons ca-btn-icon__text">unfold_more</span>
Botón de Ejemplo
</button>`
		}
	};

	caseBtnTertiary: ComponentDoc = {
		title: 'Botton Terciario',
		description: `<p>la Directiva <code class="tag">ca-button-tertiary</code> añade estilos para los botones secundarios .</p>`,
		codeExample: {
			html: `<button ca-button-tertiary>Botón de Ejemplo</button>`
		}
	};

	caseBtnIcon: ComponentDoc = {
		title: 'Botones sólo con iconos',
		description: `<p>la Directiva <code class="tag">ca-button-icon</code> añade estilos para utilizar botones sólo con iconos .</p>`,
		codeExample: {
			html: `
      <button ca-button-icon>
        <ca-icon>
          delete
        </ca-icon>
      </button>`
		}
	};

	caseBtnIconPrimary: ComponentDoc = {
		title: 'Botones de iconos en estado primario',
		description: `<p>la Directiva <code class="tag">ca-button-icon-primary</code> añade estilos para utilizar botones de iconos en estado primario .</p>`,
		codeExample: {
			html: `
      <button ca-button-icon-primary>
        <ca-icon>
          add
        </ca-icon>
      </button>`
		}
	};

	caseBtnLarge: ComponentDoc = {
		title: 'Botones grandes',
		description: `<p>
    Para hacer uso de lo botones grandes solo debemos combinar la directiva <code class="tag">ca-button-large</code> con
    cualquiera de las anteriores
  </p>`,
		codeExample: {
			html: `
      <button ca-button ca-button-large>Botón de Ejemplo</button>
      <button ca-button-secondary ca-button-large>Botón de Ejemplo</button>
      <button ca-button-tertiary ca-button-large>Botón de Ejemplo</button>
      <button ca-button-icon ca-button-large><span class="material-icons">delete</span></button>
      <button ca-button-icon-primary ca-button-large><span class="material-icons">add</span></button>
      `
		}
	};
	caseBtnDisabled: ComponentDoc = {
		title: 'Botones deshabilitados',
		description: `<p>
    Todos los botones disponen de un estado deshabilitado, para mostar este estado solo tendremos que añadir el
    attributo <code class="attribute">disabled</code> tal y como lo haríamos en un botón nativo.
  </p>`,
		codeExample: {
			html: `
      <button ca-button disabled>Botón de Ejemplo</button>
      <button ca-button-secondary disabled>Botón de Ejemplo</button>
      <button ca-button-tertiary disabled>Botón de Ejemplo</button>
      <button ca-button-icon disabled><span class="material-icons">delete</span></button>
      <button ca-button-icon-primary disabled><span class="material-icons">add</span></button>
      `
		}
	};
}
