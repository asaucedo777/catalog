import { SexoResponse } from "libs/common/src/lib/models/sexo.interface";


export const SEXO_RESPONSE_MOCK: SexoResponse = {
  "serviceId": "BuscarValorPorTablaSRV",
  "outputMap": {
      "valorParametro": [
        {
            "tvalor":"VARON",
            "nvalor":1,
            "ntabla":15
           },
             {
            "tvalor":"MUJER",
            "nvalor":2,
            "ntabla":15
           },
             {
            "tvalor":"DESCONOCIDO",
            "nvalor":9,
            "ntabla":15
           }
      ]
  }
}