import { RoadTypeResponse } from "libs/common/src/lib/models/road-type.interfaces";

export const ROAD_TYPES_RESPONSE_MOCK: RoadTypeResponse = {
  serviceId: "BuscarProvinciaPorNombreSRV",
  outputMap: {
    lista: [
      {
        clave: "ALD",
        valor: "ALDEA-ALD",
      },
      {
        clave: "APD",
        valor: "APARTADO-APD",
      },
      {
        clave: "ARR",
        valor: "ARRABAL-ARR",
      },
      {
        clave: "AUT",
        valor: "AUTOVIA-AUT",
      },
      {
        clave: "AVD",
        valor: "AVENIDA-AVD",
      },
      {
        clave: "BCO",
        valor: "BARRANCO-BCO",
      },
      {
        clave: "BDA",
        valor: "BARRIADA-BDA",
      },
      {
        clave: "CL",
        valor: "CALLE-CL",
      },
      {
        clave: "CJN",
        valor: "CALLEJON-CJN",
      },
      {
        clave: "CLZ",
        valor: "CALLIZO-CLZ",
      },
      {
        clave: "CNO",
        valor: "CAMINO-CNO",
      },
      {
        clave: "CRO",
        valor: "CARRERO-CRO",
      },
      {
        clave: "CRA",
        valor: "CARRETERA-CRA",
      },
      {
        clave: "CRL",
        valor: "CARRIL-CRL",
      },
      {
        clave: "CAS",
        valor: "CASERIO-CAS",
      },
      {
        clave: "COL",
        valor: "COLONIA-COL",
      },
      {
        clave: "CTO",
        valor: "CORTIJO-CTO",
      },
      {
        clave: "CTA",
        valor: "CUESTA-CTA",
      },
      {
        clave: "EDF",
        valor: "EDIFICIO-EDF",
      },
      {
        clave: "DIS",
        valor: "EXTRARRADIO-DIS",
      },
      {
        clave: "FCA",
        valor: "FINCA-FCA",
      },
      {
        clave: "GTA",
        valor: "GLORIETA-GTA",
      },
      {
        clave: "GPO",
        valor: "GRUPO-GPO",
      },
      {
        clave: "LUG",
        valor: "LUGAR-LUG",
      },
      {
        clave: "MAS",
        valor: "MASIA-MAS",
      },
      {
        clave: "PAG",
        valor: "PAGO-PAG",
      },
      {
        clave: "PJE",
        valor: "PARAJE-PJE",
      },
      {
        clave: "PQE",
        valor: "PARQUE-PQE",
      },
      {
        clave: "PDA",
        valor: "PARTIDA-PDA",
      },
      {
        clave: "PSO",
        valor: "PASEO-PSO",
      },
      {
        clave: "PZL",
        valor: "PLACETA-PZL",
      },
      {
        clave: "PZA",
        valor: "PLAZA-PZA",
      },
      {
        clave: "POB",
        valor: "POBLADO-POB",
      },
      {
        clave: "POL",
        valor: "POLIGONO-POL",
      },
      {
        clave: "PRL",
        valor: "PROLONGACION-PRL",
      },
      {
        clave: "RAM",
        valor: "RAMBLA-RAM",
      },
      {
        clave: "RSD",
        valor: "RESIDENCIAL-RSD",
      },
      {
        clave: "RIE",
        valor: "RIERA-RIE",
      },
      {
        clave: "RDA",
        valor: "RONDA-RDA",
      },
      {
        clave: "RUE",
        valor: "RUELA-RUE",
      },
      {
        clave: "SDA",
        valor: "SENDA-SDA",
      },
      {
        clave: "TRA",
        valor: "TRANSVERSAL-TRA",
      },
      {
        clave: "TSA",
        valor: "TRASERA-TSA",
      },
      {
        clave: "TRV",
        valor: "TRAVESIA-TRV",
      },
      {
        clave: "URB",
        valor: "URBANIZACION-URB",
      },
      {
        clave: "VER",
        valor: "VEREDA-VER",
      },
      {
        clave: "VIA",
        valor: "VIA-VIA",
      },
      {
        clave: "ZON",
        valor: "ZONA-ZON",
      },
    ],
  },
};
