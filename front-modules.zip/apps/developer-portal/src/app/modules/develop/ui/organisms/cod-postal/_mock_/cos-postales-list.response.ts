import { CodPostalesResponse } from "@global-front-components/common";

export const COD_POSTALES_RESPONSE_MOCK: CodPostalesResponse = {
  "serviceId": "BuscarLocalidadPorCodigoPostalSRV",
  "outputMap": {
      "Lista": [
          {
              "lpobla": "A ABADIA (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005020100",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27792"
          },
          {
              "lpobla": "A ABADIA (O SAVIÑAO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058190100",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27545"
          },
          {
              "lpobla": "A ABAIRA",
              "lmunic": "TRABADA",
              "cpobla": "27061050100",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "LUGO",
              "cpostal": "27765"
          },
          {
              "lpobla": "A ABELA",
              "lmunic": "XOVE",
              "cpobla": "27025050100",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "LUGO",
              "cpostal": "27879"
          },
          {
              "lpobla": "A ABELAIRA (A PASTORIZA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044100100",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27287"
          },
          {
              "lpobla": "A ABELAIRA (CORVELLE)",
              "lmunic": "VILALBA",
              "cpobla": "27065070100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27843"
          },
          {
              "lpobla": "A ABELAIRA (MURAS)",
              "lmunic": "MURAS",
              "cpobla": "27033050100",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A ABELAIRA (PANTON)",
              "lmunic": "PANTON",
              "cpobla": "27041010100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27437"
          },
          {
              "lpobla": "A ABELAIRA (PARADELA)",
              "lmunic": "PARADELA",
              "cpobla": "27042120100",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27611"
          },
          {
              "lpobla": "A ABELAIRA (SEIXON)",
              "lmunic": "FRIOL",
              "cpobla": "27020250100",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A ABELEDA DE OURENSE",
              "lmunic": "OURENSE",
              "cpobla": "32054040200",
              "codPais": "ES",
              "nHabitantes": 54,
              "lprovi": "OURENSE",
              "cpostal": "32980"
          },
          {
              "lpobla": "A ABELEDA (SAN VICENTE)",
              "lmunic": "XUNQUEIRA DE AMBIA",
              "cpobla": "32036010000",
              "codPais": "ES",
              "nHabitantes": 75,
              "lprovi": "OURENSE",
              "cpostal": "32679"
          },
          {
              "lpobla": "A ABELEDA (SANTA MARIA)",
              "lmunic": "A TEIXEIRA",
              "cpobla": "32080010000",
              "codPais": "ES",
              "nHabitantes": 110,
              "lprovi": "OURENSE",
              "cpostal": "32764"
          },
          {
              "lpobla": "A ABELEIRA",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022020100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27306"
          },
          {
              "lpobla": "A ABELEIRA (BARDAOS)",
              "lmunic": "TORDOIA",
              "cpobla": "15084DD3100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15684"
          },
          {
              "lpobla": "A ABELEIRA (BEARIZ)",
              "lmunic": "BEARIZ",
              "cpobla": "32011020100",
              "codPais": "ES",
              "nHabitantes": 39,
              "lprovi": "OURENSE",
              "cpostal": "32520"
          },
          {
              "lpobla": "A ABELEIRA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026130100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15390"
          },
          {
              "lpobla": "A ABELEIRA (PADRENDA)",
              "lmunic": "PADRENDA",
              "cpobla": "32056040100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "OURENSE",
              "cpostal": "32228"
          },
          {
              "lpobla": "A ABELENDA (O PORRIÑO)",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039060100",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36412"
          },
          {
              "lpobla": "A ABELIDA",
              "lmunic": "GOMESENDE",
              "cpobla": "32033050100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "OURENSE",
              "cpostal": "32212"
          },
          {
              "lpobla": "A ABELLEIRA  (A CAPELA)",
              "lmunic": "A CAPELA",
              "cpobla": "15018045200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A ABELLEIRA (ABADIN)",
              "lmunic": "ABADIN",
              "cpobla": "27001040100",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27845"
          },
          {
              "lpobla": "A ABELLEIRA (ARCA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017050100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36684"
          },
          {
              "lpobla": "A ABELLEIRA (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005020200",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27792"
          },
          {
              "lpobla": "A ABELLEIRA (BOVEDA)",
              "lmunic": "BOVEDA",
              "cpobla": "27008110700",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27343"
          },
          {
              "lpobla": "A ABELLEIRA (CAMBADOS)",
              "lmunic": "CAMBADOS",
              "cpobla": "36006040100",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36635"
          },
          {
              "lpobla": "A ABELLEIRA (CASTROVERDE)",
              "lmunic": "CASTROVERDE",
              "cpobla": "27011130100",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "LUGO",
              "cpostal": "27123"
          },
          {
              "lpobla": "A ABELLEIRA DE PONTEVEDRA",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038020100",
              "codPais": "ES",
              "nHabitantes": 115,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36151"
          },
          {
              "lpobla": "A ABELLEIRA (DUANCOS)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010080100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27271"
          },
          {
              "lpobla": "A ABELLEIRA (FREXULFE)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063040100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27777"
          },
          {
              "lpobla": "A ABELLEIRA (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022060100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27308"
          },
          {
              "lpobla": "A ABELLEIRA (GULDRIZ)",
              "lmunic": "FRIOL",
              "cpobla": "27020110100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27299"
          },
          {
              "lpobla": "A ABELLEIRA (LAMAS)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017230100",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36686"
          },
          {
              "lpobla": "A ABELLEIRA (MUIÑOS)",
              "lmunic": "MUIÑOS",
              "cpobla": "32051010100",
              "codPais": "ES",
              "nHabitantes": 43,
              "lprovi": "OURENSE",
              "cpostal": "32897"
          },
          {
              "lpobla": "A ABELLEIRA (O CADRAMON)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063020100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27777"
          },
          {
              "lpobla": "A ABELLEIRA (PONTEAREAS)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042010100",
              "codPais": "ES",
              "nHabitantes": 88,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36867"
          },
          {
              "lpobla": "A ABELLEIRA (RIOTORTO)",
              "lmunic": "RIOTORTO",
              "cpobla": "27054050100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27745"
          },
          {
              "lpobla": "A ABELLEIRA (SAN SADURNIÑO)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076060100",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "A CORUÑA",
              "cpostal": "15576"
          },
          {
              "lpobla": "A ABELLEIRA (VILACAMPA)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063100100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27778"
          },
          {
              "lpobla": "A ABELLEIRA (VILANOVA DE AROUSA)",
              "lmunic": "VILANOVA DE AROUSA",
              "cpobla": "36061020100",
              "codPais": "ES",
              "nHabitantes": 83,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36614"
          },
          {
              "lpobla": "A ABELLEIRA (VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066060100",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A ABELLEIRA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021050100",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27835"
          },
          {
              "lpobla": "A ABIDUEIRA (MURAS SAN PEDRO)",
              "lmunic": "MURAS",
              "cpobla": "27033050200",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A ABIDUEIRA (VIVEIRON)",
              "lmunic": "MURAS",
              "cpobla": "27033080100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27837"
          },
          {
              "lpobla": "A ACEA (ALLARIZ)",
              "lmunic": "ALLARIZ",
              "cpobla": "32001160100",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "OURENSE",
              "cpostal": "32668"
          },
          {
              "lpobla": "A ACEA (BAÑOS DE MOLGAS)",
              "lmunic": "BAÑOS DE MOLGAS",
              "cpobla": "32007020100",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "OURENSE",
              "cpostal": "32704"
          },
          {
              "lpobla": "A ACEA (BENDIA)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010050100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27289"
          },
          {
              "lpobla": "A ACEA DE ABAIXO (FARBAN)",
              "lmunic": "SARRIA",
              "cpobla": "27057500100",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "LUGO",
              "cpostal": "27619"
          },
          {
              "lpobla": "A ACEA DE ARRIBA (REIMONDEZ)",
              "lmunic": "SARRIA",
              "cpobla": "27057370400",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27618"
          },
          {
              "lpobla": "A ACEVEDA",
              "lmunic": "XOVE",
              "cpobla": "27025080100",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27877"
          },
          {
              "lpobla": "A ACHADIZA",
              "lmunic": "BUEU",
              "cpobla": "36004010100",
              "codPais": "ES",
              "nHabitantes": 190,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36937"
          },
          {
              "lpobla": "A ADEGA (PARADELA)",
              "lmunic": "PARADELA",
              "cpobla": "27042160200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27611"
          },
          {
              "lpobla": "A AFOZ (A PASTORIZA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044040100",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27286"
          },
          {
              "lpobla": "A AGOLADA (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005020300",
              "codPais": "ES",
              "nHabitantes": 44,
              "lprovi": "LUGO",
              "cpostal": "27792"
          },
          {
              "lpobla": "A AGRA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026080100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A AGRA (GUNTIN)",
              "lmunic": "GUNTIN",
              "cpobla": "27023050100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27181"
          },
          {
              "lpobla": "A AGRA (LEIRO)",
              "lmunic": "LEIRO",
              "cpobla": "32040050100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "OURENSE",
              "cpostal": "32425"
          },
          {
              "lpobla": "A AGRA (O SAVIÑAO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058230100",
              "codPais": "ES",
              "nHabitantes": 34,
              "lprovi": "LUGO",
              "cpostal": "27546"
          },
          {
              "lpobla": "A AGRA (PORTO DO SON)",
              "lmunic": "PORTO DO SON",
              "cpobla": "15071040200",
              "codPais": "ES",
              "nHabitantes": 143,
              "lprovi": "A CORUÑA",
              "cpostal": "15995"
          },
          {
              "lpobla": "A AGRA (SARRIA)",
              "lmunic": "SARRIA",
              "cpobla": "27057110100",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "LUGO",
              "cpostal": "27690"
          },
          {
              "lpobla": "A AGRA (VILARMAIOR)",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091020100",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "A CORUÑA",
              "cpostal": "15616"
          },
          {
              "lpobla": "A AGRELA (AMES)",
              "lmunic": "AMES",
              "cpobla": "15002040900",
              "codPais": "ES",
              "nHabitantes": 76,
              "lprovi": "A CORUÑA",
              "cpostal": "15895"
          },
          {
              "lpobla": "A AGRIS (SANTA COMBA)",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077090100",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "A CORUÑA",
              "cpostal": "15845"
          },
          {
              "lpobla": "A AGUARDA (SAN MARTIÑO)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044010000",
              "codPais": "ES",
              "nHabitantes": 89,
              "lprovi": "LUGO",
              "cpostal": "27248"
          },
          {
              "lpobla": "A AGUEIRA (ALFOZ)",
              "lmunic": "ALFOZ",
              "cpobla": "27002030100",
              "codPais": "ES",
              "nHabitantes": 44,
              "lprovi": "LUGO",
              "cpostal": "27776"
          },
          {
              "lpobla": "A AGUELA (MONFORTE DE LEMOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031250100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27410"
          },
          {
              "lpobla": "A AIRAVELLA (IRIXOA)",
              "lmunic": "IRIXOA",
              "cpobla": "15039040100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15313"
          },
          {
              "lpobla": "A AIRELA",
              "lmunic": "O INCIO",
              "cpobla": "27024240100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27347"
          },
          {
              "lpobla": "A AIREXA (FREIXO)",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018100100",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27134"
          },
          {
              "lpobla": "A AIREXA (GUNDIVOS)",
              "lmunic": "SOBER",
              "cpobla": "27059120500",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27469"
          },
          {
              "lpobla": "A AIREXA (LOBIOS)",
              "lmunic": "SOBER",
              "cpobla": "27059141500",
              "codPais": "ES",
              "nHabitantes": 47,
              "lprovi": "LUGO",
              "cpostal": "27423"
          },
          {
              "lpobla": "A AIREXA (PIÑEIRA)",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018200100",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "LUGO",
              "cpostal": "27135"
          },
          {
              "lpobla": "A AIREXA (ROSENDE)",
              "lmunic": "SOBER",
              "cpobla": "27059200400",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27466"
          },
          {
              "lpobla": "A AIREXA (SAN XOAN DE RIO)",
              "lmunic": "SAN XOAN DE RIO",
              "cpobla": "32070030400",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "OURENSE",
              "cpostal": "32779"
          },
          {
              "lpobla": "A AIREXE (BENADE)",
              "lmunic": "LUGO",
              "cpobla": "27028080100",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27191"
          },
          {
              "lpobla": "A AIREXE (MUXA)",
              "lmunic": "LUGO",
              "cpobla": "27028330100",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "LUGO",
              "cpostal": "27192"
          },
          {
              "lpobla": "A AIREXE (PENA)",
              "lmunic": "LUGO",
              "cpobla": "27028370100",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "LUGO",
              "cpostal": "27160"
          },
          {
              "lpobla": "A AIREXE (PROGALO)",
              "lmunic": "LUGO",
              "cpobla": "27028420100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27233"
          },
          {
              "lpobla": "A AIROA",
              "lmunic": "IRIXOA",
              "cpobla": "15039010100",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15319"
          },
          {
              "lpobla": "A AIROA (CHANTADA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016280100",
              "codPais": "ES",
              "nHabitantes": 97,
              "lprovi": "LUGO",
              "cpostal": "27516"
          },
          {
              "lpobla": "A AIROA DO REI",
              "lmunic": "IRIXOA",
              "cpobla": "15039050100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "A CORUÑA",
              "cpostal": "15314"
          },
          {
              "lpobla": "A AIROA (PANTON)",
              "lmunic": "PANTON",
              "cpobla": "27041052300",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27438"
          },
          {
              "lpobla": "A ALBARIZA (IRIXOA)",
              "lmunic": "IRIXOA",
              "cpobla": "15039070200",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "A CORUÑA",
              "cpostal": "15319"
          },
          {
              "lpobla": "A ALBERGUERIA (A ESTRADA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017130200",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36584"
          },
          {
              "lpobla": "A ALBERGUERIA (MORAÑA)",
              "lmunic": "MORAÑA",
              "cpobla": "36032090100",
              "codPais": "ES",
              "nHabitantes": 139,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36669"
          },
          {
              "lpobla": "A ALBERGUERIA (SANTA MARIA LAZA)",
              "lmunic": "LAZA",
              "cpobla": "32039010000",
              "codPais": "ES",
              "nHabitantes": 40,
              "lprovi": "OURENSE",
              "cpostal": "32622"
          },
          {
              "lpobla": "A ALBERGUERIA (SANTA MARIA VILAR)",
              "lmunic": "VILAR DE BARRIO",
              "cpobla": "32089010000",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "OURENSE",
              "cpostal": "32702"
          },
          {
              "lpobla": "A ALBOIANA",
              "lmunic": "XERMADE",
              "cpobla": "27021010200",
              "codPais": "ES",
              "nHabitantes": 33,
              "lprovi": "LUGO",
              "cpostal": "27832"
          },
          {
              "lpobla": "A ALDEA (BALDOMAR)",
              "lmunic": "BEGONTE",
              "cpobla": "27007020100",
              "codPais": "ES",
              "nHabitantes": 62,
              "lprovi": "LUGO",
              "cpostal": "27373"
          },
          {
              "lpobla": "A ALDEA (BERGONDO)",
              "lmunic": "BERGONDO",
              "cpobla": "15008030100",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "A CORUÑA",
              "cpostal": "15319"
          },
          {
              "lpobla": "A ALDEA (CABARCOS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005040100",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27798"
          },
          {
              "lpobla": "A ALDEA (CASTRO DE REI)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010230100",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "LUGO",
              "cpostal": "27258"
          },
          {
              "lpobla": "A ALDEA (CEDEIRA)",
              "lmunic": "REDONDELA",
              "cpobla": "36045020100",
              "codPais": "ES",
              "nHabitantes": 212,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36812"
          },
          {
              "lpobla": "A ALDEA DE ABAIXO (RUBIAS)",
              "lmunic": "LUGO",
              "cpobla": "27028460100",
              "codPais": "ES",
              "nHabitantes": 58,
              "lprovi": "LUGO",
              "cpostal": "27191"
          },
          {
              "lpobla": "A ALDEA DE ABAIXO (SANTIAGO COMPOSTELA)",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078100100",
              "codPais": "ES",
              "nHabitantes": 69,
              "lprovi": "A CORUÑA",
              "cpostal": "15890"
          },
          {
              "lpobla": "A ALDEA DE ABAIXO (XOVE)",
              "lmunic": "XOVE",
              "cpobla": "27025030100",
              "codPais": "ES",
              "nHabitantes": 33,
              "lprovi": "LUGO",
              "cpostal": "27876"
          },
          {
              "lpobla": "A ALDEA DE ARRIBA (BERGONDO)",
              "lmunic": "BERGONDO",
              "cpobla": "15008010100",
              "codPais": "ES",
              "nHabitantes": 135,
              "lprovi": "A CORUÑA",
              "cpostal": "15165"
          },
          {
              "lpobla": "A ALDEA DE ARRIBA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020170100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A ALDEA DE ARRIBA (VILAGARCIA DE AROUSA)",
              "lmunic": "VILAGARCIA DE AROUSA",
              "cpobla": "36060040100",
              "codPais": "ES",
              "nHabitantes": 86,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36617"
          },
          {
              "lpobla": "A ALDEA DE BAIXO (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005080200",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27798"
          },
          {
              "lpobla": "A ALDEA DE BAIXO (CASTRO DE REI)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010130100",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "LUGO",
              "cpostal": "27271"
          },
          {
              "lpobla": "A ALDEA DE RIBA (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005080300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27798"
          },
          {
              "lpobla": "A ALDEA DE XAVESTRE",
              "lmunic": "TRAZO",
              "cpobla": "15086110400",
              "codPais": "ES",
              "nHabitantes": 70,
              "lprovi": "A CORUÑA",
              "cpostal": "15686"
          },
          {
              "lpobla": "A ALDEA (FERROL)",
              "lmunic": "FERROL",
              "cpobla": "15036030100",
              "codPais": "ES",
              "nHabitantes": 164,
              "lprovi": "A CORUÑA",
              "cpostal": "15594"
          },
          {
              "lpobla": "A ALDEA (FIGUEIRAS)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030030100",
              "codPais": "ES",
              "nHabitantes": 32,
              "lprovi": "LUGO",
              "cpostal": "27749"
          },
          {
              "lpobla": "A ALDEA (FRAYAS)",
              "lmunic": "ABADIN",
              "cpobla": "27001100100",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27738"
          },
          {
              "lpobla": "A ALDEA GRANDE (RIBELA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017380100",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36687"
          },
          {
              "lpobla": "A ALDEA (PIÑEIRO)",
              "lmunic": "XERMADE",
              "cpobla": "27021080100",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27833"
          },
          {
              "lpobla": "A ALDEA (RAMIRAS)",
              "lmunic": "RAMIRAS",
              "cpobla": "32068070100",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "OURENSE",
              "cpostal": "32811"
          },
          {
              "lpobla": "A ALDEA (SANTA COMBA)",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077140100",
              "codPais": "ES",
              "nHabitantes": 93,
              "lprovi": "A CORUÑA",
              "cpostal": "15841"
          },
          {
              "lpobla": "A ALDEA (TABOADA)",
              "lmunic": "TABOADA",
              "cpobla": "27060200100",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27559"
          },
          {
              "lpobla": "A ALDEA (VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066050100",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "LUGO",
              "cpostal": "27863"
          },
          {
              "lpobla": "A ALDEA (XERMAR)",
              "lmunic": "COSPEITO",
              "cpobla": "27015190100",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27377"
          },
          {
              "lpobla": "A ALENCE (SANTA LUCIA)",
              "lmunic": "AS NOGAIS",
              "cpobla": "27037010000",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "LUGO",
              "cpostal": "27677"
          },
          {
              "lpobla": "A ALENZA (SAN XOAN DE RIO)",
              "lmunic": "SAN XOAN DE RIO",
              "cpobla": "32070070200",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "OURENSE",
              "cpostal": "32770"
          },
          {
              "lpobla": "A ALFANDIGA",
              "lmunic": "PANTON",
              "cpobla": "27041240100",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27593"
          },
          {
              "lpobla": "A ALGARA",
              "lmunic": "CARBALLO",
              "cpobla": "15019110100",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15105"
          },
          {
              "lpobla": "A ALLEIRA",
              "lmunic": "CERVO",
              "cpobla": "27013070100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27889"
          },
          {
              "lpobla": "A ALLONCA (SANTA MARIA)",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018010000",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27113"
          },
          {
              "lpobla": "A ALLONQUIÑA",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018010200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27113"
          },
          {
              "lpobla": "A ALMUIÑA (SALCEDO)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038150100",
              "codPais": "ES",
              "nHabitantes": 50,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36143"
          },
          {
              "lpobla": "A ALTIBOA (ARTES)",
              "lmunic": "CARBALLO",
              "cpobla": "15019030200",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A ALVARIÑA",
              "lmunic": "O VALADOURO",
              "cpobla": "27063080100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27777"
          },
          {
              "lpobla": "A ALZADA",
              "lmunic": "FRIOL",
              "cpobla": "27020230100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A AMAÑECIDA (SANTIAGO DE COMPOSTELA)",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078150100",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "A CORUÑA",
              "cpostal": "15897"
          },
          {
              "lpobla": "A AMARELA",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042140100",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36863"
          },
          {
              "lpobla": "A AMARELA (O VALADOURO)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063010100",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27779"
          },
          {
              "lpobla": "A AMARELA (VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066060400",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A AMARELLE (ARCA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017050200",
              "codPais": "ES",
              "nHabitantes": 32,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36684"
          },
          {
              "lpobla": "A AMEIXEIRA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026060200",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A AMEIXENDA (SANTIAGO)",
              "lmunic": "CEE",
              "cpobla": "15023010000",
              "codPais": "ES",
              "nHabitantes": 629,
              "lprovi": "A CORUÑA",
              "cpostal": "15298"
          },
          {
              "lpobla": "A AMEIXOADA",
              "lmunic": "MOAÑA",
              "cpobla": "36029030200",
              "codPais": "ES",
              "nHabitantes": 277,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36954"
          },
          {
              "lpobla": "A AMOA (O VICEDO)",
              "lmunic": "O VICEDO",
              "cpobla": "27064010100",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27868"
          },
          {
              "lpobla": "A AMOEIRA",
              "lmunic": "CERVO",
              "cpobla": "27013050300",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27889"
          },
          {
              "lpobla": "A AMOREIRA (PORTO DO SON)",
              "lmunic": "PORTO DO SON",
              "cpobla": "15071050100",
              "codPais": "ES",
              "nHabitantes": 122,
              "lprovi": "A CORUÑA",
              "cpostal": "15970"
          },
          {
              "lpobla": "A AMPROA (VILAGARCIA DE AROUSA)",
              "lmunic": "VILAGARCIA DE AROUSA",
              "cpobla": "36060020100",
              "codPais": "ES",
              "nHabitantes": 39,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36618"
          },
          {
              "lpobla": "A ANAGAZA",
              "lmunic": "A POBRA DE TRIVES",
              "cpobla": "32063150300",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "OURENSE",
              "cpostal": "32789"
          },
          {
              "lpobla": "A ANDORIÑA",
              "lmunic": "BALEIRA",
              "cpobla": "27004030100",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27133"
          },
          {
              "lpobla": "A ANDORIÑA (VILARMAIOR)",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091020300",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15616"
          },
          {
              "lpobla": "A ANDRAGALLA",
              "lmunic": "ZAS",
              "cpobla": "15093080100",
              "codPais": "ES",
              "nHabitantes": 119,
              "lprovi": "A CORUÑA",
              "cpostal": "15851"
          },
          {
              "lpobla": "A ANDURIÑA (MELIDE)",
              "lmunic": "MELIDE",
              "cpobla": "15046090100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15809"
          },
          {
              "lpobla": "A ANEA",
              "lmunic": "BARREIROS",
              "cpobla": "27005010100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27790"
          },
          {
              "lpobla": "A ANELLA",
              "lmunic": "CESURAS",
              "cpobla": "15026120200",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A ANLLADA",
              "lmunic": "CUNTIS",
              "cpobla": "36015010100",
              "codPais": "ES",
              "nHabitantes": 59,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36677"
          },
          {
              "lpobla": "A ANOCA",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010110200",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27259"
          },
          {
              "lpobla": "A ANXERIZ (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038080100",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A AOLIVEIRA (ARNOSO)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042040300",
              "codPais": "ES",
              "nHabitantes": 140,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36892"
          },
          {
              "lpobla": "A ARADA (VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066070100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27866"
          },
          {
              "lpobla": "A ARADIZA",
              "lmunic": "PORTO DO SON",
              "cpobla": "15071040300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15995"
          },
          {
              "lpobla": "A ARBIGUEIRA",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076030200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15580"
          },
          {
              "lpobla": "A ARCA",
              "lmunic": "ABADIN",
              "cpobla": "27001160200",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "LUGO",
              "cpostal": "27737"
          },
          {
              "lpobla": "A AREA (CARIÑO)",
              "lmunic": "CARIÑO",
              "cpobla": "15901040200",
              "codPais": "ES",
              "nHabitantes": 71,
              "lprovi": "A CORUÑA",
              "cpostal": "15365"
          },
          {
              "lpobla": "A AREOSA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019150300",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A AREOSA (CUIÑA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061062800",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "A CORUÑA",
              "cpostal": "15332"
          },
          {
              "lpobla": "A AREOSA (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022100100",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27372"
          },
          {
              "lpobla": "A AREOSA (MONTERROSO)",
              "lmunic": "MONTERROSO",
              "cpobla": "27032160100",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27568"
          },
          {
              "lpobla": "A AREOSA (PALAS DE REI)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040030200",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27204"
          },
          {
              "lpobla": "A AREOSA (VILARMAIOR)",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091060100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15637"
          },
          {
              "lpobla": "A AREOSA (VIMIANZO)",
              "lmunic": "VIMIANZO",
              "cpobla": "15092130100",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "A CORUÑA",
              "cpostal": "15126"
          },
          {
              "lpobla": "A ARGA DE ABAIXO",
              "lmunic": "FRIOL",
              "cpobla": "27020050100",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A ARGA DE ARRIBA",
              "lmunic": "FRIOL",
              "cpobla": "27020050200",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A ARMADA (CARTELLE)",
              "lmunic": "CARTELLE",
              "cpobla": "32020020100",
              "codPais": "ES",
              "nHabitantes": 61,
              "lprovi": "OURENSE",
              "cpostal": "32822"
          },
          {
              "lpobla": "A ARMADA (LANCARA)",
              "lmunic": "LANCARA",
              "cpobla": "27026060100",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27693"
          },
          {
              "lpobla": "A ARMADA (MURAS SAN PEDRO)",
              "lmunic": "MURAS",
              "cpobla": "27033050400",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A ARMADA (O BURGO)",
              "lmunic": "MURAS",
              "cpobla": "27033030200",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A ARMADA (O PARAMO)",
              "lmunic": "O PARAMO",
              "cpobla": "27043140100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27363"
          },
          {
              "lpobla": "A ARMADA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061270200",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "A CORUÑA",
              "cpostal": "15338"
          },
          {
              "lpobla": "A ARMADA (SALCEDO)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038152000",
              "codPais": "ES",
              "nHabitantes": 108,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36143"
          },
          {
              "lpobla": "A ARMADA (VILARMAIOR)",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091060200",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15637"
          },
          {
              "lpobla": "A ARMADA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021090300",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27835"
          },
          {
              "lpobla": "A ARMENTEIRA (SANTA MARIA)",
              "lmunic": "MEIS",
              "cpobla": "36028010000",
              "codPais": "ES",
              "nHabitantes": 833,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36192"
          },
          {
              "lpobla": "A ARMILDA",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018150200",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27113"
          },
          {
              "lpobla": "A ARMUCELA",
              "lmunic": "CESURAS",
              "cpobla": "15026020100",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "A CORUÑA",
              "cpostal": "15390"
          },
          {
              "lpobla": "A ARNELA (ABADIN)",
              "lmunic": "ABADIN",
              "cpobla": "27001070100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27845"
          },
          {
              "lpobla": "A ARNELA (ALFOZ)",
              "lmunic": "ALFOZ",
              "cpobla": "27002080200",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "LUGO",
              "cpostal": "27775"
          },
          {
              "lpobla": "A ARNELA (O VALADOURO)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063010200",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27779"
          },
          {
              "lpobla": "A ARNELA (PORTO DO SON)",
              "lmunic": "PORTO DO SON",
              "cpobla": "15071010200",
              "codPais": "ES",
              "nHabitantes": 89,
              "lprovi": "A CORUÑA",
              "cpostal": "15979"
          },
          {
              "lpobla": "A ARNOBA",
              "lmunic": "TRAZO",
              "cpobla": "15086030100",
              "codPais": "ES",
              "nHabitantes": 50,
              "lprovi": "A CORUÑA",
              "cpostal": "15687"
          },
          {
              "lpobla": "A ARNOIA",
              "lmunic": "A ARNOIA",
              "cpobla": "32003000000",
              "codPais": "ES",
              "nHabitantes": 1233,
              "lprovi": "OURENSE",
              "cpostal": "32417"
          },
          {
              "lpobla": "A ARNOIA (SAN SALVADOR)",
              "lmunic": "A ARNOIA",
              "cpobla": "32003010000",
              "codPais": "ES",
              "nHabitantes": 1233,
              "lprovi": "OURENSE",
              "cpostal": "32417"
          },
          {
              "lpobla": "A AROSA (SANTA COMBA)",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077100100",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "A CORUÑA",
              "cpostal": "15841"
          },
          {
              "lpobla": "A ARQUEIRA",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018070200",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27116"
          },
          {
              "lpobla": "A ARRABAL (PONTEAREAS)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042130100",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36861"
          },
          {
              "lpobla": "A ARREDOADA (VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066070200",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27866"
          },
          {
              "lpobla": "A ARREDOADA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021010300",
              "codPais": "ES",
              "nHabitantes": 34,
              "lprovi": "LUGO",
              "cpostal": "27832"
          },
          {
              "lpobla": "A ARRIBADA",
              "lmunic": "PANTON",
              "cpobla": "27041030100",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "LUGO",
              "cpostal": "27437"
          },
          {
              "lpobla": "A ARRIFANA",
              "lmunic": "RAMIRAS",
              "cpobla": "32068100100",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "OURENSE",
              "cpostal": "32811"
          },
          {
              "lpobla": "A ARROTEA",
              "lmunic": "CELANOVA",
              "cpobla": "32024130100",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "OURENSE",
              "cpostal": "32815"
          },
          {
              "lpobla": "A ARROTEA (PONTELLAS)",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039060200",
              "codPais": "ES",
              "nHabitantes": 255,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36412"
          },
          {
              "lpobla": "A ARROXIÑA (NAVIA DE SUARNA)",
              "lmunic": "NAVIA DE SUARNA",
              "cpobla": "27034100100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27659"
          },
          {
              "lpobla": "A ASCENSION (PONTEAREAS)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042090100",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36865"
          },
          {
              "lpobla": "A ASPERA (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005010200",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "LUGO",
              "cpostal": "27790"
          },
          {
              "lpobla": "A ASPERA (BOVEDA)",
              "lmunic": "BOVEDA",
              "cpobla": "27008070100",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27349"
          },
          {
              "lpobla": "A ASPERA (CASTRO DE REI)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010040100",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27259"
          },
          {
              "lpobla": "A ASPERA (MONDOÑEDO)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030080200",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27748"
          },
          {
              "lpobla": "A ASPERA (O VICEDO)",
              "lmunic": "O VICEDO",
              "cpobla": "27064030200",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "LUGO",
              "cpostal": "27861"
          },
          {
              "lpobla": "A ASPERA (XOVE)",
              "lmunic": "XOVE",
              "cpobla": "27025010300",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27878"
          },
          {
              "lpobla": "A ATADOIRA",
              "lmunic": "VILALBA",
              "cpobla": "27065030200",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27814"
          },
          {
              "lpobla": "A ATALAIA (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087090200",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "A CORUÑA",
              "cpostal": "15554"
          },
          {
              "lpobla": "A ATALAIA (ZAS)",
              "lmunic": "ZAS",
              "cpobla": "15093100100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "A CORUÑA",
              "cpostal": "15857"
          },
          {
              "lpobla": "A AUGAXOSA",
              "lmunic": "RIOTORTO",
              "cpobla": "27054060100",
              "codPais": "ES",
              "nHabitantes": 70,
              "lprovi": "LUGO",
              "cpostal": "27743"
          },
          {
              "lpobla": "A AUGUELA",
              "lmunic": "VEREA",
              "cpobla": "32084030100",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "OURENSE",
              "cpostal": "32813"
          },
          {
              "lpobla": "A AUREANA",
              "lmunic": "XERMADE",
              "cpobla": "27021080200",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27833"
          },
          {
              "lpobla": "A AVELOSA",
              "lmunic": "GONDOMAR",
              "cpobla": "36021070100",
              "codPais": "ES",
              "nHabitantes": 34,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36389"
          },
          {
              "lpobla": "A AVIEIRA",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040220100",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27209"
          },
          {
              "lpobla": "A AVIEIRA (OZA DOS RIOS)",
              "lmunic": "OZA DOS RIOS",
              "cpobla": "15063060100",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "A CORUÑA",
              "cpostal": "15388"
          },
          {
              "lpobla": "A AZ (A SAVIÑAO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058140100",
              "codPais": "ES",
              "nHabitantes": 59,
              "lprovi": "LUGO",
              "cpostal": "27546"
          },
          {
              "lpobla": "A AZOREIRA (ALFOZ)",
              "lmunic": "ALFOZ",
              "cpobla": "27002050400",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27774"
          },
          {
              "lpobla": "A AZOREIRA (BALEIRA)",
              "lmunic": "BALEIRA",
              "cpobla": "27004020300",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27131"
          },
          {
              "lpobla": "A AZOREIRA (CASTROVERDE)",
              "lmunic": "CASTROVERDE",
              "cpobla": "27011130200",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27123"
          },
          {
              "lpobla": "A AZOREIRA (MEIRA)",
              "lmunic": "MEIRA",
              "cpobla": "27029020100",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27241"
          },
          {
              "lpobla": "A AZOREIRA (O VALADOURO)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063100200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27778"
          },
          {
              "lpobla": "A AZOREIRA (RIOTORTO)",
              "lmunic": "RIOTORTO",
              "cpobla": "27054050300",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27745"
          },
          {
              "lpobla": "A AZOREIRA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021090500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27835"
          },
          {
              "lpobla": "A AZUMARA (SAN XOAN)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010020000",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "LUGO",
              "cpostal": "27257"
          },
          {
              "lpobla": "A BABILONIA",
              "lmunic": "OLEIROS",
              "cpobla": "15058040100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15179"
          },
          {
              "lpobla": "A BAGAÑEIRA",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042240100",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36866"
          },
          {
              "lpobla": "A BAGULLA",
              "lmunic": "FRIOL",
              "cpobla": "27020320300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27227"
          },
          {
              "lpobla": "A BAIA",
              "lmunic": "NOIA",
              "cpobla": "15057010200",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "A CORUÑA",
              "cpostal": "15213"
          },
          {
              "lpobla": "A BAILADA",
              "lmunic": "BEGONTE",
              "cpobla": "27007040100",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "LUGO",
              "cpostal": "27372"
          },
          {
              "lpobla": "A BAIUCA",
              "lmunic": "VILAMARIN",
              "cpobla": "32087050200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "OURENSE",
              "cpostal": "32101"
          },
          {
              "lpobla": "A BAIUCA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026050100",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A BAIUCA DE PULLEIRO",
              "lmunic": "OZA DOS RIOS",
              "cpobla": "15063031000",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "A CORUÑA",
              "cpostal": "15389"
          },
          {
              "lpobla": "A BAIUCA (RODEIRO)",
              "lmunic": "RODEIRO",
              "cpobla": "36047200200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36539"
          },
          {
              "lpobla": "A BAIXA (CERCEDA SAN MARTIN)",
              "lmunic": "CERCEDA",
              "cpobla": "15024014500",
              "codPais": "ES",
              "nHabitantes": 340,
              "lprovi": "A CORUÑA",
              "cpostal": "15185"
          },
          {
              "lpobla": "A BAIXA (TRAZO)",
              "lmunic": "TRAZO",
              "cpobla": "15086090100",
              "codPais": "ES",
              "nHabitantes": 91,
              "lprovi": "A CORUÑA",
              "cpostal": "15687"
          },
          {
              "lpobla": "A BALEA (CERPONZONS)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038061500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36152"
          },
          {
              "lpobla": "A BALSA (BECERREA)",
              "lmunic": "BECERREA",
              "cpobla": "27006010200",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27678"
          },
          {
              "lpobla": "A BALSA (NAVIA DE SUARNA)",
              "lmunic": "NAVIA DE SUARNA",
              "cpobla": "27034150100",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27654"
          },
          {
              "lpobla": "A BALSA (O VALADOURO)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063020400",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27777"
          },
          {
              "lpobla": "A BALSA (OUTEIRO DE REI)",
              "lmunic": "OUTEIRO DE REI",
              "cpobla": "27039010100",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27153"
          },
          {
              "lpobla": "A BALSA PEQUENA",
              "lmunic": "VILALBA",
              "cpobla": "27065290200",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27816"
          },
          {
              "lpobla": "A BALSA (SAN BREIXO)",
              "lmunic": "TRIACASTELA",
              "cpobla": "27062020000",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27631"
          },
          {
              "lpobla": "A BALSA (SANTA MARIA)",
              "lmunic": "MURAS",
              "cpobla": "27033020000",
              "codPais": "ES",
              "nHabitantes": 125,
              "lprovi": "LUGO",
              "cpostal": "27817"
          },
          {
              "lpobla": "A BANDEIRA (MEIS)",
              "lmunic": "MEIS",
              "cpobla": "36028020200",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36637"
          },
          {
              "lpobla": "A BANDEXA (VILACAMPA)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063100300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27778"
          },
          {
              "lpobla": "A BAÑA",
              "lmunic": "A BAÑA",
              "cpobla": "15007000000",
              "codPais": "ES",
              "nHabitantes": 5036,
              "lprovi": "A CORUÑA",
              "cpostal": "15863"
          },
          {
              "lpobla": "A BAÑA (SAN VICENTE)",
              "lmunic": "A BAÑA",
              "cpobla": "15007010000",
              "codPais": "ES",
              "nHabitantes": 753,
              "lprovi": "A CORUÑA",
              "cpostal": "15863"
          },
          {
              "lpobla": "A BARBELA",
              "lmunic": "A CAPELA",
              "cpobla": "15018040300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A BARCA (CAMBADOS)",
              "lmunic": "CAMBADOS",
              "cpobla": "36006020300",
              "codPais": "ES",
              "nHabitantes": 142,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36639"
          },
          {
              "lpobla": "A BARCA DE ARRIBA",
              "lmunic": "FERROL",
              "cpobla": "15036020100",
              "codPais": "ES",
              "nHabitantes": 90,
              "lprovi": "A CORUÑA",
              "cpostal": "15590"
          },
          {
              "lpobla": "A BARCA DE BARBANTES",
              "lmunic": "CENLLE",
              "cpobla": "32025100100",
              "codPais": "ES",
              "nHabitantes": 146,
              "lprovi": "OURENSE",
              "cpostal": "32450"
          },
          {
              "lpobla": "A BARCA DE BARBANTES (SAN ANTONIO)",
              "lmunic": "CENLLE",
              "cpobla": "32025100000",
              "codPais": "ES",
              "nHabitantes": 146,
              "lprovi": "OURENSE",
              "cpostal": "32454"
          },
          {
              "lpobla": "A BARCA DE MANCEBICO",
              "lmunic": "QUIROGA",
              "cpobla": "27050110100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27329"
          },
          {
              "lpobla": "A BARCA DO CASTELO",
              "lmunic": "QUIROGA",
              "cpobla": "27050160100",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27320"
          },
          {
              "lpobla": "A BARCA (PANTON)",
              "lmunic": "PANTON",
              "cpobla": "27041110100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27437"
          },
          {
              "lpobla": "A BARCA (PORTO)",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050130200",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36458"
          },
          {
              "lpobla": "A BARCA (SOBER)",
              "lmunic": "SOBER",
              "cpobla": "27059021700",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27466"
          },
          {
              "lpobla": "A BARCALA (OLEIROS)",
              "lmunic": "OLEIROS",
              "cpobla": "15058060100",
              "codPais": "ES",
              "nHabitantes": 41,
              "lprovi": "A CORUÑA",
              "cpostal": "15176"
          },
          {
              "lpobla": "A BARCIA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019160100",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A BARCIA (MARCON)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038110200",
              "codPais": "ES",
              "nHabitantes": 297,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36158"
          },
          {
              "lpobla": "A BARCIA (MEIS)",
              "lmunic": "MEIS",
              "cpobla": "36028020300",
              "codPais": "ES",
              "nHabitantes": 68,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36637"
          },
          {
              "lpobla": "A BARCIA (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038020200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A BARCIA (SAN SADURNIÑO)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076060200",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "A CORUÑA",
              "cpostal": "15576"
          },
          {
              "lpobla": "A BARCIA (SANTIAGO DE COMPOSTELA)",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078150200",
              "codPais": "ES",
              "nHabitantes": 136,
              "lprovi": "A CORUÑA",
              "cpostal": "15897"
          },
          {
              "lpobla": "A BARCIELA (SANTO ANDRE)",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078030000",
              "codPais": "ES",
              "nHabitantes": 52,
              "lprovi": "A CORUÑA",
              "cpostal": "15688"
          },
          {
              "lpobla": "A BARDANCA",
              "lmunic": "CARBALLO",
              "cpobla": "15019160200",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A BARGA",
              "lmunic": "GONDOMAR",
              "cpobla": "36021040500",
              "codPais": "ES",
              "nHabitantes": 98,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36388"
          },
          {
              "lpobla": "A BAROSA (OZA DOS RIOS)",
              "lmunic": "OZA DOS RIOS",
              "cpobla": "15063010300",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "A CORUÑA",
              "cpostal": "15388"
          },
          {
              "lpobla": "A BAROSELA",
              "lmunic": "MORAÑA",
              "cpobla": "36032090200",
              "codPais": "ES",
              "nHabitantes": 57,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36669"
          },
          {
              "lpobla": "A BARQUEIRA (ABADIN)",
              "lmunic": "ABADIN",
              "cpobla": "27001090100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27738"
          },
          {
              "lpobla": "A BARQUEIRA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026020200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "A CORUÑA",
              "cpostal": "15390"
          },
          {
              "lpobla": "A BARQUEIRA (SAN ANTON)",
              "lmunic": "CERDIDO",
              "cpobla": "15025010000",
              "codPais": "ES",
              "nHabitantes": 759,
              "lprovi": "A CORUÑA",
              "cpostal": "15569"
          },
          {
              "lpobla": "A BARQUIÑA (NOIA)",
              "lmunic": "NOIA",
              "cpobla": "15057020400",
              "codPais": "ES",
              "nHabitantes": 405,
              "lprovi": "A CORUÑA",
              "cpostal": "15210"
          },
          {
              "lpobla": "A BARQUIÑA (OUTES)",
              "lmunic": "OUTES",
              "cpobla": "15062050200",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "A CORUÑA",
              "cpostal": "15287"
          },
          {
              "lpobla": "A BARRA (OZA DOS RIOS)",
              "lmunic": "OZA DOS RIOS",
              "cpobla": "15063100100",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "A CORUÑA",
              "cpostal": "15386"
          },
          {
              "lpobla": "A BARRA (SANTA MARIA)",
              "lmunic": "COLES",
              "cpobla": "32026030000",
              "codPais": "ES",
              "nHabitantes": 196,
              "lprovi": "OURENSE",
              "cpostal": "32152"
          },
          {
              "lpobla": "A BARRACA",
              "lmunic": "RIANXO",
              "cpobla": "15072050600",
              "codPais": "ES",
              "nHabitantes": 50,
              "lprovi": "A CORUÑA",
              "cpostal": "15920"
          },
          {
              "lpobla": "A BARRACA",
              "lmunic": "CELANOVA",
              "cpobla": "32024090100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "OURENSE",
              "cpostal": "32817"
          },
          {
              "lpobla": "A BARRANCA (GUNTIN)",
              "lmunic": "GUNTIN",
              "cpobla": "27023060100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27181"
          },
          {
              "lpobla": "A BARREIRA (A FONSAGRADA)",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018290200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27113"
          },
          {
              "lpobla": "A BARREIRA (CARBALLIDO)",
              "lmunic": "VILALBA",
              "cpobla": "27065050100",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "LUGO",
              "cpostal": "27843"
          },
          {
              "lpobla": "A BARREIRA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019070100",
              "codPais": "ES",
              "nHabitantes": 42,
              "lprovi": "A CORUÑA",
              "cpostal": "15102"
          },
          {
              "lpobla": "A BARREIRA (CELANOVA)",
              "lmunic": "CELANOVA",
              "cpobla": "32024130200",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "OURENSE",
              "cpostal": "32815"
          },
          {
              "lpobla": "A BARREIRA (MEILAN)",
              "lmunic": "LUGO",
              "cpobla": "27028291100",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "LUGO",
              "cpostal": "27296"
          },
          {
              "lpobla": "A BARREIRA (MONTERROSO)",
              "lmunic": "MONTERROSO",
              "cpobla": "27032120100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27215"
          },
          {
              "lpobla": "A BARREIRA (O VICEDO)",
              "lmunic": "O VICEDO",
              "cpobla": "27064030300",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27861"
          },
          {
              "lpobla": "A BARREIRA (OUTES)",
              "lmunic": "OUTES",
              "cpobla": "15062090100",
              "codPais": "ES",
              "nHabitantes": 80,
              "lprovi": "A CORUÑA",
              "cpostal": "15236"
          },
          {
              "lpobla": "A BARREIRA (PALAS DE REI)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040170300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27205"
          },
          {
              "lpobla": "A BARREIRA (PANTIN)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087050300",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "A CORUÑA",
              "cpostal": "15553"
          },
          {
              "lpobla": "A BARREIRA (SOBER)",
              "lmunic": "SOBER",
              "cpobla": "27059030300",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27466"
          },
          {
              "lpobla": "A BARREIRA (VILARMAIOR)",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091040100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "A CORUÑA",
              "cpostal": "15638"
          },
          {
              "lpobla": "A BARRELA (CARBALLEDO)",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009180100",
              "codPais": "ES",
              "nHabitantes": 198,
              "lprovi": "LUGO",
              "cpostal": "27520"
          },
          {
              "lpobla": "A BARRELA (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038080200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A BARROCA",
              "lmunic": "OIA",
              "cpobla": "36036060100",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36309"
          },
          {
              "lpobla": "A BARRONCA",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042240300",
              "codPais": "ES",
              "nHabitantes": 32,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36866"
          },
          {
              "lpobla": "A BARROSA (BARALLA)",
              "lmunic": "BARALLA",
              "cpobla": "27901170100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27697"
          },
          {
              "lpobla": "A BARROSA (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005070200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27794"
          },
          {
              "lpobla": "A BARROSA (CASTRO DE REI)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010170100",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27256"
          },
          {
              "lpobla": "A BARXA (BARBADAS)",
              "lmunic": "BARBADAS",
              "cpobla": "32008040100",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "OURENSE",
              "cpostal": "32930"
          },
          {
              "lpobla": "A BARXA (O SAVIÑAO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058070400",
              "codPais": "ES",
              "nHabitantes": 32,
              "lprovi": "LUGO",
              "cpostal": "27548"
          },
          {
              "lpobla": "A BARXA (RIVASALTAS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031190200",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27410"
          },
          {
              "lpobla": "A BARXA (SARRIA)",
              "lmunic": "SARRIA",
              "cpobla": "27057070200",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27619"
          },
          {
              "lpobla": "A BARXA (XOVE)",
              "lmunic": "XOVE",
              "cpobla": "27025010400",
              "codPais": "ES",
              "nHabitantes": 65,
              "lprovi": "LUGO",
              "cpostal": "27878"
          },
          {
              "lpobla": "A BARXELA (MONFORTE DE LEMOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031170100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27420"
          },
          {
              "lpobla": "A BARXELA (NOGUEIRA DE RAMUIN)",
              "lmunic": "NOGUEIRA DE RAMUIN",
              "cpobla": "32052030200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "OURENSE",
              "cpostal": "32448"
          },
          {
              "lpobla": "A BARXIÑA",
              "lmunic": "CELANOVA",
              "cpobla": "32024040300",
              "codPais": "ES",
              "nHabitantes": 41,
              "lprovi": "OURENSE",
              "cpostal": "32816"
          },
          {
              "lpobla": "A BASTEIRA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061DD0100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15338"
          },
          {
              "lpobla": "A BASTIDA (SAN MIGUEL)",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018030000",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27112"
          },
          {
              "lpobla": "A BATOCA",
              "lmunic": "PADERNE DE ALLARIZ",
              "cpobla": "32055050100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "OURENSE",
              "cpostal": "32112"
          },
          {
              "lpobla": "A BAZAQUEIRA",
              "lmunic": "CESURAS",
              "cpobla": "15026120400",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A BEDOXA",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087060100",
              "codPais": "ES",
              "nHabitantes": 41,
              "lprovi": "A CORUÑA",
              "cpostal": "15550"
          },
          {
              "lpobla": "A BEIRA DA FRAGA",
              "lmunic": "OUROL",
              "cpobla": "27038011300",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A BEIRA DO RIO (A PASTORIZA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044010700",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27248"
          },
          {
              "lpobla": "A BEIRA DO RIO (LINDIN)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030040600",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27742"
          },
          {
              "lpobla": "A BEIRA DO RIO (SANTA MARIA MAIOR)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030061000",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27742"
          },
          {
              "lpobla": "A BEIRA DO RIO (VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066065100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A BEIRADA",
              "lmunic": "PADERNE DE ALLARIZ",
              "cpobla": "32055010400",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "OURENSE",
              "cpostal": "32112"
          },
          {
              "lpobla": "A BELGA",
              "lmunic": "PORTO DO SON",
              "cpobla": "15071070100",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "A CORUÑA",
              "cpostal": "15978"
          },
          {
              "lpobla": "A BEMPOSTA",
              "lmunic": "A ESTRADA",
              "cpobla": "36017400600",
              "codPais": "ES",
              "nHabitantes": 58,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36686"
          },
          {
              "lpobla": "A BEMPOSTA (VILARDEVOS)",
              "lmunic": "VILARDEVOS",
              "cpobla": "32091060100",
              "codPais": "ES",
              "nHabitantes": 68,
              "lprovi": "OURENSE",
              "cpostal": "32617"
          },
          {
              "lpobla": "A BERDEAL (O VALADOURO)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063DD0100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27777"
          },
          {
              "lpobla": "A BERGAÑA",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087070800",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "A CORUÑA",
              "cpostal": "15552"
          },
          {
              "lpobla": "A BERGAZA",
              "lmunic": "QUIROGA",
              "cpobla": "27050080500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27329"
          },
          {
              "lpobla": "A BERGUEIRA",
              "lmunic": "AMOEIRO",
              "cpobla": "32002080200",
              "codPais": "ES",
              "nHabitantes": 93,
              "lprovi": "OURENSE",
              "cpostal": "32172"
          },
          {
              "lpobla": "A BERTONIA",
              "lmunic": "SOBER",
              "cpobla": "27059030500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27466"
          },
          {
              "lpobla": "A BESTA DE ABAIXO",
              "lmunic": "VILALBA",
              "cpobla": "27065080400",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27816"
          },
          {
              "lpobla": "A BESTA DE ARRIBA",
              "lmunic": "VILALBA",
              "cpobla": "27065080500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27816"
          },
          {
              "lpobla": "A BESTA (O SAVIÑAO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058280100",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27547"
          },
          {
              "lpobla": "A BESURA (MIRAZ)",
              "lmunic": "XERMADE",
              "cpobla": "27021060100",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27833"
          },
          {
              "lpobla": "A BETARRA",
              "lmunic": "CAMPO LAMEIRO",
              "cpobla": "36007010800",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36110"
          },
          {
              "lpobla": "A BIDUEDA (NARAIO)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076063200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15576"
          },
          {
              "lpobla": "A BIDUEIRA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061272700",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "A CORUÑA",
              "cpostal": "15338"
          },
          {
              "lpobla": "A BIQUEIRA",
              "lmunic": "LAXE",
              "cpobla": "15040020600",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "A CORUÑA",
              "cpostal": "15118"
          },
          {
              "lpobla": "A BIZCAIA (LANCARA)",
              "lmunic": "LANCARA",
              "cpobla": "27026110900",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27368"
          },
          {
              "lpobla": "A BOCA (CAMPAÑO)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038040200",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36157"
          },
          {
              "lpobla": "A BOCA DA FRAGA",
              "lmunic": "VIVEIRO",
              "cpobla": "27066100300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27869"
          },
          {
              "lpobla": "A BOGA",
              "lmunic": "A TEIXEIRA",
              "cpobla": "32080010200",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "OURENSE",
              "cpostal": "32764"
          },
          {
              "lpobla": "A BOLA",
              "lmunic": "A BOLA",
              "cpobla": "32014000000",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "OURENSE",
              "cpostal": "32812"
          },
          {
              "lpobla": "A BOLETA",
              "lmunic": "FRIOL",
              "cpobla": "27020110200",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27299"
          },
          {
              "lpobla": "A BORQUERIA",
              "lmunic": "BECERREA",
              "cpobla": "27006150100",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27668"
          },
          {
              "lpobla": "A BOUBETA",
              "lmunic": "CANGAS",
              "cpobla": "36008030200",
              "codPais": "ES",
              "nHabitantes": 59,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36947"
          },
          {
              "lpobla": "A BOUCIÑA (CAMBADOS)",
              "lmunic": "CAMBADOS",
              "cpobla": "36006050100",
              "codPais": "ES",
              "nHabitantes": 109,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36633"
          },
          {
              "lpobla": "A BOUCISCA",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018200200",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27135"
          },
          {
              "lpobla": "A BOUZA (A CAPELA)",
              "lmunic": "A CAPELA",
              "cpobla": "15018030200",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A BOUZA (A PASTORIZA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044190100",
              "codPais": "ES",
              "nHabitantes": 68,
              "lprovi": "LUGO",
              "cpostal": "27286"
          },
          {
              "lpobla": "A BOUZA (ABADIN)",
              "lmunic": "ABADIN",
              "cpobla": "27001170100",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27738"
          },
          {
              "lpobla": "A BOUZA (BEARIZ)",
              "lmunic": "BEARIZ",
              "cpobla": "32011010300",
              "codPais": "ES",
              "nHabitantes": 112,
              "lprovi": "OURENSE",
              "cpostal": "32520"
          },
          {
              "lpobla": "A BOUZA (CAMBADOS)",
              "lmunic": "CAMBADOS",
              "cpobla": "36006020400",
              "codPais": "ES",
              "nHabitantes": 251,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36639"
          },
          {
              "lpobla": "A BOUZA (CARTELLE)",
              "lmunic": "CARTELLE",
              "cpobla": "32020020200",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "OURENSE",
              "cpostal": "32820"
          },
          {
              "lpobla": "A BOUZA (CASTRELO DE MIÑO)",
              "lmunic": "CASTRELO DE MIÑO",
              "cpobla": "32022040200",
              "codPais": "ES",
              "nHabitantes": 66,
              "lprovi": "OURENSE",
              "cpostal": "32430"
          },
          {
              "lpobla": "A BOUZA (CEA)",
              "lmunic": "VILAGARCIA DE AROUSA",
              "cpobla": "36060040200",
              "codPais": "ES",
              "nHabitantes": 79,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36617"
          },
          {
              "lpobla": "A BOUZA (CERPONZONS)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038061000",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36152"
          },
          {
              "lpobla": "A BOUZA DA CABRA",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087010200",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "A CORUÑA",
              "cpostal": "15551"
          },
          {
              "lpobla": "A BOUZA DA VIÑA",
              "lmunic": "LOURENZA",
              "cpobla": "27027020500",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27751"
          },
          {
              "lpobla": "A BOUZA (GOA)",
              "lmunic": "COSPEITO",
              "cpobla": "27015050400",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27378"
          },
          {
              "lpobla": "A BOUZA (MARIN)",
              "lmunic": "MARIN",
              "cpobla": "36026030300",
              "codPais": "ES",
              "nHabitantes": 99,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36915"
          },
          {
              "lpobla": "A BOUZA (MEAÑO)",
              "lmunic": "MEAÑO",
              "cpobla": "36027050200",
              "codPais": "ES",
              "nHabitantes": 37,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36638"
          },
          {
              "lpobla": "A BOUZA (MEIS)",
              "lmunic": "MEIS",
              "cpobla": "36028020400",
              "codPais": "ES",
              "nHabitantes": 74,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36637"
          },
          {
              "lpobla": "A BOUZA (MORAÑA SANTA JUSTA)",
              "lmunic": "MORAÑA",
              "cpobla": "36032070200",
              "codPais": "ES",
              "nHabitantes": 104,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36668"
          },
          {
              "lpobla": "A BOUZA (MOURENTE)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038121900",
              "codPais": "ES",
              "nHabitantes": 81,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36164"
          },
          {
              "lpobla": "A BOUZA (NETE)",
              "lmunic": "VILALBA",
              "cpobla": "27065170200",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "LUGO",
              "cpostal": "27811"
          },
          {
              "lpobla": "A BOUZA (SALVATERRA DE MIÑO)",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050102000",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36457"
          },
          {
              "lpobla": "A BOUZA (SANTA COMBA)",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077110200",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "A CORUÑA",
              "cpostal": "15860"
          },
          {
              "lpobla": "A BOUZA (SANXENXO)",
              "lmunic": "SANXENXO",
              "cpobla": "36051050100",
              "codPais": "ES",
              "nHabitantes": 35,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36990"
          },
          {
              "lpobla": "A BOUZA VELLA",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010240400",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "LUGO",
              "cpostal": "27267"
          },
          {
              "lpobla": "A BOUZA (VILAR DE ASTRES)",
              "lmunic": "OURENSE",
              "cpobla": "32054190100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "OURENSE",
              "cpostal": "32981"
          },
          {
              "lpobla": "A BOUZA (VIMIANZO)",
              "lmunic": "VIMIANZO",
              "cpobla": "15092030300",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "A CORUÑA",
              "cpostal": "15128"
          },
          {
              "lpobla": "A BOUZABOA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020290100",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27226"
          },
          {
              "lpobla": "A BOVEDA (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038050400",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27864"
          },
          {
              "lpobla": "A BRAGAÑA",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040320100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27206"
          },
          {
              "lpobla": "A BRAGAÑA",
              "lmunic": "CUNTIS",
              "cpobla": "36015050100",
              "codPais": "ES",
              "nHabitantes": 60,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36679"
          },
          {
              "lpobla": "A BRANDELA",
              "lmunic": "XUNQUEIRA DE AMBIA",
              "cpobla": "32036040100",
              "codPais": "ES",
              "nHabitantes": 32,
              "lprovi": "OURENSE",
              "cpostal": "32678"
          },
          {
              "lpobla": "A BRAÑA (A ALLONCA)",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018010300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27113"
          },
          {
              "lpobla": "A BRAÑA (A CAPELA)",
              "lmunic": "A CAPELA",
              "cpobla": "15018020200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A BRAÑA (BRAGADE)",
              "lmunic": "CESURAS",
              "cpobla": "15026030200",
              "codPais": "ES",
              "nHabitantes": 46,
              "lprovi": "A CORUÑA",
              "cpostal": "15390"
          },
          {
              "lpobla": "A BRAÑA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019120100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "A CORUÑA",
              "cpostal": "15107"
          },
          {
              "lpobla": "A BRAÑA (COTOBADE)",
              "lmunic": "COTOBADE",
              "cpobla": "36012040200",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36856"
          },
          {
              "lpobla": "A BRAÑA DE ABAIXO",
              "lmunic": "CARBALLO",
              "cpobla": "15019151000",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A BRAÑA DE ARRIBA",
              "lmunic": "CARBALLO",
              "cpobla": "15019151100",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A BRAÑA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020010900",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A BRAÑA (MONDOÑEDO)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030060100",
              "codPais": "ES",
              "nHabitantes": 33,
              "lprovi": "LUGO",
              "cpostal": "27742"
          },
          {
              "lpobla": "A BRAÑA (SAN MIGUEL)",
              "lmunic": "BALEIRA",
              "cpobla": "27004010000",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "LUGO",
              "cpostal": "27277"
          },
          {
              "lpobla": "A BRAÑA (SILLEDA)",
              "lmunic": "SILLEDA",
              "cpobla": "36052070200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36587"
          },
          {
              "lpobla": "A BRAÑA (VILALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065130400",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "LUGO",
              "cpostal": "27811"
          },
          {
              "lpobla": "A BRAÑA (VILANOVA DE AROUSA)",
              "lmunic": "VILANOVA DE AROUSA",
              "cpobla": "36061070100",
              "codPais": "ES",
              "nHabitantes": 76,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36620"
          },
          {
              "lpobla": "A BRAÑA (ZAS)",
              "lmunic": "ZAS",
              "cpobla": "15093080300",
              "codPais": "ES",
              "nHabitantes": 89,
              "lprovi": "A CORUÑA",
              "cpostal": "15851"
          },
          {
              "lpobla": "A BRAXE (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087080300",
              "codPais": "ES",
              "nHabitantes": 35,
              "lprovi": "A CORUÑA",
              "cpostal": "15543"
          },
          {
              "lpobla": "A BREA",
              "lmunic": "SAN AMARO",
              "cpobla": "32074060200",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "OURENSE",
              "cpostal": "32455"
          },
          {
              "lpobla": "A BREA (A CAPELA)",
              "lmunic": "A CAPELA",
              "cpobla": "15018040500",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A BREA (BASCUAS)",
              "lmunic": "LUGO",
              "cpobla": "27028060200",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27146"
          },
          {
              "lpobla": "A BREA (BENZA)",
              "lmunic": "TRAZO",
              "cpobla": "15086010200",
              "codPais": "ES",
              "nHabitantes": 236,
              "lprovi": "A CORUÑA",
              "cpostal": "15686"
          },
          {
              "lpobla": "A BREA (BERGONDO)",
              "lmunic": "BERGONDO",
              "cpobla": "15008040300",
              "codPais": "ES",
              "nHabitantes": 287,
              "lprovi": "A CORUÑA",
              "cpostal": "15640"
          },
          {
              "lpobla": "A BREA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019070200",
              "codPais": "ES",
              "nHabitantes": 348,
              "lprovi": "A CORUÑA",
              "cpostal": "15102"
          },
          {
              "lpobla": "A BREA (CORTEGADA)",
              "lmunic": "SILLEDA",
              "cpobla": "36052080200",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36545"
          },
          {
              "lpobla": "A BREA (FERREIROS)",
              "lmunic": "SARRIA",
              "cpobla": "27057150100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27615"
          },
          {
              "lpobla": "A BREA (LAMELA)",
              "lmunic": "SILLEDA",
              "cpobla": "36052140200",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36540"
          },
          {
              "lpobla": "A BREA (MARIN)",
              "lmunic": "MARIN",
              "cpobla": "36026070300",
              "codPais": "ES",
              "nHabitantes": 96,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36913"
          },
          {
              "lpobla": "A BREA (ORDES)",
              "lmunic": "ORDES",
              "cpobla": "15059012900",
              "codPais": "ES",
              "nHabitantes": 108,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A BREA (PALAS DE REI)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040200100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27206"
          },
          {
              "lpobla": "A BREA (PARDEMARIN)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017350100",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36686"
          },
          {
              "lpobla": "A BREA (SAMOS)",
              "lmunic": "SAMOS",
              "cpobla": "27055030100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27628"
          },
          {
              "lpobla": "A BREA (TIRIMOL)",
              "lmunic": "LUGO",
              "cpobla": "27028520200",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27298"
          },
          {
              "lpobla": "A BRIXERIA (PONTECESO)",
              "lmunic": "PONTECESO",
              "cpobla": "15068060300",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "A CORUÑA",
              "cpostal": "15110"
          },
          {
              "lpobla": "A BROZA (MONFORTE DE LEMOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031130300",
              "codPais": "ES",
              "nHabitantes": 33,
              "lprovi": "LUGO",
              "cpostal": "27592"
          },
          {
              "lpobla": "A BROZA (SAN TOME)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058020000",
              "codPais": "ES",
              "nHabitantes": 44,
              "lprovi": "LUGO",
              "cpostal": "27546"
          },
          {
              "lpobla": "A BUGALLA",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058160200",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27547"
          },
          {
              "lpobla": "A BUHIDA",
              "lmunic": "NEDA",
              "cpobla": "15055DD0100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15510"
          },
          {
              "lpobla": "A BUIÑA (A CAPELA)",
              "lmunic": "A CAPELA",
              "cpobla": "15018030300",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A BURATA",
              "lmunic": "OURENSE",
              "cpobla": "32054110200",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "OURENSE",
              "cpostal": "32981"
          },
          {
              "lpobla": "A BURATA (A ESTRADA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017130300",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36584"
          },
          {
              "lpobla": "A BURATA (RIANXO)",
              "lmunic": "RIANXO",
              "cpobla": "15072060100",
              "codPais": "ES",
              "nHabitantes": 83,
              "lprovi": "A CORUÑA",
              "cpostal": "15985"
          },
          {
              "lpobla": "A BURATIÑA",
              "lmunic": "CELANOVA",
              "cpobla": "32024080200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "OURENSE",
              "cpostal": "32815"
          },
          {
              "lpobla": "A BURDALLA",
              "lmunic": "SOBER",
              "cpobla": "27059020200",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "LUGO",
              "cpostal": "27466"
          },
          {
              "lpobla": "A BURELA (A FONSAGRADA)",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018050100",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27110"
          },
          {
              "lpobla": "A BUZAXE",
              "lmunic": "NOGUEIRA DE RAMUIN",
              "cpobla": "32052030300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "OURENSE",
              "cpostal": "32448"
          },
          {
              "lpobla": "A CABADA (COTOBADE)",
              "lmunic": "COTOBADE",
              "cpobla": "36012030300",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36858"
          },
          {
              "lpobla": "A CABADIÑA (O PORRIÑO)",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039050200",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36413"
          },
          {
              "lpobla": "A CABALGADA",
              "lmunic": "ESGOS",
              "cpobla": "32031070100",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "OURENSE",
              "cpostal": "32720"
          },
          {
              "lpobla": "A CABANA (ABADIN)",
              "lmunic": "ABADIN",
              "cpobla": "27001130100",
              "codPais": "ES",
              "nHabitantes": 35,
              "lprovi": "LUGO",
              "cpostal": "27379"
          },
          {
              "lpobla": "A CABANA (ANCEIS)",
              "lmunic": "CAMBRE",
              "cpobla": "15017010300",
              "codPais": "ES",
              "nHabitantes": 89,
              "lprovi": "A CORUÑA",
              "cpostal": "15181"
          },
          {
              "lpobla": "A CABANA (CAMBADOS)",
              "lmunic": "CAMBADOS",
              "cpobla": "36006030100",
              "codPais": "ES",
              "nHabitantes": 322,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36634"
          },
          {
              "lpobla": "A CABANA (CARLIN)",
              "lmunic": "FRIOL",
              "cpobla": "27020050300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A CABANA DA VELLA",
              "lmunic": "BARREIROS",
              "cpobla": "27005080400",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "LUGO",
              "cpostal": "27798"
          },
          {
              "lpobla": "A CABANA (IRIXOA)",
              "lmunic": "IRIXOA",
              "cpobla": "15039060300",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "A CORUÑA",
              "cpostal": "15314"
          },
          {
              "lpobla": "A CABANA (LAGOSTELLE)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022050200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27309"
          },
          {
              "lpobla": "A CABANA (MONDOÑEDO)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030140100",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "LUGO",
              "cpostal": "27747"
          },
          {
              "lpobla": "A CABANA (MONFORTE DE LEMOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031160100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27414"
          },
          {
              "lpobla": "A CABANA (MURAS SAN PEDRO)",
              "lmunic": "MURAS",
              "cpobla": "27033051100",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A CABANA (NODAR)",
              "lmunic": "FRIOL",
              "cpobla": "27020170400",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A CABANA (O PARAMO)",
              "lmunic": "O PARAMO",
              "cpobla": "27043020300",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27363"
          },
          {
              "lpobla": "A CABANA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061070500",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "A CORUÑA",
              "cpostal": "15332"
          },
          {
              "lpobla": "A CABANA (OUTEIRO DE REI)",
              "lmunic": "OUTEIRO DE REI",
              "cpobla": "27039030200",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27150"
          },
          {
              "lpobla": "A CABANA (RIBADEO)",
              "lmunic": "RIBADEO",
              "cpobla": "27051041400",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27714"
          },
          {
              "lpobla": "A CABANA (SAN ANTONIO)",
              "lmunic": "FERROL",
              "cpobla": "15036020000",
              "codPais": "ES",
              "nHabitantes": 336,
              "lprovi": "A CORUÑA",
              "cpostal": "15590"
          },
          {
              "lpobla": "A CABANA (SIGRAS)",
              "lmunic": "CAMBRE",
              "cpobla": "15017100200",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "A CORUÑA",
              "cpostal": "15181"
          },
          {
              "lpobla": "A CABANA (TRABADA)",
              "lmunic": "TRABADA",
              "cpobla": "27061050300",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27767"
          },
          {
              "lpobla": "A CABANA (TRIABA)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010240500",
              "codPais": "ES",
              "nHabitantes": 46,
              "lprovi": "LUGO",
              "cpostal": "27267"
          },
          {
              "lpobla": "A CABANA (VIEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066100500",
              "codPais": "ES",
              "nHabitantes": 33,
              "lprovi": "LUGO",
              "cpostal": "27869"
          },
          {
              "lpobla": "A CABANDELA",
              "lmunic": "XOVE",
              "cpobla": "27025060200",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27878"
          },
          {
              "lpobla": "A CABANELA (ALFOZ)",
              "lmunic": "ALFOZ",
              "cpobla": "27002080500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27775"
          },
          {
              "lpobla": "A CABANELA (CASTROVERDE)",
              "lmunic": "CASTROVERDE",
              "cpobla": "27011203300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27128"
          },
          {
              "lpobla": "A CABANELA (LAXE)",
              "lmunic": "LAXE",
              "cpobla": "15040060200",
              "codPais": "ES",
              "nHabitantes": 49,
              "lprovi": "A CORUÑA",
              "cpostal": "15118"
          },
          {
              "lpobla": "A CABANELA (MURAS)",
              "lmunic": "MURAS",
              "cpobla": "27033051200",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A CABANELA (O VALADOURO)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063090600",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "LUGO",
              "cpostal": "27778"
          },
          {
              "lpobla": "A CABANELA (ROIS)",
              "lmunic": "ROIS",
              "cpobla": "15074120200",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "A CORUÑA",
              "cpostal": "15281"
          },
          {
              "lpobla": "A CABANIÑA",
              "lmunic": "VIVEIRO",
              "cpobla": "27066080600",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27850"
          },
          {
              "lpobla": "A CABARCA",
              "lmunic": "RIBAS DE SIL",
              "cpobla": "27052050300",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27310"
          },
          {
              "lpobla": "A CABECEIRA (ABADIN)",
              "lmunic": "ABADIN",
              "cpobla": "27001080200",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "LUGO",
              "cpostal": "27379"
          },
          {
              "lpobla": "A CABECEIRA (MURAS)",
              "lmunic": "MURAS",
              "cpobla": "27033030600",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A CABECEIRA (VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066100600",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27869"
          },
          {
              "lpobla": "A CABEIRA (A PASTORIZA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044040800",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27286"
          },
          {
              "lpobla": "A CABEIRA (ABADIN)",
              "lmunic": "ABADIN",
              "cpobla": "27001140500",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27737"
          },
          {
              "lpobla": "A CABRA (CARRAL)",
              "lmunic": "CARRAL",
              "cpobla": "15021050200",
              "codPais": "ES",
              "nHabitantes": 92,
              "lprovi": "A CORUÑA",
              "cpostal": "15184"
          },
          {
              "lpobla": "A CABRA (MESIA)",
              "lmunic": "MESIA",
              "cpobla": "15047070100",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A CABREIRA (BUEU)",
              "lmunic": "BUEU",
              "cpobla": "36004040400",
              "codPais": "ES",
              "nHabitantes": 75,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36938"
          },
          {
              "lpobla": "A CABREIRA (NIGRAN)",
              "lmunic": "NIGRAN",
              "cpobla": "36035070100",
              "codPais": "ES",
              "nHabitantes": 441,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36370"
          },
          {
              "lpobla": "A CABREIRA (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038040400",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27866"
          },
          {
              "lpobla": "A CABREIRA (SANTA COMBA)",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077020400",
              "codPais": "ES",
              "nHabitantes": 78,
              "lprovi": "A CORUÑA",
              "cpostal": "15845"
          },
          {
              "lpobla": "A CACHA",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050040200",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36457"
          },
          {
              "lpobla": "A CACHARELA",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078010300",
              "codPais": "ES",
              "nHabitantes": 47,
              "lprovi": "A CORUÑA",
              "cpostal": "15892"
          },
          {
              "lpobla": "A CACHAROSA",
              "lmunic": "ZAS",
              "cpobla": "15093020400",
              "codPais": "ES",
              "nHabitantes": 95,
              "lprovi": "A CORUÑA",
              "cpostal": "15150"
          },
          {
              "lpobla": "A CACHAVEIRA",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087071000",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15552"
          },
          {
              "lpobla": "A CACHAVELLA",
              "lmunic": "CESURAS",
              "cpobla": "15026070100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A CACHOPA",
              "lmunic": "TRABADA",
              "cpobla": "27061050400",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27765"
          },
          {
              "lpobla": "A CADAVOSA (A PASTORIZA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044010100",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27248"
          },
          {
              "lpobla": "A CADAVOSA (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038040500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27866"
          },
          {
              "lpobla": "A CADELA",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061272900",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "A CORUÑA",
              "cpostal": "15338"
          },
          {
              "lpobla": "A CAFUA",
              "lmunic": "FRIOL",
              "cpobla": "27020030200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A CAIVANCA (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022100200",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27372"
          },
          {
              "lpobla": "A CAL (ALLARIZ)",
              "lmunic": "ALLARIZ",
              "cpobla": "32001060100",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "OURENSE",
              "cpostal": "32669"
          },
          {
              "lpobla": "A CAL (AMANDI)",
              "lmunic": "SOBER",
              "cpobla": "27059010400",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27423"
          },
          {
              "lpobla": "A CAL (BARANTES)",
              "lmunic": "SOBER",
              "cpobla": "27059050300",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27421"
          },
          {
              "lpobla": "A CAL (DEADE)",
              "lmunic": "PANTON",
              "cpobla": "27041070100",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27437"
          },
          {
              "lpobla": "A CAL (ESPASANTES)",
              "lmunic": "PANTON",
              "cpobla": "27041090200",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "LUGO",
              "cpostal": "27450"
          },
          {
              "lpobla": "A CAL (GUNTIN)",
              "lmunic": "GUNTIN",
              "cpobla": "27023040100",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27211"
          },
          {
              "lpobla": "A CAL (O PARAMO)",
              "lmunic": "O PARAMO",
              "cpobla": "27043161100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27363"
          },
          {
              "lpobla": "A CAL (O SAVIÑAO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058140400",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27546"
          },
          {
              "lpobla": "A CAL (PIÑOR)",
              "lmunic": "PIÑOR",
              "cpobla": "32061070200",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "OURENSE",
              "cpostal": "32138"
          },
          {
              "lpobla": "A CAL (SARRIA)",
              "lmunic": "SARRIA",
              "cpobla": "27057070500",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27619"
          },
          {
              "lpobla": "A CAL (SISTALLO)",
              "lmunic": "COSPEITO",
              "cpobla": "27015150300",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "LUGO",
              "cpostal": "27377"
          },
          {
              "lpobla": "A CALDIHUELA",
              "lmunic": "VILAGARCIA DE AROUSA",
              "cpobla": "36060130100",
              "codPais": "ES",
              "nHabitantes": 181,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36613"
          },
          {
              "lpobla": "A CALLE",
              "lmunic": "FRIOL",
              "cpobla": "27020290200",
              "codPais": "ES",
              "nHabitantes": 70,
              "lprovi": "LUGO",
              "cpostal": "27226"
          },
          {
              "lpobla": "A CALLE (BEIRA)",
              "lmunic": "CARRAL",
              "cpobla": "15021071100",
              "codPais": "ES",
              "nHabitantes": 50,
              "lprovi": "A CORUÑA",
              "cpostal": "15183"
          },
          {
              "lpobla": "A CALLE (PONTECESO)",
              "lmunic": "PONTECESO",
              "cpobla": "15068140100",
              "codPais": "ES",
              "nHabitantes": 56,
              "lprovi": "A CORUÑA",
              "cpostal": "15110"
          },
          {
              "lpobla": "A CALLE (ROIS)",
              "lmunic": "ROIS",
              "cpobla": "15074DD0100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15281"
          },
          {
              "lpobla": "A CALLE (TOMIÑO)",
              "lmunic": "TOMIÑO",
              "cpobla": "36054070300",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36750"
          },
          {
              "lpobla": "A CALOUSADA",
              "lmunic": "XERMADE",
              "cpobla": "27021091000",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27835"
          },
          {
              "lpobla": "A CALUBA",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078030400",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "A CORUÑA",
              "cpostal": "15688"
          },
          {
              "lpobla": "A CALVELA (FERREIROS)",
              "lmunic": "BARALLA",
              "cpobla": "27901070100",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27686"
          },
          {
              "lpobla": "A CALVELA (MONDOÑEDO)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030150100",
              "codPais": "ES",
              "nHabitantes": 42,
              "lprovi": "LUGO",
              "cpostal": "27752"
          },
          {
              "lpobla": "A CALVELA (VILARTELIN)",
              "lmunic": "BARALLA",
              "cpobla": "27901300500",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27680"
          },
          {
              "lpobla": "A CALZADA (A ESTRADA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017060300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36584"
          },
          {
              "lpobla": "A CALZADA (A FONSAGRADA)",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018190100",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27135"
          },
          {
              "lpobla": "A CALZADA (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005040200",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27798"
          },
          {
              "lpobla": "A CALZADA (FENE)",
              "lmunic": "FENE",
              "cpobla": "15035082400",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "A CORUÑA",
              "cpostal": "15509"
          },
          {
              "lpobla": "A CALZADA (LANDROVE)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066070400",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27866"
          },
          {
              "lpobla": "A CALZADA (MAGAZOS)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066080800",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27850"
          },
          {
              "lpobla": "A CALZADA (MESIA)",
              "lmunic": "MESIA",
              "cpobla": "15047110300",
              "codPais": "ES",
              "nHabitantes": 77,
              "lprovi": "A CORUÑA",
              "cpostal": "15689"
          },
          {
              "lpobla": "A CALZADA (VILALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065220300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27842"
          },
          {
              "lpobla": "A CAMARIÑA",
              "lmunic": "ALFOZ",
              "cpobla": "27002010400",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27773"
          },
          {
              "lpobla": "A CAMBA",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076020400",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "A CORUÑA",
              "cpostal": "15598"
          },
          {
              "lpobla": "A CAMBA (ARCOS)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042020200",
              "codPais": "ES",
              "nHabitantes": 37,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36865"
          },
          {
              "lpobla": "A CAMBA (MONTERROSO)",
              "lmunic": "MONTERROSO",
              "cpobla": "27032200200",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27568"
          },
          {
              "lpobla": "A CAMBRA",
              "lmunic": "LUGO",
              "cpobla": "27028150500",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27188"
          },
          {
              "lpobla": "A CAMPA DA BARRA",
              "lmunic": "LUGO",
              "cpobla": "27028500100",
              "codPais": "ES",
              "nHabitantes": 85,
              "lprovi": "LUGO",
              "cpostal": "27180"
          },
          {
              "lpobla": "A CAMPA DA BRAÑA",
              "lmunic": "CERVANTES",
              "cpobla": "27012052400",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27666"
          },
          {
              "lpobla": "A CAMPA DE FIEIRO",
              "lmunic": "CERVANTES",
              "cpobla": "27012052300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27666"
          },
          {
              "lpobla": "A CAMPA DO VAL",
              "lmunic": "QUIROGA",
              "cpobla": "27050070100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27328"
          },
          {
              "lpobla": "A CAMPA (FOLGOSO DO COUREL)",
              "lmunic": "FOLGOSO DO COUREL",
              "cpobla": "27017080100",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "LUGO",
              "cpostal": "27325"
          },
          {
              "lpobla": "A CAMPA (MONDOÑEDO)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030020100",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "LUGO",
              "cpostal": "27749"
          },
          {
              "lpobla": "A CAMPA (O CORGO)",
              "lmunic": "O CORGO",
              "cpobla": "27014280100",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27163"
          },
          {
              "lpobla": "A CAMPA (O INCIO)",
              "lmunic": "O INCIO",
              "cpobla": "27024220100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27346"
          },
          {
              "lpobla": "A CAMPANILLA",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040230100",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27204"
          },
          {
              "lpobla": "A CAMPANILLA",
              "lmunic": "PONTEDEUME",
              "cpobla": "15069010200",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "A CORUÑA",
              "cpostal": "15614"
          },
          {
              "lpobla": "A CAMPARA (CORES)",
              "lmunic": "PONTECESO",
              "cpobla": "15068030300",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "A CORUÑA",
              "cpostal": "15110"
          },
          {
              "lpobla": "A CAMPAZA (CHANTADA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016290300",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27513"
          },
          {
              "lpobla": "A CAMPAZA (O SAVIÑAO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058130300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27548"
          },
          {
              "lpobla": "A CAMPIÑA (MUXA)",
              "lmunic": "LUGO",
              "cpobla": "27028320700",
              "codPais": "ES",
              "nHabitantes": 43,
              "lprovi": "LUGO",
              "cpostal": "27192"
          },
          {
              "lpobla": "A CAMPIÑA (OZA DOS RIOS)",
              "lmunic": "OZA DOS RIOS",
              "cpobla": "15063100300",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "A CORUÑA",
              "cpostal": "15386"
          },
          {
              "lpobla": "A CAMPIÑA (SAN SALVADOR)",
              "lmunic": "BERGONDO",
              "cpobla": "15008020300",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15165"
          },
          {
              "lpobla": "A CAMPOSA",
              "lmunic": "FRIOL",
              "cpobla": "27020030400",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A CAMPOSA (SAN SADURNIÑO)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076030500",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15580"
          },
          {
              "lpobla": "A CAMUZA",
              "lmunic": "MALPICA DE BERGANTIÑOS",
              "cpobla": "15043060100",
              "codPais": "ES",
              "nHabitantes": 274,
              "lprovi": "A CORUÑA",
              "cpostal": "15113"
          },
          {
              "lpobla": "A CANCELA",
              "lmunic": "RAIRIZ DE VEIGA",
              "cpobla": "32067080200",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "OURENSE",
              "cpostal": "32654"
          },
          {
              "lpobla": "A CANCELA (ALFOZ)",
              "lmunic": "ALFOZ",
              "cpobla": "27002010500",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27773"
          },
          {
              "lpobla": "A CANCELA (ASMA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016060300",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27516"
          },
          {
              "lpobla": "A CANCELA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026060700",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A CANCELA (CONDES)",
              "lmunic": "FRIOL",
              "cpobla": "27020060600",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27235"
          },
          {
              "lpobla": "A CANCELA (LANCARA)",
              "lmunic": "LANCARA",
              "cpobla": "27026041900",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27692"
          },
          {
              "lpobla": "A CANCELA (O PARAMO)",
              "lmunic": "O PARAMO",
              "cpobla": "27043020500",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27363"
          },
          {
              "lpobla": "A CANCELA (SALCEDO)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038150600",
              "codPais": "ES",
              "nHabitantes": 154,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36143"
          },
          {
              "lpobla": "A CANCELA (VILALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065100700",
              "codPais": "ES",
              "nHabitantes": 47,
              "lprovi": "LUGO",
              "cpostal": "27840"
          },
          {
              "lpobla": "A CANCELIÑA",
              "lmunic": "BUEU",
              "cpobla": "36004020100",
              "codPais": "ES",
              "nHabitantes": 160,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36939"
          },
          {
              "lpobla": "A CANDA (A MEZQUITA)",
              "lmunic": "A MEZQUITA",
              "cpobla": "32048090100",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "OURENSE",
              "cpostal": "32549"
          },
          {
              "lpobla": "A CANDA (LIRIPIO)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017240200",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36684"
          },
          {
              "lpobla": "A CANDA (SAN MAMEDE)",
              "lmunic": "PIÑOR",
              "cpobla": "32061020000",
              "codPais": "ES",
              "nHabitantes": 339,
              "lprovi": "OURENSE",
              "cpostal": "32135"
          },
          {
              "lpobla": "A CANDAIRA",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058160300",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27547"
          },
          {
              "lpobla": "A CANDEDA",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031270200",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27415"
          },
          {
              "lpobla": "A CANDIEIRA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021070400",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27826"
          },
          {
              "lpobla": "A CANETA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026020600",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15390"
          },
          {
              "lpobla": "A CANICOUVA",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038050000",
              "codPais": "ES",
              "nHabitantes": 197,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36690"
          },
          {
              "lpobla": "A CANLE",
              "lmunic": "LOBEIRA",
              "cpobla": "32041080100",
              "codPais": "ES",
              "nHabitantes": 51,
              "lprovi": "OURENSE",
              "cpostal": "32850"
          },
          {
              "lpobla": "A CANOSA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019151500",
              "codPais": "ES",
              "nHabitantes": 159,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A CANOSA (CEE)",
              "lmunic": "CEE",
              "cpobla": "15023040100",
              "codPais": "ES",
              "nHabitantes": 67,
              "lprovi": "A CORUÑA",
              "cpostal": "15138"
          },
          {
              "lpobla": "A CANTEIRIÑA",
              "lmunic": "OUTES",
              "cpobla": "15062051300",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "A CORUÑA",
              "cpostal": "15287"
          },
          {
              "lpobla": "A CANTOÑA",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039060600",
              "codPais": "ES",
              "nHabitantes": 56,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36412"
          },
          {
              "lpobla": "A CAÑIZA",
              "lmunic": "A CAÑIZA",
              "cpobla": "36009000000",
              "codPais": "ES",
              "nHabitantes": 1371,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36888"
          },
          {
              "lpobla": "A CAÑIZA",
              "lmunic": "A CAÑIZA",
              "cpobla": "36009000000",
              "codPais": "ES",
              "nHabitantes": 1371,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36887"
          },
          {
              "lpobla": "A CAÑIZA",
              "lmunic": "A CAÑIZA",
              "cpobla": "36009000000",
              "codPais": "ES",
              "nHabitantes": 1371,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36886"
          },
          {
              "lpobla": "A CAÑIZA",
              "lmunic": "A CAÑIZA",
              "cpobla": "36009000000",
              "codPais": "ES",
              "nHabitantes": 1371,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36883"
          },
          {
              "lpobla": "A CAÑIZA",
              "lmunic": "A CAÑIZA",
              "cpobla": "36009000000",
              "codPais": "ES",
              "nHabitantes": 1371,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36880"
          },
          {
              "lpobla": "A CAÑIZA (SANTA TERESA)",
              "lmunic": "A CAÑIZA",
              "cpobla": "36009020000",
              "codPais": "ES",
              "nHabitantes": 1551,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36888"
          },
          {
              "lpobla": "A CAÑOTA (CAMPAÑO)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038042300",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36157"
          },
          {
              "lpobla": "A CAÑOTA (CARRAL)",
              "lmunic": "CARRAL",
              "cpobla": "15021040400",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15182"
          },
          {
              "lpobla": "A CAÑOTEIRA (ABADIN)",
              "lmunic": "ABADIN",
              "cpobla": "27001150100",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27379"
          },
          {
              "lpobla": "A CAÑOTEIRA (CASTRO DE REI)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010250200",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27259"
          },
          {
              "lpobla": "A CAÑOTEIRA DE MARROZOS",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078170900",
              "codPais": "ES",
              "nHabitantes": 52,
              "lprovi": "A CORUÑA",
              "cpostal": "15893"
          },
          {
              "lpobla": "A CAÑOTEIRA (SILLEDA)",
              "lmunic": "SILLEDA",
              "cpobla": "36052280300",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36546"
          },
          {
              "lpobla": "A CAPA",
              "lmunic": "PANTON",
              "cpobla": "27041100300",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27430"
          },
          {
              "lpobla": "A CAPARIÑA",
              "lmunic": "O VICEDO",
              "cpobla": "27064010600",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27868"
          },
          {
              "lpobla": "A CAPELA",
              "lmunic": "A CAPELA",
              "cpobla": "15018000000",
              "codPais": "ES",
              "nHabitantes": 1520,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A CAPELA (ABADIN)",
              "lmunic": "ABADIN",
              "cpobla": "27001100200",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27738"
          },
          {
              "lpobla": "A CAPELA (AGOLADA)",
              "lmunic": "AGOLADA",
              "cpobla": "36020020400",
              "codPais": "ES",
              "nHabitantes": 45,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36528"
          },
          {
              "lpobla": "A CAPELA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026060800",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A CAPELA (CUBELAS)",
              "lmunic": "RIBADEO",
              "cpobla": "27051041500",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27714"
          },
          {
              "lpobla": "A CAPELA (OBE)",
              "lmunic": "RIBADEO",
              "cpobla": "27051060300",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27713"
          },
          {
              "lpobla": "A CAPELA (PONTEDEUME)",
              "lmunic": "PONTEDEUME",
              "cpobla": "15069050500",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "A CORUÑA",
              "cpostal": "15609"
          },
          {
              "lpobla": "A CAPELA (RIANXO)",
              "lmunic": "RIANXO",
              "cpobla": "15072010300",
              "codPais": "ES",
              "nHabitantes": 116,
              "lprovi": "A CORUÑA",
              "cpostal": "15984"
          },
          {
              "lpobla": "A CAPELA (SANTIAGO)",
              "lmunic": "A CAPELA",
              "cpobla": "15018040000",
              "codPais": "ES",
              "nHabitantes": 1006,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A CAPELA (VILALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065260300",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27823"
          },
          {
              "lpobla": "A CAPELA (VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066080900",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "LUGO",
              "cpostal": "27850"
          },
          {
              "lpobla": "A CAPELADA",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061260200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15367"
          },
          {
              "lpobla": "A CAPILLA (MEIRAS)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087040300",
              "codPais": "ES",
              "nHabitantes": 44,
              "lprovi": "A CORUÑA",
              "cpostal": "15550"
          },
          {
              "lpobla": "A CAPILLA (VILLARRUBE)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087090500",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "A CORUÑA",
              "cpostal": "15554"
          },
          {
              "lpobla": "A CARBA",
              "lmunic": "XERMADE",
              "cpobla": "27021050700",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27835"
          },
          {
              "lpobla": "A CARBALIZA (CEE)",
              "lmunic": "CEE",
              "cpobla": "15023060200",
              "codPais": "ES",
              "nHabitantes": 71,
              "lprovi": "A CORUÑA",
              "cpostal": "15138"
          },
          {
              "lpobla": "A CARBALLA (A ESTRADA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017460100",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36682"
          },
          {
              "lpobla": "A CARBALLA (CABANA DE BERGANTIÑOS)",
              "lmunic": "CABANA DE BERGANTIÑOS",
              "cpobla": "15014040900",
              "codPais": "ES",
              "nHabitantes": 71,
              "lprovi": "A CORUÑA",
              "cpostal": "15115"
          },
          {
              "lpobla": "A CARBALLA (OUTES)",
              "lmunic": "OUTES",
              "cpobla": "15062060500",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "A CORUÑA",
              "cpostal": "15230"
          },
          {
              "lpobla": "A CARBALLA (SALCEDO)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038150700",
              "codPais": "ES",
              "nHabitantes": 190,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36143"
          },
          {
              "lpobla": "A CARBALLA (TOMEZA)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038171000",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36158"
          },
          {
              "lpobla": "A CARBALLA (VALGA)",
              "lmunic": "VALGA",
              "cpobla": "36056020600",
              "codPais": "ES",
              "nHabitantes": 85,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36647"
          },
          {
              "lpobla": "A CARBALLA (VIMIANZO)",
              "lmunic": "VIMIANZO",
              "cpobla": "15092110100",
              "codPais": "ES",
              "nHabitantes": 79,
              "lprovi": "A CORUÑA",
              "cpostal": "15127"
          },
          {
              "lpobla": "A CARBALLEIRA (ABADIN)",
              "lmunic": "ABADIN",
              "cpobla": "27001130200",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27379"
          },
          {
              "lpobla": "A CARBALLEIRA (ALBIXOI)",
              "lmunic": "MESIA",
              "cpobla": "15047010100",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A CARBALLEIRA (ARNOIS)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017060400",
              "codPais": "ES",
              "nHabitantes": 47,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36584"
          },
          {
              "lpobla": "A CARBALLEIRA (CADAVEDO)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044050200",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27287"
          },
          {
              "lpobla": "A CARBALLEIRA (CASTRO)",
              "lmunic": "MESIA",
              "cpobla": "15047060100",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A CARBALLEIRA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026060900",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A CARBALLEIRA (CHANTADA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016200200",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27512"
          },
          {
              "lpobla": "A CARBALLEIRA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020320500",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27227"
          },
          {
              "lpobla": "A CARBALLEIRA (GONDOMAR)",
              "lmunic": "GONDOMAR",
              "cpobla": "36021070600",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36389"
          },
          {
              "lpobla": "A CARBALLEIRA (LOURIZAN)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038100200",
              "codPais": "ES",
              "nHabitantes": 271,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36910"
          },
          {
              "lpobla": "A CARBALLEIRA (MASIDE)",
              "lmunic": "MASIDE",
              "cpobla": "32045090200",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "OURENSE",
              "cpostal": "32573"
          },
          {
              "lpobla": "A CARBALLEIRA (NIGRAN)",
              "lmunic": "NIGRAN",
              "cpobla": "36035010300",
              "codPais": "ES",
              "nHabitantes": 45,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36360"
          },
          {
              "lpobla": "A CARBALLEIRA (O GROVE)",
              "lmunic": "O GROVE",
              "cpobla": "36022010500",
              "codPais": "ES",
              "nHabitantes": 130,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36989"
          },
          {
              "lpobla": "A CARBALLEIRA (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038080500",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A CARBALLEIRA (PORTOMARIN)",
              "lmunic": "PORTOMARIN",
              "cpobla": "27049200100",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27177"
          },
          {
              "lpobla": "A CARBALLEIRA (QUIROGA)",
              "lmunic": "QUIROGA",
              "cpobla": "27050092300",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27320"
          },
          {
              "lpobla": "A CARBALLEIRA (REIGOSA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044150200",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27286"
          },
          {
              "lpobla": "A CARBALLEIRA (RIANXO)",
              "lmunic": "RIANXO",
              "cpobla": "15072050800",
              "codPais": "ES",
              "nHabitantes": 74,
              "lprovi": "A CORUÑA",
              "cpostal": "15920"
          },
          {
              "lpobla": "A CARBALLEIRA (SALCEDO)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038150800",
              "codPais": "ES",
              "nHabitantes": 97,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36143"
          },
          {
              "lpobla": "A CARBALLEIRA (SAN AMARO)",
              "lmunic": "SAN AMARO",
              "cpobla": "32074060500",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "OURENSE",
              "cpostal": "32455"
          },
          {
              "lpobla": "A CARBALLEIRA (SAN CIBRAO DAS VIÑAS)",
              "lmunic": "SAN CIBRAO DAS VIÑAS",
              "cpobla": "32075040200",
              "codPais": "ES",
              "nHabitantes": 115,
              "lprovi": "OURENSE",
              "cpostal": "32901"
          },
          {
              "lpobla": "A CARBALLEIRA (SANTA COMBA)",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077150200",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15860"
          },
          {
              "lpobla": "A CARBALLEIRA (SOMOZA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017430300",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36681"
          },
          {
              "lpobla": "A CARBALLEIRA (VILALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065290700",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27816"
          },
          {
              "lpobla": "A CARBALLEIRA (VISANTOÑA)",
              "lmunic": "MESIA",
              "cpobla": "15047110400",
              "codPais": "ES",
              "nHabitantes": 51,
              "lprovi": "A CORUÑA",
              "cpostal": "15689"
          },
          {
              "lpobla": "A CARBALLEIRA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021091200",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27835"
          },
          {
              "lpobla": "A CARBALLOSA (ANAFREITA)",
              "lmunic": "FRIOL",
              "cpobla": "27020011000",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A CARBALLOSA (CABREIROS)",
              "lmunic": "XERMADE",
              "cpobla": "27021020200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27834"
          },
          {
              "lpobla": "A CARBALLOSA (CAZAS)",
              "lmunic": "XERMADE",
              "cpobla": "27021040500",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "LUGO",
              "cpostal": "27824"
          },
          {
              "lpobla": "A CARBALLOSA (COSPEITO)",
              "lmunic": "COSPEITO",
              "cpobla": "27015190400",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "LUGO",
              "cpostal": "27377"
          },
          {
              "lpobla": "A CARBALLOSA (MOS-SAN XULIAN)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010150400",
              "codPais": "ES",
              "nHabitantes": 78,
              "lprovi": "LUGO",
              "cpostal": "27268"
          },
          {
              "lpobla": "A CARBALLOSA (MURAS)",
              "lmunic": "MURAS",
              "cpobla": "27033051400",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A CARBALLOSA (PARADELA)",
              "lmunic": "PARADELA",
              "cpobla": "27042060900",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27611"
          },
          {
              "lpobla": "A CARBEIRA (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087080700",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15543"
          },
          {
              "lpobla": "A CARBOEIRA",
              "lmunic": "VILALBA",
              "cpobla": "27065210500",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "LUGO",
              "cpostal": "27841"
          },
          {
              "lpobla": "A CARCALLOSA (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038010300",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A CARDAVELLA",
              "lmunic": "A ESTRADA",
              "cpobla": "36017210200",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36681"
          },
          {
              "lpobla": "A CARDIDA",
              "lmunic": "TABOADA",
              "cpobla": "27060230100",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27558"
          },
          {
              "lpobla": "A CARDOSA (BORA)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038030200",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36154"
          },
          {
              "lpobla": "A CARDOSA (MARCON)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038110300",
              "codPais": "ES",
              "nHabitantes": 79,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36158"
          },
          {
              "lpobla": "A CARDOSA (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087050500",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "A CORUÑA",
              "cpostal": "15553"
          },
          {
              "lpobla": "A CARIDAD",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061032800",
              "codPais": "ES",
              "nHabitantes": 166,
              "lprovi": "A CORUÑA",
              "cpostal": "15339"
          },
          {
              "lpobla": "A CARIXA (AVION)",
              "lmunic": "AVION",
              "cpobla": "32004010300",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "OURENSE",
              "cpostal": "32520"
          },
          {
              "lpobla": "A CARIXA (CASTRELO DE MIÑO)",
              "lmunic": "CASTRELO DE MIÑO",
              "cpobla": "32022030100",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "OURENSE",
              "cpostal": "32430"
          },
          {
              "lpobla": "A CARIZA",
              "lmunic": "MONTERROSO",
              "cpobla": "27032150100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27560"
          },
          {
              "lpobla": "A CARQUEIXA",
              "lmunic": "SOBER",
              "cpobla": "27059180100",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27460"
          },
          {
              "lpobla": "A CARQUEIXA (SALVATERRA DE MIÑO)",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050050200",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36457"
          },
          {
              "lpobla": "A CARRACEIRA (BALEIRA)",
              "lmunic": "BALEIRA",
              "cpobla": "27004090300",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27279"
          },
          {
              "lpobla": "A CARRACHA",
              "lmunic": "CARBALLO",
              "cpobla": "15019171000",
              "codPais": "ES",
              "nHabitantes": 78,
              "lprovi": "A CORUÑA",
              "cpostal": "15108"
          },
          {
              "lpobla": "A CARRACHEIRA",
              "lmunic": "CESURAS",
              "cpobla": "15026080700",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A CARRAPOTA",
              "lmunic": "VIVEIRO",
              "cpobla": "27066081000",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "LUGO",
              "cpostal": "27850"
          },
          {
              "lpobla": "A CARRASCA",
              "lmunic": "NIGRAN",
              "cpobla": "36035050100",
              "codPais": "ES",
              "nHabitantes": 152,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36379"
          },
          {
              "lpobla": "A CARRASQUEIRA (BUEU)",
              "lmunic": "BUEU",
              "cpobla": "36004020200",
              "codPais": "ES",
              "nHabitantes": 430,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36939"
          },
          {
              "lpobla": "A CARRASQUEIRA (PONTEAREAS)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042220300",
              "codPais": "ES",
              "nHabitantes": 32,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36895"
          },
          {
              "lpobla": "A CARREIRA (ANTAS DE ULLA)",
              "lmunic": "ANTAS DE ULLA",
              "cpobla": "27003280200",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27579"
          },
          {
              "lpobla": "A CARREIRA (CASTRO DE REI)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010250300",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27259"
          },
          {
              "lpobla": "A CARREIRA (CELANOVA)",
              "lmunic": "CELANOVA",
              "cpobla": "32024090300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "OURENSE",
              "cpostal": "32817"
          },
          {
              "lpobla": "A CARREIRA CHA",
              "lmunic": "TRABADA",
              "cpobla": "27061070100",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27767"
          },
          {
              "lpobla": "A CARREIRA (COVAS)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066031900",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "LUGO",
              "cpostal": "27861"
          },
          {
              "lpobla": "A CARREIRA (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022030900",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27307"
          },
          {
              "lpobla": "A CARREIRA (IRIXOA)",
              "lmunic": "IRIXOA",
              "cpobla": "15039060800",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "A CORUÑA",
              "cpostal": "15314"
          },
          {
              "lpobla": "A CARREIRA (MAGAZOS)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066081100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27850"
          },
          {
              "lpobla": "A CARREIRA (MONTERROSO)",
              "lmunic": "MONTERROSO",
              "cpobla": "27032280300",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27569"
          },
          {
              "lpobla": "A CARREIRA (O CORGO)",
              "lmunic": "O CORGO",
              "cpobla": "27014070300",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27163"
          },
          {
              "lpobla": "A CARREIRA (O PORRIÑO)",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039030200",
              "codPais": "ES",
              "nHabitantes": 109,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36411"
          },
          {
              "lpobla": "A CARREIRA (O SAVIÑAO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058130400",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27548"
          },
          {
              "lpobla": "A CARREIRA (O VALADOURO)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063090900",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27777"
          },
          {
              "lpobla": "A CARREIRA (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038070400",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A CARREIRA (OUTES)",
              "lmunic": "OUTES",
              "cpobla": "15062040300",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "A CORUÑA",
              "cpostal": "15239"
          },
          {
              "lpobla": "A CARREIRA (PALAS DE REI)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040210200",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "LUGO",
              "cpostal": "27205"
          },
          {
              "lpobla": "A CARREIRA (PONTEAREAS)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042060100",
              "codPais": "ES",
              "nHabitantes": 43,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36865"
          },
          {
              "lpobla": "A CARREIRA (SEQUEIRO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087060300",
              "codPais": "ES",
              "nHabitantes": 228,
              "lprovi": "A CORUÑA",
              "cpostal": "15550"
          },
          {
              "lpobla": "A CARREIRA (VALDOVIÑO SANTA EULALIA)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087071400",
              "codPais": "ES",
              "nHabitantes": 62,
              "lprovi": "A CORUÑA",
              "cpostal": "15552"
          },
          {
              "lpobla": "A CARREIRA VELLA",
              "lmunic": "OUTEIRO DE REI",
              "cpobla": "27039240200",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "LUGO",
              "cpostal": "27150"
          },
          {
              "lpobla": "A CARREIRIÑA",
              "lmunic": "RAMIRAS",
              "cpobla": "32068090100",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "OURENSE",
              "cpostal": "32810"
          },
          {
              "lpobla": "A CARRETERA (TOEN)",
              "lmunic": "TOEN",
              "cpobla": "32081010200",
              "codPais": "ES",
              "nHabitantes": 48,
              "lprovi": "OURENSE",
              "cpostal": "32940"
          },
          {
              "lpobla": "A CARRETERIA (PARADELA)",
              "lmunic": "PARADELA",
              "cpobla": "27042120300",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27611"
          },
          {
              "lpobla": "A CARUNCHADA",
              "lmunic": "BECERREA",
              "cpobla": "27006181100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27695"
          },
          {
              "lpobla": "A CASA BRANCA (LOURENZA)",
              "lmunic": "LOURENZA",
              "cpobla": "27027010300",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "LUGO",
              "cpostal": "27750"
          },
          {
              "lpobla": "A CASA DA CRUZ",
              "lmunic": "CUNTIS",
              "cpobla": "36015010400",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36677"
          },
          {
              "lpobla": "A CASA DA FRAGA",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061273100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15338"
          },
          {
              "lpobla": "A CASA DA HEDRA",
              "lmunic": "RIBADEO",
              "cpobla": "27051041600",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27714"
          },
          {
              "lpobla": "A CASA DE PARGA",
              "lmunic": "FRIOL",
              "cpobla": "27020180200",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27156"
          },
          {
              "lpobla": "A CASA DE PEDRA (LANCARA)",
              "lmunic": "LANCARA",
              "cpobla": "27026020600",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "LUGO",
              "cpostal": "27367"
          },
          {
              "lpobla": "A CASA DO BARRIO",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009090200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27527"
          },
          {
              "lpobla": "A CASA DO CAMIÑO (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038DD0100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A CASA DO MONTE (A COVA)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058030300",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27532"
          },
          {
              "lpobla": "A CASA DO MONTE (A ESTRADA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017500300",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36682"
          },
          {
              "lpobla": "A CASA DO MONTE (FREAN)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058080100",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27547"
          },
          {
              "lpobla": "A CASA DO PAZO",
              "lmunic": "FRIOL",
              "cpobla": "27020180300",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27156"
          },
          {
              "lpobla": "A CASA DO PORTO",
              "lmunic": "ROIS",
              "cpobla": "15074090200",
              "codPais": "ES",
              "nHabitantes": 33,
              "lprovi": "A CORUÑA",
              "cpostal": "15911"
          },
          {
              "lpobla": "A CASA DO VENTO (ERMEDELO)",
              "lmunic": "ROIS",
              "cpobla": "15074040300",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "A CORUÑA",
              "cpostal": "15282"
          },
          {
              "lpobla": "A CASA DO VENTO (LEROÑO)",
              "lmunic": "ROIS",
              "cpobla": "15074060100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "A CORUÑA",
              "cpostal": "15912"
          },
          {
              "lpobla": "A CASA DOS PRADOS (QUIROGA)",
              "lmunic": "QUIROGA",
              "cpobla": "27050080200",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27329"
          },
          {
              "lpobla": "A CASA GRANDE (MESIA)",
              "lmunic": "MESIA",
              "cpobla": "15047120600",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A CASA GRANDE (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021060200",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27833"
          },
          {
              "lpobla": "A CASA LOUSADA (MURAS)",
              "lmunic": "MURAS",
              "cpobla": "27033020500",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27817"
          },
          {
              "lpobla": "A CASA NOVA DE VILARIÑO",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022180500",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27307"
          },
          {
              "lpobla": "A CASA NOVA (MAGAZOS)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066081200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27850"
          },
          {
              "lpobla": "A CASA NOVA (MIÑOTOS)",
              "lmunic": "OUROL",
              "cpobla": "27038051200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A CASA NOVA (OUROL SANTA MARIA)",
              "lmunic": "OUROL",
              "cpobla": "27038063900",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A CASA NOVA (XERDIZ)",
              "lmunic": "OUROL",
              "cpobla": "27038080600",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A CASA VELLA (MIÑOTOS)",
              "lmunic": "OUROL",
              "cpobla": "27038051300",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27864"
          },
          {
              "lpobla": "A CASA VELLA (OUROL SANTA MARIA)",
              "lmunic": "OUROL",
              "cpobla": "27038061300",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A CASABRANCA (GOA)",
              "lmunic": "COSPEITO",
              "cpobla": "27015050700",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27378"
          },
          {
              "lpobla": "A CASABRANCA (LANCARA)",
              "lmunic": "LANCARA",
              "cpobla": "27026040500",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27692"
          },
          {
              "lpobla": "A CASADEDRA",
              "lmunic": "XERMADE",
              "cpobla": "27021030300",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27832"
          },
          {
              "lpobla": "A CASAGRANDE (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026061000",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A CASAGRANDE (IRIXOA)",
              "lmunic": "IRIXOA",
              "cpobla": "15039050600",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15314"
          },
          {
              "lpobla": "A CASALTA",
              "lmunic": "PARADA DE SIL",
              "cpobla": "32057020100",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "OURENSE",
              "cpostal": "32748"
          },
          {
              "lpobla": "A CASANOVA (A RIA DE ABRES)",
              "lmunic": "TRABADA",
              "cpobla": "27061030300",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27766"
          },
          {
              "lpobla": "A CASANOVA (ABADIN)",
              "lmunic": "ABADIN",
              "cpobla": "27001120200",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "LUGO",
              "cpostal": "27730"
          },
          {
              "lpobla": "A CASANOVA (ALBIXOI)",
              "lmunic": "MESIA",
              "cpobla": "15047010200",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A CASANOVA (BOIMENTE)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066010600",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27864"
          },
          {
              "lpobla": "A CASANOVA (CABRUI)",
              "lmunic": "MESIA",
              "cpobla": "15047050400",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A CASANOVA (CANDAMIL)",
              "lmunic": "XERMADE",
              "cpobla": "27021030400",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27832"
          },
          {
              "lpobla": "A CASANOVA (CARRES)",
              "lmunic": "CESURAS",
              "cpobla": "15026040200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A CASANOVA (CELANOVA)",
              "lmunic": "CELANOVA",
              "cpobla": "32024110200",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "OURENSE",
              "cpostal": "32828"
          },
          {
              "lpobla": "A CASANOVA (CORVELLE)",
              "lmunic": "SARRIA",
              "cpobla": "27057110300",
              "codPais": "ES",
              "nHabitantes": 43,
              "lprovi": "LUGO",
              "cpostal": "27690"
          },
          {
              "lpobla": "A CASANOVA (COSTA)",
              "lmunic": "VILALBA",
              "cpobla": "27065081500",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27816"
          },
          {
              "lpobla": "A CASANOVA (COTOBADE)",
              "lmunic": "COTOBADE",
              "cpobla": "36012120300",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36854"
          },
          {
              "lpobla": "A CASANOVA DA XESTOSA",
              "lmunic": "MURAS",
              "cpobla": "27033051600",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A CASANOVA DO CAMPO",
              "lmunic": "XERMADE",
              "cpobla": "27021040700",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27824"
          },
          {
              "lpobla": "A CASANOVA (EIRE)",
              "lmunic": "PANTON",
              "cpobla": "27041080200",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27439"
          },
          {
              "lpobla": "A CASANOVA (ESGOS)",
              "lmunic": "ESGOS",
              "cpobla": "32031040100",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "OURENSE",
              "cpostal": "32720"
          },
          {
              "lpobla": "A CASANOVA (ESPASANTES)",
              "lmunic": "PANTON",
              "cpobla": "27041090400",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27450"
          },
          {
              "lpobla": "A CASANOVA (GOMESENDE)",
              "lmunic": "GOMESENDE",
              "cpobla": "32033010400",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "OURENSE",
              "cpostal": "32212"
          },
          {
              "lpobla": "A CASANOVA (GRIXOA)",
              "lmunic": "SAN AMARO",
              "cpobla": "32074040200",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "OURENSE",
              "cpostal": "32455"
          },
          {
              "lpobla": "A CASANOVA (IRIXOA)",
              "lmunic": "IRIXOA",
              "cpobla": "15039040400",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "A CORUÑA",
              "cpostal": "15313"
          },
          {
              "lpobla": "A CASANOVA (LANCARA)",
              "lmunic": "LANCARA",
              "cpobla": "27026020300",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27367"
          },
          {
              "lpobla": "A CASANOVA (LOURENZA)",
              "lmunic": "LOURENZA",
              "cpobla": "27027040400",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27751"
          },
          {
              "lpobla": "A CASANOVA (MEIRA)",
              "lmunic": "MEIRA",
              "cpobla": "27029010300",
              "codPais": "ES",
              "nHabitantes": 35,
              "lprovi": "LUGO",
              "cpostal": "27248"
          },
          {
              "lpobla": "A CASANOVA (MOUCIDE)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063DD1500",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27779"
          },
          {
              "lpobla": "A CASANOVA (MURAS)",
              "lmunic": "MURAS",
              "cpobla": "27033031000",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A CASANOVA (NOICELA)",
              "lmunic": "CARBALLO",
              "cpobla": "15019110500",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "A CORUÑA",
              "cpostal": "15105"
          },
          {
              "lpobla": "A CASANOVA (O CORGO)",
              "lmunic": "O CORGO",
              "cpobla": "27014030100",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "LUGO",
              "cpostal": "27164"
          },
          {
              "lpobla": "A CASANOVA (O ERMO)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061270500",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15338"
          },
          {
              "lpobla": "A CASANOVA (O INCIO)",
              "lmunic": "O INCIO",
              "cpobla": "27024140100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27346"
          },
          {
              "lpobla": "A CASANOVA (O PEREIRO DE AGUIAR)",
              "lmunic": "O PEREIRO DE AGUIAR",
              "cpobla": "32058060100",
              "codPais": "ES",
              "nHabitantes": 34,
              "lprovi": "OURENSE",
              "cpostal": "32792"
          },
          {
              "lpobla": "A CASANOVA (O VICEDO)",
              "lmunic": "O VICEDO",
              "cpobla": "27064070500",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27860"
          },
          {
              "lpobla": "A CASANOVA (OUSENDE)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058140700",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27546"
          },
          {
              "lpobla": "A CASANOVA (OUTEIRO DE REI)",
              "lmunic": "OUTEIRO DE REI",
              "cpobla": "27039090100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27151"
          },
          {
              "lpobla": "A CASANOVA (PACIO)",
              "lmunic": "FRIOL",
              "cpobla": "27020190200",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27235"
          },
          {
              "lpobla": "A CASANOVA (PARADELA)",
              "lmunic": "PARADELA",
              "cpobla": "27042180100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27612"
          },
          {
              "lpobla": "A CASANOVA (PIÑEIRO)",
              "lmunic": "XERMADE",
              "cpobla": "27021080300",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27833"
          },
          {
              "lpobla": "A CASANOVA (PORTOMARIN)",
              "lmunic": "PORTOMARIN",
              "cpobla": "27049140200",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27187"
          },
          {
              "lpobla": "A CASANOVA (POUSADA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044140200",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27246"
          },
          {
              "lpobla": "A CASANOVA (PRADO)",
              "lmunic": "FRIOL",
              "cpobla": "27020200200",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27227"
          },
          {
              "lpobla": "A CASANOVA (PREVESOS)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010190300",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27257"
          },
          {
              "lpobla": "A CASANOVA (RIBADEO)",
              "lmunic": "RIBADEO",
              "cpobla": "27051030200",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27711"
          },
          {
              "lpobla": "A CASANOVA (RIOTORTO)",
              "lmunic": "RIOTORTO",
              "cpobla": "27054071300",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27744"
          },
          {
              "lpobla": "A CASANOVA (ROCHA)",
              "lmunic": "FRIOL",
              "cpobla": "27020220300",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27228"
          },
          {
              "lpobla": "A CASANOVA (SAN SALVADOR)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022130400",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27305"
          },
          {
              "lpobla": "A CASANOVA (SANTA CRUZ DO VALADOURO)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063091000",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27777"
          },
          {
              "lpobla": "A CASANOVA (SANTE)",
              "lmunic": "TRABADA",
              "cpobla": "27061040300",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27766"
          },
          {
              "lpobla": "A CASANOVA (SANTIAGO DE COMPOSTELA)",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078040200",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15884"
          },
          {
              "lpobla": "A CASANOVA (SEREN)",
              "lmunic": "FRIOL",
              "cpobla": "27020270200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27299"
          },
          {
              "lpobla": "A CASANOVA (VIEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066100900",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "LUGO",
              "cpostal": "27869"
          },
          {
              "lpobla": "A CASANOVA (VILAGARCIA DE AROUSA)",
              "lmunic": "VILAGARCIA DE AROUSA",
              "cpobla": "36060070600",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36619"
          },
          {
              "lpobla": "A CASANOVA (VILAR DE ORTELLE)",
              "lmunic": "PANTON",
              "cpobla": "27041260300",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27439"
          },
          {
              "lpobla": "A CASANOVA (VILARMAIOR)",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091010600",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "A CORUÑA",
              "cpostal": "15615"
          },
          {
              "lpobla": "A CASANOVA (VIMIANZO)",
              "lmunic": "VIMIANZO",
              "cpobla": "15092030400",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "A CORUÑA",
              "cpostal": "15128"
          },
          {
              "lpobla": "A CASANOVA (XANCEDA)",
              "lmunic": "MESIA",
              "cpobla": "15047120700",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A CASANOVA (XIA)",
              "lmunic": "FRIOL",
              "cpobla": "27020320600",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27227"
          },
          {
              "lpobla": "A CASAQUEIMADA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026090500",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A CASAQUEIMADA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061140500",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15339"
          },
          {
              "lpobla": "A CASARIA",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044150300",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27286"
          },
          {
              "lpobla": "A CASAVELLA (BARONCELLE)",
              "lmunic": "ABADIN",
              "cpobla": "27001040400",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27845"
          },
          {
              "lpobla": "A CASAVELLA (CAZAS)",
              "lmunic": "XERMADE",
              "cpobla": "27021040800",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27824"
          },
          {
              "lpobla": "A CASAVELLA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026130600",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15390"
          },
          {
              "lpobla": "A CASAVELLA (LOUSADA)",
              "lmunic": "XERMADE",
              "cpobla": "27021051000",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27835"
          },
          {
              "lpobla": "A CASAVELLA (MONDOÑEDO)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030111600",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27747"
          },
          {
              "lpobla": "A CASAVELLA (MURAS SAN PEDRO)",
              "lmunic": "MURAS",
              "cpobla": "27033051800",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A CASAVELLA (NOSA SEÑORA DAS NEVES)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061200300",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15338"
          },
          {
              "lpobla": "A CASAVELLA (O ERMO)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061270600",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "A CORUÑA",
              "cpostal": "15338"
          },
          {
              "lpobla": "A CASAVELLA (VIVEIRON)",
              "lmunic": "MURAS",
              "cpobla": "27033080800",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27837"
          },
          {
              "lpobla": "A CASEDA",
              "lmunic": "VILA DE CRUCES",
              "cpobla": "36059240300",
              "codPais": "ES",
              "nHabitantes": 67,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36586"
          },
          {
              "lpobla": "A CASELA (A LAXE)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063050300",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27778"
          },
          {
              "lpobla": "A CASELA (CASTRO DE REI)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010250400",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27259"
          },
          {
              "lpobla": "A CASELA (SAMOS)",
              "lmunic": "SAMOS",
              "cpobla": "27055210200",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "LUGO",
              "cpostal": "27626"
          },
          {
              "lpobla": "A CASELA (SANTA CRUZ)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063091100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27777"
          },
          {
              "lpobla": "A CASELA (SILLEDA)",
              "lmunic": "SILLEDA",
              "cpobla": "36052140300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36540"
          },
          {
              "lpobla": "A CASERIA (VILALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065210800",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27841"
          },
          {
              "lpobla": "A CASERIA (VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066032200",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27861"
          },
          {
              "lpobla": "A CASETA",
              "lmunic": "SARRIA",
              "cpobla": "27057300200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27613"
          },
          {
              "lpobla": "A CASETA (LAROUCO)",
              "lmunic": "LAROUCO",
              "cpobla": "32038010100",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "OURENSE",
              "cpostal": "32370"
          },
          {
              "lpobla": "A CASETA (MACEDA)",
              "lmunic": "MACEDA",
              "cpobla": "32043050300",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "OURENSE",
              "cpostal": "32740"
          },
          {
              "lpobla": "A CASETA (MONTEDERRAMO)",
              "lmunic": "MONTEDERRAMO",
              "cpobla": "32049110100",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "OURENSE",
              "cpostal": "32790"
          },
          {
              "lpobla": "A CASETA (SAN AMARO)",
              "lmunic": "SAN AMARO",
              "cpobla": "32074010300",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "OURENSE",
              "cpostal": "32455"
          },
          {
              "lpobla": "A CASILLA (LAMAS)",
              "lmunic": "LUGO",
              "cpobla": "27028260200",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27210"
          },
          {
              "lpobla": "A CASILLA (MELIDE)",
              "lmunic": "MELIDE",
              "cpobla": "15046200100",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "A CORUÑA",
              "cpostal": "15809"
          },
          {
              "lpobla": "A CASILLA (RIANXO)",
              "lmunic": "RIANXO",
              "cpobla": "15072012000",
              "codPais": "ES",
              "nHabitantes": 72,
              "lprovi": "A CORUÑA",
              "cpostal": "15984"
          },
          {
              "lpobla": "A CASILLA (VILALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065101300",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "LUGO",
              "cpostal": "27840"
          },
          {
              "lpobla": "A CASIÑA",
              "lmunic": "VIMIANZO",
              "cpobla": "15092070300",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "A CORUÑA",
              "cpostal": "15121"
          },
          {
              "lpobla": "A CASIÑA",
              "lmunic": "COSPEITO",
              "cpobla": "27015090400",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27375"
          },
          {
              "lpobla": "A CASIÑA (CUNTIS)",
              "lmunic": "CUNTIS",
              "cpobla": "36015010500",
              "codPais": "ES",
              "nHabitantes": 114,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36677"
          },
          {
              "lpobla": "A CASOPA",
              "lmunic": "COSPEITO",
              "cpobla": "27015130200",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27375"
          },
          {
              "lpobla": "A CASTELLANA",
              "lmunic": "SAN CIBRAO DAS VIÑAS",
              "cpobla": "32075040300",
              "codPais": "ES",
              "nHabitantes": 158,
              "lprovi": "OURENSE",
              "cpostal": "32901"
          },
          {
              "lpobla": "A CASTELLANA",
              "lmunic": "O VALADOURO",
              "cpobla": "27063030200",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27770"
          },
          {
              "lpobla": "A CASTELLANA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026020700",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "A CORUÑA",
              "cpostal": "15390"
          },
          {
              "lpobla": "A CASTIÑEIRA (A CAPELA SANTIAGO)",
              "lmunic": "A CAPELA",
              "cpobla": "15018041000",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A CASTIÑEIRA (A PASTORIZA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044041100",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27286"
          },
          {
              "lpobla": "A CASTIÑEIRA (BRAVOS)",
              "lmunic": "OUROL",
              "cpobla": "27038020500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A CASTIÑEIRA (CABALAR)",
              "lmunic": "A CAPELA",
              "cpobla": "15018030600",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A CASTIÑEIRA (CABANAS)",
              "lmunic": "OUROL",
              "cpobla": "27038031100",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A CASTIÑEIRA (CHANTADA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016300400",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27517"
          },
          {
              "lpobla": "A CASTIÑEIRA (FERREIRA)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076020500",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "A CORUÑA",
              "cpostal": "15598"
          },
          {
              "lpobla": "A CASTIÑEIRA GRANDE",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078190400",
              "codPais": "ES",
              "nHabitantes": 49,
              "lprovi": "A CORUÑA",
              "cpostal": "15820"
          },
          {
              "lpobla": "A CASTIÑEIRA (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022100600",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "LUGO",
              "cpostal": "27372"
          },
          {
              "lpobla": "A CASTIÑEIRA NOVA",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091020900",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "A CORUÑA",
              "cpostal": "15616"
          },
          {
              "lpobla": "A CASTIÑEIRA (O INCIO)",
              "lmunic": "O INCIO",
              "cpobla": "27024150300",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27346"
          },
          {
              "lpobla": "A CASTIÑEIRA PEQUENA",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078050100",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "A CORUÑA",
              "cpostal": "15820"
          },
          {
              "lpobla": "A CASTIÑEIRA (PUNXIN)",
              "lmunic": "PUNXIN",
              "cpobla": "32065040300",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "OURENSE",
              "cpostal": "32456"
          },
          {
              "lpobla": "A CASTIÑEIRA (SANTA COMBA)",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077030300",
              "codPais": "ES",
              "nHabitantes": 54,
              "lprovi": "A CORUÑA",
              "cpostal": "15847"
          },
          {
              "lpobla": "A CASTIÑEIRA (SEOANE VELLO)",
              "lmunic": "MONTEDERRAMO",
              "cpobla": "32049110200",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "OURENSE",
              "cpostal": "32790"
          },
          {
              "lpobla": "A CASTIÑEIRA (TRAZO)",
              "lmunic": "TRAZO",
              "cpobla": "15086040400",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15687"
          },
          {
              "lpobla": "A CASTIÑEIRA VELLA",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091021000",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "A CORUÑA",
              "cpostal": "15616"
          },
          {
              "lpobla": "A CASTIÑEIRA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021040900",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27824"
          },
          {
              "lpobla": "A CASTRONELA",
              "lmunic": "FRIOL",
              "cpobla": "27020321100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27227"
          },
          {
              "lpobla": "A CATUXA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061190300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15332"
          },
          {
              "lpobla": "A CAVADA",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058100200",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27548"
          },
          {
              "lpobla": "A CAVADIÑA (PONTEAREAS)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042120200",
              "codPais": "ES",
              "nHabitantes": 32,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36868"
          },
          {
              "lpobla": "A CAXIGUEIRA (ALFOZ)",
              "lmunic": "ALFOZ",
              "cpobla": "27002080600",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27775"
          },
          {
              "lpobla": "A CAZCALLEIRA",
              "lmunic": "O VALADOURO",
              "cpobla": "27063040400",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27777"
          },
          {
              "lpobla": "A CAZOLGA",
              "lmunic": "LOURENZA",
              "cpobla": "27027030300",
              "codPais": "ES",
              "nHabitantes": 91,
              "lprovi": "LUGO",
              "cpostal": "27760"
          },
          {
              "lpobla": "A CEBOLA DE ABAIXO",
              "lmunic": "ZAS",
              "cpobla": "15093010300",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "A CORUÑA",
              "cpostal": "15851"
          },
          {
              "lpobla": "A CEBOLA DE ARRIBA",
              "lmunic": "ZAS",
              "cpobla": "15093010400",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "A CORUÑA",
              "cpostal": "15851"
          },
          {
              "lpobla": "A CEGOÑEIRA (SOBER)",
              "lmunic": "SOBER",
              "cpobla": "27059020600",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27466"
          },
          {
              "lpobla": "A CELA (CARBALLEDO)",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009DD0100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27532"
          },
          {
              "lpobla": "A CELA (SANTA MARIA)",
              "lmunic": "LOBIOS",
              "cpobla": "32042030000",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "OURENSE",
              "cpostal": "32879"
          },
          {
              "lpobla": "A CENDONA",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038090500",
              "codPais": "ES",
              "nHabitantes": 62,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36156"
          },
          {
              "lpobla": "A CENTRAL",
              "lmunic": "OUTES",
              "cpobla": "15062071100",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "A CORUÑA",
              "cpostal": "15287"
          },
          {
              "lpobla": "A CEPA (OUTES)",
              "lmunic": "OUTES",
              "cpobla": "15062023400",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15237"
          },
          {
              "lpobla": "A CEPADA",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058080200",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27547"
          },
          {
              "lpobla": "A CEPADA",
              "lmunic": "MONTEDERRAMO",
              "cpobla": "32049070200",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "OURENSE",
              "cpostal": "32751"
          },
          {
              "lpobla": "A CEPEIRA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019160500",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A CEPEIRA (VILARMAIOR)",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091021200",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "A CORUÑA",
              "cpostal": "15616"
          },
          {
              "lpobla": "A CERCA",
              "lmunic": "VILANOVA DE AROUSA",
              "cpobla": "36061070300",
              "codPais": "ES",
              "nHabitantes": 172,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36620"
          },
          {
              "lpobla": "A CERCA (CARIÑO)",
              "lmunic": "CARIÑO",
              "cpobla": "15901041000",
              "codPais": "ES",
              "nHabitantes": 132,
              "lprovi": "A CORUÑA",
              "cpostal": "15365"
          },
          {
              "lpobla": "A CERCA (RIBEIRA)",
              "lmunic": "RIBEIRA",
              "cpobla": "15073010200",
              "codPais": "ES",
              "nHabitantes": 235,
              "lprovi": "A CORUÑA",
              "cpostal": "15965"
          },
          {
              "lpobla": "A CERDEIRA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020170600",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A CERDEIRA (SAN ROMAN DE VILAESTROFE)",
              "lmunic": "CERVO",
              "cpobla": "27013070400",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27889"
          },
          {
              "lpobla": "A CERDEIRA (TRAZO)",
              "lmunic": "TRAZO",
              "cpobla": "15086100300",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15687"
          },
          {
              "lpobla": "A CERDEIRA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021070600",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27826"
          },
          {
              "lpobla": "A CERDEIRIÑA (FOZ)",
              "lmunic": "FOZ",
              "cpobla": "27019090900",
              "codPais": "ES",
              "nHabitantes": 41,
              "lprovi": "LUGO",
              "cpostal": "27788"
          },
          {
              "lpobla": "A CEREIXEIRA",
              "lmunic": "CAMBADOS",
              "cpobla": "36006040700",
              "codPais": "ES",
              "nHabitantes": 82,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36635"
          },
          {
              "lpobla": "A CEREIXIÑA",
              "lmunic": "OUROL",
              "cpobla": "27038010400",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A CERNADA",
              "lmunic": "ESGOS",
              "cpobla": "32031050200",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "OURENSE",
              "cpostal": "32720"
          },
          {
              "lpobla": "A CERNADA (CASTROVERDE)",
              "lmunic": "CASTROVERDE",
              "cpobla": "27011200900",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27128"
          },
          {
              "lpobla": "A CERNADA (GONDOMAR)",
              "lmunic": "GONDOMAR",
              "cpobla": "36021100400",
              "codPais": "ES",
              "nHabitantes": 89,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36316"
          },
          {
              "lpobla": "A CERNADA (NAVIA DE SUARNA)",
              "lmunic": "NAVIA DE SUARNA",
              "cpobla": "27034090100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27652"
          },
          {
              "lpobla": "A CERNADA (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038070600",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A CERNADA (PALAS DE REI)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040010700",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27205"
          },
          {
              "lpobla": "A CERQUEIRA",
              "lmunic": "A ESTRADA",
              "cpobla": "36017500500",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36682"
          },
          {
              "lpobla": "A CERVEIRA",
              "lmunic": "XERMADE",
              "cpobla": "27021080500",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27833"
          },
          {
              "lpobla": "A CERVELA (SAN CRISTOVO)",
              "lmunic": "O INCIO",
              "cpobla": "27024040000",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27342"
          },
          {
              "lpobla": "A CERVELA (SAN MIGUEL)",
              "lmunic": "ANTAS DE ULLA",
              "cpobla": "27003140000",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27579"
          },
          {
              "lpobla": "A CESTA",
              "lmunic": "CARBALLO",
              "cpobla": "15019020500",
              "codPais": "ES",
              "nHabitantes": 85,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A CHA (CERVANTES)",
              "lmunic": "CERVANTES",
              "cpobla": "27012020200",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27665"
          },
          {
              "lpobla": "A CHA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026040300",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A CHA (MONFORTE DE LEMOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031081000",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27416"
          },
          {
              "lpobla": "A CHA (TEILAN)",
              "lmunic": "BOVEDA",
              "cpobla": "27008100500",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27359"
          },
          {
              "lpobla": "A CHABOLA",
              "lmunic": "IRIXOA",
              "cpobla": "15039040700",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "A CORUÑA",
              "cpostal": "15313"
          },
          {
              "lpobla": "A CHABOLA (COLES)",
              "lmunic": "COLES",
              "cpobla": "32026010300",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "OURENSE",
              "cpostal": "32153"
          },
          {
              "lpobla": "A CHAFARETA",
              "lmunic": "BEGONTE",
              "cpobla": "27007010500",
              "codPais": "ES",
              "nHabitantes": 43,
              "lprovi": "LUGO",
              "cpostal": "27370"
          },
          {
              "lpobla": "A CHAINZA",
              "lmunic": "NOIA",
              "cpobla": "15057040400",
              "codPais": "ES",
              "nHabitantes": 94,
              "lprovi": "A CORUÑA",
              "cpostal": "15213"
          },
          {
              "lpobla": "A CHAIRA (PANTON)",
              "lmunic": "PANTON",
              "cpobla": "27041110200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27437"
          },
          {
              "lpobla": "A CHAMUSCA",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038152400",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36143"
          },
          {
              "lpobla": "A CHAN (BUGARIN)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042050200",
              "codPais": "ES",
              "nHabitantes": 53,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36869"
          },
          {
              "lpobla": "A CHAN (CARBALLEDO)",
              "lmunic": "COTOBADE",
              "cpobla": "36012040400",
              "codPais": "ES",
              "nHabitantes": 58,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36856"
          },
          {
              "lpobla": "A CHAN (LEIRADO)",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050070800",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36457"
          },
          {
              "lpobla": "A CHAN (LOUREIRO)",
              "lmunic": "COTOBADE",
              "cpobla": "36012070500",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36855"
          },
          {
              "lpobla": "A CHAN (MORAÑA)",
              "lmunic": "MORAÑA",
              "cpobla": "36032011400",
              "codPais": "ES",
              "nHabitantes": 73,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36669"
          },
          {
              "lpobla": "A CHAN (O PORRIÑO)",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039020800",
              "codPais": "ES",
              "nHabitantes": 98,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36475"
          },
          {
              "lpobla": "A CHAN (PAZOS DE BORBEN)",
              "lmunic": "PAZOS DE BORBEN",
              "cpobla": "36037080300",
              "codPais": "ES",
              "nHabitantes": 59,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36844"
          },
          {
              "lpobla": "A CHANCA (CHANTADA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016010300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27511"
          },
          {
              "lpobla": "A CHANCA (SAN MAMEDE)",
              "lmunic": "SARRIA",
              "cpobla": "27057120000",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27618"
          },
          {
              "lpobla": "A CHANTA (MONDOÑEDO)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030071700",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27747"
          },
          {
              "lpobla": "A CHANTADA (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022080300",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27380"
          },
          {
              "lpobla": "A CHAPALEIRA",
              "lmunic": "ANTAS DE ULLA",
              "cpobla": "27003DD0100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27579"
          },
          {
              "lpobla": "A CHARRUA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019172000",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15108"
          },
          {
              "lpobla": "A CHEDA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019052500",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15108"
          },
          {
              "lpobla": "A CHIELA",
              "lmunic": "LOURENZA",
              "cpobla": "27027030500",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27750"
          },
          {
              "lpobla": "A CHISCA",
              "lmunic": "ROIS",
              "cpobla": "15074020200",
              "codPais": "ES",
              "nHabitantes": 42,
              "lprovi": "A CORUÑA",
              "cpostal": "15912"
          },
          {
              "lpobla": "A CHOCIÑA",
              "lmunic": "MORAÑA",
              "cpobla": "36032090600",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36669"
          },
          {
              "lpobla": "A CHOEIRA",
              "lmunic": "CULLEREDO",
              "cpobla": "15031010200",
              "codPais": "ES",
              "nHabitantes": 219,
              "lprovi": "A CORUÑA",
              "cpostal": "15180"
          },
          {
              "lpobla": "A CHONIA (TRAZO)",
              "lmunic": "TRAZO",
              "cpobla": "15086111900",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15686"
          },
          {
              "lpobla": "A CHOQUEIRA",
              "lmunic": "ABADIN",
              "cpobla": "27001141500",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27737"
          },
          {
              "lpobla": "A CHOUPANA (CASTRIZ)",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077040500",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15848"
          },
          {
              "lpobla": "A CHOUPANA (FONTECADA)",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077070600",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "A CORUÑA",
              "cpostal": "15837"
          },
          {
              "lpobla": "A CHOUPANA (MALPICA DE BERGANTIÑOS)",
              "lmunic": "MALPICA DE BERGANTIÑOS",
              "cpobla": "15043050300",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15111"
          },
          {
              "lpobla": "A CHOUSA (A FONSAGRADA)",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018250300",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27112"
          },
          {
              "lpobla": "A CHOUSA (FERROL)",
              "lmunic": "FERROL",
              "cpobla": "15036040500",
              "codPais": "ES",
              "nHabitantes": 74,
              "lprovi": "A CORUÑA",
              "cpostal": "15593"
          },
          {
              "lpobla": "A CHOUSA GRANDE",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091060700",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15637"
          },
          {
              "lpobla": "A CHOUSA GRANDE",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022184300",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27307"
          },
          {
              "lpobla": "A CHOUSA (O CORGO)",
              "lmunic": "O CORGO",
              "cpobla": "27014170400",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "LUGO",
              "cpostal": "27163"
          },
          {
              "lpobla": "A CHOUSA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061145300",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "A CORUÑA",
              "cpostal": "15339"
          },
          {
              "lpobla": "A CHOUSA (PONTEDEUME)",
              "lmunic": "PONTEDEUME",
              "cpobla": "15069011400",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15614"
          },
          {
              "lpobla": "A CHOUSA (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087072000",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "A CORUÑA",
              "cpostal": "15552"
          },
          {
              "lpobla": "A CHOUSELA",
              "lmunic": "SANDIAS",
              "cpobla": "32077020300",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "OURENSE",
              "cpostal": "32693"
          },
          {
              "lpobla": "A CHOUZANA (VILAMARIN)",
              "lmunic": "VILAMARIN",
              "cpobla": "32087050400",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "OURENSE",
              "cpostal": "32101"
          },
          {
              "lpobla": "A CHOUZANA (XUNQUEIRA DE AMBIA)",
              "lmunic": "XUNQUEIRA DE AMBIA",
              "cpobla": "32036020500",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "OURENSE",
              "cpostal": "32678"
          },
          {
              "lpobla": "A CHOZA (TRABADA)",
              "lmunic": "TRABADA",
              "cpobla": "27061060500",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27765"
          },
          {
              "lpobla": "A CHURIA",
              "lmunic": "ZAS",
              "cpobla": "15093120400",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15858"
          },
          {
              "lpobla": "A CIDA (SANTA MARIÑA)",
              "lmunic": "O IRIXO",
              "cpobla": "32035030000",
              "codPais": "ES",
              "nHabitantes": 84,
              "lprovi": "OURENSE",
              "cpostal": "32537"
          },
          {
              "lpobla": "A CIGOÑEIRA (BEGONTE)",
              "lmunic": "BEGONTE",
              "cpobla": "27007080200",
              "codPais": "ES",
              "nHabitantes": 54,
              "lprovi": "LUGO",
              "cpostal": "27375"
          },
          {
              "lpobla": "A CIGUÑEIRA (O PARAMO)",
              "lmunic": "O PARAMO",
              "cpobla": "27043160300",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27364"
          },
          {
              "lpobla": "A CIMA",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042130500",
              "codPais": "ES",
              "nHabitantes": 45,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36861"
          },
          {
              "lpobla": "A CIMA (CERCEDA)",
              "lmunic": "CERCEDA",
              "cpobla": "15024014600",
              "codPais": "ES",
              "nHabitantes": 48,
              "lprovi": "A CORUÑA",
              "cpostal": "15185"
          },
          {
              "lpobla": "A CIUDA",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031130700",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27592"
          },
          {
              "lpobla": "A CIVIDA",
              "lmunic": "BUEU",
              "cpobla": "36004020300",
              "codPais": "ES",
              "nHabitantes": 117,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36939"
          },
          {
              "lpobla": "A COCIÑA",
              "lmunic": "NAVIA DE SUARNA",
              "cpobla": "27034060100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27657"
          },
          {
              "lpobla": "A CODESEIRA",
              "lmunic": "SILLEDA",
              "cpobla": "36052140400",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36540"
          },
          {
              "lpobla": "A CODESEIRA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026130800",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15390"
          },
          {
              "lpobla": "A COGULA (MONTERROSO)",
              "lmunic": "MONTERROSO",
              "cpobla": "27032040200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27569"
          },
          {
              "lpobla": "A COLADA",
              "lmunic": "RIBEIRA DE PIQUIN",
              "cpobla": "27053010200",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27243"
          },
          {
              "lpobla": "A COMBOA (LOURIZAN)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038100400",
              "codPais": "ES",
              "nHabitantes": 107,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36910"
          },
          {
              "lpobla": "A CONCHADA (PALMES)",
              "lmunic": "OURENSE",
              "cpobla": "32054110400",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "OURENSE",
              "cpostal": "32981"
          },
          {
              "lpobla": "A CONCHADA (TOEN)",
              "lmunic": "TOEN",
              "cpobla": "32081030300",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "OURENSE",
              "cpostal": "32920"
          },
          {
              "lpobla": "A CONDOMIÑA (AMES)",
              "lmunic": "AMES",
              "cpobla": "15002080600",
              "codPais": "ES",
              "nHabitantes": 53,
              "lprovi": "A CORUÑA",
              "cpostal": "15228"
          },
          {
              "lpobla": "A CONDOMIÑA (DADIN)",
              "lmunic": "O IRIXO",
              "cpobla": "32035060200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "OURENSE",
              "cpostal": "32536"
          },
          {
              "lpobla": "A CONDOMIÑA (O CAMPO)",
              "lmunic": "O IRIXO",
              "cpobla": "32035010500",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "OURENSE",
              "cpostal": "32530"
          },
          {
              "lpobla": "A CONDOMIÑA (PARADELA)",
              "lmunic": "PARADELA",
              "cpobla": "27042140400",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27611"
          },
          {
              "lpobla": "A CONDOMIÑA (SAN MARTIÑO)",
              "lmunic": "BARALLA",
              "cpobla": "27901130300",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "LUGO",
              "cpostal": "27696"
          },
          {
              "lpobla": "A CONDOMIÑA (SAN MIGUEL)",
              "lmunic": "BARALLA",
              "cpobla": "27901140200",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "LUGO",
              "cpostal": "27696"
          },
          {
              "lpobla": "A CONGOSTRA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061174000",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15349"
          },
          {
              "lpobla": "A CONGUADA",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040090500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27217"
          },
          {
              "lpobla": "A CONSOLACION",
              "lmunic": "A ESTRADA",
              "cpobla": "36017450400",
              "codPais": "ES",
              "nHabitantes": 91,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36684"
          },
          {
              "lpobla": "A CONSTENLA (MEAÑO)",
              "lmunic": "MEAÑO",
              "cpobla": "36027010200",
              "codPais": "ES",
              "nHabitantes": 56,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36638"
          },
          {
              "lpobla": "A CONTIÑA",
              "lmunic": "VILA DE CRUCES",
              "cpobla": "36059170300",
              "codPais": "ES",
              "nHabitantes": 68,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36599"
          },
          {
              "lpobla": "A CORDA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020170700",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A CORDA (PALAS DE REI)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040320200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27206"
          },
          {
              "lpobla": "A CORGA",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031260100",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "LUGO",
              "cpostal": "27418"
          },
          {
              "lpobla": "A CORGA (CANDO)",
              "lmunic": "OUTES",
              "cpobla": "15062010400",
              "codPais": "ES",
              "nHabitantes": 52,
              "lprovi": "A CORUÑA",
              "cpostal": "15286"
          },
          {
              "lpobla": "A CORGA (SABARDES)",
              "lmunic": "OUTES",
              "cpobla": "15062080700",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "A CORUÑA",
              "cpostal": "15288"
          },
          {
              "lpobla": "A CORGA (SANDIAS)",
              "lmunic": "SANDIAS",
              "cpobla": "32077020200",
              "codPais": "ES",
              "nHabitantes": 58,
              "lprovi": "OURENSE",
              "cpostal": "32693"
          },
          {
              "lpobla": "A CORNA",
              "lmunic": "PIÑOR",
              "cpobla": "32061040300",
              "codPais": "ES",
              "nHabitantes": 49,
              "lprovi": "OURENSE",
              "cpostal": "32137"
          },
          {
              "lpobla": "A CORNA (CARBALLEDO)",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009060500",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27529"
          },
          {
              "lpobla": "A CORNA (SANTA COMBA)",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077070500",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "A CORUÑA",
              "cpostal": "15837"
          },
          {
              "lpobla": "A CORNELLA",
              "lmunic": "AGOLADA",
              "cpobla": "36020070300",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36528"
          },
          {
              "lpobla": "A COROTA",
              "lmunic": "MEIRA",
              "cpobla": "27029020200",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "LUGO",
              "cpostal": "27241"
          },
          {
              "lpobla": "A COROZA",
              "lmunic": "ABADIN",
              "cpobla": "27001020500",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27379"
          },
          {
              "lpobla": "A CORREDOIRA (CAMPAÑO)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038040900",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36157"
          },
          {
              "lpobla": "A CORREDOIRA (GALDO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066061200",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A CORREDOIRA (GUNTIN)",
              "lmunic": "GUNTIN",
              "cpobla": "27023160200",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27184"
          },
          {
              "lpobla": "A CORREDOIRA (MANZANEDA)",
              "lmunic": "MANZANEDA",
              "cpobla": "32044040200",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "OURENSE",
              "cpostal": "32782"
          },
          {
              "lpobla": "A CORREDOIRA (MESIA)",
              "lmunic": "MESIA",
              "cpobla": "15047121900",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A CORREDOIRA (MURAS)",
              "lmunic": "MURAS",
              "cpobla": "27033080900",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27837"
          },
          {
              "lpobla": "A CORREDOIRA (O SAVIÑAO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058190400",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27545"
          },
          {
              "lpobla": "A CORREDOIRA (QUINTELA DE LEIRADO)",
              "lmunic": "QUINTELA DE LEIRADO",
              "cpobla": "32066050500",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "OURENSE",
              "cpostal": "32814"
          },
          {
              "lpobla": "A CORREDOIRA (RAMIRAS)",
              "lmunic": "RAMIRAS",
              "cpobla": "32068060100",
              "codPais": "ES",
              "nHabitantes": 56,
              "lprovi": "OURENSE",
              "cpostal": "32811"
          },
          {
              "lpobla": "A CORREDOIRA (RUS)",
              "lmunic": "CARBALLO",
              "cpobla": "15019151900",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A CORREDOIRA (VALCARRIA)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066090900",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27866"
          },
          {
              "lpobla": "A CORREDOIRA (VILA DE CRUCES)",
              "lmunic": "VILA DE CRUCES",
              "cpobla": "36059220100",
              "codPais": "ES",
              "nHabitantes": 54,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36598"
          },
          {
              "lpobla": "A CORREDOIRA (VILALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065260500",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27823"
          },
          {
              "lpobla": "A CORTE DO MATO",
              "lmunic": "OZA DOS RIOS",
              "cpobla": "15063100500",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "A CORUÑA",
              "cpostal": "15386"
          },
          {
              "lpobla": "A CORTELLA",
              "lmunic": "MELON",
              "cpobla": "32046010200",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "OURENSE",
              "cpostal": "32410"
          },
          {
              "lpobla": "A CORTELLA (BECERREA)",
              "lmunic": "BECERREA",
              "cpobla": "27006190500",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27660"
          },
          {
              "lpobla": "A CORTELLA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020040500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27228"
          },
          {
              "lpobla": "A CORTELLA (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022120500",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27388"
          },
          {
              "lpobla": "A CORTELLA (LANCARA)",
              "lmunic": "LANCARA",
              "cpobla": "27026040800",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27692"
          },
          {
              "lpobla": "A CORTEVELLA",
              "lmunic": "BALEIRA",
              "cpobla": "27004100300",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27276"
          },
          {
              "lpobla": "A CORTIÑA",
              "lmunic": "A BOLA",
              "cpobla": "32014020300",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "OURENSE",
              "cpostal": "32812"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15707"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15705"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15703"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15404"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15405"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15080"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15071"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15070"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15011"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15010"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15009"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15008"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15007"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15006"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15005"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15004"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15003"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15002"
          },
          {
              "lpobla": "A CORUÑA",
              "lmunic": "A CORUÑA",
              "cpobla": "15030000000",
              "codPais": "ES",
              "nHabitantes": 226580,
              "lprovi": "A CORUÑA",
              "cpostal": "15001"
          },
          {
              "lpobla": "A CORUXA (NEDA)",
              "lmunic": "NEDA",
              "cpobla": "15055DD0200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15510"
          },
          {
              "lpobla": "A CORUXEIRA",
              "lmunic": "ALLARIZ",
              "cpobla": "32001070300",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "OURENSE",
              "cpostal": "32664"
          },
          {
              "lpobla": "A CORVA",
              "lmunic": "O VICEDO",
              "cpobla": "27064070900",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27860"
          },
          {
              "lpobla": "A CORVAL",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038030300",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36154"
          },
          {
              "lpobla": "A CORVEIRA (A CAPELA)",
              "lmunic": "A CAPELA",
              "cpobla": "15018020600",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A CORVEIRA (CARBALLEDO)",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009010500",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27529"
          },
          {
              "lpobla": "A CORVEIRA (CULLEREDO)",
              "lmunic": "CULLEREDO",
              "cpobla": "15031080400",
              "codPais": "ES",
              "nHabitantes": 886,
              "lprovi": "A CORUÑA",
              "cpostal": "15174"
          },
          {
              "lpobla": "A CORVEIRA DE BAIXO",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009060600",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27529"
          },
          {
              "lpobla": "A COSTA (ALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065010700",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27813"
          },
          {
              "lpobla": "A COSTA (ALFOZ)",
              "lmunic": "ALFOZ",
              "cpobla": "27002080700",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "LUGO",
              "cpostal": "27775"
          },
          {
              "lpobla": "A COSTA (ANTAS DE ULLA)",
              "lmunic": "ANTAS DE ULLA",
              "cpobla": "27003140300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27579"
          },
          {
              "lpobla": "A COSTA (ARNOIS)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017060600",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36584"
          },
          {
              "lpobla": "A COSTA (BALEIRA)",
              "lmunic": "BALEIRA",
              "cpobla": "27004100400",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27276"
          },
          {
              "lpobla": "A COSTA (BORELA)",
              "lmunic": "COTOBADE",
              "cpobla": "36012030400",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36858"
          },
          {
              "lpobla": "A COSTA (CABANA DE BERGANTIÑOS)",
              "lmunic": "CABANA DE BERGANTIÑOS",
              "cpobla": "15014031600",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "A CORUÑA",
              "cpostal": "15116"
          },
          {
              "lpobla": "A COSTA (CAMBRE)",
              "lmunic": "CAMBRE",
              "cpobla": "15017122200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15659"
          },
          {
              "lpobla": "A COSTA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019040500",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "A CORUÑA",
              "cpostal": "15108"
          },
          {
              "lpobla": "A COSTA (CAROI)",
              "lmunic": "COTOBADE",
              "cpobla": "36012050400",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36856"
          },
          {
              "lpobla": "A COSTA (CASTRELO DE MIÑO)",
              "lmunic": "CASTRELO DE MIÑO",
              "cpobla": "32022030300",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "OURENSE",
              "cpostal": "32430"
          },
          {
              "lpobla": "A COSTA (CASTRO DE REI)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010241100",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "LUGO",
              "cpostal": "27267"
          },
          {
              "lpobla": "A COSTA (CERPONZONS)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038061200",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36152"
          },
          {
              "lpobla": "A COSTA (CHAVIN)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066040900",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27864"
          },
          {
              "lpobla": "A COSTA (COSPEITO)",
              "lmunic": "COSPEITO",
              "cpobla": "27015090600",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "LUGO",
              "cpostal": "27375"
          },
          {
              "lpobla": "A COSTA (CUDEIRO)",
              "lmunic": "OURENSE",
              "cpobla": "32054060400",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "OURENSE",
              "cpostal": "32103"
          },
          {
              "lpobla": "A COSTA DA GROBA",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042130600",
              "codPais": "ES",
              "nHabitantes": 35,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36861"
          },
          {
              "lpobla": "A COSTA DE FIGUEIRON",
              "lmunic": "BUEU",
              "cpobla": "36004010500",
              "codPais": "ES",
              "nHabitantes": 95,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36937"
          },
          {
              "lpobla": "A COSTA DO CUCO",
              "lmunic": "MELON",
              "cpobla": "32046010400",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "OURENSE",
              "cpostal": "32410"
          },
          {
              "lpobla": "A COSTA DO SOL",
              "lmunic": "VILALBA",
              "cpobla": "27065081800",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27816"
          },
          {
              "lpobla": "A COSTA (EIRE)",
              "lmunic": "PANTON",
              "cpobla": "27041080300",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27439"
          },
          {
              "lpobla": "A COSTA (FERREIRA)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040160400",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27206"
          },
          {
              "lpobla": "A COSTA (FILGUEIRA DE BARRANCA)",
              "lmunic": "CESURAS",
              "cpobla": "15026010500",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "A CORUÑA",
              "cpostal": "15390"
          },
          {
              "lpobla": "A COSTA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020200300",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27227"
          },
          {
              "lpobla": "A COSTA (GUIMAREI)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017210400",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36681"
          },
          {
              "lpobla": "A COSTA (LANCARA)",
              "lmunic": "LANCARA",
              "cpobla": "27026160300",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27369"
          },
          {
              "lpobla": "A COSTA (LAXE)",
              "lmunic": "LAXE",
              "cpobla": "15040061300",
              "codPais": "ES",
              "nHabitantes": 34,
              "lprovi": "A CORUÑA",
              "cpostal": "15118"
          },
          {
              "lpobla": "A COSTA (LOUREIRO)",
              "lmunic": "COTOBADE",
              "cpobla": "36012070400",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36855"
          },
          {
              "lpobla": "A COSTA (MELIDE)",
              "lmunic": "MELIDE",
              "cpobla": "15046070400",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "A CORUÑA",
              "cpostal": "15826"
          },
          {
              "lpobla": "A COSTA (MOECHE)",
              "lmunic": "MOECHE",
              "cpobla": "15049033600",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15563"
          },
          {
              "lpobla": "A COSTA (MONFORTE DE LEMOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031100500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27416"
          },
          {
              "lpobla": "A COSTA (O IRIXO)",
              "lmunic": "O IRIXO",
              "cpobla": "32035050400",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "OURENSE",
              "cpostal": "32530"
          },
          {
              "lpobla": "A COSTA (O PARAMO)",
              "lmunic": "O PARAMO",
              "cpobla": "27043040100",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27363"
          },
          {
              "lpobla": "A COSTA (O SAVIÑAO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058050300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27548"
          },
          {
              "lpobla": "A COSTA (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038080800",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A COSTA (PADERNE DE ALLARIZ)",
              "lmunic": "PADERNE DE ALLARIZ",
              "cpobla": "32055020100",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "OURENSE",
              "cpostal": "32112"
          },
          {
              "lpobla": "A COSTA (PANTON SAN MARTIÑO)",
              "lmunic": "PANTON",
              "cpobla": "27041150300",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27419"
          },
          {
              "lpobla": "A COSTA (PONTECESO)",
              "lmunic": "PONTECESO",
              "cpobla": "15068040200",
              "codPais": "ES",
              "nHabitantes": 69,
              "lprovi": "A CORUÑA",
              "cpostal": "15114"
          },
          {
              "lpobla": "A COSTA (RAMIRAS)",
              "lmunic": "RAMIRAS",
              "cpobla": "32068050100",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "OURENSE",
              "cpostal": "32810"
          },
          {
              "lpobla": "A COSTA (RIO BARBA)",
              "lmunic": "O VICEDO",
              "cpobla": "27064040400",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27868"
          },
          {
              "lpobla": "A COSTA (SALCEDO)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038151200",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36143"
          },
          {
              "lpobla": "A COSTA (SALVATERRA DE MIÑO)",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050110300",
              "codPais": "ES",
              "nHabitantes": 45,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36457"
          },
          {
              "lpobla": "A COSTA (SAN ROMAN DE VALE)",
              "lmunic": "O VICEDO",
              "cpobla": "27064060300",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27861"
          },
          {
              "lpobla": "A COSTA (SAN SADURNIÑO)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076020600",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "A CORUÑA",
              "cpostal": "15598"
          },
          {
              "lpobla": "A COSTA (SANTIAGO)",
              "lmunic": "MACEDA",
              "cpobla": "32043040000",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "OURENSE",
              "cpostal": "32707"
          },
          {
              "lpobla": "A COSTA (TOMIÑO)",
              "lmunic": "TOMIÑO",
              "cpobla": "36054140400",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36740"
          },
          {
              "lpobla": "A COSTA (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087061300",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "A CORUÑA",
              "cpostal": "15550"
          },
          {
              "lpobla": "A COSTA (VIASCON)",
              "lmunic": "COTOBADE",
              "cpobla": "36012130600",
              "codPais": "ES",
              "nHabitantes": 51,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36121"
          },
          {
              "lpobla": "A COSTA (VIEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066101000",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27869"
          },
          {
              "lpobla": "A COSTA (VILA DE CRUCES)",
              "lmunic": "VILA DE CRUCES",
              "cpobla": "36059010300",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36585"
          },
          {
              "lpobla": "A COSTA (VIMIANZO)",
              "lmunic": "VIMIANZO",
              "cpobla": "15092101000",
              "codPais": "ES",
              "nHabitantes": 57,
              "lprovi": "A CORUÑA",
              "cpostal": "15126"
          },
          {
              "lpobla": "A COSTA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021051200",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27831"
          },
          {
              "lpobla": "A COSTA (ZAS)",
              "lmunic": "ZAS",
              "cpobla": "15093110100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15855"
          },
          {
              "lpobla": "A COSTANEIRA",
              "lmunic": "NOIA",
              "cpobla": "15057020900",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "A CORUÑA",
              "cpostal": "15210"
          },
          {
              "lpobla": "A COSTEIRA",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022020900",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27307"
          },
          {
              "lpobla": "A COSTEIRA",
              "lmunic": "CARBALLEDA DE AVIA",
              "cpobla": "32018040200",
              "codPais": "ES",
              "nHabitantes": 56,
              "lprovi": "OURENSE",
              "cpostal": "32412"
          },
          {
              "lpobla": "A COSTEIRA (CANGAS)",
              "lmunic": "CANGAS",
              "cpobla": "36008030500",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36947"
          },
          {
              "lpobla": "A COSTEIRA (O PORRIÑO)",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039050500",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36413"
          },
          {
              "lpobla": "A COSTEIRA (REDONDELA)",
              "lmunic": "REDONDELA",
              "cpobla": "36045060100",
              "codPais": "ES",
              "nHabitantes": 297,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36817"
          },
          {
              "lpobla": "A COSTEIRA (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087071600",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "A CORUÑA",
              "cpostal": "15552"
          },
          {
              "lpobla": "A COSTENLA (GOIANS)",
              "lmunic": "CARBALLO",
              "cpobla": "15019090200",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "A CORUÑA",
              "cpostal": "15106"
          },
          {
              "lpobla": "A COSTIÑA",
              "lmunic": "ALFOZ",
              "cpobla": "27002020400",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27776"
          },
          {
              "lpobla": "A COSTIÑA (BUEU)",
              "lmunic": "BUEU",
              "cpobla": "36004040700",
              "codPais": "ES",
              "nHabitantes": 65,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36938"
          },
          {
              "lpobla": "A COSTIÑA (OUTES)",
              "lmunic": "OUTES",
              "cpobla": "15062020700",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15237"
          },
          {
              "lpobla": "A COSTOIRA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061030800",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15339"
          },
          {
              "lpobla": "A COSTRELA",
              "lmunic": "PARADA DE SIL",
              "cpobla": "32057080300",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "OURENSE",
              "cpostal": "32748"
          },
          {
              "lpobla": "A COUBOEIRA (SANTA MARIA MADANELA)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030020000",
              "codPais": "ES",
              "nHabitantes": 88,
              "lprovi": "LUGO",
              "cpostal": "27749"
          },
          {
              "lpobla": "A COUTADA (COTOBADE)",
              "lmunic": "COTOBADE",
              "cpobla": "36012010800",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36854"
          },
          {
              "lpobla": "A COUTADA (PONTEAREAS)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042080400",
              "codPais": "ES",
              "nHabitantes": 73,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36893"
          },
          {
              "lpobla": "A COUZADA",
              "lmunic": "MACEDA",
              "cpobla": "32043040200",
              "codPais": "ES",
              "nHabitantes": 35,
              "lprovi": "OURENSE",
              "cpostal": "32707"
          },
          {
              "lpobla": "A COVA (A ESTRADA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017130700",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36584"
          },
          {
              "lpobla": "A COVA (A PONTENOVA)",
              "lmunic": "A PONTENOVA",
              "cpobla": "27048030200",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "LUGO",
              "cpostal": "27727"
          },
          {
              "lpobla": "A COVA (CASTRO DE REI)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010250500",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "LUGO",
              "cpostal": "27259"
          },
          {
              "lpobla": "A COVA (CUNTIS)",
              "lmunic": "CUNTIS",
              "cpobla": "36015080200",
              "codPais": "ES",
              "nHabitantes": 68,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36675"
          },
          {
              "lpobla": "A COVA (MONFORTE DE LEMOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031130800",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27592"
          },
          {
              "lpobla": "A COVA (NIGRAN)",
              "lmunic": "NIGRAN",
              "cpobla": "36035060400",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36391"
          },
          {
              "lpobla": "A COVA (O PARAMO)",
              "lmunic": "O PARAMO",
              "cpobla": "27043120400",
              "codPais": "ES",
              "nHabitantes": 34,
              "lprovi": "LUGO",
              "cpostal": "27369"
          },
          {
              "lpobla": "A COVA (O VICEDO)",
              "lmunic": "O VICEDO",
              "cpobla": "27064040500",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27868"
          },
          {
              "lpobla": "A COVA (OLEIROS)",
              "lmunic": "OLEIROS",
              "cpobla": "15058070400",
              "codPais": "ES",
              "nHabitantes": 143,
              "lprovi": "A CORUÑA",
              "cpostal": "15173"
          },
          {
              "lpobla": "A COVA (SAN MARTIÑO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058030000",
              "codPais": "ES",
              "nHabitantes": 88,
              "lprovi": "LUGO",
              "cpostal": "27548"
          },
          {
              "lpobla": "A COVA (SAN XOAN)",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009120000",
              "codPais": "ES",
              "nHabitantes": 60,
              "lprovi": "LUGO",
              "cpostal": "27532"
          },
          {
              "lpobla": "A COVA (SANTA COMBA)",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077020500",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15845"
          },
          {
              "lpobla": "A COVA (SANTIAGO DE COMPOSTELA)",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078130200",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "A CORUÑA",
              "cpostal": "15898"
          },
          {
              "lpobla": "A COVADA",
              "lmunic": "OLEIROS",
              "cpobla": "15058070500",
              "codPais": "ES",
              "nHabitantes": 58,
              "lprovi": "A CORUÑA",
              "cpostal": "15173"
          },
          {
              "lpobla": "A COVADELA (PORTOMARIN)",
              "lmunic": "PORTOMARIN",
              "cpobla": "27049040200",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27213"
          },
          {
              "lpobla": "A COVARIZA",
              "lmunic": "FRIOL",
              "cpobla": "27020280600",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27228"
          },
          {
              "lpobla": "A COVELA",
              "lmunic": "CARBALLO",
              "cpobla": "15019080700",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A COVELA (COSPEITO)",
              "lmunic": "COSPEITO",
              "cpobla": "27015190700",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27377"
          },
          {
              "lpobla": "A COVELA (FERREIRA)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040160500",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27206"
          },
          {
              "lpobla": "A COVELA (LOURENZA)",
              "lmunic": "LOURENZA",
              "cpobla": "27027040800",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "LUGO",
              "cpostal": "27751"
          },
          {
              "lpobla": "A COVELA (PORTOMARIN)",
              "lmunic": "PORTOMARIN",
              "cpobla": "27049190100",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27178"
          },
          {
              "lpobla": "A COVELA (RIBAS DE SIL)",
              "lmunic": "RIBAS DE SIL",
              "cpobla": "27052070500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27317"
          },
          {
              "lpobla": "A COVELA (ROIS)",
              "lmunic": "ROIS",
              "cpobla": "15074090500",
              "codPais": "ES",
              "nHabitantes": 63,
              "lprovi": "A CORUÑA",
              "cpostal": "15911"
          },
          {
              "lpobla": "A COVIÑA (OUTES)",
              "lmunic": "OUTES",
              "cpobla": "15062081800",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15288"
          },
          {
              "lpobla": "A COVIÑA (PORTO DO SON)",
              "lmunic": "PORTO DO SON",
              "cpobla": "15071041000",
              "codPais": "ES",
              "nHabitantes": 66,
              "lprovi": "A CORUÑA",
              "cpostal": "15995"
          },
          {
              "lpobla": "A COVIÑA (RIANXO)",
              "lmunic": "RIANXO",
              "cpobla": "15072062500",
              "codPais": "ES",
              "nHabitantes": 41,
              "lprovi": "A CORUÑA",
              "cpostal": "15985"
          },
          {
              "lpobla": "A CRIBA",
              "lmunic": "XERMADE",
              "cpobla": "27021091400",
              "codPais": "ES",
              "nHabitantes": 41,
              "lprovi": "LUGO",
              "cpostal": "27835"
          },
          {
              "lpobla": "A CRUCITARIA",
              "lmunic": "VILALBA",
              "cpobla": "27065031000",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27814"
          },
          {
              "lpobla": "A CRUS (ARZUA)",
              "lmunic": "ARZUA",
              "cpobla": "15006130300",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "A CORUÑA",
              "cpostal": "15819"
          },
          {
              "lpobla": "A CRUXEIRA (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087080900",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15543"
          },
          {
              "lpobla": "A CRUZ (A ESTRADA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017210500",
              "codPais": "ES",
              "nHabitantes": 48,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36681"
          },
          {
              "lpobla": "A CRUZ (A TEIXEIRA)",
              "lmunic": "A TEIXEIRA",
              "cpobla": "32080050300",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "OURENSE",
              "cpostal": "32764"
          },
          {
              "lpobla": "A CRUZ (ABUIME)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058010200",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27546"
          },
          {
              "lpobla": "A CRUZ (ALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065010800",
              "codPais": "ES",
              "nHabitantes": 60,
              "lprovi": "LUGO",
              "cpostal": "27813"
          },
          {
              "lpobla": "A CRUZ (ARCEDIAGO)",
              "lmunic": "SANTISO",
              "cpobla": "15079010200",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "A CORUÑA",
              "cpostal": "15808"
          },
          {
              "lpobla": "A CRUZ (AREAS)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042030300",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36861"
          },
          {
              "lpobla": "A CRUZ (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005070300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27794"
          },
          {
              "lpobla": "A CRUZ (BEGONTE)",
              "lmunic": "BEGONTE",
              "cpobla": "27007140100",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "LUGO",
              "cpostal": "27373"
          },
          {
              "lpobla": "A CRUZ (CARBALLIDO SAN SEBASTIAN)",
              "lmunic": "ALFOZ",
              "cpobla": "27002030500",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "LUGO",
              "cpostal": "27776"
          },
          {
              "lpobla": "A CRUZ (CARBALLIDO SANTA MARIA)",
              "lmunic": "VILALBA",
              "cpobla": "27065050800",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27843"
          },
          {
              "lpobla": "A CRUZ (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019171900",
              "codPais": "ES",
              "nHabitantes": 64,
              "lprovi": "A CORUÑA",
              "cpostal": "15108"
          },
          {
              "lpobla": "A CRUZ (CASTRO DE REI)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010230500",
              "codPais": "ES",
              "nHabitantes": 35,
              "lprovi": "LUGO",
              "cpostal": "27258"
          },
          {
              "lpobla": "A CRUZ (CHANTADA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016020200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27513"
          },
          {
              "lpobla": "A CRUZ (CHAPA)",
              "lmunic": "SILLEDA",
              "cpobla": "36052090200",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36570"
          },
          {
              "lpobla": "A CRUZ (CHAVE)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058040300",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27544"
          },
          {
              "lpobla": "A CRUZ (CIRA)",
              "lmunic": "SILLEDA",
              "cpobla": "36052070300",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36587"
          },
          {
              "lpobla": "A CRUZ (COSPEITO)",
              "lmunic": "COSPEITO",
              "cpobla": "27015160200",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "LUGO",
              "cpostal": "27379"
          },
          {
              "lpobla": "A CRUZ (CUNTIS)",
              "lmunic": "CUNTIS",
              "cpobla": "36015020500",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36678"
          },
          {
              "lpobla": "A CRUZ DA CARREIRA",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030060200",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "LUGO",
              "cpostal": "27742"
          },
          {
              "lpobla": "A CRUZ DA MOA",
              "lmunic": "A CAPELA",
              "cpobla": "15018044700",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A CRUZ DE OUTEIRO",
              "lmunic": "QUIROGA",
              "cpobla": "27050120100",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27328"
          },
          {
              "lpobla": "A CRUZ DE RANTE",
              "lmunic": "SAN CIBRAO DAS VIÑAS",
              "cpobla": "32075050700",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "OURENSE",
              "cpostal": "32910"
          },
          {
              "lpobla": "A CRUZ DE SANTOS",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077160200",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "A CORUÑA",
              "cpostal": "15861"
          },
          {
              "lpobla": "A CRUZ DO CABILDO",
              "lmunic": "PONTEDEUME",
              "cpobla": "15069050800",
              "codPais": "ES",
              "nHabitantes": 118,
              "lprovi": "A CORUÑA",
              "cpostal": "15609"
          },
          {
              "lpobla": "A CRUZ DO COTO",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061072200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15332"
          },
          {
              "lpobla": "A CRUZ DO INCIO",
              "lmunic": "O INCIO",
              "cpobla": "27024110100",
              "codPais": "ES",
              "nHabitantes": 214,
              "lprovi": "LUGO",
              "cpostal": "27346"
          },
          {
              "lpobla": "A CRUZ DO LOBO",
              "lmunic": "BARREIROS",
              "cpobla": "27005011100",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27790"
          },
          {
              "lpobla": "A CRUZ DOS CAMPOS",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022102700",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27372"
          },
          {
              "lpobla": "A CRUZ (GONDOMAR)",
              "lmunic": "GONDOMAR",
              "cpobla": "36021060500",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36388"
          },
          {
              "lpobla": "A CRUZ (LAGOA)",
              "lmunic": "ALFOZ",
              "cpobla": "27002051300",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "LUGO",
              "cpostal": "27774"
          },
          {
              "lpobla": "A CRUZ (MOECHE)",
              "lmunic": "MOECHE",
              "cpobla": "15049022600",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15564"
          },
          {
              "lpobla": "A CRUZ (NIGRAN)",
              "lmunic": "NIGRAN",
              "cpobla": "36035010500",
              "codPais": "ES",
              "nHabitantes": 155,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36360"
          },
          {
              "lpobla": "A CRUZ (O PORRIÑO)",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039020500",
              "codPais": "ES",
              "nHabitantes": 157,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36475"
          },
          {
              "lpobla": "A CRUZ (O VALADOURO)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063101100",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27778"
          },
          {
              "lpobla": "A CRUZ (PORTO DO SON)",
              "lmunic": "PORTO DO SON",
              "cpobla": "15071020500",
              "codPais": "ES",
              "nHabitantes": 56,
              "lprovi": "A CORUÑA",
              "cpostal": "15996"
          },
          {
              "lpobla": "A CRUZ (PORTOMARIN)",
              "lmunic": "PORTOMARIN",
              "cpobla": "27049170100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27214"
          },
          {
              "lpobla": "A CRUZ (RIANXO)",
              "lmunic": "RIANXO",
              "cpobla": "15072060700",
              "codPais": "ES",
              "nHabitantes": 49,
              "lprovi": "A CORUÑA",
              "cpostal": "15985"
          },
          {
              "lpobla": "A CRUZ (RIBADEO)",
              "lmunic": "RIBADEO",
              "cpobla": "27051120500",
              "codPais": "ES",
              "nHabitantes": 61,
              "lprovi": "LUGO",
              "cpostal": "27710"
          },
          {
              "lpobla": "A CRUZ (RIOTORTO)",
              "lmunic": "RIOTORTO",
              "cpobla": "27054020200",
              "codPais": "ES",
              "nHabitantes": 59,
              "lprovi": "LUGO",
              "cpostal": "27744"
          },
          {
              "lpobla": "A CRUZ (SALVATERRA DE MIÑO)",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050060500",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36455"
          },
          {
              "lpobla": "A CRUZ (SAN AMARO)",
              "lmunic": "SAN AMARO",
              "cpobla": "32074010400",
              "codPais": "ES",
              "nHabitantes": 50,
              "lprovi": "OURENSE",
              "cpostal": "32455"
          },
          {
              "lpobla": "A CRUZ (SAN XOAN DE RIO)",
              "lmunic": "SAN XOAN DE RIO",
              "cpobla": "32070090300",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "OURENSE",
              "cpostal": "32779"
          },
          {
              "lpobla": "A CRUZ (TABOADA)",
              "lmunic": "TABOADA",
              "cpobla": "27060130400",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27555"
          },
          {
              "lpobla": "A CRUZ (VEIGA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061262500",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15367"
          },
          {
              "lpobla": "A CRUZ VELLA",
              "lmunic": "XERMADE",
              "cpobla": "27021070900",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27826"
          },
          {
              "lpobla": "A CRUZ (VILAGARCIA DE AROUSA)",
              "lmunic": "VILAGARCIA DE AROUSA",
              "cpobla": "36060050300",
              "codPais": "ES",
              "nHabitantes": 181,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36619"
          },
          {
              "lpobla": "A CRUZADA",
              "lmunic": "POL",
              "cpobla": "27046030500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27270"
          },
          {
              "lpobla": "A CRUZANA",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077010600",
              "codPais": "ES",
              "nHabitantes": 34,
              "lprovi": "A CORUÑA",
              "cpostal": "15846"
          },
          {
              "lpobla": "A CRUZ-BENUNES",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039020600",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36475"
          },
          {
              "lpobla": "A CRUZ-ROZADAS",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039020700",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36475"
          },
          {
              "lpobla": "A CUADA",
              "lmunic": "OZA DOS RIOS",
              "cpobla": "15063090600",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "A CORUÑA",
              "cpostal": "15387"
          },
          {
              "lpobla": "A CUBA",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030010200",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27748"
          },
          {
              "lpobla": "A CUBELA (OROSA)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040280500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27204"
          },
          {
              "lpobla": "A CUBETA",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087040400",
              "codPais": "ES",
              "nHabitantes": 35,
              "lprovi": "A CORUÑA",
              "cpostal": "15550"
          },
          {
              "lpobla": "A CUCA (TRAZO)",
              "lmunic": "TRAZO",
              "cpobla": "15086070100",
              "codPais": "ES",
              "nHabitantes": 87,
              "lprovi": "A CORUÑA",
              "cpostal": "15687"
          },
          {
              "lpobla": "A CUIÑA (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022060500",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "LUGO",
              "cpostal": "27308"
          },
          {
              "lpobla": "A CUMIEIRA (O ROSAL)",
              "lmunic": "O ROSAL",
              "cpobla": "36048030500",
              "codPais": "ES",
              "nHabitantes": 151,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36760"
          },
          {
              "lpobla": "A CUQUEIRA",
              "lmunic": "OURENSE",
              "cpobla": "32054013000",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "OURENSE",
              "cpostal": "32990"
          },
          {
              "lpobla": "A CUQUEIRA (CARBALLEDO)",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009230200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27528"
          },
          {
              "lpobla": "A CUQUEIRA (CHANTADA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016080300",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27519"
          },
          {
              "lpobla": "A CUQUEIRA (COTOBADE)",
              "lmunic": "COTOBADE",
              "cpobla": "36012040300",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36856"
          },
          {
              "lpobla": "A CURISCADA (MURAS)",
              "lmunic": "MURAS",
              "cpobla": "27033052500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A CURRADA (LOURENZA)",
              "lmunic": "LOURENZA",
              "cpobla": "27027020800",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27751"
          },
          {
              "lpobla": "A CURRADA (RIBADEO)",
              "lmunic": "RIBADEO",
              "cpobla": "27051020200",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "LUGO",
              "cpostal": "27711"
          },
          {
              "lpobla": "A CURREGA DE BAIXO",
              "lmunic": "LOURENZA",
              "cpobla": "27027010400",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27750"
          },
          {
              "lpobla": "A CURREGA DE RIBA",
              "lmunic": "LOURENZA",
              "cpobla": "27027010500",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27750"
          },
          {
              "lpobla": "A CURUXEIRA (SANTIAGO DE COMPOSTELA)",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078080300",
              "codPais": "ES",
              "nHabitantes": 101,
              "lprovi": "A CORUÑA",
              "cpostal": "15899"
          },
          {
              "lpobla": "A DECOLADA",
              "lmunic": "CORTEGADA",
              "cpobla": "32027010200",
              "codPais": "ES",
              "nHabitantes": 37,
              "lprovi": "OURENSE",
              "cpostal": "32213"
          },
          {
              "lpobla": "A DEGOLADA (SAN LOURENZO)",
              "lmunic": "BALEIRA",
              "cpobla": "27004040000",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27133"
          },
          {
              "lpobla": "A DEGRADA",
              "lmunic": "CERVANTES",
              "cpobla": "27012050900",
              "codPais": "ES",
              "nHabitantes": 40,
              "lprovi": "LUGO",
              "cpostal": "27666"
          },
          {
              "lpobla": "A DERRAMADA",
              "lmunic": "PIÑOR",
              "cpobla": "32061030500",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "OURENSE",
              "cpostal": "32138"
          },
          {
              "lpobla": "A DERRASA",
              "lmunic": "O PEREIRO DE AGUIAR",
              "cpobla": "32058060200",
              "codPais": "ES",
              "nHabitantes": 167,
              "lprovi": "OURENSE",
              "cpostal": "32792"
          },
          {
              "lpobla": "A DEVESA (AGUAS SANTAS)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040011200",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27205"
          },
          {
              "lpobla": "A DEVESA (ALBA)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038010100",
              "codPais": "ES",
              "nHabitantes": 263,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36157"
          },
          {
              "lpobla": "A DEVESA (ANAFREITA)",
              "lmunic": "FRIOL",
              "cpobla": "27020010300",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A DEVESA (CANGAS)",
              "lmunic": "CANGAS",
              "cpobla": "36008030700",
              "codPais": "ES",
              "nHabitantes": 53,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36947"
          },
          {
              "lpobla": "A DEVESA (CASTRO DE REI)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010190500",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27257"
          },
          {
              "lpobla": "A DEVESA (CHANTADA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016180300",
              "codPais": "ES",
              "nHabitantes": 41,
              "lprovi": "LUGO",
              "cpostal": "27514"
          },
          {
              "lpobla": "A DEVESA (CODESEDA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017151100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36684"
          },
          {
              "lpobla": "A DEVESA (CONDES)",
              "lmunic": "FRIOL",
              "cpobla": "27020060900",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27235"
          },
          {
              "lpobla": "A DEVESA (DODRO)",
              "lmunic": "DODRO",
              "cpobla": "15033020400",
              "codPais": "ES",
              "nHabitantes": 55,
              "lprovi": "A CORUÑA",
              "cpostal": "15982"
          },
          {
              "lpobla": "A DEVESA (GUNTIN)",
              "lmunic": "GUNTIN",
              "cpobla": "27023030200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27234"
          },
          {
              "lpobla": "A DEVESA (MARRUBE)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058120300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27547"
          },
          {
              "lpobla": "A DEVESA (MEILAN)",
              "lmunic": "LUGO",
              "cpobla": "27028291200",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "LUGO",
              "cpostal": "27296"
          },
          {
              "lpobla": "A DEVESA (MONTERROSO)",
              "lmunic": "MONTERROSO",
              "cpobla": "27032110500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27215"
          },
          {
              "lpobla": "A DEVESA (MOREIRA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017270100",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36688"
          },
          {
              "lpobla": "A DEVESA (MOSENDE)",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039050600",
              "codPais": "ES",
              "nHabitantes": 43,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36413"
          },
          {
              "lpobla": "A DEVESA NOVA",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040070200",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27208"
          },
          {
              "lpobla": "A DEVESA (PIÑOR)",
              "lmunic": "PIÑOR",
              "cpobla": "32061040400",
              "codPais": "ES",
              "nHabitantes": 41,
              "lprovi": "OURENSE",
              "cpostal": "32138"
          },
          {
              "lpobla": "A DEVESA (PORTO DO SON)",
              "lmunic": "PORTO DO SON",
              "cpobla": "15071090100",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "A CORUÑA",
              "cpostal": "15998"
          },
          {
              "lpobla": "A DEVESA (PRADO)",
              "lmunic": "FRIOL",
              "cpobla": "27020200400",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27227"
          },
          {
              "lpobla": "A DEVESA (RIANXO)",
              "lmunic": "RIANXO",
              "cpobla": "15072020500",
              "codPais": "ES",
              "nHabitantes": 96,
              "lprovi": "A CORUÑA",
              "cpostal": "15984"
          },
          {
              "lpobla": "A DEVESA (RIBAS DE MIÑO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058180200",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27594"
          },
          {
              "lpobla": "A DEVESA (RIBAS DE SIL)",
              "lmunic": "RIBAS DE SIL",
              "cpobla": "27052050700",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27310"
          },
          {
              "lpobla": "A DEVESA (SANTALLA RIBADEO)",
              "lmunic": "RIBADEO",
              "cpobla": "27051050000",
              "codPais": "ES",
              "nHabitantes": 666,
              "lprovi": "LUGO",
              "cpostal": "27796"
          },
          {
              "lpobla": "A DEVESA (SANTIAGO DE COMPOSTELA)",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078010400",
              "codPais": "ES",
              "nHabitantes": 227,
              "lprovi": "A CORUÑA",
              "cpostal": "15892"
          },
          {
              "lpobla": "A DEVESA (SARRIA)",
              "lmunic": "SARRIA",
              "cpobla": "27057030300",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27616"
          },
          {
              "lpobla": "A DEVESA (SOBER)",
              "lmunic": "SOBER",
              "cpobla": "27059160900",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27468"
          },
          {
              "lpobla": "A DEVESA (SOUTOMAIOR)",
              "lmunic": "SOUTOMAIOR",
              "cpobla": "36053010300",
              "codPais": "ES",
              "nHabitantes": 525,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36690"
          },
          {
              "lpobla": "A DEVESA (VALGA)",
              "lmunic": "VALGA",
              "cpobla": "36056010200",
              "codPais": "ES",
              "nHabitantes": 429,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36647"
          },
          {
              "lpobla": "A DEVESA (VIMIANZO)",
              "lmunic": "VIMIANZO",
              "cpobla": "15092070400",
              "codPais": "ES",
              "nHabitantes": 67,
              "lprovi": "A CORUÑA",
              "cpostal": "15121"
          },
          {
              "lpobla": "A DEVESA (ZAS)",
              "lmunic": "ZAS",
              "cpobla": "15093060400",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15856"
          },
          {
              "lpobla": "A DEVESIÑA",
              "lmunic": "TRAZO",
              "cpobla": "15086050400",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "A CORUÑA",
              "cpostal": "15687"
          },
          {
              "lpobla": "A DICOITA",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050080900",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36862"
          },
          {
              "lpobla": "A DOBREIXA (MERZA)",
              "lmunic": "VILA DE CRUCES",
              "cpobla": "36059200100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36580"
          },
          {
              "lpobla": "A DONA",
              "lmunic": "VILAGARCIA DE AROUSA",
              "cpobla": "36060020500",
              "codPais": "ES",
              "nHabitantes": 105,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36618"
          },
          {
              "lpobla": "A DORNA (AS NOGAIS)",
              "lmunic": "AS NOGAIS",
              "cpobla": "27037030300",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27674"
          },
          {
              "lpobla": "A DORNA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061072500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "A CORUÑA",
              "cpostal": "15332"
          },
          {
              "lpobla": "A DUCA",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042180100",
              "codPais": "ES",
              "nHabitantes": 47,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36864"
          },
          {
              "lpobla": "A EDRA (MESIA)",
              "lmunic": "MESIA",
              "cpobla": "15047DD0100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A EDRADA (SANTIAGO)",
              "lmunic": "PARADA DE SIL",
              "cpobla": "32057030000",
              "codPais": "ES",
              "nHabitantes": 40,
              "lprovi": "OURENSE",
              "cpostal": "32748"
          },
          {
              "lpobla": "A EDREIRA (MELON)",
              "lmunic": "MELON",
              "cpobla": "32046010500",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "OURENSE",
              "cpostal": "32410"
          },
          {
              "lpobla": "A EIRA PEDRIÑA",
              "lmunic": "REDONDELA",
              "cpobla": "36045020300",
              "codPais": "ES",
              "nHabitantes": 225,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36812"
          },
          {
              "lpobla": "A EIREXA (ALAIS)",
              "lmunic": "CASTRO CALDELAS",
              "cpobla": "32023010500",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "OURENSE",
              "cpostal": "32766"
          },
          {
              "lpobla": "A EIREXA (AUGASANTAS)",
              "lmunic": "ROIS",
              "cpobla": "15074010800",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "A CORUÑA",
              "cpostal": "15913"
          },
          {
              "lpobla": "A EIREXA (CAMBOÑO)",
              "lmunic": "LOUSAME",
              "cpobla": "15042DD0100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15214"
          },
          {
              "lpobla": "A EIREXA (CANEDA)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031030300",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27415"
          },
          {
              "lpobla": "A EIREXA (CANEDO)",
              "lmunic": "OURENSE",
              "cpobla": "32054220600",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "OURENSE",
              "cpostal": "32001"
          },
          {
              "lpobla": "A EIREXA (CORTEGADA)",
              "lmunic": "CORTEGADA",
              "cpobla": "32027050200",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "OURENSE",
              "cpostal": "32213"
          },
          {
              "lpobla": "A EIREXA (GALEGOS)",
              "lmunic": "NAVIA DE SUARNA",
              "cpobla": "27034060200",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27657"
          },
          {
              "lpobla": "A EIREXA (GRANDAL)",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091021500",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "A CORUÑA",
              "cpostal": "15616"
          },
          {
              "lpobla": "A EIREXA (LEROÑO)",
              "lmunic": "ROIS",
              "cpobla": "15074060400",
              "codPais": "ES",
              "nHabitantes": 32,
              "lprovi": "A CORUÑA",
              "cpostal": "15912"
          },
          {
              "lpobla": "A EIREXA (MACEDA SAN PEDRO)",
              "lmunic": "MACEDA",
              "cpobla": "32043070400",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "OURENSE",
              "cpostal": "32703"
          },
          {
              "lpobla": "A EIREXA (MAZAIRA)",
              "lmunic": "CASTRO CALDELAS",
              "cpobla": "32023060300",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "OURENSE",
              "cpostal": "32766"
          },
          {
              "lpobla": "A EIREXA (O IRIXO)",
              "lmunic": "O IRIXO",
              "cpobla": "32035051100",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "OURENSE",
              "cpostal": "32530"
          },
          {
              "lpobla": "A EIREXA (OBE)",
              "lmunic": "RIBADEO",
              "cpobla": "27051061400",
              "codPais": "ES",
              "nHabitantes": 41,
              "lprovi": "LUGO",
              "cpostal": "27713"
          },
          {
              "lpobla": "A EIREXA (OIN)",
              "lmunic": "ROIS",
              "cpobla": "15074070400",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "A CORUÑA",
              "cpostal": "15911"
          },
          {
              "lpobla": "A EIREXA (PIÑEIRA)",
              "lmunic": "RIBADEO",
              "cpobla": "27051070500",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "LUGO",
              "cpostal": "27710"
          },
          {
              "lpobla": "A EIREXA (PONTEVEIGA)",
              "lmunic": "O CARBALLIÑO",
              "cpobla": "32019130500",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "OURENSE",
              "cpostal": "32574"
          },
          {
              "lpobla": "A EIREXA (RABEDA)",
              "lmunic": "SAN CIBRAO DAS VIÑAS",
              "cpobla": "32075040400",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "OURENSE",
              "cpostal": "32901"
          },
          {
              "lpobla": "A EIREXA (READEGOS)",
              "lmunic": "VILAMARIN",
              "cpobla": "32087040600",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "OURENSE",
              "cpostal": "32102"
          },
          {
              "lpobla": "A EIREXA (RIBEIRA)",
              "lmunic": "RIBEIRA",
              "cpobla": "15073070905",
              "codPais": "ES",
              "nHabitantes": 284,
              "lprovi": "A CORUÑA",
              "cpostal": "15969"
          },
          {
              "lpobla": "A EIREXA (RIOS)",
              "lmunic": "RIOS",
              "cpobla": "32071070300",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "OURENSE",
              "cpostal": "32610"
          },
          {
              "lpobla": "A EIREXA (RIOTORTO)",
              "lmunic": "RIOTORTO",
              "cpobla": "27054070300",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27744"
          },
          {
              "lpobla": "A EIREXA (SEIRA)",
              "lmunic": "ROIS",
              "cpobla": "15074100300",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "A CORUÑA",
              "cpostal": "15911"
          },
          {
              "lpobla": "A EIREXA (SIXTIN)",
              "lmunic": "A TEIXEIRA",
              "cpobla": "32080080300",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "OURENSE",
              "cpostal": "32765"
          },
          {
              "lpobla": "A EIREXA (TABOADELA)",
              "lmunic": "TABOADELA",
              "cpobla": "32079070100",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "OURENSE",
              "cpostal": "32690"
          },
          {
              "lpobla": "A EIREXA (TALLARA)",
              "lmunic": "LOUSAME",
              "cpobla": "15042050700",
              "codPais": "ES",
              "nHabitantes": 88,
              "lprovi": "A CORUÑA",
              "cpostal": "15216"
          },
          {
              "lpobla": "A EIREXA (TAMALLANCOS)",
              "lmunic": "VILAMARIN",
              "cpobla": "32087070200",
              "codPais": "ES",
              "nHabitantes": 33,
              "lprovi": "OURENSE",
              "cpostal": "32102"
          },
          {
              "lpobla": "A EIREXA (TIOIRA)",
              "lmunic": "MACEDA",
              "cpobla": "32043100400",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "OURENSE",
              "cpostal": "32707"
          },
          {
              "lpobla": "A EIREXA (TOEN)",
              "lmunic": "TOEN",
              "cpobla": "32081050400",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "OURENSE",
              "cpostal": "32940"
          },
          {
              "lpobla": "A EIREXA (VILAR DE BARRIO)",
              "lmunic": "VILAR DE BARRIO",
              "cpobla": "32089020103",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "OURENSE",
              "cpostal": "32705"
          },
          {
              "lpobla": "A EIREXA (VILASELAN)",
              "lmunic": "RIBADEO",
              "cpobla": "27051120700",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "LUGO",
              "cpostal": "27710"
          },
          {
              "lpobla": "A EIREXE (AGUADA)",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009010300",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27529"
          },
          {
              "lpobla": "A EIREXE (ALTO)",
              "lmunic": "O CORGO",
              "cpobla": "27014030400",
              "codPais": "ES",
              "nHabitantes": 32,
              "lprovi": "LUGO",
              "cpostal": "27164"
          },
          {
              "lpobla": "A EIREXE (ANTAS DE ULLA)",
              "lmunic": "ANTAS DE ULLA",
              "cpobla": "27003190100",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27579"
          },
          {
              "lpobla": "A EIREXE (ASMA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016080500",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27519"
          },
          {
              "lpobla": "A EIREXE (BEGONTE)",
              "lmunic": "BEGONTE",
              "cpobla": "27007100500",
              "codPais": "ES",
              "nHabitantes": 50,
              "lprovi": "LUGO",
              "cpostal": "27375"
          },
          {
              "lpobla": "A EIREXE (CABANA)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040050100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27203"
          },
          {
              "lpobla": "A EIREXE (CABORRECELLE)",
              "lmunic": "PORTOMARIN",
              "cpobla": "27049030300",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27177"
          },
          {
              "lpobla": "A EIREXE (CASTRO DE CASTRO)",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009100400",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27530"
          },
          {
              "lpobla": "A EIREXE (CEDRON)",
              "lmunic": "LANCARA",
              "cpobla": "27026040200",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27692"
          },
          {
              "lpobla": "A EIREXE (CORTAPEZAS)",
              "lmunic": "PORTOMARIN",
              "cpobla": "27049060300",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27188"
          },
          {
              "lpobla": "A EIREXE (ENTRAMBASAGUAS)",
              "lmunic": "GUNTIN",
              "cpobla": "27023030300",
              "codPais": "ES",
              "nHabitantes": 37,
              "lprovi": "LUGO",
              "cpostal": "27234"
          },
          {
              "lpobla": "A EIREXE (GULLADE)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031080300",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "LUGO",
              "cpostal": "27416"
          },
          {
              "lpobla": "A EIREXE (MERLAN)",
              "lmunic": "CHANTADA",
              "cpobla": "27016210100",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27517"
          },
          {
              "lpobla": "A EIREXE (NARLA)",
              "lmunic": "FRIOL",
              "cpobla": "27020160400",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27226"
          },
          {
              "lpobla": "A EIREXE (PARAMO)",
              "lmunic": "CASTROVERDE",
              "cpobla": "27011230200",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27166"
          },
          {
              "lpobla": "A EIREXE (PIÑOR)",
              "lmunic": "PIÑOR",
              "cpobla": "32061070400",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "OURENSE",
              "cpostal": "32138"
          },
          {
              "lpobla": "A EIREXE (SAN BREIXO)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022120800",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "LUGO",
              "cpostal": "27388"
          },
          {
              "lpobla": "A EIREXE (SAN MARTIÑO)",
              "lmunic": "BARALLA",
              "cpobla": "27901130100",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27696"
          },
          {
              "lpobla": "A EIREXE (SILVELA)",
              "lmunic": "FRIOL",
              "cpobla": "27020280700",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27228"
          },
          {
              "lpobla": "A EIREXE (URIZ)",
              "lmunic": "CASTROVERDE",
              "cpobla": "27011340100",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27125"
          },
          {
              "lpobla": "A EIREXE (VERDIA)",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078280100",
              "codPais": "ES",
              "nHabitantes": 46,
              "lprovi": "A CORUÑA",
              "cpostal": "15884"
          },
          {
              "lpobla": "A EIREXE (VILARAGUNTE)",
              "lmunic": "PARADELA",
              "cpobla": "27042180400",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27611"
          },
          {
              "lpobla": "A EIREXE (VILAXUSTE)",
              "lmunic": "PORTOMARIN",
              "cpobla": "27049200400",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27177"
          },
          {
              "lpobla": "A EIREXE (XIA)",
              "lmunic": "FRIOL",
              "cpobla": "27020321300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27227"
          },
          {
              "lpobla": "A EIREXIÑA",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009060100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27529"
          },
          {
              "lpobla": "A EIRIXA (CORUXOU)",
              "lmunic": "IRIXOA",
              "cpobla": "15039020400",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "A CORUÑA",
              "cpostal": "15313"
          },
          {
              "lpobla": "A EIRIZ (O PORRIÑO)",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039021100",
              "codPais": "ES",
              "nHabitantes": 116,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36475"
          },
          {
              "lpobla": "A EIXAVEDRA",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010140200",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27271"
          },
          {
              "lpobla": "A ELFE",
              "lmunic": "CHANTADA",
              "cpobla": "27016030400",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27518"
          },
          {
              "lpobla": "A ENCIÑEIRA (SANTA ISABEL)",
              "lmunic": "QUIROGA",
              "cpobla": "27050060000",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27390"
          },
          {
              "lpobla": "A ENCOMENDA (SANTO ANTONIO)",
              "lmunic": "A POBRA DE TRIVES",
              "cpobla": "32063050000",
              "codPais": "ES",
              "nHabitantes": 133,
              "lprovi": "OURENSE",
              "cpostal": "32789"
          },
          {
              "lpobla": "A ENCOUTADA",
              "lmunic": "CORTEGADA",
              "cpobla": "32027060300",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "OURENSE",
              "cpostal": "32211"
          },
          {
              "lpobla": "A ENCRUCELADA",
              "lmunic": "O VICEDO",
              "cpobla": "27064050200",
              "codPais": "ES",
              "nHabitantes": 47,
              "lprovi": "LUGO",
              "cpostal": "27861"
          },
          {
              "lpobla": "A ENCRUCILLADA (MONFORTE DE LEMOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031130900",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27592"
          },
          {
              "lpobla": "A ENFERMERIA",
              "lmunic": "MEIRA",
              "cpobla": "27029010600",
              "codPais": "ES",
              "nHabitantes": 71,
              "lprovi": "LUGO",
              "cpostal": "27240"
          },
          {
              "lpobla": "A ENFESTA (RAMIRAS)",
              "lmunic": "RAMIRAS",
              "cpobla": "32068100800",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "OURENSE",
              "cpostal": "32810"
          },
          {
              "lpobla": "A ENFESTA (SAN CRISTOVO)",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078100000",
              "codPais": "ES",
              "nHabitantes": 793,
              "lprovi": "A CORUÑA",
              "cpostal": "15890"
          },
          {
              "lpobla": "A ENFESTELA",
              "lmunic": "ALLARIZ",
              "cpobla": "32001060300",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "OURENSE",
              "cpostal": "32669"
          },
          {
              "lpobla": "A ENFONXA",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009230300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27528"
          },
          {
              "lpobla": "A ENXAMEA",
              "lmunic": "PARADELA",
              "cpobla": "27042061300",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27611"
          },
          {
              "lpobla": "A ERMIDA (A PASTORIZA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044150700",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "LUGO",
              "cpostal": "27286"
          },
          {
              "lpobla": "A ERMIDA (A POBRA DE BROLLON)",
              "lmunic": "A POBRA DO BROLLON",
              "cpobla": "27047030500",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27335"
          },
          {
              "lpobla": "A ERMIDA (A PONTENOVA)",
              "lmunic": "A PONTENOVA",
              "cpobla": "27048020700",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27728"
          },
          {
              "lpobla": "A ERMIDA (BEARIZ)",
              "lmunic": "BEARIZ",
              "cpobla": "32011030200",
              "codPais": "ES",
              "nHabitantes": 103,
              "lprovi": "OURENSE",
              "cpostal": "32520"
          },
          {
              "lpobla": "A ERMIDA (BECERREA)",
              "lmunic": "BECERREA",
              "cpobla": "27006190800",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27131"
          },
          {
              "lpobla": "A ERMIDA (BEGONTE)",
              "lmunic": "BEGONTE",
              "cpobla": "27007070100",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "LUGO",
              "cpostal": "27373"
          },
          {
              "lpobla": "A ERMIDA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019172900",
              "codPais": "ES",
              "nHabitantes": 47,
              "lprovi": "A CORUÑA",
              "cpostal": "15108"
          },
          {
              "lpobla": "A ERMIDA (CASTRO DE REI)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010050500",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27289"
          },
          {
              "lpobla": "A ERMIDA (CERPONZONS)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038061300",
              "codPais": "ES",
              "nHabitantes": 49,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36152"
          },
          {
              "lpobla": "A ERMIDA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026110600",
              "codPais": "ES",
              "nHabitantes": 48,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A ERMIDA (CHANTADA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016090200",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27514"
          },
          {
              "lpobla": "A ERMIDA DE TERNANDE",
              "lmunic": "CULLEREDO",
              "cpobla": "15031040200",
              "codPais": "ES",
              "nHabitantes": 43,
              "lprovi": "A CORUÑA",
              "cpostal": "15198"
          },
          {
              "lpobla": "A ERMIDA (FOZ)",
              "lmunic": "FOZ",
              "cpobla": "27019050700",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "LUGO",
              "cpostal": "27787"
          },
          {
              "lpobla": "A ERMIDA (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022130600",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27305"
          },
          {
              "lpobla": "A ERMIDA (LANCARA)",
              "lmunic": "LANCARA",
              "cpobla": "27026230200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27367"
          },
          {
              "lpobla": "A ERMIDA (MARCON)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038110500",
              "codPais": "ES",
              "nHabitantes": 257,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36158"
          },
          {
              "lpobla": "A ERMIDA (MILLEIROS)",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009200100",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27533"
          },
          {
              "lpobla": "A ERMIDA (MONFORTE DE LEMOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031040200",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27418"
          },
          {
              "lpobla": "A ERMIDA (MONTERROSO)",
              "lmunic": "MONTERROSO",
              "cpobla": "27032100300",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27215"
          },
          {
              "lpobla": "A ERMIDA (NUESTRA SEÑORA ASUNCION)",
              "lmunic": "PAZOS DE BORBEN",
              "cpobla": "36037040000",
              "codPais": "ES",
              "nHabitantes": 105,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36841"
          },
          {
              "lpobla": "A ERMIDA (O CORGO)",
              "lmunic": "O CORGO",
              "cpobla": "27014230400",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27164"
          },
          {
              "lpobla": "A ERMIDA (O INCIO)",
              "lmunic": "O INCIO",
              "cpobla": "27024060600",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27345"
          },
          {
              "lpobla": "A ERMIDA (O IRIXO)",
              "lmunic": "O IRIXO",
              "cpobla": "32035010900",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "OURENSE",
              "cpostal": "32530"
          },
          {
              "lpobla": "A ERMIDA (O SAVIÑAO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058100300",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27548"
          },
          {
              "lpobla": "A ERMIDA (OLVEDA)",
              "lmunic": "ANTAS DE ULLA",
              "cpobla": "27003190200",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27579"
          },
          {
              "lpobla": "A ERMIDA (PALAS DE REI)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040420900",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27216"
          },
          {
              "lpobla": "A ERMIDA (RIOTORTO)",
              "lmunic": "RIOTORTO",
              "cpobla": "27054020300",
              "codPais": "ES",
              "nHabitantes": 53,
              "lprovi": "LUGO",
              "cpostal": "27744"
          },
          {
              "lpobla": "A ERMIDA (SAN SADURNIÑO)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076031500",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15580"
          },
          {
              "lpobla": "A ERMIDA (SANTA MARIA)",
              "lmunic": "QUIROGA",
              "cpobla": "27050080000",
              "codPais": "ES",
              "nHabitantes": 185,
              "lprovi": "LUGO",
              "cpostal": "27329"
          },
          {
              "lpobla": "A ERMIDA (SARRIA)",
              "lmunic": "SARRIA",
              "cpobla": "27057300400",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27613"
          },
          {
              "lpobla": "A ERMIDA (TRABADA)",
              "lmunic": "TRABADA",
              "cpobla": "27061051900",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27765"
          },
          {
              "lpobla": "A ERMIDA (VEASCOS)",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009030700",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27531"
          },
          {
              "lpobla": "A ERMIDA (VIANA DO BOLO)",
              "lmunic": "VIANA DO BOLO",
              "cpobla": "32086330100",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "OURENSE",
              "cpostal": "32555"
          },
          {
              "lpobla": "A ERMIDA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021091600",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27835"
          },
          {
              "lpobla": "A ERVELLA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061051000",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "A CORUÑA",
              "cpostal": "15339"
          },
          {
              "lpobla": "A ERVILLEGA",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044110200",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27287"
          },
          {
              "lpobla": "A ESBARRELA",
              "lmunic": "CERDEDO",
              "cpobla": "36011040700",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36558"
          },
          {
              "lpobla": "A ESCADA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061051100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15339"
          },
          {
              "lpobla": "A ESCANAREGA",
              "lmunic": "TRABADA",
              "cpobla": "27061051300",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27765"
          },
          {
              "lpobla": "A ESCANAVADA (COSPEITO)",
              "lmunic": "COSPEITO",
              "cpobla": "27015200300",
              "codPais": "ES",
              "nHabitantes": 113,
              "lprovi": "LUGO",
              "cpostal": "27377"
          },
          {
              "lpobla": "A ESCANAVADA (O VICEDO)",
              "lmunic": "O VICEDO",
              "cpobla": "27064011100",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27868"
          },
          {
              "lpobla": "A ESCARABELLEIRA (MESIA SAN CRISTOBAL)",
              "lmunic": "MESIA",
              "cpobla": "15047091000",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A ESCARABUÑA",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078210400",
              "codPais": "ES",
              "nHabitantes": 68,
              "lprovi": "A CORUÑA",
              "cpostal": "15898"
          },
          {
              "lpobla": "A ESCARAVELLA",
              "lmunic": "FRIOL",
              "cpobla": "27020260100",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27235"
          },
          {
              "lpobla": "A ESCOIRA",
              "lmunic": "VILALBA",
              "cpobla": "27065300500",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27375"
          },
          {
              "lpobla": "A ESCOLA",
              "lmunic": "O VICEDO",
              "cpobla": "27064011200",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27868"
          },
          {
              "lpobla": "A ESCOLA (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087090800",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "A CORUÑA",
              "cpostal": "15554"
          },
          {
              "lpobla": "A ESCOLEIRA (COSPEITO)",
              "lmunic": "COSPEITO",
              "cpobla": "27015160300",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27379"
          },
          {
              "lpobla": "A ESCOLEIRA (RIBAS DE SIL)",
              "lmunic": "RIBAS DE SIL",
              "cpobla": "27052050800",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27310"
          },
          {
              "lpobla": "A ESCORA",
              "lmunic": "VIVEIRO",
              "cpobla": "27066041400",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27864"
          },
          {
              "lpobla": "A ESCORRENTADA",
              "lmunic": "PORTO DO SON",
              "cpobla": "15071070800",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "A CORUÑA",
              "cpostal": "15978"
          },
          {
              "lpobla": "A ESCRITA (ANTAS DE ULLA)",
              "lmunic": "ANTAS DE ULLA",
              "cpobla": "27003190300",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27579"
          },
          {
              "lpobla": "A ESCRITA (PALAS DE REI)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040090600",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27217"
          },
          {
              "lpobla": "A ESCRITA (PORTOMARIN)",
              "lmunic": "PORTOMARIN",
              "cpobla": "27049200500",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27177"
          },
          {
              "lpobla": "A ESCRITA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021011000",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27832"
          },
          {
              "lpobla": "A ESCULCA",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038151400",
              "codPais": "ES",
              "nHabitantes": 142,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36143"
          },
          {
              "lpobla": "A ESCUSA (O PORRIÑO)",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039040700",
              "codPais": "ES",
              "nHabitantes": 53,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36414"
          },
          {
              "lpobla": "A ESCUSALLA (PONTEDEVA)",
              "lmunic": "PONTEDEVA",
              "cpobla": "32064010500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "OURENSE",
              "cpostal": "32235"
          },
          {
              "lpobla": "A ESFARRAPA",
              "lmunic": "O IRIXO",
              "cpobla": "32035010600",
              "codPais": "ES",
              "nHabitantes": 70,
              "lprovi": "OURENSE",
              "cpostal": "32530"
          },
          {
              "lpobla": "A ESFARRAPA (CEDRON)",
              "lmunic": "LANCARA",
              "cpobla": "27026041800",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27692"
          },
          {
              "lpobla": "A ESFARRAPA (CULLEREDO)",
              "lmunic": "CULLEREDO",
              "cpobla": "15031110400",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "A CORUÑA",
              "cpostal": "15199"
          },
          {
              "lpobla": "A ESFARRAPA (MONFORTE DE LEMOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031100800",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27416"
          },
          {
              "lpobla": "A ESPANADEIRA",
              "lmunic": "CARBALLO",
              "cpobla": "15019082900",
              "codPais": "ES",
              "nHabitantes": 56,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A ESPASA",
              "lmunic": "CHANDREXA DE QUEIXA",
              "cpobla": "32029060400",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "OURENSE",
              "cpostal": "32786"
          },
          {
              "lpobla": "A ESPEDREGUEIRA",
              "lmunic": "MORAÑA",
              "cpobla": "36032030400",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36668"
          },
          {
              "lpobla": "A ESPERANZA",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076051200",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "A CORUÑA",
              "cpostal": "15561"
          },
          {
              "lpobla": "A ESPERELA (MARIN)",
              "lmunic": "MARIN",
              "cpobla": "36026060400",
              "codPais": "ES",
              "nHabitantes": 57,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36914"
          },
          {
              "lpobla": "A ESPERELA (SAN PEDRO)",
              "lmunic": "BALEIRA",
              "cpobla": "27004050000",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27130"
          },
          {
              "lpobla": "A ESPERIÑA",
              "lmunic": "COTOBADE",
              "cpobla": "36012040600",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36856"
          },
          {
              "lpobla": "A ESPIÑA (BALEIRA)",
              "lmunic": "BALEIRA",
              "cpobla": "27004030700",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27278"
          },
          {
              "lpobla": "A ESPIÑEIRA",
              "lmunic": "CANGAS",
              "cpobla": "36008010100",
              "codPais": "ES",
              "nHabitantes": 566,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36945"
          },
          {
              "lpobla": "A ESPIÑEIRA (A PASTORIZA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044030300",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "LUGO",
              "cpostal": "27246"
          },
          {
              "lpobla": "A ESPIÑEIRA (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005010400",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27790"
          },
          {
              "lpobla": "A ESPIÑEIRA (COSPEITO)",
              "lmunic": "COSPEITO",
              "cpobla": "27015120700",
              "codPais": "ES",
              "nHabitantes": 49,
              "lprovi": "LUGO",
              "cpostal": "27376"
          },
          {
              "lpobla": "A ESPIÑEIRA (FOZ)",
              "lmunic": "FOZ",
              "cpobla": "27019090200",
              "codPais": "ES",
              "nHabitantes": 112,
              "lprovi": "LUGO",
              "cpostal": "27788"
          },
          {
              "lpobla": "A ESPIÑEIRA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020160500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27226"
          },
          {
              "lpobla": "A ESPIÑEIRA (PADERNE)",
              "lmunic": "CESURAS",
              "cpobla": "15026100300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A ESPIÑUDA",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087072200",
              "codPais": "ES",
              "nHabitantes": 73,
              "lprovi": "A CORUÑA",
              "cpostal": "15552"
          },
          {
              "lpobla": "A ESQUIPA (SANTIAGO DE COMPOSTELA)",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078190500",
              "codPais": "ES",
              "nHabitantes": 134,
              "lprovi": "A CORUÑA",
              "cpostal": "15820"
          },
          {
              "lpobla": "A ESQUIPA (VIMIANZO)",
              "lmunic": "VIMIANZO",
              "cpobla": "15092090200",
              "codPais": "ES",
              "nHabitantes": 98,
              "lprovi": "A CORUÑA",
              "cpostal": "15121"
          },
          {
              "lpobla": "A ESTACION (BRENCE)",
              "lmunic": "A POBRA DO BROLLON",
              "cpobla": "27047020300",
              "codPais": "ES",
              "nHabitantes": 76,
              "lprovi": "LUGO",
              "cpostal": "27331"
          },
          {
              "lpobla": "A ESTACION (COLES)",
              "lmunic": "COLES",
              "cpobla": "32026080900",
              "codPais": "ES",
              "nHabitantes": 46,
              "lprovi": "OURENSE",
              "cpostal": "32950"
          },
          {
              "lpobla": "A ESTACION (LAXOSA)",
              "lmunic": "O CORGO",
              "cpobla": "27014260200",
              "codPais": "ES",
              "nHabitantes": 91,
              "lprovi": "LUGO",
              "cpostal": "27163"
          },
          {
              "lpobla": "A ESTACION (O IRIXO)",
              "lmunic": "O IRIXO",
              "cpobla": "32035010700",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "OURENSE",
              "cpostal": "32530"
          },
          {
              "lpobla": "A ESTACION (PANTON)",
              "lmunic": "PANTON",
              "cpobla": "27041110300",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27437"
          },
          {
              "lpobla": "A ESTACION (SOBER)",
              "lmunic": "SOBER",
              "cpobla": "27059090200",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27440"
          },
          {
              "lpobla": "A ESTALADOIRA",
              "lmunic": "LANCARA",
              "cpobla": "27026040900",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27692"
          },
          {
              "lpobla": "A ESTIBADA (CARBALLEDO)",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009220200",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "LUGO",
              "cpostal": "27533"
          },
          {
              "lpobla": "A ESTIBADA (O VALADOURO)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063070700",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27777"
          },
          {
              "lpobla": "A ESTIBADA (PONTEAREAS)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042020400",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36865"
          },
          {
              "lpobla": "A ESTOXA (A CAPELA)",
              "lmunic": "A CAPELA",
              "cpobla": "15018041300",
              "codPais": "ES",
              "nHabitantes": 58,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A ESTRADA",
              "lmunic": "A ESTRADA",
              "cpobla": "36017000000",
              "codPais": "ES",
              "nHabitantes": 7716,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36680"
          },
          {
              "lpobla": "A ESTRADA (ALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065010400",
              "codPais": "ES",
              "nHabitantes": 59,
              "lprovi": "LUGO",
              "cpostal": "27813"
          },
          {
              "lpobla": "A ESTRADA (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005020600",
              "codPais": "ES",
              "nHabitantes": 76,
              "lprovi": "LUGO",
              "cpostal": "27792"
          },
          {
              "lpobla": "A ESTRADA (BASCOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031020400",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27412"
          },
          {
              "lpobla": "A ESTRADA (BASCUAS)",
              "lmunic": "LUGO",
              "cpobla": "27028060300",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27146"
          },
          {
              "lpobla": "A ESTRADA (BEGONTE SAN PEDRO)",
              "lmunic": "BEGONTE",
              "cpobla": "27007030800",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27373"
          },
          {
              "lpobla": "A ESTRADA (CASTRO CALDELAS)",
              "lmunic": "CASTRO CALDELAS",
              "cpobla": "32023130100",
              "codPais": "ES",
              "nHabitantes": 44,
              "lprovi": "OURENSE",
              "cpostal": "32794"
          },
          {
              "lpobla": "A ESTRADA (CERVANTES)",
              "lmunic": "CERVANTES",
              "cpobla": "27012020500",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27665"
          },
          {
              "lpobla": "A ESTRADA (COEO)",
              "lmunic": "LUGO",
              "cpobla": "27028DD0700",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27190"
          },
          {
              "lpobla": "A ESTRADA (DONAS)",
              "lmunic": "GONDOMAR",
              "cpobla": "36021040800",
              "codPais": "ES",
              "nHabitantes": 56,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36388"
          },
          {
              "lpobla": "A ESTRADA (ESCOUREDA)",
              "lmunic": "O CORGO",
              "cpobla": "27014170300",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "LUGO",
              "cpostal": "27163"
          },
          {
              "lpobla": "A ESTRADA (GONDOMAR SAN BENITO)",
              "lmunic": "GONDOMAR",
              "cpobla": "36021050900",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36380"
          },
          {
              "lpobla": "A ESTRADA (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022100300",
              "codPais": "ES",
              "nHabitantes": 48,
              "lprovi": "LUGO",
              "cpostal": "27372"
          },
          {
              "lpobla": "A ESTRADA (NOCHE)",
              "lmunic": "VILALBA",
              "cpobla": "27065181500",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "LUGO",
              "cpostal": "27812"
          },
          {
              "lpobla": "A ESTRADA (PANTON)",
              "lmunic": "PANTON",
              "cpobla": "27041080400",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27439"
          },
          {
              "lpobla": "A ESTRADA (PORTOMARIN)",
              "lmunic": "PORTOMARIN",
              "cpobla": "27049060400",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27188"
          },
          {
              "lpobla": "A ESTRADA (SABAREI)",
              "lmunic": "O CORGO",
              "cpobla": "27014360100",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27163"
          },
          {
              "lpobla": "A ESTRADA (SAN PAIO)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017190000",
              "codPais": "ES",
              "nHabitantes": 8257,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36681"
          },
          {
              "lpobla": "A ESTRADA (SANTA COMBA)",
              "lmunic": "LUGO",
              "cpobla": "27028490400",
              "codPais": "ES",
              "nHabitantes": 46,
              "lprovi": "LUGO",
              "cpostal": "27161"
          },
          {
              "lpobla": "A ESTRADA (TOMIÑO)",
              "lmunic": "TOMIÑO",
              "cpobla": "36054030300",
              "codPais": "ES",
              "nHabitantes": 56,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36791"
          },
          {
              "lpobla": "A ESTRELA",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040420700",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27216"
          },
          {
              "lpobla": "A FABEGA (MONDOÑEDO)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030080400",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27748"
          },
          {
              "lpobla": "A FACHA",
              "lmunic": "RAMIRAS",
              "cpobla": "32068100900",
              "codPais": "ES",
              "nHabitantes": 53,
              "lprovi": "OURENSE",
              "cpostal": "32810"
          },
          {
              "lpobla": "A FACHA (TABOADA)",
              "lmunic": "TABOADA",
              "cpobla": "27060110700",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27559"
          },
          {
              "lpobla": "A FAIA (BACOI)",
              "lmunic": "ALFOZ",
              "cpobla": "27002020600",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27776"
          },
          {
              "lpobla": "A FAMELGA (OUTES)",
              "lmunic": "OUTES",
              "cpobla": "15062040400",
              "codPais": "ES",
              "nHabitantes": 58,
              "lprovi": "A CORUÑA",
              "cpostal": "15239"
          },
          {
              "lpobla": "A FAMULIA",
              "lmunic": "PANTON",
              "cpobla": "27041090500",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27450"
          },
          {
              "lpobla": "A FARIXA",
              "lmunic": "SAN CIBRAO DAS VIÑAS",
              "cpobla": "32075060300",
              "codPais": "ES",
              "nHabitantes": 49,
              "lprovi": "OURENSE",
              "cpostal": "32911"
          },
          {
              "lpobla": "A FARRIA",
              "lmunic": "XUNQUEIRA DE AMBIA",
              "cpobla": "32036050300",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "OURENSE",
              "cpostal": "32678"
          },
          {
              "lpobla": "A FAXARDA",
              "lmunic": "RIBADEO",
              "cpobla": "27051060700",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "LUGO",
              "cpostal": "27713"
          },
          {
              "lpobla": "A FEIRA DE BERDILLO (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019030800",
              "codPais": "ES",
              "nHabitantes": 160,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A FEIRA DO MONTE",
              "lmunic": "COSPEITO",
              "cpobla": "27015150700",
              "codPais": "ES",
              "nHabitantes": 386,
              "lprovi": "LUGO",
              "cpostal": "27377"
          },
          {
              "lpobla": "A FEIRA NOVA",
              "lmunic": "MALPICA DE BERGANTIÑOS",
              "cpobla": "15043050500",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "A CORUÑA",
              "cpostal": "15111"
          },
          {
              "lpobla": "A FEIRA (OUTEIRO DE REI)",
              "lmunic": "OUTEIRO DE REI",
              "cpobla": "27039130100",
              "codPais": "ES",
              "nHabitantes": 34,
              "lprovi": "LUGO",
              "cpostal": "27157"
          },
          {
              "lpobla": "A FEIRA (SALVATERRA DE MIÑO)",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050040400",
              "codPais": "ES",
              "nHabitantes": 65,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36457"
          },
          {
              "lpobla": "A FEIRA VELLA",
              "lmunic": "ENTRIMO",
              "cpobla": "32030020200",
              "codPais": "ES",
              "nHabitantes": 64,
              "lprovi": "OURENSE",
              "cpostal": "32860"
          },
          {
              "lpobla": "A FELGUEIRA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061191800",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "A CORUÑA",
              "cpostal": "15332"
          },
          {
              "lpobla": "A FENTEIRA",
              "lmunic": "TABOADA",
              "cpobla": "27060270500",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27557"
          },
          {
              "lpobla": "A FERRALA",
              "lmunic": "OLEIROS",
              "cpobla": "15058040800",
              "codPais": "ES",
              "nHabitantes": 183,
              "lprovi": "A CORUÑA",
              "cpostal": "15179"
          },
          {
              "lpobla": "A FERRARIA (A FONSAGRADA)",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018010400",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27113"
          },
          {
              "lpobla": "A FERRARIA (BALEIRA)",
              "lmunic": "BALEIRA",
              "cpobla": "27004070200",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27278"
          },
          {
              "lpobla": "A FERRARIA DA CUIÑA",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018290400",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27113"
          },
          {
              "lpobla": "A FERRARIA (MURAS)",
              "lmunic": "MURAS",
              "cpobla": "27033060600",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27837"
          },
          {
              "lpobla": "A FERRARIA (RIOTORTO)",
              "lmunic": "RIOTORTO",
              "cpobla": "27054050900",
              "codPais": "ES",
              "nHabitantes": 34,
              "lprovi": "LUGO",
              "cpostal": "27745"
          },
          {
              "lpobla": "A FERRARIA (SAN SADURNIÑO)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076061300",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "A CORUÑA",
              "cpostal": "15576"
          },
          {
              "lpobla": "A FERRAXOSA",
              "lmunic": "OUROL",
              "cpobla": "27038010600",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A FERREIRA (LEREZ)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038091800",
              "codPais": "ES",
              "nHabitantes": 98,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36156"
          },
          {
              "lpobla": "A FERREIRA (SEREN)",
              "lmunic": "FRIOL",
              "cpobla": "27020270100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27299"
          },
          {
              "lpobla": "A FERREIROA (ALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065011300",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27813"
          },
          {
              "lpobla": "A FERREIRUA",
              "lmunic": "NOGUEIRA DE RAMUIN",
              "cpobla": "32052120300",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "OURENSE",
              "cpostal": "32448"
          },
          {
              "lpobla": "A FERREIRUA DE ABAIXO",
              "lmunic": "A POBRA DO BROLLON",
              "cpobla": "27047090300",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "LUGO",
              "cpostal": "27335"
          },
          {
              "lpobla": "A FERREIRUA (SAN MARTIÑO)",
              "lmunic": "A POBRA DO BROLLON",
              "cpobla": "27047090000",
              "codPais": "ES",
              "nHabitantes": 219,
              "lprovi": "LUGO",
              "cpostal": "27335"
          },
          {
              "lpobla": "A FERRERIA (A PASTORIZA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044050300",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "LUGO",
              "cpostal": "27287"
          },
          {
              "lpobla": "A FERRERIA (AGUEIRA)",
              "lmunic": "BECERREA",
              "cpobla": "27006010500",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27678"
          },
          {
              "lpobla": "A FERRERIA (AS NOGAIS)",
              "lmunic": "AS NOGAIS",
              "cpobla": "27037070300",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27677"
          },
          {
              "lpobla": "A FERRERIA (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005060800",
              "codPais": "ES",
              "nHabitantes": 43,
              "lprovi": "LUGO",
              "cpostal": "27793"
          },
          {
              "lpobla": "A FERRERIA (BRAVOS)",
              "lmunic": "OUROL",
              "cpobla": "27038021300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A FERRERIA (GUNDRIZ)",
              "lmunic": "SAMOS",
              "cpobla": "27055080200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27623"
          },
          {
              "lpobla": "A FERRERIA (MONTEDERRAMO)",
              "lmunic": "MONTEDERRAMO",
              "cpobla": "32049040100",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "OURENSE",
              "cpostal": "32750"
          },
          {
              "lpobla": "A FERRERIA (O INCIO)",
              "lmunic": "O INCIO",
              "cpobla": "27024240200",
              "codPais": "ES",
              "nHabitantes": 53,
              "lprovi": "LUGO",
              "cpostal": "27347"
          },
          {
              "lpobla": "A FERRERIA (O SAVIÑAO)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058170300",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27544"
          },
          {
              "lpobla": "A FERRERIA (PORTOMARIN)",
              "lmunic": "PORTOMARIN",
              "cpobla": "27049080100",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27188"
          },
          {
              "lpobla": "A FERRERIA (VILOALLE)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030140300",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "LUGO",
              "cpostal": "27747"
          },
          {
              "lpobla": "A FERVEDA (RUS)",
              "lmunic": "CARBALLO",
              "cpobla": "15019153800",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A FERVENZA (MONTEDERRAMO)",
              "lmunic": "MONTEDERRAMO",
              "cpobla": "32049050400",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "OURENSE",
              "cpostal": "32769"
          },
          {
              "lpobla": "A FERVENZA (SAN SADURNIÑO)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076031200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15580"
          },
          {
              "lpobla": "A FERVOIRA",
              "lmunic": "ABADIN",
              "cpobla": "27001020700",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27379"
          },
          {
              "lpobla": "A FIALLA",
              "lmunic": "NOIA",
              "cpobla": "15057021500",
              "codPais": "ES",
              "nHabitantes": 47,
              "lprovi": "A CORUÑA",
              "cpostal": "15210"
          },
          {
              "lpobla": "A FIEIRA DE BAIXO",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061076600",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "A CORUÑA",
              "cpostal": "15332"
          },
          {
              "lpobla": "A FIEIRA DE RIBA",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061076700",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "A CORUÑA",
              "cpostal": "15332"
          },
          {
              "lpobla": "A FIEITEIRA (MESIA)",
              "lmunic": "MESIA",
              "cpobla": "15047010400",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A FIEITEIRA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061271200",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "A CORUÑA",
              "cpostal": "15338"
          },
          {
              "lpobla": "A FIESTRA",
              "lmunic": "A PEROXA",
              "cpobla": "32059130500",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "OURENSE",
              "cpostal": "32150"
          },
          {
              "lpobla": "A FIGUEIRA (A POBRA DO CARAMIÑAL)",
              "lmunic": "A POBRA DO CARAMIÑAL",
              "cpobla": "15067040100",
              "codPais": "ES",
              "nHabitantes": 58,
              "lprovi": "A CORUÑA",
              "cpostal": "15949"
          },
          {
              "lpobla": "A FIGUEIRA (SANTIAGO DE COMPOSTELA)",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078040500",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "A CORUÑA",
              "cpostal": "15884"
          },
          {
              "lpobla": "A FIGUEIRA (TABOADA)",
              "lmunic": "TABOADA",
              "cpobla": "27060110800",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27559"
          },
          {
              "lpobla": "A FIGUEIRA (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087081000",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "A CORUÑA",
              "cpostal": "15543"
          },
          {
              "lpobla": "A FILGUEIRA (COUZADOIRO)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061051400",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "A CORUÑA",
              "cpostal": "15339"
          },
          {
              "lpobla": "A FLORIDA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020150300",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A FLORIDA (MELIDE)",
              "lmunic": "MELIDE",
              "cpobla": "15046070500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "A CORUÑA",
              "cpostal": "15826"
          },
          {
              "lpobla": "A FLORIDA (MOS)",
              "lmunic": "MOS",
              "cpobla": "36033060101",
              "codPais": "ES",
              "nHabitantes": 322,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36419"
          },
          {
              "lpobla": "A FLORIDA (PALAS DE REI)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040230500",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27204"
          },
          {
              "lpobla": "A FOCA",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078030500",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "A CORUÑA",
              "cpostal": "15688"
          },
          {
              "lpobla": "A FOLGOSA (PIÑOR)",
              "lmunic": "PIÑOR",
              "cpobla": "32061020300",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "OURENSE",
              "cpostal": "32136"
          },
          {
              "lpobla": "A FOLGUEIRA (A VIDE)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031260300",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27418"
          },
          {
              "lpobla": "A FOLGUEIRA (AMES)",
              "lmunic": "AMES",
              "cpobla": "15002020300",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "A CORUÑA",
              "cpostal": "15870"
          },
          {
              "lpobla": "A FOLGUEIRA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020300200",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27299"
          },
          {
              "lpobla": "A FONQUEIXEIRA",
              "lmunic": "MURAS",
              "cpobla": "27033021100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27817"
          },
          {
              "lpobla": "A FONSAGRADA",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018000000",
              "codPais": "ES",
              "nHabitantes": 1067,
              "lprovi": "LUGO",
              "cpostal": "27100"
          },
          {
              "lpobla": "A FONSAGRADA (SANTA MARIA)",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018090000",
              "codPais": "ES",
              "nHabitantes": 1074,
              "lprovi": "LUGO",
              "cpostal": "27100"
          },
          {
              "lpobla": "A FONTAIÑA (BOVEDA)",
              "lmunic": "BOVEDA",
              "cpobla": "27008060200",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27359"
          },
          {
              "lpobla": "A FONTAIÑA (LEREZ)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038090900",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36156"
          },
          {
              "lpobla": "A FONTAN (LAXES)",
              "lmunic": "BAIONA",
              "cpobla": "36003010601",
              "codPais": "ES",
              "nHabitantes": 340,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36308"
          },
          {
              "lpobla": "A FONTANEIRA (SANTIAGO)",
              "lmunic": "BALEIRA",
              "cpobla": "27004060000",
              "codPais": "ES",
              "nHabitantes": 39,
              "lprovi": "LUGO",
              "cpostal": "27133"
          },
          {
              "lpobla": "A FONTATAZA",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022170300",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27308"
          },
          {
              "lpobla": "A FONTE (A CAPELA)",
              "lmunic": "A CAPELA",
              "cpobla": "15018021700",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A FONTE (ALFOZ)",
              "lmunic": "ALFOZ",
              "cpobla": "27002040400",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27776"
          },
          {
              "lpobla": "A FONTE ALTA",
              "lmunic": "BUEU",
              "cpobla": "36004040800",
              "codPais": "ES",
              "nHabitantes": 44,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36938"
          },
          {
              "lpobla": "A FONTE (ANDEIRO)",
              "lmunic": "CAMBRE",
              "cpobla": "15017020200",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "A CORUÑA",
              "cpostal": "15669"
          },
          {
              "lpobla": "A FONTE ARNOSA",
              "lmunic": "TRAZO",
              "cpobla": "15086010400",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15686"
          },
          {
              "lpobla": "A FONTE (BASCOI)",
              "lmunic": "MESIA",
              "cpobla": "15047020700",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A FONTE (BRENCE)",
              "lmunic": "A POBRA DO BROLLON",
              "cpobla": "27047DD0900",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27413"
          },
          {
              "lpobla": "A FONTE CALDEIRA",
              "lmunic": "CARBALLO",
              "cpobla": "15019161700",
              "codPais": "ES",
              "nHabitantes": 45,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A FONTE (CANEDA)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031030700",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27415"
          },
          {
              "lpobla": "A FONTE (CANEDO)",
              "lmunic": "A POBRA DO BROLLON",
              "cpobla": "27047030400",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27335"
          },
          {
              "lpobla": "A FONTE (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019010300",
              "codPais": "ES",
              "nHabitantes": 37,
              "lprovi": "A CORUÑA",
              "cpostal": "15108"
          },
          {
              "lpobla": "A FONTE (CEREIXA)",
              "lmunic": "A POBRA DO BROLLON",
              "cpobla": "27047DD1000",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27334"
          },
          {
              "lpobla": "A FONTE (CHANTADA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016210200",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27517"
          },
          {
              "lpobla": "A FONTE (COSPEITO)",
              "lmunic": "COSPEITO",
              "cpobla": "27015040200",
              "codPais": "ES",
              "nHabitantes": 81,
              "lprovi": "LUGO",
              "cpostal": "27376"
          },
          {
              "lpobla": "A FONTE CUNTIN",
              "lmunic": "CAMBRE",
              "cpobla": "15017120600",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15659"
          },
          {
              "lpobla": "A FONTE (CUTIAN)",
              "lmunic": "CESURAS",
              "cpobla": "15026050300",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A FONTE DA BESTRA",
              "lmunic": "ALFOZ",
              "cpobla": "27002011300",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27773"
          },
          {
              "lpobla": "A FONTE DA BOUZA",
              "lmunic": "VILALBA",
              "cpobla": "27065242100",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27830"
          },
          {
              "lpobla": "A FONTE DA UZ (MERLAN)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040250400",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27205"
          },
          {
              "lpobla": "A FONTE DA VILA (O CADRAMON)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063021400",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "LUGO",
              "cpostal": "27777"
          },
          {
              "lpobla": "A FONTE DA VILA (RECARE)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063080700",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27777"
          },
          {
              "lpobla": "A FONTE DE AMBOA",
              "lmunic": "IRIXOA",
              "cpobla": "15039010900",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "A CORUÑA",
              "cpostal": "15319"
          },
          {
              "lpobla": "A FONTE DO CAN",
              "lmunic": "FRIOL",
              "cpobla": "27020061100",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27235"
          },
          {
              "lpobla": "A FONTE DO CANDO",
              "lmunic": "AS NOGAIS",
              "cpobla": "27037070500",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27677"
          },
          {
              "lpobla": "A FONTE DO CURA",
              "lmunic": "LOURENZA",
              "cpobla": "27027041100",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27751"
          },
          {
              "lpobla": "A FONTE DO FREIRE",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010180500",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27256"
          },
          {
              "lpobla": "A FONTE DO MOURO (ABADIN)",
              "lmunic": "ABADIN",
              "cpobla": "27001040700",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27845"
          },
          {
              "lpobla": "A FONTE DO MOURO (SOÑAR)",
              "lmunic": "LUGO",
              "cpobla": "27028500400",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "LUGO",
              "cpostal": "27180"
          },
          {
              "lpobla": "A FONTE DO PORCO",
              "lmunic": "MONTERROSO",
              "cpobla": "27032111700",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27568"
          },
          {
              "lpobla": "A FONTE DO TORNO",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078030600",
              "codPais": "ES",
              "nHabitantes": 47,
              "lprovi": "A CORUÑA",
              "cpostal": "15688"
          },
          {
              "lpobla": "A FONTE DO VAL",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010020700",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27257"
          },
          {
              "lpobla": "A FONTE ESPIÑO",
              "lmunic": "ZAS",
              "cpobla": "15093120500",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "A CORUÑA",
              "cpostal": "15858"
          },
          {
              "lpobla": "A FONTE (GONDOMAR)",
              "lmunic": "GONDOMAR",
              "cpobla": "36021080400",
              "codPais": "ES",
              "nHabitantes": 110,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36389"
          },
          {
              "lpobla": "A FONTE GRANDE (MONTERROSO)",
              "lmunic": "MONTERROSO",
              "cpobla": "27032111800",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27568"
          },
          {
              "lpobla": "A FONTE GRANDE (PORTOMARIN)",
              "lmunic": "PORTOMARIN",
              "cpobla": "27049040400",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27213"
          },
          {
              "lpobla": "A FONTE (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022120900",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27388"
          },
          {
              "lpobla": "A FONTE (IRIXOA)",
              "lmunic": "IRIXOA",
              "cpobla": "15039030400",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "A CORUÑA",
              "cpostal": "15313"
          },
          {
              "lpobla": "A FONTE MOURA",
              "lmunic": "CAMBRE",
              "cpobla": "15017120800",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "A CORUÑA",
              "cpostal": "15659"
          },
          {
              "lpobla": "A FONTE (MURAS SAN PEDRO)",
              "lmunic": "MURAS",
              "cpobla": "27033052800",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A FONTE (O VICEDO)",
              "lmunic": "O VICEDO",
              "cpobla": "27064030700",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27861"
          },
          {
              "lpobla": "A FONTE (OUTES)",
              "lmunic": "OUTES",
              "cpobla": "15062030300",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "A CORUÑA",
              "cpostal": "15236"
          },
          {
              "lpobla": "A FONTE PEQUENA",
              "lmunic": "IRIXOA",
              "cpobla": "15039020500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "A CORUÑA",
              "cpostal": "15313"
          },
          {
              "lpobla": "A FONTE (REZA)",
              "lmunic": "OURENSE",
              "cpobla": "32054130400",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "OURENSE",
              "cpostal": "32940"
          },
          {
              "lpobla": "A FONTE (SAN XOAN DE RIO)",
              "lmunic": "SAN XOAN DE RIO",
              "cpobla": "32070030300",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "OURENSE",
              "cpostal": "32779"
          },
          {
              "lpobla": "A FONTE SANTA",
              "lmunic": "MELON",
              "cpobla": "32046010600",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "OURENSE",
              "cpostal": "32410"
          },
          {
              "lpobla": "A FONTE (SARRIA)",
              "lmunic": "SARRIA",
              "cpobla": "27057260300",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27619"
          },
          {
              "lpobla": "A FONTE SOUTELO",
              "lmunic": "A ESTRADA",
              "cpobla": "36017360300",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36658"
          },
          {
              "lpobla": "A FONTE (TOMIÑO)",
              "lmunic": "TOMIÑO",
              "cpobla": "36054050300",
              "codPais": "ES",
              "nHabitantes": 32,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36792"
          },
          {
              "lpobla": "A FONTE (VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066013000",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27864"
          },
          {
              "lpobla": "A FONTE (XANCEDA)",
              "lmunic": "MESIA",
              "cpobla": "15047121100",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A FONTECATIVA",
              "lmunic": "CESURAS",
              "cpobla": "15026120900",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A FONTECHOUSA",
              "lmunic": "VILALBA",
              "cpobla": "27065090400",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "LUGO",
              "cpostal": "27822"
          },
          {
              "lpobla": "A FONTECOVA",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018270300",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27116"
          },
          {
              "lpobla": "A FONTECOVA (SANTIAGO DE COMPOSTELA)",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078130600",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15898"
          },
          {
              "lpobla": "A FONTECRIBO",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022021100",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27306"
          },
          {
              "lpobla": "A FONTEDAUDE (SALAIA)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040390400",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27206"
          },
          {
              "lpobla": "A FONTEGRANDE (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087091200",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "A CORUÑA",
              "cpostal": "15554"
          },
          {
              "lpobla": "A FONTELA (MONFORTE DE LEMOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031160200",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27414"
          },
          {
              "lpobla": "A FONTELA (NARAIO)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076061600",
              "codPais": "ES",
              "nHabitantes": 33,
              "lprovi": "A CORUÑA",
              "cpostal": "15576"
          },
          {
              "lpobla": "A FONTELA (SANDIAS)",
              "lmunic": "SANDIAS",
              "cpobla": "32077020400",
              "codPais": "ES",
              "nHabitantes": 44,
              "lprovi": "OURENSE",
              "cpostal": "32693"
          },
          {
              "lpobla": "A FONTEMOURELA",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022140500",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27305"
          },
          {
              "lpobla": "A FONTENLA (CAMBRE)",
              "lmunic": "CAMBRE",
              "cpobla": "15017090500",
              "codPais": "ES",
              "nHabitantes": 135,
              "lprovi": "A CORUÑA",
              "cpostal": "15668"
          },
          {
              "lpobla": "A FONTENLA (VILANOVA DE AROUSA)",
              "lmunic": "VILANOVA DE AROUSA",
              "cpobla": "36061020600",
              "codPais": "ES",
              "nHabitantes": 125,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36614"
          },
          {
              "lpobla": "A FONTENOVA (BENADE)",
              "lmunic": "LUGO",
              "cpobla": "27028080300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27191"
          },
          {
              "lpobla": "A FONTENOVA (COTOBADE)",
              "lmunic": "COTOBADE",
              "cpobla": "36012020300",
              "codPais": "ES",
              "nHabitantes": 86,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36859"
          },
          {
              "lpobla": "A FONTEVELLA (LANZOS)",
              "lmunic": "VILALBA",
              "cpobla": "27065141600",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27816"
          },
          {
              "lpobla": "A FONTEVELLA (RIOAVESO COSPEITO)",
              "lmunic": "COSPEITO",
              "cpobla": "27015100500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27377"
          },
          {
              "lpobla": "A FONTEVILAR",
              "lmunic": "VILALBA",
              "cpobla": "27065161000",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "LUGO",
              "cpostal": "27820"
          },
          {
              "lpobla": "A FONTIÑA",
              "lmunic": "TRAZO",
              "cpobla": "15086040600",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15687"
          },
          {
              "lpobla": "A FORCAMUÑIZ",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022181000",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27307"
          },
          {
              "lpobla": "A FORMA",
              "lmunic": "ALLARIZ",
              "cpobla": "32001080300",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "OURENSE",
              "cpostal": "32664"
          },
          {
              "lpobla": "A FORMIGA (REDONDELA)",
              "lmunic": "REDONDELA",
              "cpobla": "36045020400",
              "codPais": "ES",
              "nHabitantes": 199,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36812"
          },
          {
              "lpobla": "A FORNAZA",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018290500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27113"
          },
          {
              "lpobla": "A FORNEA (SANTO ESTEVO)",
              "lmunic": "TRABADA",
              "cpobla": "27061020000",
              "codPais": "ES",
              "nHabitantes": 118,
              "lprovi": "LUGO",
              "cpostal": "27768"
          },
          {
              "lpobla": "A FORQUETA",
              "lmunic": "O VICEDO",
              "cpobla": "27064040900",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "LUGO",
              "cpostal": "27868"
          },
          {
              "lpobla": "A FORRAQUEIRA",
              "lmunic": "NOGUEIRA DE RAMUIN",
              "cpobla": "32052120400",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "OURENSE",
              "cpostal": "32448"
          },
          {
              "lpobla": "A FORTALEZA (OLEIROS)",
              "lmunic": "OLEIROS",
              "cpobla": "15058060500",
              "codPais": "ES",
              "nHabitantes": 138,
              "lprovi": "A CORUÑA",
              "cpostal": "15176"
          },
          {
              "lpobla": "A FORXA (CARBALLEDO)",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009240300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27531"
          },
          {
              "lpobla": "A FORXA (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022021300",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27306"
          },
          {
              "lpobla": "A FORXA (LANCARA)",
              "lmunic": "LANCARA",
              "cpobla": "27026020800",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27367"
          },
          {
              "lpobla": "A FORXA (PUNXIN)",
              "lmunic": "PUNXIN",
              "cpobla": "32065040800",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "OURENSE",
              "cpostal": "32456"
          },
          {
              "lpobla": "A FRACELA",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022060600",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27308"
          },
          {
              "lpobla": "A FRADERIA",
              "lmunic": "O VICEDO",
              "cpobla": "27064060400",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27861"
          },
          {
              "lpobla": "A FRAGA (ALBIXOI)",
              "lmunic": "MESIA",
              "cpobla": "15047010600",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A FRAGA (ANTAS DE ULLA)",
              "lmunic": "ANTAS DE ULLA",
              "cpobla": "27003080400",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27578"
          },
          {
              "lpobla": "A FRAGA (BASCOI)",
              "lmunic": "MESIA",
              "cpobla": "15047020800",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A FRAGA (BERGONDO)",
              "lmunic": "BERGONDO",
              "cpobla": "15008030600",
              "codPais": "ES",
              "nHabitantes": 221,
              "lprovi": "A CORUÑA",
              "cpostal": "15319"
          },
          {
              "lpobla": "A FRAGA (CABRUI)",
              "lmunic": "MESIA",
              "cpobla": "15047050700",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A FRAGA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019031300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A FRAGA CHA (MURAS)",
              "lmunic": "MURAS",
              "cpobla": "27033052900",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27836"
          },
          {
              "lpobla": "A FRAGA (CORZANS)",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050040500",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36457"
          },
          {
              "lpobla": "A FRAGA (COSPEITO)",
              "lmunic": "COSPEITO",
              "cpobla": "27015090900",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27375"
          },
          {
              "lpobla": "A FRAGA (COUSO)",
              "lmunic": "GONDOMAR",
              "cpobla": "36021020600",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36389"
          },
          {
              "lpobla": "A FRAGA DA LATA",
              "lmunic": "MESIA",
              "cpobla": "15047010700",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A FRAGA (DOROÑA)",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091011300",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "A CORUÑA",
              "cpostal": "15615"
          },
          {
              "lpobla": "A FRAGA (FERREIRA)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076021100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15598"
          },
          {
              "lpobla": "A FRAGA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020040700",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27228"
          },
          {
              "lpobla": "A FRAGA (MANIÑOS)",
              "lmunic": "FENE",
              "cpobla": "15035051400",
              "codPais": "ES",
              "nHabitantes": 57,
              "lprovi": "A CORUÑA",
              "cpostal": "15520"
          },
          {
              "lpobla": "A FRAGA (MOAÑA)",
              "lmunic": "MOAÑA",
              "cpobla": "36029040200",
              "codPais": "ES",
              "nHabitantes": 66,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36959"
          },
          {
              "lpobla": "A FRAGA (O CARBALLIÑO)",
              "lmunic": "O CARBALLIÑO",
              "cpobla": "32019140400",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "OURENSE",
              "cpostal": "32516"
          },
          {
              "lpobla": "A FRAGA (O IRIXO)",
              "lmunic": "O IRIXO",
              "cpobla": "32035051000",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "OURENSE",
              "cpostal": "32530"
          },
          {
              "lpobla": "A FRAGA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061271300",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "A CORUÑA",
              "cpostal": "15338"
          },
          {
              "lpobla": "A FRAGA (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038062000",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27838"
          },
          {
              "lpobla": "A FRAGA (PERLIO)",
              "lmunic": "FENE",
              "cpobla": "15035062200",
              "codPais": "ES",
              "nHabitantes": 122,
              "lprovi": "A CORUÑA",
              "cpostal": "15500"
          },
          {
              "lpobla": "A FRAGA (RIBAS DE SIL)",
              "lmunic": "RIBAS DE SIL",
              "cpobla": "27052060300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27319"
          },
          {
              "lpobla": "A FRAGA (SAN BARTOLOMEU)",
              "lmunic": "LOBEIRA",
              "cpobla": "32041010000",
              "codPais": "ES",
              "nHabitantes": 66,
              "lprovi": "OURENSE",
              "cpostal": "32858"
          },
          {
              "lpobla": "A FRAGA (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087060400",
              "codPais": "ES",
              "nHabitantes": 40,
              "lprovi": "A CORUÑA",
              "cpostal": "15550"
          },
          {
              "lpobla": "A FRAGA VELLA",
              "lmunic": "VILALBA",
              "cpobla": "27065130600",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "LUGO",
              "cpostal": "27811"
          },
          {
              "lpobla": "A FRAGA (VILALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065291800",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27816"
          },
          {
              "lpobla": "A FRAGA (VINCIOS)",
              "lmunic": "GONDOMAR",
              "cpobla": "36021100600",
              "codPais": "ES",
              "nHabitantes": 246,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36316"
          },
          {
              "lpobla": "A FRAGA (XANCEDA)",
              "lmunic": "MESIA",
              "cpobla": "15047121200",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A FRAGA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021041400",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27824"
          },
          {
              "lpobla": "A FRAGUELA (IGREXAFEITA)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076031300",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "A CORUÑA",
              "cpostal": "15580"
          },
          {
              "lpobla": "A FRAGUELA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021030700",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27832"
          },
          {
              "lpobla": "A FRAIRA",
              "lmunic": "VILARDEVOS",
              "cpobla": "32091120300",
              "codPais": "ES",
              "nHabitantes": 33,
              "lprovi": "OURENSE",
              "cpostal": "32617"
          },
          {
              "lpobla": "A FRAIRIA (SANTA MARIA)",
              "lmunic": "CASTROVERDE",
              "cpobla": "27011120000",
              "codPais": "ES",
              "nHabitantes": 37,
              "lprovi": "LUGO",
              "cpostal": "27124"
          },
          {
              "lpobla": "A FRANCA (LOURENZA)",
              "lmunic": "LOURENZA",
              "cpobla": "27027021000",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27751"
          },
          {
              "lpobla": "A FRANCA (MONDOÑEDO)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030020300",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27749"
          },
          {
              "lpobla": "A FRANQUEIRAN",
              "lmunic": "RIBADAVIA",
              "cpobla": "32069050200",
              "codPais": "ES",
              "nHabitantes": 133,
              "lprovi": "OURENSE",
              "cpostal": "32416"
          },
          {
              "lpobla": "A FREIRIA",
              "lmunic": "FRIOL",
              "cpobla": "27020040800",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27228"
          },
          {
              "lpobla": "A FREITA",
              "lmunic": "CERVANTES",
              "cpobla": "27012051400",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27666"
          },
          {
              "lpobla": "A FREIXA (BUGARIN)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042050400",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36869"
          },
          {
              "lpobla": "A FRIEIRA (A ESTRADA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017020500",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36685"
          },
          {
              "lpobla": "A FRIEIRA (A POBRA DE BROLLON)",
              "lmunic": "A POBRA DO BROLLON",
              "cpobla": "27047020700",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27413"
          },
          {
              "lpobla": "A FRIEIRA (ALLARIZ)",
              "lmunic": "ALLARIZ",
              "cpobla": "32001030200",
              "codPais": "ES",
              "nHabitantes": 35,
              "lprovi": "OURENSE",
              "cpostal": "32669"
          },
          {
              "lpobla": "A FRIEIRA (CASTRELO DE MIÑO)",
              "lmunic": "CASTRELO DE MIÑO",
              "cpobla": "32022060100",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "OURENSE",
              "cpostal": "32430"
          },
          {
              "lpobla": "A FROCELA",
              "lmunic": "PORTOMARIN",
              "cpobla": "27049200600",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27177"
          },
          {
              "lpobla": "A FROUSEIRA",
              "lmunic": "VILALBA",
              "cpobla": "27065230600",
              "codPais": "ES",
              "nHabitantes": 78,
              "lprovi": "LUGO",
              "cpostal": "27810"
          },
          {
              "lpobla": "A FUMEIRA",
              "lmunic": "ABADIN",
              "cpobla": "27001080700",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27379"
          },
          {
              "lpobla": "A FURADA (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038021600",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A FURADA (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087020600",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "A CORUÑA",
              "cpostal": "15542"
          },
          {
              "lpobla": "A GABEIRA",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087051500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "A CORUÑA",
              "cpostal": "15553"
          },
          {
              "lpobla": "A GAFA",
              "lmunic": "PORTO DO SON",
              "cpobla": "15071050700",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "A CORUÑA",
              "cpostal": "15970"
          },
          {
              "lpobla": "A GAIBA (VILARMAIOR)",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091021400",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "A CORUÑA",
              "cpostal": "15616"
          },
          {
              "lpobla": "A GAIOLA (TABOADA)",
              "lmunic": "TABOADA",
              "cpobla": "27060080600",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27555"
          },
          {
              "lpobla": "A GALIANA",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038041200",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36157"
          },
          {
              "lpobla": "A GALIÑEIRA (CABANA DE BERGANTIÑOS)",
              "lmunic": "CABANA DE BERGANTIÑOS",
              "cpobla": "15014011600",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "A CORUÑA",
              "cpostal": "15149"
          },
          {
              "lpobla": "A GALUFA",
              "lmunic": "VILAGARCIA DE AROUSA",
              "cpobla": "36060050500",
              "codPais": "ES",
              "nHabitantes": 194,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36619"
          },
          {
              "lpobla": "A GAMALLEIRA (A FONSAGRADA)",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018120700",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27117"
          },
          {
              "lpobla": "A GAMALLEIRA (NEGUEIRA DE MUÑIZ)",
              "lmunic": "NEGUEIRA DE MUÑIZ",
              "cpobla": "27035050300",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27113"
          },
          {
              "lpobla": "A GANDARA (ARCOS)",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042020500",
              "codPais": "ES",
              "nHabitantes": 59,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36865"
          },
          {
              "lpobla": "A GANDARA (CAMBRE)",
              "lmunic": "CAMBRE",
              "cpobla": "15017090600",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "A CORUÑA",
              "cpostal": "15668"
          },
          {
              "lpobla": "A GANDARA (CARBALLO)",
              "lmunic": "FRIOL",
              "cpobla": "27020041600",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27228"
          },
          {
              "lpobla": "A GANDARA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019172400",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "A CORUÑA",
              "cpostal": "15108"
          },
          {
              "lpobla": "A GANDARA DA EIRIXA",
              "lmunic": "IRIXOA",
              "cpobla": "15039020600",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15313"
          },
          {
              "lpobla": "A GANDARA DE PONTEVEDRA",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038091000",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36156"
          },
          {
              "lpobla": "A GANDARA DO CAMPO",
              "lmunic": "IRIXOA",
              "cpobla": "15039020700",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "A CORUÑA",
              "cpostal": "15313"
          },
          {
              "lpobla": "A GANDARA (IRIXOA)",
              "lmunic": "IRIXOA",
              "cpobla": "15039030500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "A CORUÑA",
              "cpostal": "15313"
          },
          {
              "lpobla": "A GANDARA (LEA)",
              "lmunic": "FRIOL",
              "cpobla": "27020130500",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "LUGO",
              "cpostal": "27229"
          },
          {
              "lpobla": "A GANDARA (MEIS)",
              "lmunic": "MEIS",
              "cpobla": "36028020700",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36637"
          },
          {
              "lpobla": "A GANDARA (MESIA)",
              "lmunic": "MESIA",
              "cpobla": "15047050800",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A GANDARA (NOS)",
              "lmunic": "OLEIROS",
              "cpobla": "15058060600",
              "codPais": "ES",
              "nHabitantes": 224,
              "lprovi": "A CORUÑA",
              "cpostal": "15176"
          },
          {
              "lpobla": "A GANDARA (O VICEDO)",
              "lmunic": "O VICEDO",
              "cpobla": "27064030900",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27861"
          },
          {
              "lpobla": "A GANDARA (PONTEDEUME)",
              "lmunic": "PONTEDEUME",
              "cpobla": "15069052000",
              "codPais": "ES",
              "nHabitantes": 63,
              "lprovi": "A CORUÑA",
              "cpostal": "15609"
          },
          {
              "lpobla": "A GANDARA (SAN SADURNIÑO)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076021200",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "A CORUÑA",
              "cpostal": "15598"
          },
          {
              "lpobla": "A GANDARA (SANTA COMBA)",
              "lmunic": "LUGO",
              "cpobla": "27028490500",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "LUGO",
              "cpostal": "27161"
          },
          {
              "lpobla": "A GANDARA (SEOANE)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031211100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27590"
          },
          {
              "lpobla": "A GANDARA (SERANTES)",
              "lmunic": "OLEIROS",
              "cpobla": "15058090400",
              "codPais": "ES",
              "nHabitantes": 147,
              "lprovi": "A CORUÑA",
              "cpostal": "15177"
          },
          {
              "lpobla": "A GANDARA (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087040700",
              "codPais": "ES",
              "nHabitantes": 128,
              "lprovi": "A CORUÑA",
              "cpostal": "15550"
          },
          {
              "lpobla": "A GANDARA (VIMIANZO)",
              "lmunic": "VIMIANZO",
              "cpobla": "15092140300",
              "codPais": "ES",
              "nHabitantes": 57,
              "lprovi": "A CORUÑA",
              "cpostal": "15129"
          },
          {
              "lpobla": "A GANDARELA",
              "lmunic": "CELANOVA",
              "cpobla": "32024080500",
              "codPais": "ES",
              "nHabitantes": 54,
              "lprovi": "OURENSE",
              "cpostal": "32815"
          },
          {
              "lpobla": "A GANDARELA (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022031600",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27307"
          },
          {
              "lpobla": "A GANDARIÑA",
              "lmunic": "BEGONTE",
              "cpobla": "27007160400",
              "codPais": "ES",
              "nHabitantes": 61,
              "lprovi": "LUGO",
              "cpostal": "27375"
          },
          {
              "lpobla": "A GANDUMA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019040800",
              "codPais": "ES",
              "nHabitantes": 87,
              "lprovi": "A CORUÑA",
              "cpostal": "15108"
          },
          {
              "lpobla": "A GARDUÑA",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010190600",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27257"
          },
          {
              "lpobla": "A GARDUÑEIRA (ARRABALDO)",
              "lmunic": "OURENSE",
              "cpobla": "32054013200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "OURENSE",
              "cpostal": "32990"
          },
          {
              "lpobla": "A GAREA (AMES)",
              "lmunic": "AMES",
              "cpobla": "15002010100",
              "codPais": "ES",
              "nHabitantes": 44,
              "lprovi": "A CORUÑA",
              "cpostal": "15864"
          },
          {
              "lpobla": "A GARGA",
              "lmunic": "PONTECESO",
              "cpobla": "15068010300",
              "codPais": "ES",
              "nHabitantes": 63,
              "lprovi": "A CORUÑA",
              "cpostal": "15110"
          },
          {
              "lpobla": "A GARITA (CARIÑO)",
              "lmunic": "CARIÑO",
              "cpobla": "15901050500",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "A CORUÑA",
              "cpostal": "15369"
          },
          {
              "lpobla": "A GARITA (SAN SADURNIÑO)",
              "lmunic": "SAN SADURNIÑO",
              "cpobla": "15076051400",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15561"
          },
          {
              "lpobla": "A GARRIDA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019042500",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15108"
          },
          {
              "lpobla": "A GARRIDA (IRIXOA)",
              "lmunic": "IRIXOA",
              "cpobla": "15039061400",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "A CORUÑA",
              "cpostal": "15314"
          },
          {
              "lpobla": "A GARRONA",
              "lmunic": "XERMADE",
              "cpobla": "27021051700",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27835"
          },
          {
              "lpobla": "A GASALLA (BALEIRA)",
              "lmunic": "BALEIRA",
              "cpobla": "27004020900",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27131"
          },
          {
              "lpobla": "A GATARIZA",
              "lmunic": "O VICEDO",
              "cpobla": "27064031000",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27861"
          },
          {
              "lpobla": "A GLORIA",
              "lmunic": "XERMADE",
              "cpobla": "27021100800",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27833"
          },
          {
              "lpobla": "A GLORIA",
              "lmunic": "PONTEAREAS",
              "cpobla": "36042090600",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36865"
          },
          {
              "lpobla": "A GOIA (QUIROGA)",
              "lmunic": "QUIROGA",
              "cpobla": "27050070300",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27328"
          },
          {
              "lpobla": "A GOIBA",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091060900",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15637"
          },
          {
              "lpobla": "A GOLADA (BECERREA)",
              "lmunic": "BECERREA",
              "cpobla": "27006130200",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27665"
          },
          {
              "lpobla": "A GOLADA (NIGRAN)",
              "lmunic": "NIGRAN",
              "cpobla": "36035070700",
              "codPais": "ES",
              "nHabitantes": 233,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36370"
          },
          {
              "lpobla": "A GOLETA (A ESTRADA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017050600",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36684"
          },
          {
              "lpobla": "A GOLETA (MONTERROSO)",
              "lmunic": "MONTERROSO",
              "cpobla": "27032220200",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27568"
          },
          {
              "lpobla": "A GOLETA (PALAS DE REI)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040070500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27208"
          },
          {
              "lpobla": "A GOLETA (SILLEDA)",
              "lmunic": "SILLEDA",
              "cpobla": "36052140500",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36540"
          },
          {
              "lpobla": "A GOLPILLEIRA (BALEIRA)",
              "lmunic": "BALEIRA",
              "cpobla": "27004090800",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27278"
          },
          {
              "lpobla": "A GOLPILLEIRA (DUMPIN)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010100300",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27289"
          },
          {
              "lpobla": "A GOLPILLEIRA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021041600",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "LUGO",
              "cpostal": "27824"
          },
          {
              "lpobla": "A GORGOEIRA",
              "lmunic": "NAVIA DE SUARNA",
              "cpobla": "27034080200",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27656"
          },
          {
              "lpobla": "A GOULLA",
              "lmunic": "MEIS",
              "cpobla": "36028080300",
              "codPais": "ES",
              "nHabitantes": 90,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36616"
          },
          {
              "lpobla": "A GRACIOSA",
              "lmunic": "VAL DO DUBRA",
              "cpobla": "15088020200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15873"
          },
          {
              "lpobla": "A GRADE (SAN VICENTE)",
              "lmunic": "CHANTADA",
              "cpobla": "27016020000",
              "codPais": "ES",
              "nHabitantes": 71,
              "lprovi": "LUGO",
              "cpostal": "27513"
          },
          {
              "lpobla": "A GRADEIRA",
              "lmunic": "TOEN",
              "cpobla": "32081060400",
              "codPais": "ES",
              "nHabitantes": 60,
              "lprovi": "OURENSE",
              "cpostal": "32930"
          },
          {
              "lpobla": "A GRAMELA",
              "lmunic": "LUGO",
              "cpobla": "27028551100",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27231"
          },
          {
              "lpobla": "A GRANDA (A LAXE)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063050400",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27778"
          },
          {
              "lpobla": "A GRANDA (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005060900",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "LUGO",
              "cpostal": "27793"
          },
          {
              "lpobla": "A GRANDA (BAZAR)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010040800",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27258"
          },
          {
              "lpobla": "A GRANDA (BUDIAN)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063011100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27779"
          },
          {
              "lpobla": "A GRANDA (CARBALLIDO)",
              "lmunic": "ALFOZ",
              "cpobla": "27002030700",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "LUGO",
              "cpostal": "27776"
          },
          {
              "lpobla": "A GRANDA (LAGOA)",
              "lmunic": "ALFOZ",
              "cpobla": "27002052000",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27774"
          },
          {
              "lpobla": "A GRANDA (MEIRA)",
              "lmunic": "MEIRA",
              "cpobla": "27029020400",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27241"
          },
          {
              "lpobla": "A GRANDA (MOUCIDE)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063060500",
              "codPais": "ES",
              "nHabitantes": 44,
              "lprovi": "LUGO",
              "cpostal": "27779"
          },
          {
              "lpobla": "A GRANDA (O CASTRO DE OURO)",
              "lmunic": "ALFOZ",
              "cpobla": "27002040500",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27776"
          },
          {
              "lpobla": "A GRANDA (O CORGO)",
              "lmunic": "O CORGO",
              "cpobla": "27014340200",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27162"
          },
          {
              "lpobla": "A GRANDA (OLEIROS)",
              "lmunic": "VILALBA",
              "cpobla": "27065191800",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27812"
          },
          {
              "lpobla": "A GRANDA PEQUENA",
              "lmunic": "OUTEIRO DE REI",
              "cpobla": "27039170400",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27150"
          },
          {
              "lpobla": "A GRANDA VELLA (POL)",
              "lmunic": "POL",
              "cpobla": "27046080300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27272"
          },
          {
              "lpobla": "A GRANDELA (ABADIN)",
              "lmunic": "ABADIN",
              "cpobla": "27001060300",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "LUGO",
              "cpostal": "27849"
          },
          {
              "lpobla": "A GRANDELA (BAZAR)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010040900",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27258"
          },
          {
              "lpobla": "A GRANDELA (COSPEITO)",
              "lmunic": "COSPEITO",
              "cpobla": "27015010300",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27379"
          },
          {
              "lpobla": "A GRANDELA (TRABADA)",
              "lmunic": "TRABADA",
              "cpobla": "27061070200",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27767"
          },
          {
              "lpobla": "A GRANXA (A ESTRADA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017060900",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36584"
          },
          {
              "lpobla": "A GRANXA (ARRABALDO)",
              "lmunic": "OURENSE",
              "cpobla": "32054011500",
              "codPais": "ES",
              "nHabitantes": 111,
              "lprovi": "OURENSE",
              "cpostal": "32990"
          },
          {
              "lpobla": "A GRANXA (BANDE)",
              "lmunic": "BANDE",
              "cpobla": "32006030400",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "OURENSE",
              "cpostal": "32849"
          },
          {
              "lpobla": "A GRANXA (BOBORAS)",
              "lmunic": "BOBORAS",
              "cpobla": "32013040600",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "OURENSE",
              "cpostal": "32514"
          },
          {
              "lpobla": "A GRANXA (CARBALLEDO)",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009210800",
              "codPais": "ES",
              "nHabitantes": 52,
              "lprovi": "LUGO",
              "cpostal": "27528"
          },
          {
              "lpobla": "A GRANXA (CEE SANTA MARIA)",
              "lmunic": "CEE",
              "cpobla": "15023030300",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "A CORUÑA",
              "cpostal": "15270"
          },
          {
              "lpobla": "A GRANXA (CELANOVA)",
              "lmunic": "CELANOVA",
              "cpobla": "32024020800",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "OURENSE",
              "cpostal": "32817"
          },
          {
              "lpobla": "A GRANXA (CUDEIRO)",
              "lmunic": "OURENSE",
              "cpobla": "32054060700",
              "codPais": "ES",
              "nHabitantes": 83,
              "lprovi": "OURENSE",
              "cpostal": "32103"
          },
          {
              "lpobla": "A GRANXA DE SAN LAZARO",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078230800",
              "codPais": "ES",
              "nHabitantes": 224,
              "lprovi": "A CORUÑA",
              "cpostal": "15891"
          },
          {
              "lpobla": "A GRANXA (ESGOS)",
              "lmunic": "ESGOS",
              "cpobla": "32031070400",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "OURENSE",
              "cpostal": "32720"
          },
          {
              "lpobla": "A GRANXA (GOMESENDE)",
              "lmunic": "GOMESENDE",
              "cpobla": "32033010900",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "OURENSE",
              "cpostal": "32212"
          },
          {
              "lpobla": "A GRANXA (MESIA)",
              "lmunic": "MESIA",
              "cpobla": "15047070700",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A GRANXA (MONTEALEGRE)",
              "lmunic": "OURENSE",
              "cpobla": "32054080100",
              "codPais": "ES",
              "nHabitantes": 59,
              "lprovi": "OURENSE",
              "cpostal": "32971"
          },
          {
              "lpobla": "A GRANXA (O CARBALLIÑO)",
              "lmunic": "O CARBALLIÑO",
              "cpobla": "32019010100",
              "codPais": "ES",
              "nHabitantes": 35,
              "lprovi": "OURENSE",
              "cpostal": "32510"
          },
          {
              "lpobla": "A GRANXA (REZA)",
              "lmunic": "OURENSE",
              "cpobla": "32054130500",
              "codPais": "ES",
              "nHabitantes": 51,
              "lprovi": "OURENSE",
              "cpostal": "32940"
          },
          {
              "lpobla": "A GRANXA (SALVATERRA DE MIÑO)",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050030900",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36458"
          },
          {
              "lpobla": "A GRANXA (SAN XOAN)",
              "lmunic": "OIMBRA",
              "cpobla": "32053030000",
              "codPais": "ES",
              "nHabitantes": 92,
              "lprovi": "OURENSE",
              "cpostal": "32613"
          },
          {
              "lpobla": "A GRANXA (TOBA)",
              "lmunic": "CEE",
              "cpobla": "15023060500",
              "codPais": "ES",
              "nHabitantes": 35,
              "lprovi": "A CORUÑA",
              "cpostal": "15138"
          },
          {
              "lpobla": "A GRANXA (TOMIÑO)",
              "lmunic": "TOMIÑO",
              "cpobla": "36054150300",
              "codPais": "ES",
              "nHabitantes": 53,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36747"
          },
          {
              "lpobla": "A GRANXA (TRABADA)",
              "lmunic": "TRABADA",
              "cpobla": "27061051800",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27765"
          },
          {
              "lpobla": "A GRANXA (VALDOVIÑO)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087072500",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15552"
          },
          {
              "lpobla": "A GRANXA VELLA",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022031800",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27307"
          },
          {
              "lpobla": "A GRANXA (VILAFRAMIL)",
              "lmunic": "RIBADEO",
              "cpobla": "27051100500",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27797"
          },
          {
              "lpobla": "A GRANXA (VILASELAN)",
              "lmunic": "RIBADEO",
              "cpobla": "27051121200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27710"
          },
          {
              "lpobla": "A GRANXA (VISTA FERMOSA)",
              "lmunic": "OURENSE",
              "cpobla": "32054200200",
              "codPais": "ES",
              "nHabitantes": 108,
              "lprovi": "OURENSE",
              "cpostal": "32940"
          },
          {
              "lpobla": "A GRANXA (VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066101300",
              "codPais": "ES",
              "nHabitantes": 80,
              "lprovi": "LUGO",
              "cpostal": "27869"
          },
          {
              "lpobla": "A GRAÑA (A CAPELA)",
              "lmunic": "A CAPELA",
              "cpobla": "15018020700",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A GRAÑA (A ESTRADA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017260200",
              "codPais": "ES",
              "nHabitantes": 40,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36689"
          },
          {
              "lpobla": "A GRAÑA (BANDOXA)",
              "lmunic": "OZA DOS RIOS",
              "cpobla": "15063010500",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "A CORUÑA",
              "cpostal": "15388"
          },
          {
              "lpobla": "A GRAÑA (BECIN)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022010600",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27305"
          },
          {
              "lpobla": "A GRAÑA (BEGONTE)",
              "lmunic": "BEGONTE",
              "cpobla": "27007040400",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27372"
          },
          {
              "lpobla": "A GRAÑA (BORELA)",
              "lmunic": "COTOBADE",
              "cpobla": "36012030500",
              "codPais": "ES",
              "nHabitantes": 52,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36858"
          },
          {
              "lpobla": "A GRAÑA (BRION)",
              "lmunic": "BRION",
              "cpobla": "15013060400",
              "codPais": "ES",
              "nHabitantes": 102,
              "lprovi": "A CORUÑA",
              "cpostal": "15839"
          },
          {
              "lpobla": "A GRAÑA (BUEU)",
              "lmunic": "BUEU",
              "cpobla": "36004020500",
              "codPais": "ES",
              "nHabitantes": 341,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36939"
          },
          {
              "lpobla": "A GRAÑA (CARBALLIDO SANTA MARIA)",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018050300",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "LUGO",
              "cpostal": "27110"
          },
          {
              "lpobla": "A GRAÑA (CAROI)",
              "lmunic": "COTOBADE",
              "cpobla": "36012050700",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36856"
          },
          {
              "lpobla": "A GRAÑA (CASTROVERDE)",
              "lmunic": "CASTROVERDE",
              "cpobla": "27011201400",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27128"
          },
          {
              "lpobla": "A GRAÑA DE CHAO DE FORNOS",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018130500",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27112"
          },
          {
              "lpobla": "A GRAÑA DE SEOANE",
              "lmunic": "MONTEDERRAMO",
              "cpobla": "32049110300",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "OURENSE",
              "cpostal": "32790"
          },
          {
              "lpobla": "A GRAÑA (IRIXOA)",
              "lmunic": "IRIXOA",
              "cpobla": "15039011000",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "A CORUÑA",
              "cpostal": "15319"
          },
          {
              "lpobla": "A GRAÑA (MELIDE)",
              "lmunic": "MELIDE",
              "cpobla": "15046170200",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "A CORUÑA",
              "cpostal": "15809"
          },
          {
              "lpobla": "A GRAÑA (MONTEDERRAMO SANTA MARIA)",
              "lmunic": "MONTEDERRAMO",
              "cpobla": "32049130100",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "OURENSE",
              "cpostal": "32751"
          },
          {
              "lpobla": "A GRAÑA (MONTERROSO)",
              "lmunic": "MONTERROSO",
              "cpobla": "27032040400",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27569"
          },
          {
              "lpobla": "A GRAÑA (O GROVE)",
              "lmunic": "O GROVE",
              "cpobla": "36022010800",
              "codPais": "ES",
              "nHabitantes": 162,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36989"
          },
          {
              "lpobla": "A GRAÑA (O PORRIÑO)",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039030600",
              "codPais": "ES",
              "nHabitantes": 92,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36411"
          },
          {
              "lpobla": "A GRAÑA (ORTIGUEIRA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061111400",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15338"
          },
          {
              "lpobla": "A GRAÑA (PALAS DE REI)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040060200",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27204"
          },
          {
              "lpobla": "A GRAÑA (PONTEDEUME)",
              "lmunic": "PONTEDEUME",
              "cpobla": "15069051200",
              "codPais": "ES",
              "nHabitantes": 34,
              "lprovi": "A CORUÑA",
              "cpostal": "15609"
          },
          {
              "lpobla": "A GRAÑA (RIBADEO)",
              "lmunic": "RIBADEO",
              "cpobla": "27051061100",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27713"
          },
          {
              "lpobla": "A GRAÑA (RIBEIRA)",
              "lmunic": "RIBEIRA",
              "cpobla": "15073031200",
              "codPais": "ES",
              "nHabitantes": 171,
              "lprovi": "A CORUÑA",
              "cpostal": "15967"
          },
          {
              "lpobla": "A GRAÑA (SAN BERNABE)",
              "lmunic": "COVELO",
              "cpobla": "36013080000",
              "codPais": "ES",
              "nHabitantes": 257,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36873"
          },
          {
              "lpobla": "A GRAÑA (SAN VICENTE)",
              "lmunic": "PONTECESO",
              "cpobla": "15068070000",
              "codPais": "ES",
              "nHabitantes": 287,
              "lprovi": "A CORUÑA",
              "cpostal": "15110"
          },
          {
              "lpobla": "A GRAÑA (SANTA ROSA DE VITERBO)",
              "lmunic": "FERROL",
              "cpobla": "15036060000",
              "codPais": "ES",
              "nHabitantes": 528,
              "lprovi": "A CORUÑA",
              "cpostal": "15590"
          },
          {
              "lpobla": "A GRAÑA (SANTIAGO)",
              "lmunic": "XUNQUEIRA DE AMBIA",
              "cpobla": "32036040000",
              "codPais": "ES",
              "nHabitantes": 42,
              "lprovi": "OURENSE",
              "cpostal": "32678"
          },
          {
              "lpobla": "A GRAÑA VILARENTE(SANTA MARIA MADANELA)",
              "lmunic": "ABADIN",
              "cpobla": "27001130000",
              "codPais": "ES",
              "nHabitantes": 273,
              "lprovi": "LUGO",
              "cpostal": "27730"
          },
          {
              "lpobla": "A GRAÑA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021091500",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27835"
          },
          {
              "lpobla": "A GRAÑA (XUNQUEIRA ESPADANEDO)",
              "lmunic": "XUNQUEIRA DE ESPADANEDO",
              "cpobla": "32037040700",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "OURENSE",
              "cpostal": "32730"
          },
          {
              "lpobla": "A GRELA (A ESTRADA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017151500",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36684"
          },
          {
              "lpobla": "A GRELA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019070500",
              "codPais": "ES",
              "nHabitantes": 71,
              "lprovi": "A CORUÑA",
              "cpostal": "15102"
          },
          {
              "lpobla": "A GRELA DE SAN VICENTE",
              "lmunic": "CARRAL",
              "cpobla": "15021080700",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15175"
          },
          {
              "lpobla": "A GRELA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020190300",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27235"
          },
          {
              "lpobla": "A GRELA (MARIN)",
              "lmunic": "MARIN",
              "cpobla": "36026030100",
              "codPais": "ES",
              "nHabitantes": 96,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36915"
          },
          {
              "lpobla": "A GRELA (SAN CRISTOVO DE CEA)",
              "lmunic": "SAN CRISTOVO DE CEA",
              "cpobla": "32076030400",
              "codPais": "ES",
              "nHabitantes": 64,
              "lprovi": "OURENSE",
              "cpostal": "32141"
          },
          {
              "lpobla": "A GRELEIRA",
              "lmunic": "VILARMAIOR",
              "cpobla": "15091011400",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15615"
          },
          {
              "lpobla": "A GRIS (ZAS)",
              "lmunic": "ZAS",
              "cpobla": "15093040300",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "A CORUÑA",
              "cpostal": "15859"
          },
          {
              "lpobla": "A GRIXA (BRENS)",
              "lmunic": "CEE",
              "cpobla": "15023020400",
              "codPais": "ES",
              "nHabitantes": 138,
              "lprovi": "A CORUÑA",
              "cpostal": "15299"
          },
          {
              "lpobla": "A GRIXOA",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009130300",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27532"
          },
          {
              "lpobla": "A GROBA (BOBORAS)",
              "lmunic": "BOBORAS",
              "cpobla": "32013120200",
              "codPais": "ES",
              "nHabitantes": 42,
              "lprovi": "OURENSE",
              "cpostal": "32574"
          },
          {
              "lpobla": "A GROBA (LEIRO)",
              "lmunic": "LEIRO",
              "cpobla": "32040040300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "OURENSE",
              "cpostal": "32427"
          },
          {
              "lpobla": "A GROBA (RIBADAVIA)",
              "lmunic": "RIBADAVIA",
              "cpobla": "32069070200",
              "codPais": "ES",
              "nHabitantes": 61,
              "lprovi": "OURENSE",
              "cpostal": "32415"
          },
          {
              "lpobla": "A GROVA",
              "lmunic": "RIOTORTO",
              "cpobla": "27054080200",
              "codPais": "ES",
              "nHabitantes": 56,
              "lprovi": "LUGO",
              "cpostal": "27744"
          },
          {
              "lpobla": "A GRUA",
              "lmunic": "A CAPELA",
              "cpobla": "15018031100",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A GRUBENLA",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050031000",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36458"
          },
          {
              "lpobla": "A GRUEIRA",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010130400",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27271"
          },
          {
              "lpobla": "A GUARDA",
              "lmunic": "A GUARDA",
              "cpobla": "36023000000",
              "codPais": "ES",
              "nHabitantes": 6189,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36780"
          },
          {
              "lpobla": "A GUARDA (SANTA MARIA)",
              "lmunic": "A GUARDA",
              "cpobla": "36023020000",
              "codPais": "ES",
              "nHabitantes": 6189,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36780"
          },
          {
              "lpobla": "A GUDIÑA",
              "lmunic": "A GUDIÑA",
              "cpobla": "32034000000",
              "codPais": "ES",
              "nHabitantes": 813,
              "lprovi": "OURENSE",
              "cpostal": "32540"
          },
          {
              "lpobla": "A GUDIÑA (SAN MARTIÑO E SAN PEDRO)",
              "lmunic": "A GUDIÑA",
              "cpobla": "32034040000",
              "codPais": "ES",
              "nHabitantes": 826,
              "lprovi": "OURENSE",
              "cpostal": "32540"
          },
          {
              "lpobla": "A GUELRA",
              "lmunic": "CARBALLO",
              "cpobla": "15019110800",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15105"
          },
          {
              "lpobla": "A GUIA (MOAÑA)",
              "lmunic": "MOAÑA",
              "cpobla": "36029020700",
              "codPais": "ES",
              "nHabitantes": 376,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36955"
          },
          {
              "lpobla": "A GUIA (SANTA MARIA)",
              "lmunic": "GOMESENDE",
              "cpobla": "32033050000",
              "codPais": "ES",
              "nHabitantes": 100,
              "lprovi": "OURENSE",
              "cpostal": "32212"
          },
          {
              "lpobla": "A HEDRADA (IRIXOA)",
              "lmunic": "IRIXOA",
              "cpobla": "15039070600",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15319"
          },
          {
              "lpobla": "A HEDREIRA (AVION)",
              "lmunic": "AVION",
              "cpobla": "32004080200",
              "codPais": "ES",
              "nHabitantes": 34,
              "lprovi": "OURENSE",
              "cpostal": "32520"
          },
          {
              "lpobla": "A HEDREIRA (BEGONTE)",
              "lmunic": "BEGONTE",
              "cpobla": "27007140200",
              "codPais": "ES",
              "nHabitantes": 44,
              "lprovi": "LUGO",
              "cpostal": "27373"
          },
          {
              "lpobla": "A HEDREIRA (FRIOL)",
              "lmunic": "FRIOL",
              "cpobla": "27020061400",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "LUGO",
              "cpostal": "27235"
          },
          {
              "lpobla": "A HEDREIRA (OLEIROS)",
              "lmunic": "OLEIROS",
              "cpobla": "15058070900",
              "codPais": "ES",
              "nHabitantes": 163,
              "lprovi": "A CORUÑA",
              "cpostal": "15173"
          },
          {
              "lpobla": "A HERBOSA",
              "lmunic": "PONTEDEUME",
              "cpobla": "15069020700",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "A CORUÑA",
              "cpostal": "15607"
          },
          {
              "lpobla": "A HERDADIÑA",
              "lmunic": "LOBIOS",
              "cpobla": "32042100300",
              "codPais": "ES",
              "nHabitantes": 33,
              "lprovi": "OURENSE",
              "cpostal": "32892"
          },
          {
              "lpobla": "A HERMIDA (CASTRELO DE MIÑO)",
              "lmunic": "CASTRELO DE MIÑO",
              "cpobla": "32022040700",
              "codPais": "ES",
              "nHabitantes": 37,
              "lprovi": "OURENSE",
              "cpostal": "32430"
          },
          {
              "lpobla": "A HERVELLAQUEIRA",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061073200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15332"
          },
          {
              "lpobla": "A HORTA (BECERREA)",
              "lmunic": "BECERREA",
              "cpobla": "27006010600",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27678"
          },
          {
              "lpobla": "A HORTA (CERVANTES)",
              "lmunic": "CERVANTES",
              "cpobla": "27012100100",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27666"
          },
          {
              "lpobla": "A IBIA",
              "lmunic": "MELON",
              "cpobla": "32046020500",
              "codPais": "ES",
              "nHabitantes": 131,
              "lprovi": "OURENSE",
              "cpostal": "32411"
          },
          {
              "lpobla": "A IGLESIA (ALBIXOI)",
              "lmunic": "MESIA",
              "cpobla": "15047010800",
              "codPais": "ES",
              "nHabitantes": 29,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A IGLESIA (ALXEN)",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050010900",
              "codPais": "ES",
              "nHabitantes": 333,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36458"
          },
          {
              "lpobla": "A IGLESIA (ANDEIRO)",
              "lmunic": "CAMBRE",
              "cpobla": "15017020400",
              "codPais": "ES",
              "nHabitantes": 45,
              "lprovi": "A CORUÑA",
              "cpostal": "15669"
          },
          {
              "lpobla": "A IGLESIA (ARCA)",
              "lmunic": "O PINO",
              "cpobla": "15066010300",
              "codPais": "ES",
              "nHabitantes": 82,
              "lprovi": "A CORUÑA",
              "cpostal": "15821"
          },
          {
              "lpobla": "A IGLESIA (BOADO)",
              "lmunic": "MESIA",
              "cpobla": "15047030800",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15686"
          },
          {
              "lpobla": "A IGLESIA (BOIMIL)",
              "lmunic": "BOIMORTO",
              "cpobla": "15010DD0100",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15818"
          },
          {
              "lpobla": "A IGLESIA (CABRUI)",
              "lmunic": "MESIA",
              "cpobla": "15047050900",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A IGLESIA (CARDEIRO)",
              "lmunic": "BOIMORTO",
              "cpobla": "15010080500",
              "codPais": "ES",
              "nHabitantes": 33,
              "lprovi": "A CORUÑA",
              "cpostal": "15818"
          },
          {
              "lpobla": "A IGLESIA (CASTRO SAN SEBASTIAN)",
              "lmunic": "MESIA",
              "cpobla": "15047060300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A IGLESIA (CASTROFEITO)",
              "lmunic": "O PINO",
              "cpobla": "15066030400",
              "codPais": "ES",
              "nHabitantes": 69,
              "lprovi": "A CORUÑA",
              "cpostal": "15821"
          },
          {
              "lpobla": "A IGLESIA (CELA)",
              "lmunic": "CAMBRE",
              "cpobla": "15017070100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15669"
          },
          {
              "lpobla": "A IGLESIA (CHAIN)",
              "lmunic": "GONDOMAR",
              "cpobla": "36021030300",
              "codPais": "ES",
              "nHabitantes": 87,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36389"
          },
          {
              "lpobla": "A IGLESIA (CUMBRAOS)",
              "lmunic": "MESIA",
              "cpobla": "15047070800",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A IGLESIA (FERREIROS)",
              "lmunic": "O PINO",
              "cpobla": "15066060700",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "A CORUÑA",
              "cpostal": "15824"
          },
          {
              "lpobla": "A IGLESIA (IRIS)",
              "lmunic": "CABANAS",
              "cpobla": "15015020500",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "A CORUÑA",
              "cpostal": "15611"
          },
          {
              "lpobla": "A IGLESIA (LEIRO-SANTA MARIA)",
              "lmunic": "RIANXO",
              "cpobla": "15072040400",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "A CORUÑA",
              "cpostal": "15928"
          },
          {
              "lpobla": "A IGLESIA (MEDER)",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050101000",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36457"
          },
          {
              "lpobla": "A IGLESIA (MESIA SAN CRISTOBAL)",
              "lmunic": "MESIA",
              "cpobla": "15047091500",
              "codPais": "ES",
              "nHabitantes": 295,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A IGLESIA (MONTE)",
              "lmunic": "TOQUES",
              "cpobla": "15083050400",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "A CORUÑA",
              "cpostal": "15806"
          },
          {
              "lpobla": "A IGLESIA (NANTES)",
              "lmunic": "SANXENXO",
              "cpobla": "36051060900",
              "codPais": "ES",
              "nHabitantes": 72,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36969"
          },
          {
              "lpobla": "A IGLESIA (PORTO)",
              "lmunic": "SALVATERRA DE MIÑO",
              "cpobla": "36050130600",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36458"
          },
          {
              "lpobla": "A IGLESIA (RODIEIROS)",
              "lmunic": "BOIMORTO",
              "cpobla": "15010DD0200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15816"
          },
          {
              "lpobla": "A IGLESIA (SENDELLE)",
              "lmunic": "BOIMORTO",
              "cpobla": "15010130600",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "A CORUÑA",
              "cpostal": "15817"
          },
          {
              "lpobla": "A IGLESIA (TARAGOÑA)",
              "lmunic": "RIANXO",
              "cpobla": "15072061300",
              "codPais": "ES",
              "nHabitantes": 109,
              "lprovi": "A CORUÑA",
              "cpostal": "15985"
          },
          {
              "lpobla": "A IGLESIA (TRABA)",
              "lmunic": "CORISTANCO",
              "cpobla": "15029120400",
              "codPais": "ES",
              "nHabitantes": 55,
              "lprovi": "A CORUÑA",
              "cpostal": "15147"
          },
          {
              "lpobla": "A IGLESIA (VILAZA)",
              "lmunic": "GONDOMAR",
              "cpobla": "36021090600",
              "codPais": "ES",
              "nHabitantes": 40,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36380"
          },
          {
              "lpobla": "A IGLESIA (VISANTOÑA)",
              "lmunic": "MESIA",
              "cpobla": "15047110900",
              "codPais": "ES",
              "nHabitantes": 333,
              "lprovi": "A CORUÑA",
              "cpostal": "15689"
          },
          {
              "lpobla": "A IGLESIA (XANCEDA)",
              "lmunic": "MESIA",
              "cpobla": "15047121300",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A IGREXA (A AGUARDA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044010300",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27248"
          },
          {
              "lpobla": "A IGREXA (A AMEIXENDA)",
              "lmunic": "CEE",
              "cpobla": "15023010400",
              "codPais": "ES",
              "nHabitantes": 196,
              "lprovi": "A CORUÑA",
              "cpostal": "15298"
          },
          {
              "lpobla": "A IGREXA (A BAÑA)",
              "lmunic": "A BAÑA",
              "cpobla": "15007050300",
              "codPais": "ES",
              "nHabitantes": 48,
              "lprovi": "A CORUÑA",
              "cpostal": "15839"
          },
          {
              "lpobla": "A IGREXA (ADELAN)",
              "lmunic": "ALFOZ",
              "cpobla": "27002011400",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27773"
          },
          {
              "lpobla": "A IGREXA (AGRON)",
              "lmunic": "AMES",
              "cpobla": "15002010700",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "A CORUÑA",
              "cpostal": "15864"
          },
          {
              "lpobla": "A IGREXA (AMBOSORES)",
              "lmunic": "OUROL",
              "cpobla": "27038010800",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A IGREXA (ANDEADE)",
              "lmunic": "TOURO",
              "cpobla": "15085010500",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "A CORUÑA",
              "cpostal": "15824"
          },
          {
              "lpobla": "A IGREXA (ANZO)",
              "lmunic": "LALIN",
              "cpobla": "36024040600",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36512"
          },
          {
              "lpobla": "A IGREXA (AÑA)",
              "lmunic": "FRADES",
              "cpobla": "15038020600",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "A CORUÑA",
              "cpostal": "15686"
          },
          {
              "lpobla": "A IGREXA (ARABEXO)",
              "lmunic": "VAL DO DUBRA",
              "cpobla": "15088011000",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "A CORUÑA",
              "cpostal": "15874"
          },
          {
              "lpobla": "A IGREXA (ARDAÑA)",
              "lmunic": "CARBALLO",
              "cpobla": "15019020800",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "A CORUÑA",
              "cpostal": "15109"
          },
          {
              "lpobla": "A IGREXA (ARGALO)",
              "lmunic": "NOIA",
              "cpobla": "15057010900",
              "codPais": "ES",
              "nHabitantes": 42,
              "lprovi": "A CORUÑA",
              "cpostal": "15213"
          },
          {
              "lpobla": "A IGREXA (ARNOIS)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017060700",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36584"
          },
          {
              "lpobla": "A IGREXA (AS OIRAS)",
              "lmunic": "ALFOZ",
              "cpobla": "27002070400",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27775"
          },
          {
              "lpobla": "A IGREXA (AZUMARA)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010020800",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27257"
          },
          {
              "lpobla": "A IGREXA (BACOI)",
              "lmunic": "ALFOZ",
              "cpobla": "27002020800",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27776"
          },
          {
              "lpobla": "A IGREXA (BALBOA)",
              "lmunic": "TRABADA",
              "cpobla": "27061010700",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27766"
          },
          {
              "lpobla": "A IGREXA (BALMONTE)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010030200",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27259"
          },
          {
              "lpobla": "A IGREXA (BALOIRA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017070300",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36682"
          },
          {
              "lpobla": "A IGREXA (BAMA)",
              "lmunic": "TOURO",
              "cpobla": "15085020500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "A CORUÑA",
              "cpostal": "15823"
          },
          {
              "lpobla": "A IGREXA (BANDE)",
              "lmunic": "BANDE",
              "cpobla": "32006040200",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "OURENSE",
              "cpostal": "32849"
          },
          {
              "lpobla": "A IGREXA (BAROÑA)",
              "lmunic": "PORTO DO SON",
              "cpobla": "15071010400",
              "codPais": "ES",
              "nHabitantes": 66,
              "lprovi": "A CORUÑA",
              "cpostal": "15979"
          },
          {
              "lpobla": "A IGREXA (BARRO)",
              "lmunic": "NOIA",
              "cpobla": "15057021800",
              "codPais": "ES",
              "nHabitantes": 104,
              "lprovi": "A CORUÑA",
              "cpostal": "15210"
          },
          {
              "lpobla": "A IGREXA (BASTAVALES)",
              "lmunic": "BRION",
              "cpobla": "15013021200",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15280"
          },
          {
              "lpobla": "A IGREXA (BERRES)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017110300",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36688"
          },
          {
              "lpobla": "A IGREXA (BESEÑO)",
              "lmunic": "TOURO",
              "cpobla": "15085040600",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15824"
          },
          {
              "lpobla": "A IGREXA (BOIMENTE)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066011700",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27864"
          },
          {
              "lpobla": "A IGREXA (BORA)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038030500",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36154"
          },
          {
              "lpobla": "A IGREXA (BORRIFANS)",
              "lmunic": "CESURAS",
              "cpobla": "15026021200",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "A CORUÑA",
              "cpostal": "15390"
          },
          {
              "lpobla": "A IGREXA (BOULLON)",
              "lmunic": "BRION",
              "cpobla": "15013040200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15865"
          },
          {
              "lpobla": "A IGREXA (BRAVOS)",
              "lmunic": "OUROL",
              "cpobla": "27038021800",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A IGREXA (BRION SAN FINS)",
              "lmunic": "BRION",
              "cpobla": "15013051300",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "A CORUÑA",
              "cpostal": "15865"
          },
          {
              "lpobla": "A IGREXA (BUXAN)",
              "lmunic": "VAL DO DUBRA",
              "cpobla": "15088030600",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "A CORUÑA",
              "cpostal": "15874"
          },
          {
              "lpobla": "A IGREXA (CAAVEIRO)",
              "lmunic": "A CAPELA",
              "cpobla": "15018020800",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A IGREXA (CABALAR)",
              "lmunic": "A CAPELA",
              "cpobla": "15018031300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A IGREXA (CABANAS SANTA MARIA)",
              "lmunic": "O VICEDO",
              "cpobla": "27064011600",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27868"
          },
          {
              "lpobla": "A IGREXA (CABEIRO)",
              "lmunic": "REDONDELA",
              "cpobla": "36045010100",
              "codPais": "ES",
              "nHabitantes": 400,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36813"
          },
          {
              "lpobla": "A IGREXA (CARBALLEDO)",
              "lmunic": "COTOBADE",
              "cpobla": "36012040700",
              "codPais": "ES",
              "nHabitantes": 51,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36856"
          },
          {
              "lpobla": "A IGREXA (CARNOTA)",
              "lmunic": "CARNOTA",
              "cpobla": "15020011200",
              "codPais": "ES",
              "nHabitantes": 44,
              "lprovi": "A CORUÑA",
              "cpostal": "15293"
          },
          {
              "lpobla": "A IGREXA (CAROI)",
              "lmunic": "COTOBADE",
              "cpobla": "36012050800",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36856"
          },
          {
              "lpobla": "A IGREXA (CASTRO)",
              "lmunic": "LALIN",
              "cpobla": "36024130300",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36511"
          },
          {
              "lpobla": "A IGREXA (CEDOFEITA)",
              "lmunic": "RIBADEO",
              "cpobla": "27051020300",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27711"
          },
          {
              "lpobla": "A IGREXA (CELTIGOS)",
              "lmunic": "FRADES",
              "cpobla": "15038040500",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "A CORUÑA",
              "cpostal": "15686"
          },
          {
              "lpobla": "A IGREXA (CEQUERIL)",
              "lmunic": "CUNTIS",
              "cpobla": "36015020600",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36678"
          },
          {
              "lpobla": "A IGREXA (CEREIXO)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017140200",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36687"
          },
          {
              "lpobla": "A IGREXA (CORNAZO)",
              "lmunic": "VILAGARCIA DE AROUSA",
              "cpobla": "36060050600",
              "codPais": "ES",
              "nHabitantes": 43,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36619"
          },
          {
              "lpobla": "A IGREXA (COUCIEIRO)",
              "lmunic": "VAL DO DUBRA",
              "cpobla": "15088040300",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15871"
          },
          {
              "lpobla": "A IGREXA (CUIÑA)",
              "lmunic": "OZA DOS RIOS",
              "cpobla": "15063030700",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "A CORUÑA",
              "cpostal": "15389"
          },
          {
              "lpobla": "A IGREXA DA BARCIELA",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078030700",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15688"
          },
          {
              "lpobla": "A IGREXA DA ENFESTA",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078100500",
              "codPais": "ES",
              "nHabitantes": 46,
              "lprovi": "A CORUÑA",
              "cpostal": "15890"
          },
          {
              "lpobla": "A IGREXA DE BUSTO",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078040600",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15884"
          },
          {
              "lpobla": "A IGREXA DE CESAR",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078070500",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "A CORUÑA",
              "cpostal": "15688"
          },
          {
              "lpobla": "A IGREXA DE DODRO (SANTA MARIA DE DODRO)",
              "lmunic": "DODRO",
              "cpobla": "15033010200",
              "codPais": "ES",
              "nHabitantes": 128,
              "lprovi": "A CORUÑA",
              "cpostal": "15981"
          },
          {
              "lpobla": "A IGREXA DE FECHA",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078110500",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "A CORUÑA",
              "cpostal": "15898"
          },
          {
              "lpobla": "A IGREXA DE GRIXOA",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078140100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15898"
          },
          {
              "lpobla": "A IGREXA DE LAIÑO",
              "lmunic": "DODRO",
              "cpobla": "15033030200",
              "codPais": "ES",
              "nHabitantes": 49,
              "lprovi": "A CORUÑA",
              "cpostal": "15981"
          },
          {
              "lpobla": "A IGREXA DE LARAÑO",
              "lmunic": "SANTIAGO DE COMPOSTELA",
              "cpobla": "15078150500",
              "codPais": "ES",
              "nHabitantes": 93,
              "lprovi": "A CORUÑA",
              "cpostal": "15897"
          },
          {
              "lpobla": "A IGREXA DE QUEMBRE",
              "lmunic": "CARRAL",
              "cpobla": "15021030500",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "A CORUÑA",
              "cpostal": "15183"
          },
          {
              "lpobla": "A IGREXA DE SAN VICENTE",
              "lmunic": "CARRAL",
              "cpobla": "15021080800",
              "codPais": "ES",
              "nHabitantes": 32,
              "lprovi": "A CORUÑA",
              "cpostal": "15175"
          },
          {
              "lpobla": "A IGREXA DE TABEAIO",
              "lmunic": "CARRAL",
              "cpobla": "15021060800",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "A CORUÑA",
              "cpostal": "15182"
          },
          {
              "lpobla": "A IGREXA (DISTRIZ)",
              "lmunic": "VILALBA",
              "cpobla": "27065090700",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27822"
          },
          {
              "lpobla": "A IGREXA (DUANCOS)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010080500",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27271"
          },
          {
              "lpobla": "A IGREXA (DUARRIA)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010090800",
              "codPais": "ES",
              "nHabitantes": 44,
              "lprovi": "LUGO",
              "cpostal": "27269"
          },
          {
              "lpobla": "A IGREXA (FAO)",
              "lmunic": "TOURO",
              "cpobla": "15085090800",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "A CORUÑA",
              "cpostal": "15822"
          },
          {
              "lpobla": "A IGREXA (FOMIÑA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044080400",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27246"
          },
          {
              "lpobla": "A IGREXA (FOXAS)",
              "lmunic": "TOURO",
              "cpobla": "15085100400",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "A CORUÑA",
              "cpostal": "15822"
          },
          {
              "lpobla": "A IGREXA (FREIRES)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061100800",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15332"
          },
          {
              "lpobla": "A IGREXA (GALDO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066062000",
              "codPais": "ES",
              "nHabitantes": 40,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A IGREXA (GOA)",
              "lmunic": "COSPEITO",
              "cpobla": "27015052100",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27378"
          },
          {
              "lpobla": "A IGREXA (GOBERNO)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010110400",
              "codPais": "ES",
              "nHabitantes": 24,
              "lprovi": "LUGO",
              "cpostal": "27259"
          },
          {
              "lpobla": "A IGREXA (ILLOBRE)",
              "lmunic": "VEDRA",
              "cpobla": "15089010300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15885"
          },
          {
              "lpobla": "A IGREXA (INSUA)",
              "lmunic": "ORTIGUEIRA",
              "cpobla": "15061111500",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "A CORUÑA",
              "cpostal": "15338"
          },
          {
              "lpobla": "A IGREXA (IRIXOA)",
              "lmunic": "MURAS",
              "cpobla": "27033040300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27837"
          },
          {
              "lpobla": "A IGREXA (LAGOA)",
              "lmunic": "ALFOZ",
              "cpobla": "27002052200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27774"
          },
          {
              "lpobla": "A IGREXA (LEDOIRA)",
              "lmunic": "FRADES",
              "cpobla": "15038080400",
              "codPais": "ES",
              "nHabitantes": 73,
              "lprovi": "A CORUÑA",
              "cpostal": "15686"
          },
          {
              "lpobla": "A IGREXA (LIRIPIO)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017240400",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36684"
          },
          {
              "lpobla": "A IGREXA (LOIMIL)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017250500",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36588"
          },
          {
              "lpobla": "A IGREXA (LOIRA)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087020700",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15542"
          },
          {
              "lpobla": "A IGREXA (LOURENZA SAN ADRIANO)",
              "lmunic": "LOURENZA",
              "cpobla": "27027010800",
              "codPais": "ES",
              "nHabitantes": 111,
              "lprovi": "LUGO",
              "cpostal": "27750"
          },
          {
              "lpobla": "A IGREXA (LOURENZA SANTO TOME)",
              "lmunic": "LOURENZA",
              "cpobla": "27027041200",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27751"
          },
          {
              "lpobla": "A IGREXA (LOURIZAN)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038100700",
              "codPais": "ES",
              "nHabitantes": 114,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36153"
          },
          {
              "lpobla": "A IGREXA (LOXO)",
              "lmunic": "TOURO",
              "cpobla": "15085120600",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "A CORUÑA",
              "cpostal": "15823"
          },
          {
              "lpobla": "A IGREXA (LUAÑA)",
              "lmunic": "BRION",
              "cpobla": "15013070600",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "A CORUÑA",
              "cpostal": "15839"
          },
          {
              "lpobla": "A IGREXA (MADRIÑAN)",
              "lmunic": "LALIN",
              "cpobla": "36024320400",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36512"
          },
          {
              "lpobla": "A IGREXA (MAGAZOS)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066081800",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27850"
          },
          {
              "lpobla": "A IGREXA (MEIRAS)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087040800",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "A CORUÑA",
              "cpostal": "15550"
          },
          {
              "lpobla": "A IGREXA (MERILLE)",
              "lmunic": "OUROL",
              "cpobla": "27038041200",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27866"
          },
          {
              "lpobla": "A IGREXA (MERIN)",
              "lmunic": "VEDRA",
              "cpobla": "15089020400",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "A CORUÑA",
              "cpostal": "15885"
          },
          {
              "lpobla": "A IGREXA (MIÑOTOS)",
              "lmunic": "OUROL",
              "cpobla": "27038052100",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A IGREXA (MIRAZ)",
              "lmunic": "XERMADE",
              "cpobla": "27021060500",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27833"
          },
          {
              "lpobla": "A IGREXA (MOECHE)",
              "lmunic": "MOECHE",
              "cpobla": "15049020900",
              "codPais": "ES",
              "nHabitantes": 32,
              "lprovi": "A CORUÑA",
              "cpostal": "15564"
          },
          {
              "lpobla": "A IGREXA (MONDRIZ)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010140300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27271"
          },
          {
              "lpobla": "A IGREXA (MOUCIDE)",
              "lmunic": "O VALADOURO",
              "cpobla": "27063060700",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27779"
          },
          {
              "lpobla": "A IGREXA (MOURENTE)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038122000",
              "codPais": "ES",
              "nHabitantes": 142,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36164"
          },
          {
              "lpobla": "A IGREXA (NEGROS)",
              "lmunic": "REDONDELA",
              "cpobla": "36045050200",
              "codPais": "ES",
              "nHabitantes": 109,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36814"
          },
          {
              "lpobla": "A IGREXA (NIVEIRO)",
              "lmunic": "VAL DO DUBRA",
              "cpobla": "15088060300",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "A CORUÑA",
              "cpostal": "15874"
          },
          {
              "lpobla": "A IGREXA (O GROVE)",
              "lmunic": "O GROVE",
              "cpobla": "36022021100",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36988"
          },
          {
              "lpobla": "A IGREXA (O VICEDO SAN ESTEBO)",
              "lmunic": "O VICEDO",
              "cpobla": "27064071500",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27860"
          },
          {
              "lpobla": "A IGREXA (OBRE)",
              "lmunic": "NOIA",
              "cpobla": "15057040700",
              "codPais": "ES",
              "nHabitantes": 42,
              "lprovi": "A CORUÑA",
              "cpostal": "15213"
          },
          {
              "lpobla": "A IGREXA (ONS)",
              "lmunic": "BRION",
              "cpobla": "15013080200",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15839"
          },
          {
              "lpobla": "A IGREXA (OUROL SANTA MARIA)",
              "lmunic": "OUROL",
              "cpobla": "27038062100",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A IGREXA (PAPUCIN)",
              "lmunic": "FRADES",
              "cpobla": "15038110500",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "A CORUÑA",
              "cpostal": "15685"
          },
          {
              "lpobla": "A IGREXA (PARADA SANTA MARIA)",
              "lmunic": "LALIN",
              "cpobla": "36024380200",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36514"
          },
          {
              "lpobla": "A IGREXA (PARAMOS)",
              "lmunic": "VAL DO DUBRA",
              "cpobla": "15088070300",
              "codPais": "ES",
              "nHabitantes": 69,
              "lprovi": "A CORUÑA",
              "cpostal": "15871"
          },
          {
              "lpobla": "A IGREXA PEQUENA",
              "lmunic": "VILALBA",
              "cpobla": "27065150200",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27816"
          },
          {
              "lpobla": "A IGREXA (PIGARA)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022102800",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27372"
          },
          {
              "lpobla": "A IGREXA (PIÑEIRO SAN MAMED)",
              "lmunic": "CUNTIS",
              "cpobla": "36015060400",
              "codPais": "ES",
              "nHabitantes": 57,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36679"
          },
          {
              "lpobla": "A IGREXA (PONTEDEUME)",
              "lmunic": "PONTEDEUME",
              "cpobla": "15069080800",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "A CORUÑA",
              "cpostal": "15614"
          },
          {
              "lpobla": "A IGREXA (PONTELLAS)",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039061000",
              "codPais": "ES",
              "nHabitantes": 191,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36412"
          },
          {
              "lpobla": "A IGREXA (PORTOMEIRO)",
              "lmunic": "VAL DO DUBRA",
              "cpobla": "15088080200",
              "codPais": "ES",
              "nHabitantes": 120,
              "lprovi": "A CORUÑA",
              "cpostal": "15871"
          },
          {
              "lpobla": "A IGREXA (PORTOMOURO)",
              "lmunic": "VAL DO DUBRA",
              "cpobla": "15088090200",
              "codPais": "ES",
              "nHabitantes": 94,
              "lprovi": "A CORUÑA",
              "cpostal": "15871"
          },
          {
              "lpobla": "A IGREXA (PRADO)",
              "lmunic": "LALIN",
              "cpobla": "36024390200",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36512"
          },
          {
              "lpobla": "A IGREXA (RAMIL)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010210700",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27259"
          },
          {
              "lpobla": "A IGREXA (REIGOSA)",
              "lmunic": "A PASTORIZA",
              "cpobla": "27044150800",
              "codPais": "ES",
              "nHabitantes": 43,
              "lprovi": "LUGO",
              "cpostal": "27286"
          },
          {
              "lpobla": "A IGREXA (RIAL)",
              "lmunic": "VAL DO DUBRA",
              "cpobla": "15088101100",
              "codPais": "ES",
              "nHabitantes": 46,
              "lprovi": "A CORUÑA",
              "cpostal": "15874"
          },
          {
              "lpobla": "A IGREXA (RODIS)",
              "lmunic": "LALIN",
              "cpobla": "36024400100",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36596"
          },
          {
              "lpobla": "A IGREXA (ROO)",
              "lmunic": "NOIA",
              "cpobla": "15057050400",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15211"
          },
          {
              "lpobla": "A IGREXA (RUBIN)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017400800",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36686"
          },
          {
              "lpobla": "A IGREXA (SACOS)",
              "lmunic": "COTOBADE",
              "cpobla": "36012090700",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36121"
          },
          {
              "lpobla": "A IGREXA (SALCEDO)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038151500",
              "codPais": "ES",
              "nHabitantes": 94,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36143"
          },
          {
              "lpobla": "A IGREXA (SAN PANTALEON CABANAS)",
              "lmunic": "OUROL",
              "cpobla": "27038031800",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A IGREXA (SAN PEDRO DE MOR)",
              "lmunic": "ALFOZ",
              "cpobla": "27002060800",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27775"
          },
          {
              "lpobla": "A IGREXA (SAN PEDRO VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066110700",
              "codPais": "ES",
              "nHabitantes": 70,
              "lprovi": "LUGO",
              "cpostal": "27866"
          },
          {
              "lpobla": "A IGREXA (SAN ROMAN)",
              "lmunic": "VAL DO DUBRA",
              "cpobla": "15088110400",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "A CORUÑA",
              "cpostal": "15872"
          },
          {
              "lpobla": "A IGREXA (SANTE)",
              "lmunic": "TRABADA",
              "cpobla": "27061040800",
              "codPais": "ES",
              "nHabitantes": 39,
              "lprovi": "LUGO",
              "cpostal": "27766"
          },
          {
              "lpobla": "A IGREXA (SANTIAGO DE ARRIBA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016050400",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27517"
          },
          {
              "lpobla": "A IGREXA (SANTISO)",
              "lmunic": "LALIN",
              "cpobla": "36024410200",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36512"
          },
          {
              "lpobla": "A IGREXA (SILAN)",
              "lmunic": "MURAS",
              "cpobla": "27033060700",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27837"
          },
          {
              "lpobla": "A IGREXA (SOUTOLONGO)",
              "lmunic": "LALIN",
              "cpobla": "36024430300",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36519"
          },
          {
              "lpobla": "A IGREXA (TOEDO)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017460200",
              "codPais": "ES",
              "nHabitantes": 21,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36682"
          },
          {
              "lpobla": "A IGREXA (TRASMAÑO)",
              "lmunic": "REDONDELA",
              "cpobla": "36045100200",
              "codPais": "ES",
              "nHabitantes": 236,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36811"
          },
          {
              "lpobla": "A IGREXA (TRAZO)",
              "lmunic": "TRAZO",
              "cpobla": "15086020400",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15687"
          },
          {
              "lpobla": "A IGREXA (TRIABA)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010241400",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27267"
          },
          {
              "lpobla": "A IGREXA (VERIS)",
              "lmunic": "IRIXOA",
              "cpobla": "15039061500",
              "codPais": "ES",
              "nHabitantes": 31,
              "lprovi": "A CORUÑA",
              "cpostal": "15314"
          },
          {
              "lpobla": "A IGREXA (VICESO)",
              "lmunic": "BRION",
              "cpobla": "15013090300",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15839"
          },
          {
              "lpobla": "A IGREXA (VIEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066101400",
              "codPais": "ES",
              "nHabitantes": 84,
              "lprovi": "LUGO",
              "cpostal": "27869"
          },
          {
              "lpobla": "A IGREXA (VILABOA)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087081100",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "A CORUÑA",
              "cpostal": "15543"
          },
          {
              "lpobla": "A IGREXA (VILAFORMAN)",
              "lmunic": "TRABADA",
              "cpobla": "27061070300",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27767"
          },
          {
              "lpobla": "A IGREXA (VILANOVA)",
              "lmunic": "LALIN",
              "cpobla": "36024460600",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36515"
          },
          {
              "lpobla": "A IGREXA (VILAR DE INFESTA)",
              "lmunic": "REDONDELA",
              "cpobla": "36045120100",
              "codPais": "ES",
              "nHabitantes": 601,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36815"
          },
          {
              "lpobla": "A IGREXA (VILARIÑO)",
              "lmunic": "VAL DO DUBRA",
              "cpobla": "15088120200",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "A CORUÑA",
              "cpostal": "15871"
          },
          {
              "lpobla": "A IGREXA (VILASANTE)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058260300",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27549"
          },
          {
              "lpobla": "A IGREXA (VILAUXE)",
              "lmunic": "CHANTADA",
              "cpobla": "27016340500",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "LUGO",
              "cpostal": "27514"
          },
          {
              "lpobla": "A IGREXA (VILOALLE)",
              "lmunic": "MONDOÑEDO",
              "cpobla": "27030140400",
              "codPais": "ES",
              "nHabitantes": 26,
              "lprovi": "LUGO",
              "cpostal": "27747"
          },
          {
              "lpobla": "A IGREXA (VIVEIRON)",
              "lmunic": "MURAS",
              "cpobla": "27033081600",
              "codPais": "ES",
              "nHabitantes": 34,
              "lprovi": "LUGO",
              "cpostal": "27837"
          },
          {
              "lpobla": "A IGREXA (XERDIZ)",
              "lmunic": "OUROL",
              "cpobla": "27038081700",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27865"
          },
          {
              "lpobla": "A IGREXA (XEVE)",
              "lmunic": "PONTEVEDRA",
              "cpobla": "36038080500",
              "codPais": "ES",
              "nHabitantes": 241,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36151"
          },
          {
              "lpobla": "A ILLA",
              "lmunic": "SANTA COMBA",
              "cpobla": "15077080800",
              "codPais": "ES",
              "nHabitantes": 122,
              "lprovi": "A CORUÑA",
              "cpostal": "15846"
          },
          {
              "lpobla": "A ILLA DE AROUSA",
              "lmunic": "A ILLA DE AROUSA",
              "cpobla": "36901000000",
              "codPais": "ES",
              "nHabitantes": 4877,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36626"
          },
          {
              "lpobla": "A ILLA DE ONS (SAN XOAQUIN)",
              "lmunic": "BUEU",
              "cpobla": "36004060000",
              "codPais": "ES",
              "nHabitantes": 61,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36939"
          },
          {
              "lpobla": "A ILLA (SAN LOURENZO ENTRIMO)",
              "lmunic": "ENTRIMO",
              "cpobla": "32030030000",
              "codPais": "ES",
              "nHabitantes": 168,
              "lprovi": "OURENSE",
              "cpostal": "32869"
          },
          {
              "lpobla": "A ILLA (SAN LOURENZO LOBIOS)",
              "lmunic": "LOBIOS",
              "cpobla": "32042060000",
              "codPais": "ES",
              "nHabitantes": 212,
              "lprovi": "OURENSE",
              "cpostal": "32869"
          },
          {
              "lpobla": "A IMENDE",
              "lmunic": "CARBALLO",
              "cpobla": "15019110900",
              "codPais": "ES",
              "nHabitantes": 172,
              "lprovi": "A CORUÑA",
              "cpostal": "15105"
          },
          {
              "lpobla": "A INFESTA (MONFORTE DE LEMOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031200300",
              "codPais": "ES",
              "nHabitantes": 6,
              "lprovi": "LUGO",
              "cpostal": "27413"
          },
          {
              "lpobla": "A INFESTA (VILALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065130800",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27811"
          },
          {
              "lpobla": "A INSUA (A PONTENOVA)",
              "lmunic": "A PONTENOVA",
              "cpobla": "27048040200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27726"
          },
          {
              "lpobla": "A INSUA (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005030400",
              "codPais": "ES",
              "nHabitantes": 30,
              "lprovi": "LUGO",
              "cpostal": "27279"
          },
          {
              "lpobla": "A INSUA (CESURAS)",
              "lmunic": "CESURAS",
              "cpobla": "15026121100",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "A CORUÑA",
              "cpostal": "15391"
          },
          {
              "lpobla": "A INSUA (COSPEITO)",
              "lmunic": "COSPEITO",
              "cpobla": "27015110700",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27378"
          },
          {
              "lpobla": "A INSUA (OUTEIRO DE REI)",
              "lmunic": "OUTEIRO DE REI",
              "cpobla": "27039260400",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27157"
          },
          {
              "lpobla": "A INSUA (VILAPEDRE)",
              "lmunic": "VILALBA",
              "cpobla": "27065292300",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27816"
          },
          {
              "lpobla": "A INSUA (VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066062100",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A INSUELA (COTOBADE)",
              "lmunic": "COTOBADE",
              "cpobla": "36012070800",
              "codPais": "ES",
              "nHabitantes": 19,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36855"
          },
          {
              "lpobla": "A IREXA (FANOY)",
              "lmunic": "ABADIN",
              "cpobla": "27001090900",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "LUGO",
              "cpostal": "27738"
          },
          {
              "lpobla": "A IREXA (PREVESOS)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010190700",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27257"
          },
          {
              "lpobla": "A IREXE (CAMPO)",
              "lmunic": "TRAZO",
              "cpobla": "15086030300",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15687"
          },
          {
              "lpobla": "A IREXE (RESTANDE)",
              "lmunic": "TRAZO",
              "cpobla": "15086080300",
              "codPais": "ES",
              "nHabitantes": 75,
              "lprovi": "A CORUÑA",
              "cpostal": "15686"
          },
          {
              "lpobla": "A IREXE (VILOUCHADA)",
              "lmunic": "TRAZO",
              "cpobla": "15086100400",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "A CORUÑA",
              "cpostal": "15687"
          },
          {
              "lpobla": "A IRGEXA (BARREIROS)",
              "lmunic": "BARREIROS",
              "cpobla": "27005040600",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27798"
          },
          {
              "lpobla": "A LABIADA",
              "lmunic": "A FONSAGRADA",
              "cpobla": "27018240200",
              "codPais": "ES",
              "nHabitantes": 22,
              "lprovi": "LUGO",
              "cpostal": "27112"
          },
          {
              "lpobla": "A LABRADA (A POBRA DE BROLLON)",
              "lmunic": "A POBRA DO BROLLON",
              "cpobla": "27047010200",
              "codPais": "ES",
              "nHabitantes": 43,
              "lprovi": "LUGO",
              "cpostal": "27391"
          },
          {
              "lpobla": "A LABRADA (MEIXENTE)",
              "lmunic": "SARRIA",
              "cpobla": "27057290200",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27612"
          },
          {
              "lpobla": "A LACIANA",
              "lmunic": "OUTEIRO DE REI",
              "cpobla": "27039270200",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27152"
          },
          {
              "lpobla": "A LADEIRA",
              "lmunic": "SANDIAS",
              "cpobla": "32077020500",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "OURENSE",
              "cpostal": "32693"
          },
          {
              "lpobla": "A LADEIRA (O PORRIÑO)",
              "lmunic": "O PORRIÑO",
              "cpobla": "36039041000",
              "codPais": "ES",
              "nHabitantes": 27,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36414"
          },
          {
              "lpobla": "A LADRELA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021080600",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "LUGO",
              "cpostal": "27833"
          },
          {
              "lpobla": "A LAGARIZA (PANTON)",
              "lmunic": "PANTON",
              "cpobla": "27041260500",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27439"
          },
          {
              "lpobla": "A LAGARTEIRA (CARBALLO)",
              "lmunic": "CARBALLO",
              "cpobla": "15019173000",
              "codPais": "ES",
              "nHabitantes": 72,
              "lprovi": "A CORUÑA",
              "cpostal": "15108"
          },
          {
              "lpobla": "A LAGOA (A CAPELA)",
              "lmunic": "A CAPELA",
              "cpobla": "15018041700",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "A CORUÑA",
              "cpostal": "15613"
          },
          {
              "lpobla": "A LAGOA (A ESTRADA)",
              "lmunic": "A ESTRADA",
              "cpobla": "36017010300",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36685"
          },
          {
              "lpobla": "A LAGOA (AGOLADA)",
              "lmunic": "AGOLADA",
              "cpobla": "36020250300",
              "codPais": "ES",
              "nHabitantes": 65,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36514"
          },
          {
              "lpobla": "A LAGOA (BERGONDO)",
              "lmunic": "BERGONDO",
              "cpobla": "15008070600",
              "codPais": "ES",
              "nHabitantes": 101,
              "lprovi": "A CORUÑA",
              "cpostal": "15167"
          },
          {
              "lpobla": "A LAGOA (CARTELLE)",
              "lmunic": "CARTELLE",
              "cpobla": "32020030300",
              "codPais": "ES",
              "nHabitantes": 70,
              "lprovi": "OURENSE",
              "cpostal": "32824"
          },
          {
              "lpobla": "A LAGOA (CASTROVERDE)",
              "lmunic": "CASTROVERDE",
              "cpobla": "27011230300",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27166"
          },
          {
              "lpobla": "A LAGOA (CEE)",
              "lmunic": "CEE",
              "cpobla": "15023040200",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "A CORUÑA",
              "cpostal": "15138"
          },
          {
              "lpobla": "A LAGOA (CHANTADA)",
              "lmunic": "CHANTADA",
              "cpobla": "27016340600",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "LUGO",
              "cpostal": "27514"
          },
          {
              "lpobla": "A LAGOA (GUITIRIZ)",
              "lmunic": "GUITIRIZ",
              "cpobla": "27022021600",
              "codPais": "ES",
              "nHabitantes": 13,
              "lprovi": "LUGO",
              "cpostal": "27306"
          },
          {
              "lpobla": "A LAGOA (MEIRA)",
              "lmunic": "MEIRA",
              "cpobla": "27029011100",
              "codPais": "ES",
              "nHabitantes": 14,
              "lprovi": "LUGO",
              "cpostal": "27247"
          },
          {
              "lpobla": "A LAGOA (MOREDA)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031131100",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27592"
          },
          {
              "lpobla": "A LAGOA (OLEIROS)",
              "lmunic": "OLEIROS",
              "cpobla": "15058050400",
              "codPais": "ES",
              "nHabitantes": 314,
              "lprovi": "A CORUÑA",
              "cpostal": "15177"
          },
          {
              "lpobla": "A LAGOA (OUROL)",
              "lmunic": "OUROL",
              "cpobla": "27038022100",
              "codPais": "ES",
              "nHabitantes": 8,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A LAGOA (PALAS DE REI)",
              "lmunic": "PALAS DE REI",
              "cpobla": "27040250600",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27205"
          },
          {
              "lpobla": "A LAGOA (PANTIN)",
              "lmunic": "VALDOVIÑO",
              "cpobla": "15087051700",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "A CORUÑA",
              "cpostal": "15553"
          },
          {
              "lpobla": "A LAGOA (POL)",
              "lmunic": "POL",
              "cpobla": "27046160500",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27270"
          },
          {
              "lpobla": "A LAGOA (SADA)",
              "lmunic": "SADA",
              "cpobla": "15075030900",
              "codPais": "ES",
              "nHabitantes": 71,
              "lprovi": "A CORUÑA",
              "cpostal": "15168"
          },
          {
              "lpobla": "A LAGOA (SAN CIBRAO DAS VIÑAS)",
              "lmunic": "SAN CIBRAO DAS VIÑAS",
              "cpobla": "32075060400",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "OURENSE",
              "cpostal": "32911"
          },
          {
              "lpobla": "A LAGOA (TABOADA)",
              "lmunic": "TABOADA",
              "cpobla": "27060090300",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27596"
          },
          {
              "lpobla": "A LAGOA (TRABADA)",
              "lmunic": "TRABADA",
              "cpobla": "27061052000",
              "codPais": "ES",
              "nHabitantes": 5,
              "lprovi": "LUGO",
              "cpostal": "27768"
          },
          {
              "lpobla": "A LAGOA (VILALBA)",
              "lmunic": "VILALBA",
              "cpobla": "27065083400",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27816"
          },
          {
              "lpobla": "A LAGOA (VIMIANZO)",
              "lmunic": "VIMIANZO",
              "cpobla": "15092100900",
              "codPais": "ES",
              "nHabitantes": 18,
              "lprovi": "A CORUÑA",
              "cpostal": "15126"
          },
          {
              "lpobla": "A LAGOA (VIVEIRO)",
              "lmunic": "VIVEIRO",
              "cpobla": "27066062200",
              "codPais": "ES",
              "nHabitantes": 20,
              "lprovi": "LUGO",
              "cpostal": "27867"
          },
          {
              "lpobla": "A LAGOA (XERMADE)",
              "lmunic": "XERMADE",
              "cpobla": "27021011100",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27832"
          },
          {
              "lpobla": "A LAGOA (ZAS)",
              "lmunic": "ZAS",
              "cpobla": "15093030300",
              "codPais": "ES",
              "nHabitantes": 11,
              "lprovi": "A CORUÑA",
              "cpostal": "15859"
          },
          {
              "lpobla": "A LAGOELA (O VICEDO)",
              "lmunic": "O VICEDO",
              "cpobla": "27064011700",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27868"
          },
          {
              "lpobla": "A LAGOELA (XOVE)",
              "lmunic": "XOVE",
              "cpobla": "27025060900",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27878"
          },
          {
              "lpobla": "A LAGUA (AS NOGAIS)",
              "lmunic": "AS NOGAIS",
              "cpobla": "27037070600",
              "codPais": "ES",
              "nHabitantes": 25,
              "lprovi": "LUGO",
              "cpostal": "27677"
          },
          {
              "lpobla": "A LAGUA (BECERREA)",
              "lmunic": "BECERREA",
              "cpobla": "27006050500",
              "codPais": "ES",
              "nHabitantes": 34,
              "lprovi": "LUGO",
              "cpostal": "27695"
          },
          {
              "lpobla": "A LAGUA (PEDRAFITA DO CEBREIRO)",
              "lmunic": "PEDRAFITA DO CEBREIRO",
              "cpobla": "27045010600",
              "codPais": "ES",
              "nHabitantes": 15,
              "lprovi": "LUGO",
              "cpostal": "27674"
          },
          {
              "lpobla": "A LAGUA (TRIACASTELA)",
              "lmunic": "TRIACASTELA",
              "cpobla": "27062040200",
              "codPais": "ES",
              "nHabitantes": 28,
              "lprovi": "LUGO",
              "cpostal": "27632"
          },
          {
              "lpobla": "A LAMA",
              "lmunic": "A LAMA",
              "cpobla": "36025000000",
              "codPais": "ES",
              "nHabitantes": 231,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36830"
          },
          {
              "lpobla": "A LAMA (A COVA)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058030800",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27532"
          },
          {
              "lpobla": "A LAMA (A POBRA DE TRIVES)",
              "lmunic": "A POBRA DE TRIVES",
              "cpobla": "32063050108",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "OURENSE",
              "cpostal": "32789"
          },
          {
              "lpobla": "A LAMA (ABUIME)",
              "lmunic": "O SAVIÑAO",
              "cpobla": "27058010400",
              "codPais": "ES",
              "nHabitantes": 2,
              "lprovi": "LUGO",
              "cpostal": "27546"
          },
          {
              "lpobla": "A LAMA (AGOLADA)",
              "lmunic": "AGOLADA",
              "cpobla": "36020060200",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "PONTEVEDRA",
              "cpostal": "36527"
          },
          {
              "lpobla": "A LAMA (ALFOZ)",
              "lmunic": "ALFOZ",
              "cpobla": "27002011500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27773"
          },
          {
              "lpobla": "A LAMA (AMANDI)",
              "lmunic": "SOBER",
              "cpobla": "27059010800",
              "codPais": "ES",
              "nHabitantes": 0,
              "lprovi": "LUGO",
              "cpostal": "27423"
          },
          {
              "lpobla": "A LAMA (BARXA DE LOR)",
              "lmunic": "A POBRA DO BROLLON",
              "cpobla": "27047010300",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27391"
          },
          {
              "lpobla": "A LAMA (BOVEDA)",
              "lmunic": "BOVEDA",
              "cpobla": "27008041300",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27349"
          },
          {
              "lpobla": "A LAMA (CASTRO CALDELAS)",
              "lmunic": "CASTRO CALDELAS",
              "cpobla": "32023010600",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "OURENSE",
              "cpostal": "32766"
          },
          {
              "lpobla": "A LAMA (CASTRO DE REI)",
              "lmunic": "CASTRO DE REI",
              "cpobla": "27010050600",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27289"
          },
          {
              "lpobla": "A LAMA (CENLLE)",
              "lmunic": "CENLLE",
              "cpobla": "32025090400",
              "codPais": "ES",
              "nHabitantes": 38,
              "lprovi": "OURENSE",
              "cpostal": "32454"
          },
          {
              "lpobla": "A LAMA (CERVANTES)",
              "lmunic": "CERVANTES",
              "cpobla": "27012120100",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27665"
          },
          {
              "lpobla": "A LAMA (CORVELLE)",
              "lmunic": "SARRIA",
              "cpobla": "27057110600",
              "codPais": "ES",
              "nHabitantes": 7,
              "lprovi": "LUGO",
              "cpostal": "27690"
          },
          {
              "lpobla": "A LAMA DA VILA",
              "lmunic": "AS NOGAIS",
              "cpobla": "27037070700",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27677"
          },
          {
              "lpobla": "A LAMA DE FENTE",
              "lmunic": "CARBALLEDO",
              "cpobla": "27009110300",
              "codPais": "ES",
              "nHabitantes": 17,
              "lprovi": "LUGO",
              "cpostal": "27527"
          },
          {
              "lpobla": "A LAMA DE OUTEIRO",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031131300",
              "codPais": "ES",
              "nHabitantes": 3,
              "lprovi": "LUGO",
              "cpostal": "27592"
          },
          {
              "lpobla": "A LAMA DO FRANCO",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031131200",
              "codPais": "ES",
              "nHabitantes": 9,
              "lprovi": "LUGO",
              "cpostal": "27592"
          },
          {
              "lpobla": "A LAMA DO RIO",
              "lmunic": "PANTON",
              "cpobla": "27041090800",
              "codPais": "ES",
              "nHabitantes": 1,
              "lprovi": "LUGO",
              "cpostal": "27450"
          },
          {
              "lpobla": "A LAMA DO SOBRADO",
              "lmunic": "SOBER",
              "cpobla": "27059200500",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27466"
          },
          {
              "lpobla": "A LAMA DOS CAMPOS",
              "lmunic": "SOBER",
              "cpobla": "27059200600",
              "codPais": "ES",
              "nHabitantes": 12,
              "lprovi": "LUGO",
              "cpostal": "27466"
          },
          {
              "lpobla": "A LAMA (ESGOS)",
              "lmunic": "ESGOS",
              "cpobla": "32031010400",
              "codPais": "ES",
              "nHabitantes": 36,
              "lprovi": "OURENSE",
              "cpostal": "32720"
          },
          {
              "lpobla": "A LAMA (GUNDIVOS)",
              "lmunic": "SOBER",
              "cpobla": "27059120600",
              "codPais": "ES",
              "nHabitantes": 10,
              "lprovi": "LUGO",
              "cpostal": "27469"
          },
          {
              "lpobla": "A LAMA (LANDOY)",
              "lmunic": "CARIÑO",
              "cpobla": "15901030900",
              "codPais": "ES",
              "nHabitantes": 16,
              "lprovi": "A CORUÑA",
              "cpostal": "15366"
          },
          {
              "lpobla": "A LAMA (LOBIOS)",
              "lmunic": "LOBIOS",
              "cpobla": "32042100400",
              "codPais": "ES",
              "nHabitantes": 23,
              "lprovi": "OURENSE",
              "cpostal": "32892"
          },
          {
              "lpobla": "A LAMA (MONFORTE DE LEMOS)",
              "lmunic": "MONFORTE DE LEMOS",
              "cpobla": "27031090300",
              "codPais": "ES",
              "nHabitantes": 4,
              "lprovi": "LUGO",
              "cpostal": "27416"
          }
      ]
  }
}
