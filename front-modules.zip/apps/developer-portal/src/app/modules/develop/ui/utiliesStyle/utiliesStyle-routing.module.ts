import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BackgroundView } from './background/background.view';
import { BorderView } from './border/border.view';
import { BoxShadowView } from './box-shadows/box-shadow.view';
import { ColorsView } from './colors/colors.view';
import { ColumnView } from './column/column.view';
import { ContainerView } from './container/container.view';
import { DisplayView } from './display/display.view';
import { FlexView } from './flex/flex.view';
import { GridView } from './grid/grid.view';
import { HeaderView } from './header/header.view';
import { MarginView } from './margin/margin.view';
import { PaddingView } from './padding/padding.view';
import { PositionView } from './position/position.view';
import { TextView } from './text/text.view';
import { UtilieStyleView } from './utiliesStyle.view';
import { UtilitiesView } from './utilities/utilities.view';
import { VisibilityView } from './visibility/visibility.view';

const routes: Routes = [
 {
   path: '',
   component: UtilieStyleView,
   children: [
     {
       path: 'border',
       component: BorderView
     },
     {
        path: 'background',
        component: BackgroundView
      },
      {
        path: 'boxshadow',
        component: BoxShadowView
      },
      {
        path: 'container',
        component: ContainerView
      },
      {
        path: 'display',
        component: DisplayView
      },
      {
        path: 'column',
        component: ColumnView
      },
      {
        path: 'colors',
        component: ColorsView
      },
      {
        path: 'flex',
        component: FlexView
      },
      {
        path: 'grid',
        component: GridView
      },
      {
        path: 'header',
        component: HeaderView
      },
      {
        path: 'margin',
        component: MarginView
      },
      {
        path: 'padding',
        component: PaddingView
      },
      {
        path: 'position',
        component: PositionView
      },
      {
        path: 'text',
        component: TextView
      },
      {
        path: 'utilities',
        component: UtilitiesView
      },
      {
        path: 'visibility',
        component: VisibilityView
      }
   ]
 }
];


@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class UtiliesStyleRoutingModule {}
