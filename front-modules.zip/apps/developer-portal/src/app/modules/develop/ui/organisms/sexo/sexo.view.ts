import { Component, OnInit } from '@angular/core';
import { CaSexoService } from '@global-front-components/common';
import { Sexo, SexoRequest, SexoResponse } from 'libs/common/src/lib/models/sexo.interface';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { SEXO_RESPONSE_MOCK } from './_mock_/sexo-list.response';


@Component({
	templateUrl: 'sexo.view.html',
	styleUrls: ['sexo.view.scss']
})
export class SexoView implements OnInit {
	constructor(private _CaSexoService: CaSexoService) {}
	sexos: Sexo[];
	sexo: Sexo;
	sexoFound: Sexo;
	selectedSexo: Sexo;

	caseSexoSelect: ComponentDoc = {
		title: 'Componente Seleccionable de Sexo',
		description: `
    `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-select
          placeholder="Seleccione su Sexo"
          keyValue="tvalor"
          [options]="sexos"
          [(ngModel)]="selectedSexo"
        ></ca-select>
        <pre class="mt-2" *ngIf="selectedSexo">
          {{ selectedSexo | json }}
        </pre>
      </ca-form-field>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { Sexo, SexoRequest, SexoResponse, CaSexoService } from '@global-front-components/common';

      @Component({
        selector: 'sexo-select-example',
        templateUrl: 'sexo-select-example.component.html',
        styleUrls: ['sexo-select-example.component.scss']
      })

      export class SexoSelectExampleComponent implements OnInit {
        constructor( private _caSexoService: CaSexoService ) { }

        sexos: Sexo[];
        selectedSexo: Sexo;

        ngOnInit() {
          const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
          const request: SexoRequest = {
            serviceId: 'BuscarValorPorTablaSRV',
            inputMap: {
              codigoCatalogo: 15,
              usuario: 'BDI',
              aplicacion: 'BDI',
            }
          };
          this._caSexoService.getSexo(endpoint, request).subscribe((response: SexoResponse) => {
            this.sexos = response.outputMap.valorParametro;
          })
        }
      }`
		}
	};

	codeSexoTypeahead: ComponentDoc = {
		title: 'Componente Predictivo de sexo',
		description: `Hay dos formas de emplear este componente predictivo. Por un lado se puede hacer una única llamada al servicio de sexo que nos devuelva toda la lista y filtrar a través del componente,
    o bien, llamar al servicio cada vez que el usuario introduce un valor en el <code class="tag">input</code>.
    <br />
    Primeramente se describe como implementarlo con una única llamada incial.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Sexo</ca-label>
        <input
          type="text"
          placeholder="Busque una sexo"
          [caTypeahead]="search"
          [inputFormatter]="sexoFormatter"
          [(ngModel)]="sexo"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="sexo">
        {{ sexo | json }}
      </pre>`,
			ts: `
      import { Component, OnInit } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
      import { Sexo, SexoRequest, SexoResponse, CaSexoService } from '@global-front-components/common';

      @Component({
        selector: 'sexo-typeahead-example',
        templateUrl: 'sexo-typeahead-example.component.html',
        styleUrls: ['sexo-typeahead-example.component.scss']
      })

      export class SexoTypeaheadExampleComponent implements OnInit {
        constructor( private _caSexoService: CaSexoService ) { }

        sexos: Sexo[];
        sexo: Sexo;

        sexoFormatter = (x:{tvalor: string}) => x.tvalor;

        search = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            map(term => term === '' ? []
              : this.sexos.filter(v => v.tvalor.toLowerCase().indexOf(term.toLowerCase()) > -1))
          )

        ngOnInit() {
          const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
          const request: SexoRequest = {
            serviceId: 'BuscarValorPorTablaSRV',
            inputMap: {
                codigoCatalogo: 15,
                usuario: 'BDI',
                aplicacion: 'BDI',
            }
          };
          this._caSexoService.getSexo(endpoint, request).subscribe((response: SexoResponse) => {
            this.sexos = response.outputMap.valorParametro;
          })
        }
      }`
		}
	};

	codeSexoTypeaheadService: ComponentDoc = {
		description: `A continuación se describe como implementarlo con llamadas al servicio cuando el usuario interactúe.`,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Sexo</ca-label>
        <input
          type="text"
          placeholder="Busque una sexo"
          [caTypeahead]="searchSexo"
          [inputFormatter]="sexoFormatter"
          [(ngModel)]="sexoFound"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="sexoFound">
        {{ sexoFound | json }}
      </pre>`,
			ts: `
      import { Component } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
      import { Sexo, SexoRequest, SexoResponse, CaSexoService } from '@global-front-components/common';

      @Component({
        selector: 'sexo-typeahead-example',
        templateUrl: 'sexo-typeahead-example.component.html',
        styleUrls: ['sexo-typeahead-example.component.scss']
      })

      export class SexoTypeaheadExampleComponent {
        constructor( private _caSexoService: CaSexoService ) { }

        sexoFound: Sexo;

        sexoFormatter = (x:{tvalor: string}) => x.tvalor;

        searchSexo = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            switchMap(term => {
              const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
              const request: SexoRequest = {
                serviceId: 'BuscarValorPorTablaSRV',
                inputMap: {
                  codigoCatalogo: 15,
                  usuario: 'BDI',
                  aplicacion: 'BDI',
                }
              };
              return this._caSexoService.getSexo(endpoint, request)
            })
            ).pipe(map((response: SexoResponse) => response.outputMap.valorParametro)
          );
      }`
		}
	};

	sexoFormatter = (x: { tvalor: string }) => x.tvalor;


	search = (text$: Observable<string>) =>
		text$.pipe(
			debounceTime(300),
			distinctUntilChanged(),
			map((term) =>
				term === '' ? [] : this.sexos.filter((v) => v.tvalor.toLowerCase().indexOf(term.toLowerCase()) > -1)
			)
		);

	searchSexo = (text$: Observable<string>) =>
		text$
			.pipe(
				debounceTime(300),
				distinctUntilChanged(),
				switchMap((term) => {
					const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
					const request: SexoRequest = {
						serviceId: 'BuscarValorPorTablaSRV',
						inputMap: {
							codigoCatalogo: 15,
							usuario: 'BDI',
                            aplicacion: 'BDI',
						}
					};
					return combineLatest([this._getSexoMock(endpoint, request), of(term)]);
				})
			)
			.pipe(
				map(([response, term]) =>
					term === '' ? [] : this.sexos.filter((v) => v.tvalor.toLowerCase().indexOf(term.toLowerCase()) > -1)
				)
			);

	private _getSexoMock(endpoint: string, request: SexoRequest): Observable<SexoResponse> {
		return this._CaSexoService.getSexo(endpoint, request).pipe(
			catchError(() => {
				return of(<SexoResponse>SEXO_RESPONSE_MOCK);
			})
		);
	}

	ngOnInit() {
    const endpoint: string = '/apibdihttpchannel/bindJSONServlet';
    const request: SexoRequest = {
      serviceId: 'BuscarValorPorTablaSRV',
      inputMap: {
        codigoCatalogo: 15,
        usuario: 'BDI',
        aplicacion: 'BDI',
    }
    };
		this._getSexoMock(endpoint, request).subscribe((response:SexoResponse) => {
			this.sexos = response.outputMap.valorParametro;
		});
	}
}
