import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: 'datepicker.view.html',
	styleUrls: ['datepicker.view.scss']
})
export class DatepickerView implements OnInit {
	importModule = `import { CaDatepickerModule } from '@global-front-components/ui';`;
	birthdayDate: number;
  dateNoCalendar: number;
  dateWithtime: number;
  rangeDates: number[] = [];
  minDate = new Date(new Date().getTime()-(5*24*60*60*1000)).valueOf()
  maxDate = new Date(new Date().getTime()+(5*24*60*60*1000)).valueOf()

	caseNgModel: ComponentDoc = {
		title: `Uso con Template Driven [(NgModel)]`,
		description: `
    <p>Para generar el uso básico de un datepicker, tan solo debemos introducir la etiqueta <code class="tag">ca-datepicker</code>, y referenciar en el <code class="attribute">[(ngModel)]</code> la variable que queramos que haga de modelo.</p>
    `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Fecha de nacimiento</ca-label>
        <ca-datepicker [(ngModel)]="birthdayDate" name="datepicker"> </ca-datepicker>
      </ca-form-field>
        `
		}
	};

	caseTime: ComponentDoc = {
		title: `Calendario con Hora`,
		description: `
    <p>Para generar un datepicker con hora, tan sólo debemos introducir el atributo <code class="attribute">showTime</code>. de esta forma el calendario mostrará un sección donde poder modificar la hora</p>
    <p>Esta hora estará en formato 24h.<p>
    <p>Es necesario seleccionar un día después de setear la hora para que el calendario emita el cambio<p>

    `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Fecha de nacimiento</ca-label>
        <ca-datepicker [(ngModel)]="birthdayDate" name="datepicker" showTime> </ca-datepicker>
      </ca-form-field>
        `
		}
	};
	caseReactive: ComponentDoc = {
		title: `Uso con Reactive form`,
		description: `
    <p>Podemos usarlo como parte de un formulario reactivo. Para ello lo incluiremos dentro un form y le asignaremos el control con el atributo <code class="attribute">formControlName</code> tal y como se indica en el ejemplo.</p>
    `,
		codeExample: {
			html: `
      <form [formGroup]="form">
        <ca-form-field>
          <ca-label>Fecha de nacimiento</ca-label>
          <ca-datepicker formControlName="birthday" name="datepicker"> </ca-datepicker>
        </ca-form-field>
      </form>
        `,
      ts: `
      import { FormBuilder, FormGroup, Validators } from '@angular/forms';

      export class MyComponent{
        constructor(private _fb: FormBuilder){}
        public form: FormGroup = this._fb({
          birthday: ''
        })

      }
      `
		}
  };

	caseFormatDate: ComponentDoc = {
		title: `Retorno de un Date`,
		description: `
    <p>Si necesitamos que el compoenente nos devuelva la fecha con este formato debemos añadir el atributo <code class="attribute">formatDate</code> tal y como se indica en el ejemplo.</p>
    <p>Para saber como dar otros formatos a la fecha, vaya a la pestaña formato de fecha de la documentación</p>
    `,
		codeExample: {
			html: `
      <form [formGroup]="form">
        <ca-form-field>
          <ca-label>Fecha de nacimiento</ca-label>
          <ca-datepicker formControlName="birthday" name="datepicker" formatDate> </ca-datepicker>
        </ca-form-field>
      </form>
        `,
      ts: `
      import { FormBuilder, FormGroup, Validators } from '@angular/forms';

      export class MyComponent{
        constructor(private _fb: FormBuilder){}
        public form: FormGroup = this._fb({
          birthday: ''
        })

      }
      `
		}
  };
	caseDefaultValue: ComponentDoc = {
		title: `Datepicker con valor por defecto`,
		description: `
    <p>Para asignarle un valor por defecto, debemos pasarle el timestamp de una fecha válida en milisegundos.</p>
    `,
		codeExample: {
			html: `
      <form [formGroup]="form">
        <ca-form-field>
          <ca-label>Fecha de nacimiento</ca-label>
          <ca-datepicker formControlName="birthday" name="datepicker"> </ca-datepicker>
        </ca-form-field>
      </form>
        `,
      ts: `
      import { FormBuilder, FormGroup, Validators } from '@angular/forms';

      export class MyComponent{
        private date = new Date('1980/09/05').valueOf()
        constructor(private _fb: FormBuilder){}
        public form: FormGroup = this._fb({
          birthday: date
        })

      }
      `
		}
  };

	caseRequired: ComponentDoc = {
		title: `Datepicker como campo requerido`,
		description: `
    <p>Para hacer que el datepicker sea un campo requerido, tan solo debemos añadir el atributo <code class="attribute">required</code> a la tag del datepicker, si estamos usando ngModel.</p>
    <p>Si estamos usando formularios reactivos, también podemos hacer que el campo sea requerido, usando <code class="directive">Validator.required</code> en control del input.</p>
    `,
		codeExample: {
      html: `

      <!--Template Driven -->
      <ca-form-field>
        <ca-label>Fecha de nacimiento</ca-label>
        <ca-datepicker [(ngModel)]="birthdayDate" name="datepicker" required> </ca-datepicker>
      </ca-form-field>
        `,
      ts: `
      // Reactive Form
      import { FormBuilder, FormGroup, Validators } from '@angular/forms';

      export class MyReactiveComponent{
        constructor(private _fb: FormBuilder){}
        public form: FormGroup = this._fb({
          birthday: ['', Validators.required]
        })

      }
      `
		}
  };

	caseDisabled: ComponentDoc = {
		title: `Datepicker como campo Deshabilitado`,
    description: `
    <p>Igualmente podemos hacer uso tanto del modelo de plantilla cómo de los formularios reactivos para hacer que el campo este deshabilitado.</p>
    <p>Bastaría añadir el atributo <code class="attribute">disabled</code> a la etiqueta del datepicker.</p>
    <p>O podemos añadir el atributo  <code class="attribute">{diabled: true}</code>al control de formulario, si preferimos hacer uso de los formularios reactivos.</p>
    `,
		codeExample: {
      html: `

      <!--Template Driven -->
      <ca-form-field>
        <ca-label>Fecha de nacimiento</ca-label>
        <ca-datepicker [(ngModel)]="birthdayDate" name="datepicker" disabled> </ca-datepicker>
      </ca-form-field>
        `,
      ts: `
      // Reactive Form
      import { FormBuilder, FormGroup} from '@angular/forms';

      export class MyReactiveComponent{
        constructor(private _fb: FormBuilder){}
        public form: FormGroup = this._fb({
          birthday: [{value: '', disabled: true}]
        })

      }
      `
		}
  };

  caseNoCalendar: ComponentDoc = {
		title: `Datepicker sin icono de calendario`,
    description: `
    <p>Si no se desea mostrar el icono del calendario, simplemente bastará con añadir el attributo <code class="attribute">noCalendar</code> al componente.</p>`,
		codeExample: {
      html: `
      <ca-form-field>
        <ca-label>Fecha de nacimiento</ca-label>
        <ca-datepicker [(ngModel)]="date" name="datepicker" noCalendar> </ca-datepicker>
      </ca-form-field>`
		}
  };

  caseLimitDates: ComponentDoc = {
		title: `Limitación de fechas seleccionables`,
		description: `
    <p>Para limitar el rango de fechas que se podrán seleccionar, podemos añadir los atributos <code class="attribute">minDate</code> y/o <code class="attribute">maxDate</code> asignándole una fecha en formato DD/MM/YYYY o timestamp.</p>
    <p>En este caso los días fuera del rango aparecen deshabilitadas en el calendario.</p>
    `,
		codeExample: {
			html: `
      <ca-form-field>
        <ca-label>Fecha de nacimiento</ca-label>
        <ca-datepicker [(ngModel)]="birthdayDate" name="datepicker" minDate="15/10/2020" maxDate="02/05/2021"></ca-datepicker>
      </ca-form-field>
        `
		}
  };

  caseRangeDate: ComponentDoc = {
		title: `datepicker con rango de fechas`,
    description: `
    <p>Para generar un datepicker con rango de fechas, le añadiremos el atributo <code class="attribute">range</code> </p>
    <p>Si utilizamos este tipo de datepicker tendremos en cuenta que tanto el formato de entrada como el de salida ha de ser un array</P>
    <p>este tipo de datepicker no es compatible con el de tipo hora</p>`
    ,

		codeExample: {
      html: `
      <ca-form-field>
				<ca-label>Seleccione un rango de fechas</ca-label>
				<ca-datepicker [(ngModel)]="rangeDate" range> </ca-datepicker>
			</ca-form-field>

      `
		}
  };

  caseEntryDate: ComponentDoc = {
		title: `Parseo de fecha tipo 'DD/MM/AAAA' a timestamp para que la acepte el componente`,
    description: `
    <p>Suponemos que recibimos una fecha, por ejemplo 30/09/2021, que queremos transformar a timestamp para que el componente la pueda rendereizar correctamente.
    Por ello, emplearemos un método que convierta dicho <em>string</em> de fecha a timestamp en el <em>TypeScript</em> y se lo pasaremos al control correspondiente.</p>`,
		codeExample: {
      html: `
      <form [formGroup]="formFormat">
        <ca-form-field>
          <ca-label>Fecha de entrada</ca-label>
          <ca-datepicker formControlName="entryDate"></ca-datepicker>
        </ca-form-field>
      </form>`,
      ts: `
      constructor(private _fb: FormBuilder) {}
      formFormat: FormGroup;
      entryDate = '30/09/2021';

      esStringDatetoTimestamp(date: string): number {
        const splitted = date.split('/');
        return new Date(splitted[1]+'/'+splitted[0]+'/'+splitted[2]).getTime();
      }

      ngOnInit(): void {
        this.formFormat = this._fb.group({
          entryDate: this.esStringDatetoTimestamp(this.entryDate)
        });
      }`
		}
  };

  caseOutputDate: ComponentDoc = {
		title: `Parseo de timestamp devuelto por el componente a fecha tipo 'DD/MM/AAAA'`,
    description: `
    <p>Ahora vamos a convertir el timestamp, tipo <em>number</em>, devuelto por el datepicker al formato 'DD/MM/AAAA'.
    Por ello, emplearemos un método en el <em>TypeScript</em> que convierta el timestamp a <em>string</em> de fecha en el formato elegido</p>`,
		codeExample: {
      html: `
      <form [formGroup]="formFormat">
        <ca-form-field>
          <ca-label>Fecha de salida</ca-label>
          <ca-datepicker formControlName="exitDate"></ca-datepicker>
        </ca-form-field>
        <div class="my-1 d-flex flex-column">
          <span>timestamp devuelto por el control: {{formFormat.get('exitDate').value}}</span>
          <span>Fecha en formato 'DD/MM/AAAA': {{timestampToString(formFormat.get('exitDate').value)}}</span>
        </div>
      </form>`,
      ts: `
      constructor(private _fb: FormBuilder) {}
      formFormat: FormGroup;

      timestampToString(value: number): string {
        if (value && value === value) {
          const date = Intl.DateTimeFormat('en-GB')
            .format(new Date(value))
          return date.replace(/[^ -~]/g,''); // Para que funcione en IE
        } else {
          return '';
        }
      }

      ngOnInit(): void {
        this.formFormat = this._fb.group({
          exitDate: ''
        });
      }`
		}
  };

  caseShowOnStart: ComponentDoc = {
		title: `Datepicker con calendario abierto por defecto`,
    description: `
    <p>Si se desea mostrar el calendario por defecto, simplemente bastará con añadir el attributo <code class="attribute">showOnStart</code> al componente.</p>`,
		codeExample: {
      html: `
      <ca-form-field>
        <ca-label>Fecha de nacimiento</ca-label>
        <ca-datepicker [(ngModel)]="date" name="datepicker" showOnStart> </ca-datepicker>
      </ca-form-field>

      `
		}
  };

	form: FormGroup;
	date = new Date('2020/12/05').valueOf();
	required = true;
	constructor(private _fb: FormBuilder) {}
  formFormat: FormGroup;
  entryDate = '30/09/2021';

  timestampToString(value: number): string {
    if (value && value === value) {
      const date = Intl.DateTimeFormat('en-GB')
        .format(new Date(value))
      return date.replace(/[^ -~]/g,''); // Para que funcione en IE
    } else {
      return '';
    }
  }

  esStringDatetoTimestamp(date: string): number {
    const splitted = date.split('/');
    return Number(new Date(splitted[1]+'/'+splitted[0]+'/'+splitted[2]));
  }
  reset(){
    this.form.reset();
  }

  setCurrentDate(){
    this.form.get('date').setValue(new Date().valueOf())
    this.dateWithtime = new Date('2021/11/16 14:00:00').valueOf();
  }

  resetNgModel(){
    this.birthdayDate = null;
  }


  onChange(event: any){
    console.log('ngModel change:', event);

  }

	ngOnInit(): void {

		this.form = this._fb.group({
      date: '',
      dateRequiered: ['', [Validators.required]],
      dateDisabled: [{value: '', disabled: true}],
      defaultDate: [new Date('1980-09-05T19:30:00').valueOf()],
      rangeInit: [''],
      rangeEnd: [''],
      formatDate: ''
		});

		this.form.controls['date'].valueChanges.subscribe((value) => console.log(value));

    this.formFormat = this._fb.group({
      entryDate: this.esStringDatetoTimestamp(this.entryDate),
      exitDate: ''
    })
  }
}
