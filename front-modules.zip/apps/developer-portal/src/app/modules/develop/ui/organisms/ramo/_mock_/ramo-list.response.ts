import { RamosResponse } from '@global-front-components/common';

export const RAMOS_RESPONSE_MOCK: RamosResponse = {
	serviceId: 'ConsultaRamosSrv',
	outputMap: {
		mapacoddescripcion: [
			{
				codigo: '01',
				descripcion: 'MAAF AUTO'
			},
			{
				codigo: '11',
				descripcion: 'ACCIDENTES'
			},
			{
				codigo: '12',
				descripcion: 'CAUCION'
			},
			{
				codigo: '14',
				descripcion: 'AUTOS'
			},
			{
				codigo: '15',
				descripcion: 'CAZADORES'
			},
			{
				codigo: '16',
				descripcion: 'TODO RIESGO CONSTRUCCION'
			},
			{
				codigo: '17',
				descripcion: 'AVAL HIPOTECARIO'
			},
			{
				codigo: '18',
				descripcion: 'CRISTALES'
			},
			{
				codigo: '19',
				descripcion: 'GANADO'
			},
			{
				codigo: '21',
				descripcion: 'INCENDIOS'
			},
			{
				codigo: '22',
				descripcion: 'MAQUINARIA LEASING'
			},
			{
				codigo: '23',
				descripcion: 'R.C.NUCLEAR'
			},
			{
				codigo: '24',
				descripcion: 'PERDIDAS PECUNIARIAS'
			},
			{
				codigo: '25',
				descripcion: 'RESPONSABILIDAD CIVIL'
			},
			{
				codigo: '26',
				descripcion: 'ROBO'
			},
			{
				codigo: '27',
				descripcion: 'ROBO COMBINADO'
			},
			{
				codigo: '28',
				descripcion: 'TRANSPORTES'
			},
			{
				codigo: '29',
				descripcion: 'VIDA'
			},
			{
				codigo: '30',
				descripcion: 'MULTIRRIESGOS'
			},
			{
				codigo: '31',
				descripcion: 'AGRARIOS'
			},
			{
				codigo: '33',
				descripcion: 'INCAPACIDAD TEMPORAL Y DESEMPLEO'
			},
			{
				codigo: '34',
				descripcion: 'DECESOS'
			},
			{
				codigo: '35',
				descripcion: 'SALUD'
			},
			{
				codigo: '36',
				descripcion: 'ASISTENCIA VIAJE'
			},
			{
				codigo: '37',
				descripcion: 'DEFENSA JURIDICA'
			},
			{
				codigo: '51',
				descripcion: 'GESTIÓN JUDICIAL CORPORATIVOS'
			},
			{
				codigo: '55',
				descripcion: 'POL.FICTICIAS APERTURA EXP.EXTRANJEROS'
			},
			{
				codigo: '99',
				descripcion: 'GENERICO NGA'
			}
		]
	}
};
