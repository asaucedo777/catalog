import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ComponentDocModule } from '../../../../components/component-doc/component-doc.module';
import { CheckDataServiceView } from './check-data/check-data-service.view';
import { ClientValueServiceView } from './client-value/client-value-service.view';
import { CodPostalServiceView } from './cod-postal/cod-postal-service.view';
import { CompaniesServiceView } from './companies/companies-service.view';
import { DocumentTypeServiceView } from './document-type/document-type-service.view';
import { DocumentServiceView } from './document/document-service.view';
import { FondosServiceView } from './fondo/fondo-service.view';
import { GlobalPositionServiceView } from './global-position/global-position-service.view';
import { MenuApplicationsServiceView } from './menu-applications/menu-applications-service.view';
import { PopulationServiceView } from './population/population-service.view';
import { ProvincesServiceView } from './provinces/provinces-service.view';
import { RamoServiceView } from './ramo/ramo-service.view';
import { ServicesRoutingModule } from './services-routing.module';
import { ServicesView } from './services.view';
import { SessionHandlerView } from './session-handler/session-handler.view';
import { SexoServiceView } from './sexo/sexo-service.view';
import { ModaServiceView } from './moda/moda-service.view';
import { RoadTypeServiceView } from './road-type/road-type-service.view';
import { SubmodaServiceView } from './submoda/submoda-service.view';
import { SubPlanServiceView } from './sub-plan/sub-plan-service.view';
import { PlanServiceView } from './plan/plan-service.view';
@NgModule({
  declarations: [
    ClientValueServiceView,
    CompaniesServiceView,
    GlobalPositionServiceView,
    ProvincesServiceView,
    DocumentServiceView,
    ServicesView,
    SessionHandlerView,
    DocumentTypeServiceView,
    MenuApplicationsServiceView,
    CodPostalServiceView,
    CheckDataServiceView,
    SexoServiceView,
    ModaServiceView,
    RamoServiceView,
    FondosServiceView,
    RoadTypeServiceView,
    SubmodaServiceView,
    SubPlanServiceView,
    PlanServiceView,
    PopulationServiceView
  ],
  imports: [
    CommonModule,
    ComponentDocModule,
    NgbModule,
    ServicesRoutingModule,
    RouterModule,
  ],
})
export class ServicesModule {}
