import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EdocsTableView } from './edocs-table.view';

describe('EdocsTableView', () => {
  let component: EdocsTableView;
  let fixture: ComponentFixture<EdocsTableView>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EdocsTableView ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EdocsTableView);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
