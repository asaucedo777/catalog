import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';

@Component({
	templateUrl: 'radio-button.view.html',
	styleUrls: ['radio-button.view.scss']
})
export class RadioButtonView implements OnInit {
	favoriteLanguage = 'Phyton';
  options = ['Opción 1', 'Opción 2', 'Opción 3'];
	languagues = ['JavaScript', 'Java', 'Phyton', 'Assembly'];
  frameworks = ['Angular', 'React', 'Vue', 'Vanilla Js'];
  form: FormGroup;
  optionsForm: FormGroup;

  moduleContent = `import { CaRadioButtonModule  } from '@global-front-components/ui';`;
  formModuleContent = `import { CaRadioButtonModule, CaFormFieldModule  } from '@global-front-components/ui';`;

  caseBasic: ComponentDoc = {
    title: 'Radio Group',
    description: `Para utilizarlo debemos añadir tantas etiquetas <code class="tag">ca-radio-button</code> como opciones necesitemos.
    Añadiendole el attributo <code class="attribute"> value</code> y un texto entre las etiquetas para el label. Estas etiquetas estarán dentro de la etiqueta <code class="tag">ca-radio-group</code>. Y a esta le añadiremos los atributos
    <code class="attribute">id</code> y <code class="attribute">name</code>.`,
    codeExample: {
      html: `
      <ca-radio-group id="uno" name="basic">
        <ca-radio-button value="1" >value 1</ca-radio-button>
        <ca-radio-button value="2" >value 2</ca-radio-button>
      </ca-radio-group>`
    }
  };

  caseDefaultValue: ComponentDoc = {
    title: 'Con valor por defecto',
    description: `Con el atributo <code class="attribute">value</code> en <code class="tag">ca-radio-button</code>, daremos un valor por defecto. Este valor debe coincidir con unos de los radio.`,
    codeExample: {
      html: `
      <ca-radio-group id="uno" name="basic" value="2">
        <ca-radio-button value="1" >value 1</ca-radio-button>
        <ca-radio-button value="2" >value 2</ca-radio-button>
      </ca-radio-group>`
    }
  };

  casePositionLabel: ComponentDoc = {
    title: 'Posicionando el label',
    description: `Añadiendo el atributo <code class="attribute">labelPosition</code> con los valores <b>before</b> o <b>after</b> podemos decidir si
    el label se posiciona delante o detras del radio.`,
    codeExample: {
      html: `
      <ca-radio-group id="uno" name="position" labelPosition="before">
        <ca-radio-button value="1" >value 1</ca-radio-button>
        <ca-radio-button value="2" >value 2</ca-radio-button>
      </ca-radio-group>`
    }
  };

  caseNgModel: ComponentDoc = {
    title: 'RadioButton con NgModel',
    description: `podemos utilizar el radio con <code class="attribute">ngModel</code>.`,
    codeExample: {
      html: `
      <ca-radio-group id="tres" name="model" [(ngModel)]="favoriteLanguage">
        <ca-radio-button *ngFor="let item of languagues"[value]="item">{{item}}</ca-radio-button>
      </ca-radio-group>`,
      ts: `
      public favoriteLanguage = 'phyton';
      public languagues = ['JavaScript', 'Java', 'phyton', 'Assembly'];
      `
    }
  };

  caseReactiveForm: ComponentDoc = {
    title: 'RadioButton en formulario reactivo',
    description: `Tambien podemos utilizar el radio dentro de un formulario reactivo .`,
    codeExample: {
      html:  `
      <form [formGroup]="form">
        <ca-radio-group id="react" name="reactive" formControlName="favoriteFramework">
          <ca-radio-button *ngFor="let item of frameworks"[value]="item">{{item}}</ca-radio-button>
        </ca-radio-group>
      </form>`,
      ts: `
      public form: FormGroup;
      frameworks = ['Angular', 'React', 'Vue', 'Vanilla Js'];

      constructor(private fb: FormBuilder) {}

      ngOnInit() {
        this.form = this.fb.group({ favoriteFramework: ['Angular'] });
      }
      `
    }
  };

  caseBasicMin: ComponentDoc = {
    title: 'Radio Group tamaño mínimo',
    description: `Para utilizarlo debemos añadir tantas etiquetas <code class="tag">ca-radio-button</code> como opciones necesitemos.
    Añadiendole el atributo <code class="attribute"> value</code> y la directiva <code class="attribute">ca-min-component</code>, y un texto entre las etiquetas para el label. Estas etiquetas estarán dentro de la etiqueta <code class="tag">ca-radio-group</code>. Y a esta le añadiremos los atributos
    <code class="attribute">id</code> y <code class="attribute">name</code>.`,
    codeExample: {
      html: `
      <ca-radio-group id="uno" name="basic-min">
        <ca-radio-button value="1" ca-min-component>value 1</ca-radio-button>
        <ca-radio-button value="2" ca-min-component>value 2</ca-radio-button>
      </ca-radio-group>`
    }
  };

  caseBasicForm: ComponentDoc = {
    title: 'Radio Group con Label y hint',
    codeExample: {
      html: `
      <ca-label>Label</ca-label>
      <ca-radio-group id="uno" name="basic">
        <ca-radio-button value="1">value 1</ca-radio-button>
        <ca-radio-button value="2">value 2</ca-radio-button>
      </ca-radio-group>
      <ca-hint>Hint</ca-hint>`
    }
  };

  caseErrorsForm: ComponentDoc = {
    title: 'RadioButton con errores',
    codeExample: {
      html:  `
      <form [formGroup]="form">
        <ca-label required>Elige una opción</ca-label>
        <ca-radio-group id="options-error" name="options" formControlName="option">
          <ca-radio-button *ngFor="let opt of options" [value]="opt">{{ opt }}</ca-radio-button>
        </ca-radio-group>
        <ca-hint *ngIf="form.get('option').valid">Opciones populares</ca-hint>
        <ca-error *ngIf="form.get('option').invalid">Campo obligatorio</ca-error>
      </form>`,
      ts: `
      public form: FormGroup;
      options = ['Opción 1', 'Opción 2', 'Opción 3'];

      constructor(private fb: FormBuilder) {}

      ngOnInit() {
        this.form = this.fb.group({ option: ['', [Validators.required]]});
      }
      `
    }
  };

	constructor(private fb: FormBuilder) {}

	ngOnInit() {
		this.form = this.fb.group({ favoriteFramework: ['Angular'] });
    this.optionsForm = this.fb.group({ option: ['', [Validators.required]]});
	}
}
