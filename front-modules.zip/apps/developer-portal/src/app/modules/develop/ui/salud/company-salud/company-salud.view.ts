import { Component, OnInit } from '@angular/core';
import {
  combineLatest,
  Observable,
  of
} from 'rxjs';
import {
  catchError,
  debounceTime,
  distinctUntilChanged,
  map,
  switchMap
} from 'rxjs/operators';
import {
  CaCompaniesSaludService,
  CompaniesSaludResponse,
  CompanySalud
} from '@global-front-components/salud';

import { ComponentDoc } from '../../../../../components/component-doc/component-doc.interface';
import { COMPANIES_SALUD_RESPONSE_MOCK } from './_mock_/companies-salud-list.response';

@Component({
  templateUrl: 'company-salud.view.html',
  styleUrls: ['company-salud.view.scss']
})


export class CompanySaludViewComponent implements OnInit {
  constructor(
    private _caCompaniesSaludService: CaCompaniesSaludService
  ) { }
  companies: CompanySalud[];
  company: CompanySalud;
  companyFound: CompanySalud;
  selectedCompany: CompanySalud;

  caseCompaniesSelect: ComponentDoc = {
    title: 'Componente Seleccionable de Compañías',
    description: `
    `,
    codeExample: {
      html: `
      <ca-form-field>
        <ca-select
          placeholder="Seleccione su compañía"
          keyValue="denCia"
          [options]="companies"
          [(ngModel)]="selectedCompany"
        ></ca-select>
        <pre class="mt-2" *ngIf="selectedCompany">
         {{ selectedCompany | json }}
        </pre>
      </ca-form-field>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { Company, CompaniesSaludResponse, CaCompaniesSaludService } from '@global-front-components/salud';

      @Component({
        selector: 'company-select-example',
        templateUrl: 'company-select-example.component.html',
        styleUrls: ['company-select-example.component.scss']
      })

      export class CompanySelectExampleComponent implements OnInit {
        constructor( private _CaCompaniesSaludService: CaCompaniesSaludService ) { }

        companies: Company[];
        selectedCompany: Company;

        ngOnInit() {
          const endpoint: string = '/lib-core-salud-sb/api/salud/companies';
         
          this._CaCompaniesSaludService.getCompanies(endpoint).subscribe((response: CompaniesSaludResponse) => {
            this.companies = response.outputMap.lista;
          })
        }
      }`
    }
  }

  codeCompaniesTypeahead: ComponentDoc = {
    title: 'Componente Predictivo de compañías',
    description: `Hay dos formas de emplear este componente predictivo. Por un lado se puede hacer una única llamada al servicio de compañías que nos devuelva toda la lista y filtrar a través del componente,
    o bien, llamar al servicio cada vez que el usuario introduce un valor en el <code class="tag">input</code>.
    <br />
    Primeramente se describe como implementarlo con una única llamada incial.`,
    codeExample: {
      html: `
      <ca-form-field>
        <ca-label>Compañía</ca-label>
        <input
          type="text"
          placeholder="Busque una compañía"
          [caTypeahead]="search"
          [inputFormatter]="companyFormatter"
          [(ngModel)]="company"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="company">
        {{ company | json }}
      </pre>`,
      ts: `
      import { Component, OnInit } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
      import { Company, CompaniesSaludResponse, CaCompaniesSaludService } from '@global-front-components/salud';

      @Component({
        selector: 'company-typeahead-example',
        templateUrl: 'company-typeahead-example.component.html',
        styleUrls: ['company-typeahead-example.component.scss']
      })

      export class CompanyTypeaheadExampleComponent implements OnInit {
        constructor( private _CaCompaniesSaludService: CaCompaniesSaludService ) { }

        companies: Company[];
        company: Company;

        companyFormatter = (x:{denCia: string}) => x.denCia;

        search = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            map(term => term === '' ? []
              : this.companies.filter(v => v.denCia.toLowerCase().indexOf(term.toLowerCase()) > -1))
          )

        ngOnInit() {
          const endpoint: string = '/lib-core-salud-sb/api/salud/companies';
         
          this._CaCompaniesSaludService.getCompaniesSalud(endpoint).subscribe((response: CompaniesSaludResponse) => {
            this.companies = response.outputMap.lista;
          })
        }
      }`

    }
  }

  codeCompaniesTypeaheadService: ComponentDoc = {
    description: `A continuación se describe como implementarlo con llamadas al servicio cuando el usuario interactúe.`,
    codeExample: {
      html: `
      <ca-form-field>
        <ca-label>Compañía</ca-label>
        <input
          type="text"
          placeholder="Busque una compañía"
          [caTypeahead]="searchCompanies"
          [inputFormatter]="companyFormatter"
          [(ngModel)]="companyFound"
        />
      </ca-form-field>
      <pre class="mt-2" *ngIf="companyFound">
        {{ companyFound | json }}
      </pre>`,
      ts: `
      import { Component } from '@angular/core';
      import { Observable } from 'rxjs';
      import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
      import { Company, CompaniesSaludResponse, CaCompaniesSaludService } from '@global-front-components/salud';

      @Component({
        selector: 'company-typeahead-example',
        templateUrl: 'company-typeahead-example.component.html',
        styleUrls: ['company-typeahead-example.component.scss']
      })

      export class CompanyTypeaheadExampleComponent {
        constructor( private _CaCompaniesSaludService: CaCompaniesSaludService ) { }

        companyFound: Company;

        companyFormatter = (x:{denCia: string}) => x.denCia;

        searchCompanies = (text$: Observable<string>) =>
          text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            switchMap(term => {
              const endpoint: string = '/lib-core-salud-sb/api/salud/companies';

              return this._CaCompaniesSaludService.getCompaniesSalud(endpoint)
            })
            ).pipe(map((response: CompaniesSaludResponse) => response.outputMap.lista)
          );
      }`
    }
  }

  companyFormatter = (x:{descCorta: string}) => x.descCorta;

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      map(term => term === '' ? []
        : this.companies.filter(v => v.descCorta.toLowerCase().indexOf(term.toLowerCase()) > -1))
    )

  searchCompanies = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      switchMap(term => {
        const endpoint: string = '/lib-core-salud-sb/api/salud/companies';
       
        return combineLatest([this._getCompaniesMock(endpoint), of(term)])
       })
      )
      .pipe(map(([response, term]) => term === '' ? []
          : this.companies.filter(v => v.descCorta.toLowerCase().indexOf(term.toLowerCase()) > -1))
      );

  private _getCompaniesMock(endpoint: string): Observable<CompaniesSaludResponse> {
    return this._caCompaniesSaludService.getCompaniesSalud(endpoint).pipe(catchError(() => {
      return of (<CompaniesSaludResponse>COMPANIES_SALUD_RESPONSE_MOCK);
    }))
  }

  ngOnInit() {
    const endpoint: string = '/lib-core-salud-sb/api/salud/companies';
  
    this._getCompaniesMock(endpoint).subscribe((response: CompaniesSaludResponse) => {
      this.companies = response._embedded.companies;
    })
  }
}
