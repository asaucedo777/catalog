import { CheckDataResponse } from '@global-front-components/common';

export const CHECK_DATA_INVALID_RESPONSE_MOCK: CheckDataResponse = {
	serviceId: 'ChequarDatosCuentaSRV',
	outputMap: {
		entId: '2100',
		ofiId: '1028',
		dig: '44',
		numCta: '0200097941',
		digCorrecto: '94',
		mensaje: 'Valores incorrectos: 2100, 1028, 44, 0200097941',
		error: '-107'
	}
};

export const CHECK_DATA_RESPONSE_MOCK: CheckDataResponse = {
	serviceId: 'ChequarDatosCuentaSRV',
	outputMap: {
		iban: 'ES1621001027440200097941',
		bic: 'CAIXESBBXXX',
		error: '0',
		entId: '2100',
		dig: '44',
		ofiId: '1027',
		numCta: '0200097941'
	}
};

export const CHECK_DATA_IBAN_INVALID_RESPONSE_MOCK: CheckDataResponse = {
	serviceId: 'ChequarDatosCuentaSRV',
	outputMap: {
		iban: 'ES1621001027440200097951',
		bic: 'CAIXESBBXXX',
		error: '-115',
		mensaje: 'Error en la  verificaci n del IBAN. El c digo de error es  162'
	}
};
