import { Component } from '@angular/core';

@Component({
  templateUrl: 'display.view.html'
})
export class DisplayView {

  columnClassList = [
    {type: 'Column', title: 'Una columna', listItem: [
      {className: 'ca-column-1', description: 'Divide el contenido en 1 columna.'},
      {className: 'ca-column-1-2', description: 'Divide el contenido en 2 columna.'},
      {className: 'ca-column-1-3', description: 'Divide el contenido en 3 columna.'},
      {className: 'ca-column-1-4', description: 'Divide el contenido en 4 columna.'},
      {className: 'ca-column-1-5', description: 'Divide el contenido en 5 columna.'},
      {className: 'ca-column-1-6', description: 'Divide el contenido en 6 columna.'},
      {className: 'ca-column-1-7', description: 'Divide el contenido en 7 columna.'},
      {className: 'ca-column-1-8', description: 'Divide el contenido en 8 columna.'},
      {className: 'ca-column-1-9', description: 'Divide el contenido en 9 columna.'},
      {className: 'ca-column-1-10', description: 'Divide el contenido en 10 columna.'},
      {className: 'ca-column-1-11', description: 'Divide el contenido en 11 columna.'},
      {className: 'ca-column-1-12', description: 'Divide el contenido en 12 columna.'},
    ]}
  ];

}