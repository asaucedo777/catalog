import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckDataView } from './check-data/check-data.view';
import { ClientValueView } from './client-value/client-value.view';
import { CompanyView } from './company/company.view';
import { DocumentTypeView } from './document-type/document-type.view';
import { CodPostalView } from './cod-postal/cod-postal.view';
import { DocumentView } from './document/document.view';
import { EdocsTableView } from './edocs-table/edocs-table.view';
import { GlobalPositionView } from './global-position/global-position.view';
import { OrganismsView } from './organisms.view';
import { ProvincesView } from './provinces/provinces.view';
import { RamoView } from './ramo/ramo.view';
import { RoadTypeView } from './road-type/road-type.view';
import { SubmodaView } from './submoda/submoda.view';
import { ModaView } from './moda/moda.view';
import { PlanPenView } from './plan/plan.view';
import { FondoView } from './fondo/fondo.view';
import { SubPlanView } from './sub-plan/sub-plan.view';
import { SexoView } from './sexo/sexo.view';
import { PopulationView } from './population/population.view';

const routes: Routes = [
	{
		path: '',
		component: OrganismsView,
		children: [
			{
				path: 'company',
				component: CompanyView
			},
			{
				path: 'edocs-table',
				component: EdocsTableView
			},
			{
				path: 'global-position',
				component: GlobalPositionView
			},
			{
				path: 'provinces',
				component: ProvincesView
			},
			{
				path: 'submoda',
				component: SubmodaView
			},
			{
				path: 'client-value',
				component: ClientValueView
			},
			{
				path: 'document',
				component: DocumentView
			},
			{
				path: 'document-type',
				component: DocumentTypeView
			},
			{
				path: 'ramo',
				component: RamoView
			},
			{
				path: 'check-data',
				component: CheckDataView
			},
			{
				path: 'moda',
				component: ModaView
			},
			{
				path: 'plan',
				component: PlanPenView
			},
			{
				path: 'fondo',
				component: FondoView
			},
			{
				path: 'road-type',
				component: RoadTypeView
			},
			{
				path: 'sub-plan',
				component: SubPlanView
			},
			{
				path: 'sexo',
				component: SexoView
			},
			{
				path: 'cod-postal',
				component: CodPostalView
			},
			{
			  path: "population",
			  component: PopulationView,
			},
		]
	}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OrganismsRoutingModule {}
