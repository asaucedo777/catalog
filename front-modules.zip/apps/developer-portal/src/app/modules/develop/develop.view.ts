import { Component } from "@angular/core";
import { Sidebar } from "../../models/sidebar.interface";

@Component({
  selector: "ca-develop",
  templateUrl: "./develop.view.html",
  styleUrls: ["./develop.view.scss"],
})
export class DevelopView {
  constructor() {}
  sidebarItems: Sidebar[] = [
    {
      title: "Átomos",
      subItems: [
        {
          title: "Breadcrumb",
          link: "atoms/breadcrumb/prueba1/prueba2/prueba3",
        },
        { title: "Button", link: "atoms/button" },
        { title: "Card", link: "atoms/card" },
        { title: "Cdk Table", link: "atoms/cdk-table" },
        { title: "Checkbox", link: "atoms/checkbox" },
        { title: "Client Value", link: "atoms/client-value" },
        { title: "Datepicker", link: "atoms/datepicker" },
        { title: "Download", link: "atoms/download" },
        { title: "Form Field", link: "atoms/form-field" },
        { title: "Header", link: "atoms/header" },
        { title: "Input", link: "atoms/input" },
        { title: "Input File", link: "atoms/input-file" },
        { title: "Menu", link: "atoms/menu" },
        { title: "Modal", link: "atoms/modal" },

        { title: "Pagination", link: "atoms/pagination" },
        { title: "Radio Button", link: "atoms/radio-button" },
        { title: "Select", link: "atoms/select" },
        { title: "Sidenav Menu", link: "atoms/sidenav-menu" },
        { title: "Slide Toggle", link: "atoms/slide-toggle" },
        { title: "Snackbar", link: "atoms/snackbar" },
        { title: "Spinner", link: "atoms/spinner" },
        { title: "Tabs", link: "atoms/tabs" },
        { title: "Textarea", link: "atoms/textarea" },
        { title: "Tooltip", link: "atoms/tooltip" },
        { title: "Tree", link: "atoms/tree" },
        { title: "Typeahead", link: "atoms/typeahead" },
      ],
    },
    {
      title: "Moléculas",
      subItems: [
        { title: "Accordion", link: "molecules/accordion" },
        { title: "Menu Header", link: "molecules/menu-header" },
        { title: "Transfer", link: "molecules/transfer" },
        { title: "Sidebar", link: "molecules/sidebar" },
      ],
    },
    {
      title: 'Organismos', subItems: [
        { title: 'Compañía', link: 'organisms/company' },
        { title: 'eDOCS Table', link: 'organisms/edocs-table' },
        { title: 'Posición Global', link: 'organisms/global-position' },
        { title: 'Provincias', link: 'organisms/provinces' },
        { title: 'Valor Cliente', link: 'organisms/client-value' },
        { title: 'Ramo', link: 'organisms/ramo' },
        { title: 'Documento', link: 'organisms/document' },
        { title: 'Tipo de Documento', link: 'organisms/document-type'},
        { title: 'Sexo', link: 'organisms/sexo'},
        { title: 'Sub-planes de pensión', link: 'organisms/sub-plan'},
        { title: 'Planes de Pensión', link: 'organisms/plan'},
        { title: 'Moda', link: 'organisms/moda' },
        { title: 'Fondos', link: 'organisms/fondo' },
        { title: 'Tipo de Vias', link: 'organisms/road-type' },
        { title: 'Submoda', link: 'organisms/submoda'},
      ]
    },
    {
      title: 'Servicios', subItems: [
        { title: 'Caducidad de sesión', link: 'services/session-handler' },
				{ title: 'Compañía', link: 'services/companies' },
				{ title: 'Menú de aplicaciones', link: 'services/menu-applications' },
				{ title: 'Posición Global', link: 'services/global-position' },
				{ title: 'Provincias', link: 'services/provinces' },
				{ title: 'Valor Cliente', link: 'services/client-value' },
				{ title: 'Ramo', link: 'services/ramo' },
				{ title: 'Documento', link: 'services/document' },
				{ title: 'Tipo de Documento', link: 'services/document-type' },
				{ title: 'Código Postal', link: 'services/cod-postal' },
				{ title: 'Sexo', link: 'services/sexo' },
				{ title: 'Sub-planes de pensión', link: 'services/sub-plan' },
				{ title: 'Planes de Pensión', link: 'services/plan' },
				{ title: 'Moda', link: 'services/moda' },
				{ title: 'Fondos', link: 'services/fondo' },
				{ title: 'Tipo de Vias', link: 'services/road-type' },
				{ title: 'Submoda', link: 'services/submoda' },
				{ title: 'Comprobar Datos Cuenta', link: 'services/check-data' },
				{ title: 'Poblaciones', link: 'services/population' }
      ]
    },
    {
      title: 'Extensiones',
      subItems: [
        {title: 'Ngx-Mask', link: 'extensions/mask'},
        { title: "Ngx-Charts", link: "extensions/ngx-charts" },
      ]
    },
    {
      title: "Utilidades CSS",
      subItems: [
        // { title: "Border", link: "utilities/border" },
        // { title: "Background", link: "utilities/background" },
        // { title: "Box-Shadow", link: "utilities/boxshadow" },
        // { title: "Color", link: "utilities/colors" },
        // { title: "Column", link: "utilities/column" },
        { title: "Bootstrap", link: "utilities/column" },
        { title: "Caser", link: "utilities/container" },
        // { title: "Display", link: "utilities/display" },
        // { title: "Flex", link: "utilities/flex" },
        // { title: "Grid", link: "utilities/grid" },
        // { title: "Heading", link: "utilities/header" },
        // { title: "Margin", link: "utilities/margin" },
        // { title: "Padding", link: "utilities/padding" },
        // { title: "Position", link: "utilities/position" },
        // { title: "Text", link: "utilities/text" },
        // { title: "Visibility", link: "utilities/visibility" },
        // { title: "Utilities", link: "utilities/utilities" },
      ],
    },
    {
      title: "Caser Salud",
      subItems: [
        { title: "Protocolo", link: "salud/protocolo" },
        { title: "Input Modal Filter", link: "salud/input-modal-filter" },
        { title: "Select Modal Filter", link: "salud/select-modal-filter" },
        { title: "Componente Compañías Salud", link: "salud/salud-companies" },
        { title: "Servicio Compañías", link: "salud/salud-companies-service" },
      ],
    },
  ];
}
