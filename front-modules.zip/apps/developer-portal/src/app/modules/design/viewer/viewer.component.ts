import { Component } from '@angular/core';
import { ActivatedRoute, NavigationEnd, NavigationStart, Router } from '@angular/router';
import { ComponentEstructure } from '../../../models/component-structure.interface';
import { ComponentsService } from '../../../providers/components.service';

@Component({
	selector: 'ca-viewer',
	templateUrl: './viewer.component.html',
	styleUrls: ['./viewer.component.scss']
})
export class Vieweromponent {
	public componetList: ComponentEstructure;
	public component: string;
	constructor(
		private componentService: ComponentsService,
		private router: Router,
		private activatedRoute: ActivatedRoute
	) {}

	private getComponentDoc(component): void {
		this.componentService.getComponents(component).subscribe(
			(res) => {
				this.componetList = res;
			},
			(err) => {
				console.log(err);
			}
		);
	}

	ngOnInit() {
		this.component = this.activatedRoute.snapshot.paramMap.get('comp');
		this.getComponentDoc(this.component);
		this.router.events.subscribe((event) => {
			if (event instanceof NavigationStart) {
				const adri = this.activatedRoute.snapshot.paramMap.get('comp');
				this.component = event.url.split('/')[event.url.split('/').length - 1];
				this.getComponentDoc(this.component);
			}
		});
	}
}
