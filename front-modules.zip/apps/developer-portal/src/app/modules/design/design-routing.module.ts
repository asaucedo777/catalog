import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ComposeView } from './compose-view/compose.view';
import { DesignView } from './design.view';
import { ResourcesComponent } from './resources/resources.component';
import { UseGuideComponent } from './use-guide/use-guide.component';
import { Vieweromponent } from './viewer/viewer.component';

const routes: Routes = [
	{
		path: '',
		component: DesignView,
		children: [
			{
				path: '',
				component: UseGuideComponent
			},
			{
				path: 'use-guide',
				component: UseGuideComponent
			},
			{
				path: 'component/:comp',
				component: Vieweromponent
			},
			{
				path: 'resources',
				component: ResourcesComponent
			},
			{
				path: 'compose-view',
				component: ComposeView
			}

		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class DesignRoutingModule {}
