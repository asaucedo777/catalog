import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { Component, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { CaFilterPipe, CaSortByPipe, SortConfig } from '@global-front-components/common';
import { CaModalOverlayService, IBreadCrumb } from '@global-front-components/ui';
import { BehaviorSubject, Subject } from 'rxjs';
import { debounceTime, takeUntil } from 'rxjs/operators';
import { ComponentDoc } from '../../../components/component-doc/component-doc.interface';
import { ModalComponent } from './modal-action/modal-action.view';

@Component({
  selector: 'ca-compose-view',
  templateUrl: './compose.view.html',
  styleUrls: ['./compose.view.scss'],
  providers: [CaFilterPipe, CaSortByPipe],
  encapsulation: ViewEncapsulation.None
})
export class ComposeView {

    dataBreadcrumb: IBreadCrumb[] = [
        {
          label: 'Diseño',
          url: '/develop/atoms/card'
        },
        {
          label: 'Composición de ventanas',
          url: '/develop/atoms/cdk-table'
        },
        {
          label: 'Vista tipo',
          url: '/develop/atoms/breadcrumb/prueba1/prueba2/prueba3'
        }
      ];

    toggAcFilter: boolean = true;
    toggAcResult: boolean = true;
    iconTextAccordion: string = 'keyboard_arrow_down';

    public formOptions = [
        {
          value: 'M',
          textValue: 'Masculino'
        },
        {
          value: 'F',
          textValue: 'Femenino'
        }
    ];

    arrayOptions = ['Opción 1','Opción 2','Opción 3','Opción 4','Opción 5'];

    frameworks = ['Angular', 'React', 'Vue', 'Vanilla Js'];
    pepe: string = '';

    private _destroy$: Subject<void> = new Subject();
    private _filterChange$: BehaviorSubject<string> = new BehaviorSubject(undefined);
    displayedColumns: string[] = [];
    dataSize: number;
    displayedTableData: any[] = [];
    page = 1;
    pageSize = 3;
    paginatedTableData: any[] = [];
    queryFilter = '';
    selectedRow: any;
    columns: TableColumn[] = [
      {
        id: 0,
        field: 'idPlantilla',
        value: 'ID plantillas',
        align: 'text-right'
      },
      {
        id: 1,
        field: 'tipoPlantilla',
        value: 'Tipo plantillas',
        align: 'text-left'
      },
      {
        id: 2,
        field: 'nombreFichero',
        value: 'Nombre Fichero',
        align: 'text-left'
      },
      {
        id: 3,
        field: 'descripcion',
        value: 'Descipción',
        align: 'text-right'
      },
      {
        id: 4,
        field: 'idPlantilla2',
        value: 'ID plantillas 2',
        align: 'text-right'
      },
      {
        id: 5,
        field: 'tipoPlantilla2',
        value: 'Tipo plantillas 2',
        align: 'text-left'
      },
      {
        id: 6,
        field: 'nombreFichero2',
        value: 'Nombre Fichero 2',
        align: 'text-left'
      },
      {
        id: 7,
        field: 'descripcion2',
        value: 'Descipción 2',
        align: 'text-right'
      },
      {
        id: 8,
        field: 'idPlantilla3',
        value: 'ID plantillas 3',
        align: 'text-right'
      },
      {
        id: 9,
        field: 'tipoPlantilla3',
        value: 'Tipo plantillas 3',
        align: 'text-left'
      },
      {
        id: 10,
        field: 'nombreFichero3',
        value: 'Nombre Fichero 3',
        align: 'text-left'
      },
      {
        id: 11,
        field: 'descripcion3',
        value: 'Descipción 3',
        align: 'text-right'
      }
    ];
    tableData = [
      {
        idPlantilla: 1,
        tipoPlantilla: 'Carta',
        nombreFichero: 'H',
        descripcion: 1.00794,
        rutaPlantilla: 1.00794,
        idPlantilla2: 1,
        tipoPlantilla2: 'Carta',
        nombreFichero2: 'H',
        descripcion2: 1.00794,
        rutaPlantilla2: 1.00794,
        idPlantilla3: 1,
        tipoPlantilla3: 'Carta',
        nombreFichero3: 'H',
        descripcion3: 1.00794
      },
      {
        idPlantilla: 1,
        tipoPlantilla: 'Carta1',
        nombreFichero: 'H',
        descripcion: 1.00794,
        rutaPlantilla: 1.00794,
        idPlantilla2: 1,
        tipoPlantilla2: 'Carta',
        nombreFichero2: 'H',
        descripcion2: 1.00794,
        rutaPlantilla2: 1.00794,
        idPlantilla3: 1,
        tipoPlantilla3: 'Carta',
        nombreFichero3: 'H',
        descripcion3: 1.00794
      },
      {
        idPlantilla: 1,
        tipoPlantilla: 'Carta2',
        nombreFichero: 'H',
        descripcion: 1.00794,
        rutaPlantilla: 1.00794,
        idPlantilla2: 1,
        tipoPlantilla2: 'Carta',
        nombreFichero2: 'H',
        descripcion2: 1.00794,
        rutaPlantilla2: 1.00794,
        idPlantilla3: 1,
        tipoPlantilla3: 'Carta',
        nombreFichero3: 'H',
        descripcion3: 1.00794
      },
      {
        idPlantilla: 1,
        tipoPlantilla: 'Carta3',
        nombreFichero: 'H',
        descripcion: 1.00794,
        rutaPlantilla: 1.00794,
        idPlantilla2: 1,
        tipoPlantilla2: 'Carta',
        nombreFichero2: 'H',
        descripcion2: 1.00794,
        rutaPlantilla2: 1.00794,
        idPlantilla3: 1,
        tipoPlantilla3: 'Carta',
        nombreFichero3: 'H',
        descripcion3: 1.00794
      },
      {
        idPlantilla: 1,
        tipoPlantilla: 'Carta4',
        nombreFichero: 'H',
        descripcion: 1.00794,
        rutaPlantilla: 1.00794,
        idPlantilla2: 1,
        tipoPlantilla2: 'Carta',
        nombreFichero2: 'H',
        descripcion2: 1.00794,
        rutaPlantilla2: 1.00794,
        idPlantilla3: 1,
        tipoPlantilla3: 'Carta',
        nombreFichero3: 'H',
        descripcion3: 1.00794
      },
      {
        idPlantilla: 1,
        tipoPlantilla: 'Carta5',
        nombreFichero: 'H',
        descripcion: 1.00794,
        rutaPlantilla: 1.00794,
        idPlantilla2: 1,
        tipoPlantilla2: 'Carta',
        nombreFichero2: 'H',
        descripcion2: 1.00794,
        rutaPlantilla2: 1.00794,
        idPlantilla3: 1,
        tipoPlantilla3: 'Carta',
        nombreFichero3: 'H',
        descripcion3: 1.00794
      },
      {
        idPlantilla: 1,
        tipoPlantilla: 'Carta6',
        nombreFichero: 'H',
        descripcion: 1.00794,
        rutaPlantilla: 1.00794,
        idPlantilla2: 1,
        tipoPlantilla2: 'Carta',
        nombreFichero2: 'H',
        descripcion2: 1.00794,
        rutaPlantilla2: 1.00794,
        idPlantilla3: 1,
        tipoPlantilla3: 'Carta',
        nombreFichero3: 'H',
        descripcion3: 1.00794
      },
      {
        idPlantilla: 1,
        tipoPlantilla: 'Carta7',
        nombreFichero: 'H',
        descripcion: 1.00794,
        rutaPlantilla: 1.00794,
        idPlantilla2: 1,
        tipoPlantilla2: 'Carta',
        nombreFichero2: 'H',
        descripcion2: 1.00794,
        rutaPlantilla2: 1.00794,
        idPlantilla3: 1,
        tipoPlantilla3: 'Carta',
        nombreFichero3: 'H',
        descripcion3: 1.00794
      },
      {
        idPlantilla: 1,
        tipoPlantilla: 'Carta8',
        nombreFichero: 'H',
        descripcion: 1.00794,
        rutaPlantilla: 1.00794,
        idPlantilla2: 1,
        tipoPlantilla2: 'Carta',
        nombreFichero2: 'H',
        descripcion2: 1.00794,
        rutaPlantilla2: 1.00794,
        idPlantilla3: 1,
        tipoPlantilla3: 'Carta',
        nombreFichero3: 'H',
        descripcion3: 1.00794
      },
      {
        idPlantilla: 1,
        tipoPlantilla: 'Carta9',
        nombreFichero: 'H',
        descripcion: 1.00794,
        rutaPlantilla: 1.00794,
        idPlantilla2: 1,
        tipoPlantilla2: 'Carta',
        nombreFichero2: 'H',
        descripcion2: 1.00794,
        rutaPlantilla2: 1.00794,
        idPlantilla3: 1,
        tipoPlantilla3: 'Carta',
        nombreFichero3: 'H',
        descripcion3: 1.00794
      },
      {
        idPlantilla: 1,
        tipoPlantilla: 'Carta10',
        nombreFichero: 'H',
        descripcion: 1.00794,
        rutaPlantilla: 1.00794,
        idPlantilla2: 1,
        tipoPlantilla2: 'Carta',
        nombreFichero2: 'H',
        descripcion2: 1.00794,
        rutaPlantilla2: 1.00794,
        idPlantilla3: 1,
        tipoPlantilla3: 'Carta',
        nombreFichero3: 'H',
        descripcion3: 1.00794
      }
    ];

    actionsToSelect = ['Descargar', 'Modificar', 'Eliminar'];
    actionSelected = '';

    caseOne: ComponentDoc = {
      title: 'Ejemplo de uso',
      description: `<p>Ejemplo de uso de pantalla tipo en aplicaciones Caser</p>`,
      codeExample: {
          html: `<ca-breadcrumb>
          <li
          ca-breadcrumb-item
          *ngFor="let item of dataBreadcrumb"
          >
              <a
              routerLink="{{item.url}}"
              routerLinkActive="ca-router-link-active"
              [routerLinkActiveOptions]="{exact:true}">
              {{item.label}}
              </a>
              <span class="material-icons">keyboard_arrow_right</span>
          </li>
      </ca-breadcrumb>
      <ca-card ui-3 class="mt-3">
          <div ca-card-title>Filtro de búsqueda</div>
          <div ca-card-content>
              <form [formGroup]="formBlur" class="row">
                  <ca-form-field class="col-3">
                      <ca-label>Nombre</ca-label>
                      <input
                        caInput
                        formControlName="name"
                        placeholder="Nombre"
                        type="text"
                        required />
                      <ca-hint>Introduce tu nombre</ca-hint>
                      <ca-error *ngIf="formBlur.controls['name'].errors?.required">El campo es requerido</ca-error>
                  </ca-form-field>
                  <ca-form-field class="col-3">
                      <ca-label>Apellido</ca-label>
                      <input
                        caInput
                        formControlName="surName"
                        placeholder="Apellido"
                        type="text"
                        required />
                      <ca-hint>Introduce tu apellido</ca-hint>
                      <ca-error *ngIf="formBlur.controls['surName'].errors?.required">El campo es requerido</ca-error>
                  </ca-form-field>
                  <ca-form-field class="col-4">
                      <ca-label>Email</ca-label>
                      <input
                        caInput
                        formControlName="email"
                        placeholder="Email"
                        type="text"
                        required />
                      <ca-hint>Introduce tu dirección de correo</ca-hint>
                      <ca-error *ngIf="formBlur.controls['email'].errors?.required">El campo es requerido</ca-error>
                      <ca-error *ngIf="formBlur.controls['email'].errors?.minlength">El campo debe tener 6 caracteres</ca-error>
                      <ca-error *ngIf="formBlur.controls['email'].errors?.email">Introduce una dirección de correo valida</ca-error>
                  </ca-form-field>
                  <ca-form-field class="col-2">
                      <ca-label>Fecha de nacimiento</ca-label>
                      <ca-datepicker
                          formControlName="birthday"
                          name="datepicker"
                          required
                      ></ca-datepicker>
                      <ca-error *ngIf="formBlur.controls['birthday'].errors?.required">El campo es requerido</ca-error>
                  </ca-form-field>
                  <ca-form-field class="col-3 mt-5">
                      <ca-label>Género (Simple)</ca-label>
                      <ca-select
                          placeholder="Género"
                          keyValue="textValue"
                          formControlName="genderControl"
                          [options]="formOptions"
                          required
                      ></ca-select>
                      <ca-error *ngIf="formBlur.controls['genderControl'].errors?.required">El campo es requerido</ca-error>
                  </ca-form-field>
                  <ca-form-field class="col-3 mt-5">
                      <ca-label>Opciones multiples</ca-label>
                      <ca-select
                          placeholder="Opciones multiples"
                          formControlName="multiple"
                          [options]="arrayOptions"
                          required
                          multiple
                          virtualScroll
                      ></ca-select>
                      <ca-error *ngIf="formBlur.controls['multiple'].errors?.required">El campo es requerido</ca-error>
                  </ca-form-field>
                  <ca-form-field class="col-4 mt-5">
                      <ca-label>Descripción</ca-label>
                      <textarea
                        caTextarea
                        formControlName="controlTextarea"
                        placeholder="Inserte aquí una descripción"
                        required
                      ></textarea>
                      <ca-hint>Introduce una descripción de cómo mínimo 20 carácteres</ca-hint>
                      <ca-error *ngIf="formBlur.controls['controlTextarea'].errors?.required">El campo es requerido</ca-error>
                      <ca-error *ngIf="formBlur.controls['controlTextarea'].errors?.minlength">El campo debe tener 20 caracteres como mínimo</ca-error>
                  </ca-form-field>
                  <div class="col-2 mt-5">
                      <ca-label>RadioButton</ca-label>
                      <ca-radio-group
                      id="react"
                      name="reactive"
                      formControlName="favoriteFramework"
                      required>
                          <ca-radio-button
                              *ngFor="let item of frameworks"
                              [value]="item">
                              {{item}}
                          </ca-radio-button>
                  </ca-radio-group>
                  </div>
                  <ca-checkbox
                      class="col-6 mt-5"
                      formControlName="controlOne">
                      Acepto política de privacidad de datos
                  </ca-checkbox>
                  <div class="col-6 mt-5 text-right">
                      <button class="ml-2" (click)="onCreateOption()" ca-button-secondary>Abrir modal</button>
                      <button class="ml-2" ca-button-secondary (click)="cleanFilter()">Limpiar</button>
                      <button class="ml-2"
                          type="submit"
                          [disabled]="formBlur.invalid || formBlur.controls['controlOne'].value === false"
                          ca-button>
                              Buscar
                          </button>
                  </div>
              </form>
              </div>
          </ca-card>
          <ca-card class="mt-3">
              <div ca-card-title>Resultado</div>
              <div ca-card-content>
                  <div class="row">
                      <ca-form-field class="col-3">
                        <ca-label [visible]="false">Filtro</ca-label>
                        <ca-icon>search</ca-icon>
                        <input caInput type="text" placeholder="" [(ngModel)]="queryFilter" (ngModelChange)="onFilter($event)" />
                      </ca-form-field>
                      <div class="offset-6 col-3">
                        <ca-form-field class="select">
                            <ca-select placeholder="Seleccione una acción"
                              [options]="actionsToSelect"
                              [(ngModel)]="actionSelected"
                              (ngModelChange)="onSelectedOption(selectedRow)"
                              [disabled]="!selectedRow">
                            </ca-select>
                        </ca-form-field>
                    </div>
                  <div class="col-12 mt-4">
                      <ng-container *ngIf="displayedTableData.length > 0; else noresult">
                        <table
                        cdk-table
                        [dataSource]="displayedTableData"
                        class="ca-table"
                        caResizableTable>
                          <ng-container *ngFor="let column of columns; let i = index" [cdkColumnDef]="column.field">
                            <th cdk-header-cell *cdkHeaderCellDef class="ca-table__header" [caResizeColumn]="true" [index]="i" resizeWithScroll>
                              <div class="ca-table__header-container justify-content-start">
                                  <span class="ca-table__header-wrapper">
                                    <span class="ca-table__header-text">{{ column.value }}</span>
                                  </span>
                                  <button ca-button-icon
                                    class="ca-button-icon ml-2" (click)="sortColumn(column)">
                                    <span class="material-icons size-xl">unfold_more</span>
                                  </button>
                                </div>
                            </th>
                            <td cdk-cell *cdkCellDef="let row; let i = index" class="ca-table__cell" #selectableCell>
                              <div class="ca-table__cell-container {{column.align}}">
                                <span class="ca-table__cell-text">
                                  {{ row[column.field] }}
                                </span>
                              </div>
                            </td>
                          </ng-container>
                          <thead class="ca-table__thead">
                            <tr cdk-header-row *cdkHeaderRowDef="displayedColumns"
                              class="ca-table__row ca-table__row--bordered ca-table__row--clean"></tr>
                          </thead>
                          <tbody class="ca-table__tbody">
                            <tr cdk-row *cdkRowDef="let row; columns: displayedColumns; let i = index" class="ca-table__row" [class.ca-table__row--selected]="isSelectedRow(row)"
                            (click)="onSelectedRow(row, i)"></tr>
                          </tbody>
                        </table>
                        <div class="d-flex justify-content-center ca-table__pagination-wrapper mt-3">
                          <ca-pagination [dataSize]="dataSize" [(page)]="page" [pageSize]="pageSize" (pageChange)="paginate()">
                          </ca-pagination>
                        </div>
                      </ng-container>
                    </div>
                    <ng-template #noresult>
                      <p>No se han encontrado resultados</p>
                    </ng-template>

              </div>
              <div class="row">
                  <div class="col-6">
                      <button ca-button-secondary>Volver</button>
                  </div>
                  <div class="col-6 text-right">
                      <button class="ml-2" ca-button-secondary>Exportar</button>
                      <button class="ml-2" ca-button>Guardar</button>
                  </div>
              </div>
              </div>
          </ca-card>
          `,
          css: `
          .ca-table {
            width: 100%;
            font-size: 14px;
            border-collapse: collapse;
            border: 1px solid #d0d2d3;
            &__row {
              &:nth-child(odd) {
                background-color: #eef2f5;
              }
              &:nth-child(even) {
                background-color: #ffffff;
              }
              &:hover {
                background-color: #dcf1f0;
              }
              &--bordered {
                border-bottom: 1px solid #d0d2d3;
              }
              &--clean {
                &:nth-child(odd) {
                  background-color: #ffffff;
                }
                &:hover {
                  background-color: inherit;
                }
              }
            }
            &__header {
              padding: 6px 16px;
              text-align: left;
              background-color: #ffffff;
              position: relative;

              &-container {
                display: flex;
                justify-content: center;
                align-items: center;
                overflow: hidden;
                text-overflow: ellipsis;
              }
              &-text {
                white-space: nowrap;
              }
              .ca-button-icon {
                flex-grow: 0;
                flex-shrink: 0;
                flex-basis: auto;
              }
            }
            &__cell {
              cursor: pointer;
              height: 32px;
              position: relative;
              padding: 0 16px;
              vertical-align: middle;
              max-width: 90px;
              &-container {
                overflow: hidden;
                text-overflow: ellipsis;
              }
              &-text {
                white-space: nowrap;
              }
            }
          }

          .cdk-drag-preview {
            font-family: Lato;
            font-size: 14px;
            color: #717578;
            font-weight: bold;
            display: flex;
            align-items: center;
          }

          .cdk-drag-placeholder {
            opacity: 0;
            cursor: e-resize;
          }

          .cdk-virtual-scroll-viewport {
            .cdk-virtual-scroll-content-wrapper {
              position: relative;
              overflow-x: scroll;
            }
          }

          .cdk-overlay-backdrop.cdk-overlay-backdrop-showing {
            &.dark-backdrop {
              background: rgba(83, 87, 90, 0.4);
            }
          }

          .cdk-overlay-container {
            z-index: 9999;
          }

        .ca-btn-icon__container {
            position: relative;
            padding-left: 35px;
        }

        .ca-btn-icon__container .ca-btn-icon__text {
            position: absolute;
            left: 10px;
        }

        .ca-button-icon,
        .ca-button-icon-primary {
            vertical-align: bottom;
            height: 35px;
            width: 35px;
        }`
      }
  };

  caseThree: ComponentDoc = {
    title: 'Ejemplo de uso',
    description: `<p>Ejemplo de uso de grid complejo en aplicaciones Caser</p>`,
    codeExample: {
        html: `<ca-card>
        <div ca-card-title>Composición</div>
        <div ca-card-content>
            <div class="row mt-3">
                <ca-form-field class="col-3">
                  <ca-label [visible]="false">Filtro</ca-label>
                  <ca-icon>search</ca-icon>
                  <input caInput type="text" placeholder="" [(ngModel)]="queryFilter" (ngModelChange)="onFilter($event)" />
                </ca-form-field>
                <div class="offset-6 col-3">
                  <ca-form-field class="select">
                      <ca-select placeholder="Seleccione una acción"
                        [options]="actionsToSelect"
                        [(ngModel)]="actionSelected"
                        (ngModelChange)="onSelectedOption(selectedRow)"
                        [disabled]="!selectedRow">
                      </ca-select>
                  </ca-form-field>
              </div>
            <div class="col-12 mt-4">
                <ng-container *ngIf="displayedTableData.length > 0; else noresult">
                  <table
                    cdk-table
                    [dataSource]="displayedTableData"
                    class="ca-table"
                    caResizableTable
                    (cdkDropListDropped)="tableDrop($event)"
                    cdkDropList
                    cdkDropListOrientation="horizontal">
                    <ng-container *ngFor="let column of columns; let i = index" [cdkColumnDef]="column.field">
                      <th cdk-header-cell *cdkHeaderCellDef
                        class="ca-table__header"
                        cdkDrag
                        caHeaderCell
                        cdkDropListLockAxis="x"
                        style="width: 'item.width}'">
                        <div class="ca-table__header-container justify-content-start">
                            <span class="ca-table__header-wrapper">
                              <span class="ca-table__header-text">{{ column.value }}</span>
                            </span>
                            <button ca-button-icon
                              class="ca-button-icon ml-2" (click)="sortColumn(column)">
                              <span class="material-icons size-xl">unfold_more</span>
                            </button>
                          </div>
                      </th>
                      <td
                      caCell
                      cdk-cell
                      *cdkCellDef="let row; let i = index"
                      class="ca-table__cell">
                      <div class="ca-table__cell-container">
                        <span class="ca-table__cell-text">
                          {{ row[column.field] }}
                        </span>
                      </div>
                    </td>
                    </ng-container>
                    <thead class="ca-table__thead">
                      <tr cdk-header-row *cdkHeaderRowDef="displayedColumns"
                        class="ca-table__row ca-table__row--bordered ca-table__row--clean"></tr>
                    </thead>
                    <tbody class="ca-table__tbody">
                      <tr cdk-row *cdkRowDef="let row; columns: displayedColumns; let i = index" class="ca-table__row" [class.ca-table__row--selected]="isSelectedRow(row)"
                      (click)="onSelectedRow(row, i)"></tr>
                    </tbody>
                  </table>
                  <div class="d-flex justify-content-center ca-table__pagination-wrapper mt-3">
                    <ca-pagination [dataSize]="dataSize" [(page)]="page" [pageSize]="pageSize" (pageChange)="paginate()">
                    </ca-pagination>
                  </div>
                  <div class="row">
                    <div class="col-6">
                        <button ca-button-secondary>Volver</button>
                    </div>
                    <div class="col-6 text-right">
                        <button class="ml-2" ca-button-secondary>Exportar</button>
                        <button class="ml-2" ca-button>Guardar</button>
                    </div>
                </div>
                </ng-container>
              </div>
              <ng-template #noresult>
                <p>No se han encontrado resultados</p>
              </ng-template>

        </div>
        </div>
    </ca-card>`,
        css: `
        .ca-table {
          width: 100%;
          font-size: 14px;
          border-collapse: collapse;
          border: 1px solid #d0d2d3;
          &__row {
            &:nth-child(odd) {
              background-color: #eef2f5;
            }
            &:nth-child(even) {
              background-color: #ffffff;
            }
            &:hover {
              background-color: #dcf1f0;
            }
            &--bordered {
              border-bottom: 1px solid #d0d2d3;
            }
            &--clean {
              &:nth-child(odd) {
                background-color: #ffffff;
              }
              &:hover {
                background-color: inherit;
              }
            }
          }
          &__header {
            padding: 6px 16px;
            text-align: left;
            background-color: #ffffff;
            position: relative;

            &-container {
              display: flex;
              justify-content: center;
              align-items: center;
              overflow: hidden;
              text-overflow: ellipsis;
            }
            &-text {
              white-space: nowrap;
            }
            .ca-button-icon {
              flex-grow: 0;
              flex-shrink: 0;
              flex-basis: auto;
            }
          }
          &__cell {
            cursor: pointer;
            height: 32px;
            position: relative;
            padding: 0 16px;
            vertical-align: middle;
            max-width: 90px;
            &-container {
              overflow: hidden;
              text-overflow: ellipsis;
            }
            &-text {
              white-space: nowrap;
            }
          }
        }

        .cdk-drag-preview {
          font-family: Lato;
          font-size: 14px;
          color: #717578;
          font-weight: bold;
          display: flex;
          align-items: center;
        }

        .cdk-drag-placeholder {
          opacity: 0;
          cursor: e-resize;
        }

        .cdk-virtual-scroll-viewport {
          .cdk-virtual-scroll-content-wrapper {
            position: relative;
            overflow-x: scroll;
          }
        }

        .cdk-overlay-backdrop.cdk-overlay-backdrop-showing {
          &.dark-backdrop {
            background: rgba(83, 87, 90, 0.4);
          }
        }

        .cdk-overlay-container {
          z-index: 9999;
        }`
    }
};

caseTwo: ComponentDoc = {
  title: 'Ejemplo de uso',
  description: `<p>Ejemplo de uso de formulario complejo en aplicaciones Caser</p>`,
  codeExample: {
      html: `<form [formGroup]="formBlur" class="row">
      <ca-form-field class="col-3">
          <ca-label>Nombre</ca-label>
          <input
            caInput
            formControlName="name"
            placeholder="Nombre"
            type="text"
            required />
          <ca-hint>Introduce tu nombre</ca-hint>
          <ca-error *ngIf="formBlur.controls['name'].errors?.required">El campo es requerido</ca-error>
      </ca-form-field>
      <ca-form-field class="col-3">
          <ca-label>Apellido</ca-label>
          <input
            caInput
            formControlName="surName"
            placeholder="Apellido"
            type="text"
            required />
          <ca-hint>Introduce tu apellido</ca-hint>
          <ca-error *ngIf="formBlur.controls['surName'].errors?.required">El campo es requerido</ca-error>
      </ca-form-field>
      <ca-form-field class="col-4">
          <ca-label>Email</ca-label>
          <input
            caInput
            formControlName="email"
            placeholder="Email"
            type="text"
            required />
          <ca-hint>Introduce tu dirección de correo</ca-hint>
          <ca-error *ngIf="formBlur.controls['email'].errors?.required">El campo es requerido</ca-error>
          <ca-error *ngIf="formBlur.controls['email'].errors?.minlength">El campo debe tener 6 caracteres</ca-error>
          <ca-error *ngIf="formBlur.controls['email'].errors?.email">Introduce una dirección de correo valida</ca-error>
      </ca-form-field>
      <ca-form-field class="col-2">
          <ca-label>Fecha de nacimiento</ca-label>
          <ca-datepicker
              formControlName="birthday"
              name="datepicker"
              required
          ></ca-datepicker>
          <ca-error *ngIf="formBlur.controls['birthday'].errors?.required">El campo es requerido</ca-error>
      </ca-form-field>
      <ca-form-field class="col-3 mt-5">
          <ca-label>Género (Simple)</ca-label>
          <ca-select
              placeholder="Género"
              keyValue="textValue"
              formControlName="genderControl"
              [options]="formOptions"
              required
          ></ca-select>
          <ca-error *ngIf="formBlur.controls['genderControl'].errors?.required">El campo es requerido</ca-error>
      </ca-form-field>
      <ca-form-field class="col-3 mt-5">
          <ca-label>Opciones multiples</ca-label>
          <ca-select
              placeholder="Opciones multiples"
              formControlName="multiple"
              [options]="arrayOptions"
              required
              multiple
              virtualScroll
          ></ca-select>
          <ca-error *ngIf="formBlur.controls['multiple'].errors?.required">El campo es requerido</ca-error>
      </ca-form-field>
      <ca-form-field class="col-4 mt-5">
          <ca-label>Descripción</ca-label>
          <textarea
            caTextarea
            formControlName="controlTextarea"
            placeholder="Inserte aquí una descripción"
            required
          ></textarea>
          <ca-hint>Introduce una descripción de cómo mínimo 20 carácteres</ca-hint>
          <ca-error *ngIf="formBlur.controls['controlTextarea'].errors?.required">El campo es requerido</ca-error>
          <ca-error *ngIf="formBlur.controls['controlTextarea'].errors?.minlength">El campo debe tener 20 caracteres como mínimo</ca-error>
      </ca-form-field>
      <div class="col-2 mt-5">
          <ca-label>RadioButton</ca-label>
          <ca-radio-group
          id="react"
          name="reactive"
          formControlName="favoriteFramework"
          required>
              <ca-radio-button
                  *ngFor="let item of frameworks"
                  [value]="item">
                  {{item}}
              </ca-radio-button>
      </ca-radio-group>
      </div>
      <ca-checkbox
          class="col-6 mt-5"
          formControlName="controlOne">
          Acepto política de privacidad de datos
      </ca-checkbox>
      <div class="col-6 mt-5 text-right">
          <button ca-button-secondary>Otras acciones</button>
          <button class="ml-2" ca-button-secondary (click)="cleanFilter()">Limpiar</button>
          <button class="ml-2"
              type="submit"
              [disabled]="formBlur.invalid || formBlur.controls['controlOne'].value === false"
              ca-button>
                  Buscar
              </button>
      </div>
  </form>`
  }
};

caseFour: ComponentDoc = {
  title: 'Ejemplo de uso',
  description: `<p>Ejemplo de uso de botones en aplicaciones Caser</p>`,
  codeExample: {
      html: `
      <div class="row">
          <div class="col-6">
              <button ca-button-secondary>Volver</button>
          </div>
          <div class="col-6 text-right">
              <button class="ml-2" ca-button-secondary>Exportar</button>
              <button class="ml-2" ca-button>Guardar</button>
          </div>
      </div>

      <div class="row mt-5">
      <div class="col-6">
          <button ca-button-secondary>Volver</button>
      </div>
      <div class="col-6 text-right">
          <ca-form-field class="select ca-group-action">
              <ca-select placeholder="Seleccione una acción"
                [options]="actionsToSelect"
                [(ngModel)]="actionSelected"
                (ngModelChange)="onSelectedOption(selectedRow)">
              </ca-select>
          </ca-form-field>
          <button class="ml-2" ca-button>Guardar</button>
      </div>
  </div>

  `
  }
};

caseFive: ComponentDoc = {
  title: 'Ejemplo de uso',
  description: `<p>Ejemplo de uso de breadcrumb en aplicaciones Caser</p>`,
  codeExample: {
      html: `
      <ca-breadcrumb>
          <li
          ca-breadcrumb-item
          *ngFor="let item of dataBreadcrumb"
          >
              <a
              routerLink="{{item.url}}"
              routerLinkActive="ca-router-link-active"
              [routerLinkActiveOptions]="{exact:true}">
              {{item.label}}
              </a>
              <span class="material-icons">keyboard_arrow_right</span>
          </li>
      </ca-breadcrumb>
  `
  }
};

caseSix: ComponentDoc = {
  title: 'Ejemplo de uso',
  description: `<p>Ejemplo de uso de breadcrumb en aplicaciones Caser</p>`,
  codeExample: {
      html: `

      // Vista
      <div class="text-right">
          <button (click)="onCreateOption()" ca-button>Abrir modal</button>
      </div>
      <rcb-modal-tratamiento-plantillas *ngIf="true" [data]="selectedRow"></rcb-modal-tratamiento-plantillas>

      // Componente Modal
      <form [formGroup]="formTratamientoPlantillasModal" class="row">
        <div class="col-4">
            <ca-form-field class="col-12 p-0">
                <ca-label>ID Plantilla</ca-label>
                <input caInput
                formControlName="idPlantilla"
                placeholder="ID Plantillas"
                type="number"
                required />
                <ca-error *ngIf="formTratamientoPlantillasModal.controls['idPlantilla'].errors?.required">El campo es requerido</ca-error>
            </ca-form-field>
            <div class="col-12 mt-5 p-0">
                <ca-label>Tipo plantilla</ca-label>
                <ca-radio-group
                id="react"
                name="reactive"
                formControlName="tipoPlantilla"
                required>
                    <ca-radio-button
                        *ngFor="let item of tiposPlantilla"
                        [value]="item">
                        {{item}}
                    </ca-radio-button>
                </ca-radio-group>
            </div>
        </div>
        <div class="col-8">
            <ca-form-field class="col-12">
                <ca-label>Descripción</ca-label>
                <textarea
                  caTextarea
                  formControlName="descripcion"
                    placeholder="Descripción"
                    required
                ></textarea>
                <ca-error *ngIf="formTratamientoPlantillasModal.controls['descripcion'].errors?.required">El campo es requerido</ca-error>
            </ca-form-field>
            <ca-form-field class="col-4 mt-5">
                <ca-label>Nombre fichero</ca-label>
                <input caInput
                formControlName="nombreFichero"
                placeholder="Nombre fichero"
                type="text"
                required />
                <ca-error *ngIf="formTratamientoPlantillasModal.controls['nombreFichero'].errors?.required">El campo es requerido</ca-error>
            </ca-form-field>
            <ca-form-field class="col-8 mt-5">
                <ca-label>Ruta plantilla</ca-label>
                <input caInput
                formControlName="rutaPlantilla"
                placeholder="Ruta plantilla"
                type="number"
                required />
                <ca-error *ngIf="formTratamientoPlantillasModal.controls['rutaPlantilla'].errors?.required">El campo es requerido</ca-error>
            </ca-form-field>
        </div>
        <div class="col-6 mt-5">
            <p class="ca-form-field__message">* Todos los campos son obligatorios</p>
        </div>
        <div class="col-6 mt-5 text-right">
            <button ca-button-secondary (click)="closeDialog()">Cancelar</button>
            <button (click)="closeDialog(formTratamientoPlantillasModal)" class="ml-2" type="submit" ca-button [disabled]="formTratamientoPlantillasModal.invalid">Aceptar</button>
        </div>
    </form>
  `
  }
};

    private _sortChanges$: BehaviorSubject<SortConfig> = new BehaviorSubject(undefined);

    get countries() {
      return this.tableData.map((country, i) => ({ id: i + 1, ...country })).slice(
        (this.page - 1) * this.pageSize,
        (this.page - 1) * this.pageSize + this.pageSize
      );
    }

    constructor(private formBuilder: FormBuilder,
      private _filterPipe: CaFilterPipe,
      private _sortByPipe: CaSortByPipe,
      private _modalService: CaModalOverlayService) {}

    public formBlur: FormGroup;

    private _formBlurBuilder(): void {
      this.formBlur = this.formBuilder.group({
        name: ['', [Validators.required]],
        surName: ['', [Validators.required]],
        email: ['', [Validators.required, Validators.email, Validators.minLength(6)]],
        genderControl: '',
        birthday: '',
        multiple: [],
        favoriteFramework: '',
        controlTextarea:  ['', [Validators.required, Validators.minLength(20)]],
        controlOne: [false, [Validators.required]],
      });
    }

  onFilter(query: string): void {
      this._filterChange$.next(query);
  }

  private _setDisplayedColumns(): void {
      this.displayedColumns = this.columns.map((column) => column.field);
  }

  isSelectedRow(row): boolean {
      return this.selectedRow && Object.keys(this.selectedRow).every((key) => this.selectedRow[key] === row[key]);
  }

  onSelectedRow(row: any): void {
      if (!this.isSelectedRow(row)) {
          this.selectedRow = row;
      }
  }

  // Modal acciones
  onSelectedOption(row?: any, i?: number): void {
      switch (this.actionSelected) {
          case 'Descargar':
              console.log('Descargar');
              break;
          case 'Modificar':
              console.log('Modificar');
              break;
          case 'Eliminar':
              console.log('Eliminar');
              break;
          default:
              break;
      }
  }

  sortColumn(column: TableColumn): void {
    this._sortChanges$.next({
      field: column.field,
      isAsc: column.sortAsc = !column.sortAsc
    });
  }

  paginate(): void {
    this.paginatedTableData = this.tableData?.slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }

  tableDrop(event: CdkDragDrop<string[]>): void {
    moveItemInArray(this.displayedColumns, event.previousIndex, event.currentIndex)
  }

    ngOnInit(): void {
      this._formBlurBuilder();
      this._setDisplayedColumns();
      this._filterChange$.pipe(takeUntil(this._destroy$),debounceTime(200)).subscribe((value) => {
        this.displayedTableData = this._filterPipe.transform(this.tableData, value);
      });
      this.paginatedTableData= this.tableData;
      this.dataSize = this.paginatedTableData.length;
      this.paginate();

    }

    onCreateOption() {
      let newItem = {
          idPlantilla: null,
          tipoPlantilla: '',
          nombreFichero: '',
          descripcion: null,
          rutaPlantilla: null,
          idPlantill2: null,
          tipoPlantilla2: '',
          nombreFichero2: '',
          descripcion2: null,
          rutaPlantilla2: null,
          idPlantilla3: null,
          tipoPlantilla3: '',
          nombreFichero3: '',
          descripcion3: null
      }
      this._modalService.open(ModalComponent, {
          title: 'Crear',
          data: {
              index: null,
              row: newItem
          }
      });
      // this.tableData.push(newItem);;
  }

    toggleAccordion(): void {
        this.toggAcFilter = !this.toggAcFilter;
        if (this.toggAcFilter) {
            this.iconTextAccordion = 'keyboard_arrow_up';
        } else {
            this.iconTextAccordion = 'keyboard_arrow_down';
        }
    }

    cleanFilter(formDirective: FormGroupDirective) {
      this.formBlur.reset();
      this.formBlur.markAsPristine();
      this.formBlur.markAsUntouched();
        console.log(formDirective);

    }

    ngOnDestroy() {
      this._destroy$.next();
      this._destroy$.complete();
  }

  onChangeTab(event) {
    console.log(event);
  }

}


interface TableColumn {
  id: number;
  field: string;
  value: string;
  align?: string;
  sortAsc?: boolean;
}
