import { Component, Input, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CaModalOverlayRef } from '@global-front-components/ui';

@Component({
	templateUrl: './modal-action.view.html',
	styleUrls: ['./modal-action.view.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ModalComponent {
    constructor(
        private _modalRef: CaModalOverlayRef<ModalComponent>,
        private formBuilder: FormBuilder
        ) {}
    text = '';
    @Input() data: any;

    tiposPlantilla = ['Carta', 'SMS', 'Email', 'FTP'];ç

    public formTratamientoPlantillasModal: FormGroup;
  
    getInfo(info: string): void {
      this.text = info;
      console.log(this.data);
    }

    private _formBlurBuilder(): void {
        this.formTratamientoPlantillasModal = this.formBuilder.group({
            idPlantilla: [this.data.row.idPlantilla, [Validators.required]],
            descripcion: [this.data.row.descripcion, [Validators.required]],
            tipoPlantilla: [this.data.row.tipoPlantilla, [Validators.required]],
            rutaPlantilla: [this.data.row.rutaPlantilla, [Validators.required]],
            nombreFichero: [this.data.row.nombreFichero, [Validators.required]]
        });
    }

    ngOnInit() {
        console.log(this.data);
        this._formBlurBuilder();
    }
  
    closeDialog(data?: any): void {
      if (data) {
        this.data.row.idPlantilla = this.formTratamientoPlantillasModal.controls.idPlantilla.value;
        this.data.row.descripcion = this.formTratamientoPlantillasModal.controls.descripcion.value;
        this.data.row.tipoPlantilla = this.formTratamientoPlantillasModal.controls.tipoPlantilla.value;
        this.data.row.rutaPlantilla = this.formTratamientoPlantillasModal.controls.rutaPlantilla.value;
        this.data.row.nombreFichero = this.formTratamientoPlantillasModal.controls.nombreFichero.value;
        this._modalRef.close(this.data);
      } else {
        this._modalRef.close();
      }
    }
}