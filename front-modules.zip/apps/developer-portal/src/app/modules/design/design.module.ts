import { CdkTableModule } from '@angular/cdk/table';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CaResizableTableModule, CaResizeColumnModule } from '@global-front-components/common';
import {
  CaAccordionModule,
  CaBreadcrumbModule,
  CaButtonModule,
  CaCardModule,
  CaCheckboxModule,
  CaDatepickerModule,
  CaFormFieldModule, CaInputModule, CaModalOverlayModule,
  CaModalOverlayService,
  CaPaginationModule,
  CaRadioButtonModule,
  CaSelectModule,
  CaSidebarModule,
  CaTabsModule,
  CaTextareaModule
} from '@global-front-components/ui';
import { ComponentDocModule } from '../../components/component-doc/component-doc.module';
import { ComponentViewerComponent } from '../../components/component-viewer/component-viewer.component';
import { DownloadComponent } from '../../components/download/download.component';
import { ComposeView } from './compose-view/compose.view';
import { ModalComponent } from './compose-view/modal-action/modal-action.view';
import { DesignRoutingModule } from './design-routing.module';
import { DesignView } from './design.view';
import { ResourcesComponent } from './resources/resources.component';
import { UseGuideComponent } from './use-guide/use-guide.component';
import { Vieweromponent } from './viewer/viewer.component';
@NgModule({
	imports: [
		CommonModule,
		HttpClientModule,
		DesignRoutingModule,
		CaSidebarModule,
		CaAccordionModule,
		ReactiveFormsModule,
		FormsModule,
		CaFormFieldModule,
		CaInputModule,
		CaButtonModule,
		CaBreadcrumbModule,
		CaSelectModule,
		CaDatepickerModule,
		CaRadioButtonModule,
		CaTextareaModule,
		CaCheckboxModule,
		CdkTableModule,
		CaPaginationModule,
		CaTabsModule,
		CaCardModule,
		CaResizableTableModule,
		CaResizeColumnModule,
		CaPaginationModule,
		CaModalOverlayModule,
		ComponentDocModule
	],
	declarations: [
		UseGuideComponent,
		Vieweromponent,
		ComponentViewerComponent,
		DownloadComponent,
		ResourcesComponent,
		DesignView,
		ComposeView,
		ModalComponent
	],
	providers: [CaModalOverlayService]
})
export class DesignModule {}
