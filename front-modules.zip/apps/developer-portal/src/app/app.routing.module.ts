import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IntroComponent } from './modules/principles/intro/intro.component';

const routes: Routes = [
	{
		path: '',
		redirectTo: 'principles/intro',
		pathMatch: 'full'
	},
	{
		path: 'principles',
		loadChildren: () => import('./modules/principles/principles.module').then((m) => m.PrinciplesModule)
	},
	{
		path: 'design',
		loadChildren: () => import('./modules/design/design.module').then((m) => m.DesignModule)
	},
	{
		path: 'develop',
		loadChildren: () => import('./modules/develop/develop.module').then((m) => m.DevelopModule)
	},
	{
		path: 'documentation',
		loadChildren: () => import('./modules/documentation/documentation.module').then((m) => m.DocumentationModule)
	}
];

@NgModule({
	imports: [RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled' })],
	exports: [RouterModule]
})
export class AppRoutingModule {}
