import { Component, Input } from '@angular/core';

@Component({
	selector: 'ca-news-item',
	templateUrl: './news-item.component.html',
	styleUrls: ['./news-item.component.scss']
})
export class NewsItemComponent {
	@Input() data: {
		image: string;
        title: string;
        text: string;
        date: string;
	} = {
        image: "https://picsum.photos/265/179",
        title: "13.4 - 15/10/2020",
        text: "Descubre los últimos cambios que hemos añadido a la librería de componentes.",
        date: "02/10/2020"
    };
}
