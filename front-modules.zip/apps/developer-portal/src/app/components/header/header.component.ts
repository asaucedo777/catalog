import { DOCUMENT } from '@angular/common';
import { Component, EventEmitter, Output, Input, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';

@Component({
	selector: 'ca-page-header',
	templateUrl: './header.component.html',
	styleUrls: ['./header.component.scss']
})
export class PageHeaderComponent implements OnInit{
	constructor(
    @Inject(DOCUMENT) private readonly documentRef: Document,
    private router: Router) {}
  themeTitle ='Tema Base';

	@Input() open = false;
	@Output() changeStatusMenu = new EventEmitter<boolean>();

	public toggleMenu(): void {
		this.open = !this.open;
		this.changeStatusMenu.emit(this.open);
	}

	public goTo(target: string) {
		switch (target) {
			case 'home':
				this.router.navigateByUrl('/');
				break;
			case 'principles':
				this.router.navigateByUrl('/principles/intro');
				break;
			case 'design':
				this.router.navigateByUrl('/design');
				break;
			case 'develop':
				this.router.navigateByUrl('/develop/atoms/button');
				break;
			case 'docu':
				this.router.navigateByUrl('/documentation/fundamentals/nodenv');
				break;

			default:
				break;
		}
	}

  private _switchThemeTitle(url): void {
    switch (url) {
      case '/assets/themes/umbrela.min.css':
        this.themeTitle = 'Umbrela (en desarrollo)';
        break;
	case '/assets/themes//base-small-theme.min.css':
			this.themeTitle = 'Small Theme (en desarrollo)';
			break;
      case '/assets/themes/base-theme.min.css':
        default:
        this.themeTitle = 'Tema Base';
        break;

    }
  }

  changeTheme(url: string): void {
    localStorage.setItem('theme-url',url);
    this._switchThemeTitle(url);
    this.documentRef.head.querySelector('.theme-stylesheet').setAttribute('href',url);
  }

  ngOnInit() {
    if(localStorage.getItem('theme-url')) {
      this.documentRef.head.querySelector('.theme-stylesheet').setAttribute('href',localStorage.getItem('theme-url'));
      this._switchThemeTitle(localStorage.getItem('theme-url'))
    }
  }
}
