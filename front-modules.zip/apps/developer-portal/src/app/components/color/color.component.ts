import { Component, Input } from '@angular/core';
import { Color } from '../../models/color.interface';

@Component({
	selector: 'ca-color',
	templateUrl: './color.component.html',
	styleUrls: ['./color.component.scss']
})
export class ColorComponent {
	constructor() {}
    @Input() color: Color;
	// ngAfterViewInit(){
	// 	document.getElementById('color').style.backgroundColor = this.color.code;
	// }
}
