import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ComponentDocComponent } from './component-doc.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ClipboardModule } from '@angular/cdk/clipboard';
import { CaTooltipModule } from '@global-front-components/ui';

@NgModule({
  declarations: [ComponentDocComponent],
  imports: [
    CaTooltipModule,
    ClipboardModule,
    CommonModule,
    NgbModule
  ],
  exports: [ ComponentDocComponent ]
})
export class ComponentDocModule { }
