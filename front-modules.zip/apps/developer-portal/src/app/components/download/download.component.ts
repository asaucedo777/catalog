import { Component } from '@angular/core';

@Component({
	selector: 'ca-download',
	templateUrl: './download.component.html',
	styleUrls: ['./download.component.scss']
})
export class DownloadComponent {
	constructor() {
    }

}
