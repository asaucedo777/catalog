import { DOCUMENT } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { fromEvent } from 'rxjs';
import { distinctUntilChanged, filter, map, pairwise, throttleTime } from 'rxjs/operators';

const THRESHOLD = 500;
@Component({
	selector: 'ca-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent{

	constructor(
		private router: Router) {}

	isDocView(): boolean{
		// console.log(this.router.url.startsWith("/documentation"));
		return this.router.url.startsWith("/documentation");
	}

}

